"""`revl deploy` — attested admission, correlated seams, coordinated rollback
(roadmap item 118, Slice 1 + Slice 2a).

The design (docs/design/118-revl-deploy.md) leads with a finding that reshapes
everything built here: **the LIFO rollback theorem `apply` proves is an
IN-PROCESS property and it does not cross a seam.** A peer process's inverses
live in that process's memory and its own durable WAL; the conducting process
holds neither. So nothing in this module lifts `apply.py`'s theorem across a
boundary. What crosses is a *protocol*, and the honest verdict vocabulary that
comes with it.

Slice 1 is the cut that is landable on today's tree: every seam is a LOCAL
process seam (a UDS bridge, item 56's transport reused unchanged), so the
control plane a cross-machine deploy would need — a replicated WAL, a quorum
coordinator, a remote runner — is deliberately absent (Slice 2b+).
What Slice 1 does build, in the four pieces the design names:

1. **the attestation chain, verified at admission** (§2). `chain_bindings`
   folds the per-facet sha256 of the artifact bytes, the capability policy, the
   component lock, the gauntlet evidence and the per-backend conformance cert
   into item 127's signed `evidence_bindings` (item 290's hook), so one
   signature commits `source -> IR -> artifact -> policy -> evidence`.
   :func:`admit` verifies it on the RECEIVING side, against a local
   :class:`TrustStore`.

   The binding rule that makes this worth anything (Addendum 3a): the receiver
   **re-hashes the IR and the artifact bytes it will actually execute** and
   never trusts a self-declared `backend`/`artifact_hash` in the attestation.
   The signed chain is checked against the bytes in hand, not the bytes the
   sender claims about itself. :data:`SELF_DECLARED_IGNORED` names the members
   admission structurally refuses to read.

2. **effect-correlation identity on every seam crossing** (§1.4). A
   :class:`Correlation` envelope — `{composition_id, generation, realm,
   effect_id, idempotency_key, parent_effect}` plus the peer's identity — rides
   the existing JSON-line request. The binding rule (Addendum 3b): the envelope
   is **authenticated against the peer identity**, and duplicate detection is
   scoped on `(peer_identity, composition_id, generation, idempotency_key)`, so
   a peer cannot forge another peer's identity or replay its envelope.
   :class:`CorrelationGuard` is what `bridge.serve` runs before dispatch.

   A **network** seam cannot carry the SEALING half: the per-process secret is
   minted per boot by one conductor and a cross-composition peer runs under
   another, so demanding a sealed envelope there refuses the legitimate caller.
   What mTLS *does* give is a proven peer identity, and what was missing was a
   closed set to check it against — :class:`PeerAllowlist` (§1.4b). It also
   gives the dedup scope for free: the identity a replay check keys on is the
   one the handshake proved, so :class:`TransportReplayGuard` refuses a replay
   there with no shared secret at all. The achieved level is recorded per seam
   as :class:`SeamAdmission` (`sealed` / `peer-bound` / `peer-pinned` /
   `unverified`), because a weaker property under the same name would be the
   lie this module is written not to tell.

3. **coordinated cross-process rollback** (§3). :func:`run_deploy` drives a
   two-phase PREPARE/COMMIT over :class:`Participant`s that are *other
   processes*. The coordinator holds an ordered **commit ledger** — who
   committed, and when — and NOTHING ELSE. It never holds an inverse and never
   runs one. On a COMMIT failure it drives ABORT in reverse ledger order and
   each participant runs its OWN local LIFO unwind, in its own process, against
   its own accumulator and WAL. A participant it cannot reach is reported
   `unresolved(...)`, never `rolled-back`. That distinction — a coordinated
   protocol over per-process-atomic units versus one lifted theorem — is the
   whole content of the first CRITICAL.

4. **all-or-nothing federation update across co-located compositions**
   (Addendum 2, the second CRITICAL). No composition may cross an irreversible
   effect until a durable `federation-commit-approved` record exists. PREPARE
   holds every irreversible crossing as an item-245 class-(b) deferred
   emission, so a plan that NECESSARILY crosses a non-deferrable irreversible
   effect is REFUSED admission (:func:`federation_admission`) rather than
   silently degrading atomicity. A stranded participant applies
   `recovery.py`'s existing rule VERBATIM — record present, roll forward;
   absent, roll back — and fails closed on a guess (:func:`settle_stranded`).

**Slice 2a** (§5) adds the written form of a deploy and the plan-time
admission of it. Slice 1 had no way to WRITE a deploy down — the caller built
`Participant`s in Python — and so no way to refuse one before things started
being spawned. §5 reads the item-56 placement map's new per-process `[deploy]`
table, and admits it against the one question that decides what a deploy can
promise: **which boundary does this target sit behind?** `process` (Slice 1's
own child), `container` (a separate namespace set on this machine), or
`machine` (a different kernel). :data:`TEARDOWN_PROMISE` answers what teardown
is worth across each, because G7 is LIFO-complete over the *registered* entries
of an accumulator and each boundary changes which set outlives the failure.
Only the first two are opened here: a `machine` boundary is REFUSED, not
best-efforted. §5b then puts a real participant behind a container boundary
(:func:`launch_container_participant`), reusing item 411's container driver and
speaking the same stdio control channel — because the protocol in §3 never held
an inverse, it does not care what kind of boundary the other end is behind.

Deliberately NOT here, and named so the boundary is explicit: cross-machine
orchestration (bundle staging, a remote `deploy-admit` runner, a load-measured
signed COMMIT receipt, a pinned SSH host key), a replicated WAL, a quorum
coordinator, and the Ed25519 upgrade to `attest.py`. The last one is a HARD prerequisite for
a cross-trust-domain deploy (§2.4/§5-A1): a symmetric HMAC verifier is also a
forger, so "signer untrusted" would be a fiction. Slice 1 is single-host, where
signer and host are the same trust domain, so HMAC is honest here — and
:func:`admit` REFUSES outright when a :class:`TrustStore` declares itself
`cross_domain` under a symmetric algorithm, rather than pretending.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import shutil
import subprocess
import sys
import time
from collections import OrderedDict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping, Optional, Sequence

from . import attest
from .errors import RevlError

# ---------------------------------------------------------------------------
# §2. the attestation chain
# ---------------------------------------------------------------------------

#: Bundle-relative locations of every facet the chain binds (item 305's layout).
IR_DOCUMENT = "ir/ir.json"
EMITTED_ROOT = "emitted"
#: the bundled `.rvl` sources and the bundle's own manifest — the two the signer
#: re-runs the frontend over, so an attestation is signed over a composition
#: this toolchain admitted rather than over an IR document someone handed it.
SOURCE_ROOT = "source"
RUNTIME_MANIFEST = "runtime-manifest.json"
POLICY_NAME = "policy.json"
LOCK_NAME = "components.lock"
GAUNTLET_NAME = "gauntlet.json"
ATTESTATION_NAME = "attestation.json"
#: item 306's per-backend conformance certs, staged as `conformance/<backend>.json`.
CONFORMANCE_ROOT = "conformance"

#: The facet keys inside `evidence_bindings`. `artifact/<backend>` and
#: `conformance/<backend>` are per-backend; the rest are whole-bundle.
FACET_POLICY = "policy"
FACET_LOCK = "lock"
FACET_GAUNTLET = "gauntlet"

#: The one item-31 gauntlet verdict that is evidence of admissibility, and the
#: dossier member naming the composition the dossier was graded over. Both are
#: `bundle.py`'s spellings, re-stated here so admission never imports the
#: bundler (the receiver has a bundle, not a build).
GAUNTLET_ADMISSIBLE = "admissible"
GAUNTLET_IDENTITY = "compositionHash"


def artifact_facet(backend: str) -> str:
    """The `evidence_bindings` key binding one backend's emitted artifact."""
    return f"artifact/{backend}"


def conformance_facet(backend: str) -> str:
    """The `evidence_bindings` key binding one backend's item-306 cert."""
    return f"conformance/{backend}"


#: Members a sender may *write into* an attestation to describe the artifact it
#: claims to have emitted. Admission NEVER reads them: the chain is checked
#: against the bytes in hand (Addendum 3a). Named as data so the refusal to
#: trust them is a stated property and a test can pin it.
#:
#: `sign_alg` is deliberately NOT on this list and never was — but it also is no
#: longer self-declared in any meaningful sense: `attest.verify_attestation`
#: refuses any value but `attest.SIGN_ALG`, and admission's cross-domain refusal
#: reads the algorithm off THIS build rather than off the record.
SELF_DECLARED_IGNORED = ("backend", "artifact_hash", "artifact_sha256",
                         "emitted_hash", "ir_hash")


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _file_digest(path: Path) -> str:
    return _sha256_bytes(path.read_bytes())


def _artifact_files(root: Path) -> list[Path]:
    """Every REGULAR file under `root`, walked without following a single link.

    `rglob` plus `p.is_file()` followed symlinks, so a link inside
    `emitted/<backend>/` bound bytes that live OUTSIDE the bundle and stay
    writable after the signature is taken: the digest covered a path the bundle
    does not own (roadmap 428 F11). A tree digest is only a statement about the
    bundle if every byte it folds is IN the bundle, so a link is refused rather
    than resolved. The same refusal covers a fifo, socket or device node, whose
    "bytes" are not bytes the receiver can re-read and get the same answer.
    """
    if root.is_symlink():
        raise RevlError(str(root), 0,
                        "the emitted artifact directory is a symlink; a digest "
                        "over it would bind bytes the bundle does not contain")
    found: list[Path] = []
    stack = [root]
    while stack:
        for entry in sorted(stack.pop().iterdir()):
            if entry.is_symlink():
                raise RevlError(
                    str(entry), 0,
                    "the emitted artifact tree contains a symlink, so the "
                    "bytes it binds live outside the bundle and stay writable "
                    "after the signature is taken; it is refused rather than "
                    "followed")
            if entry.is_dir():
                stack.append(entry)
            elif entry.is_file():
                found.append(entry)
            else:
                raise RevlError(
                    str(entry), 0,
                    "the emitted artifact tree contains an entry that is not a "
                    "regular file, so it has no stable bytes to bind")
    return sorted(found)


def artifact_digest(backend_dir: Path | str) -> str:
    """The digest of one backend's emitted artifact — a *tree* digest, since a
    backend may emit several files (the wasm emitter emits one `.wat` per
    module).

    Canonical by construction: the relative path of each file and its bytes are
    folded in sorted-path order with explicit length framing, so no rename or
    split of the emitted set can collide with another. This is the value the
    signer binds and the value the receiver RE-COMPUTES from the bytes it is
    about to execute.

    Two things it REFUSES rather than digests, both `RevlError` (428 F11):

      * a symlink anywhere in the tree, or a `backend_dir` that is itself one —
        the bytes would live outside the bundle and stay writable after
        signing, so the digest would not be a statement about the bundle;
      * an EMPTY tree — it folds nothing and yields `sha256(b"")`, a value
        anyone can produce without holding any artifact at all. An artifact of
        no bytes is not an artifact, and admitting one means admitting a bundle
        with nothing to execute on the strength of a matching hash.
    """
    root = Path(backend_dir)
    files = _artifact_files(root)
    if not files:
        raise RevlError(
            str(root), 0,
            "the emitted artifact directory is empty, so its tree digest is "
            f"sha256 of nothing ({_sha256_bytes(b'')[:12]}…) — a value that "
            "matches without any artifact being present. An empty artifact is "
            "refused, never digested")
    digest = hashlib.sha256()
    for path in files:
        rel = path.relative_to(root).as_posix().encode("utf-8")
        data = path.read_bytes()
        digest.update(len(rel).to_bytes(8, "big"))
        digest.update(rel)
        digest.update(len(data).to_bytes(8, "big"))
        digest.update(data)
    return digest.hexdigest()


def chain_bindings(bundle_dir: Path | str, *,
                   backends: Optional[Iterable[str]] = None) -> dict:
    """Collect every link of the chain as a per-facet sha256, ready to fold into
    item 127's signed `evidence_bindings`.

    A facet whose file the bundle does not carry is simply absent from the
    bindings. An `emitted/<backend>/` that EXISTS but holds no bytes, or that
    reaches outside the bundle through a link, is not an absent facet: it is a
    bundle that cannot be honestly signed, and :func:`artifact_digest` raises
    rather than binding it (roadmap 428 F11).

    Nothing here is re-derived: `bundle.py` already wrote `components.lock`,
    `policy.json`, `emitted/<backend>/...` and `gauntlet.json`, and
    `conformance_cert.py` already wrote the per-backend cert. This hashes those
    bytes so ONE signature commits the whole chain (§2.1). A facet the bundle
    does not carry is simply absent from the bindings — and an absent binding is
    what makes :func:`admit` refuse with `backend` when the host's own backend
    has no `artifact/<backend>` link.
    """
    root = Path(bundle_dir)
    bindings: dict[str, str] = {}
    for facet, name in ((FACET_POLICY, POLICY_NAME),
                        (FACET_LOCK, LOCK_NAME),
                        (FACET_GAUNTLET, GAUNTLET_NAME)):
        path = root / name
        if path.is_file():
            bindings[facet] = _file_digest(path)
    emitted = root / EMITTED_ROOT
    names = sorted(backends) if backends is not None else sorted(
        p.name for p in emitted.iterdir() if p.is_dir()) if emitted.is_dir() else []
    for backend in names:
        backend_dir = emitted / backend
        if backend_dir.is_dir():
            bindings[artifact_facet(backend)] = artifact_digest(backend_dir)
        cert = root / CONFORMANCE_ROOT / f"{backend}.json"
        if cert.is_file():
            bindings[conformance_facet(backend)] = _file_digest(cert)
    return bindings


def staged_ir(bundle_dir: Path | str) -> dict:
    """The IR document as it exists ON THE RECEIVER's disk.

    Read here, and only here, so every hash admission compares comes from the
    staged bytes rather than from anything the sender asserted about them.
    """
    path = Path(bundle_dir) / IR_DOCUMENT
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError, UnicodeDecodeError) as error:
        raise RevlError(str(path), 0,
                        f"cannot read the staged IR document: {error}") from error


def capability_surface(ir: Mapping) -> tuple[set[str], dict]:
    """The capability labels a composition reaches, DERIVED FROM THE IR.

    This is the same derivation `bundle.build_bundle` runs to *write*
    `policy.json` (`_policy_of(_audit_document(ir))`, itself G4's own boundary
    analysis over the IR), so `policy.json` is a projection of this value and
    never the other way round.

    Admission needs the value, not the projection. `ir/ir.json` is the only
    capability authority a receiver has that the deploying side cannot move:
    admission has already re-derived its `composition_hash` from the staged
    bytes and checked it against the SIGNED one, so an IR whose boundary
    analysis reaches fewer capabilities is a different composition and refuses
    at :data:`LINK_COMPOSITION` before the ceiling is ever consulted. It is also
    the document every emitter emits from, so the capability set it yields is
    the set the artifact in hand can actually reach.

    Returns `(capability labels, the full derived policy surface)`. Raises
    :class:`RevlError` when the surface cannot be derived: the ceiling has no
    honest answer then, and its caller refuses.
    """
    import copy  # noqa: PLC0415 (lazy, with the two below)

    from .bundle import _policy_of          # noqa: PLC0415 (avoids a cycle)
    from .registry import _audit_document   # noqa: PLC0415

    try:
        surface = _policy_of(_audit_document(copy.deepcopy(dict(ir))))
    except Exception as error:              # noqa: BLE001 (any failure refuses)
        raise RevlError(IR_DOCUMENT, 0,
                        "cannot derive the capability surface from the staged "
                        f"IR: {type(error).__name__}: {error}") from error
    labels = surface.get("capabilities")
    if not isinstance(labels, (list, tuple, set, frozenset)):
        raise RevlError(IR_DOCUMENT, 0,
                        "the capability surface derived from the staged IR has "
                        f"no readable `capabilities` member (got {labels!r})")
    return {str(label) for label in labels}, surface


def staged_sources(bundle_dir: Path | str) -> list[str]:
    """The bundle's `.rvl` sources, in the order the bundle recorded them.

    Order matters: `compile_files` composes the files in the order given, so the
    recompile must use the recorded order to reproduce the staged IR. Falls back
    to sorted basenames for a bundle with no readable manifest.
    """
    root = Path(bundle_dir)
    names: list = []
    manifest_path = root / RUNTIME_MANIFEST
    if manifest_path.is_file():
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError, UnicodeDecodeError):
            manifest = {}
        names = [rec.get("name")
                 for rec in ((manifest.get("source") or {}).get("files") or [])]
    source_dir = root / SOURCE_ROOT
    if not names and source_dir.is_dir():
        names = sorted(path.name for path in source_dir.iterdir()
                       if path.suffix == ".rvl")
    return [str(source_dir / name) for name in names if name]


def gate_bundle(bundle_dir: Path | str) -> attest.GateVerdict:
    """Run the reference frontend over the bundle's OWN staged source and return
    the verdict, hashed in the bundle's normalized IR spelling.

    This is the measurement an attestation over a bundle records. It is also
    what makes `attest.make_attestation`'s hash equality meaningful here: the
    verdict's hash is the recompile's, so signing succeeds only when the staged
    `ir/ir.json` is REPRODUCED by compiling the staged source — the same
    property `revl verify` reports, enforced at signing time.
    """
    from .bundle import _canonical_ir  # noqa: PLC0415 — lazy, avoids an import cycle

    return attest.run_gate(paths=staged_sources(bundle_dir),
                           normalize=_canonical_ir)


def make_deploy_attestation(bundle_dir: Path | str, key: bytes, *,
                            backends: Optional[Iterable[str]] = None,
                            now=None, signer: str | None = None) -> dict:
    """Sign the deploy attestation for a staged bundle: item 127's attestation
    over the bundle's IR, with the whole chain folded into `evidence_bindings`.

    A thin composition on purpose — the signature primitive, the canonical IR
    hash and the bindings member are all item 127/290's, unchanged. What is NOT
    thin, and is the point: the gate verdict comes from :func:`gate_bundle`, a
    real frontend run over the staged source. A bundle whose source no longer
    admits, or whose staged IR is not what its source compiles to, is REFUSED
    signing rather than signed with a guarantee list nothing measured.
    """
    ir = staged_ir(bundle_dir)
    verdict = gate_bundle(bundle_dir)
    if not verdict.admitted and verdict.error is not None:
        raise verdict.error
    return attest.make_attestation(
        ir, key, verdict=verdict, now=now, signer=signer,
        evidence_bindings=chain_bindings(bundle_dir, backends=backends))


# ---------------------------------------------------------------------------
# §2.4. host-side admission and the trust store
# ---------------------------------------------------------------------------

#: The six named links a host refuses on (§2.2). A refusal always names one, so
#: it is a mechanical check with a located cause, never a judgement call.
LINK_SIGNER = "signer-untrusted"
LINK_SIGNATURE = "signature"
LINK_COMPOSITION = "source-or-ir-hash"
LINK_BACKEND = "backend"
LINK_ARTIFACT = "artifact-bytes"
LINK_POLICY = "policy"
LINK_CAPABILITY = "capability-ceiling"
LINK_EVIDENCE = "evidence-stale"

ACCEPT = "ACCEPT"
REFUSE = "REFUSE"
#: The third receipt verdict, distinct from the two admission ones. An ACCEPT
#: receipt is what `admit` returns in PREPARE — "I verified this chain and LOADED
#: NOTHING". A COMMITTED receipt is what a host returns in COMMIT — "these are
#: the exact bytes I measured at the instant I handed them to the runtime"
#: (design R2 / §1.3 step 7). They share a kind and a signing key but never a
#: verdict, so one can never stand in for the other: an admission that loaded
#: nothing must not read as a load, and a load-time measurement must not read as
#: an admission of a chain it never checked.
COMMITTED = "COMMITTED"
#: The phase tag a COMMIT receipt carries, so a COMMITTED receipt is legible as a
#: load-time measurement even before its verdict is read, and so the conductor's
#: comparison (:func:`compare_commit_receipt`) refuses anything not minted at
#: COMMIT-load time.
COMMIT_PHASE = "commit-load"

RECEIPT_KIND = "revl.deploy.receipt"
RECEIPT_VERSION = "1.0"

#: The domain-separation prefix folded into every receipt MAC, distinct from
#: `attest.SIGN_DOMAIN`. Both MACs are `hmac(key, canonical(body-minus-
#: signature))` over the same canonical spelling, so without a per-protocol tag
#: an ACCEPT receipt verified as a valid attestation and an attestation verified
#: as a valid receipt — cross-protocol confusion between two records that mean
#: entirely different things ("I admitted this" vs "this was admitted").
RECEIPT_DOMAIN = b"revl.deploy.receipt/v1\x00"

#: How far into the RECEIVER's future a signed timestamp may sit and still be
#: read as a real instant rather than a post-date. Freshness was anchored on a
#: signer-chosen field with a lower bound only, so a 2019 stamp was refused as
#: stale and a 2099 stamp ACCEPTED — its age is negative, and nothing compared
#: a negative age against anything (roadmap 428 F7). The bound exists because
#: two clocks are never identical, not because a signer may choose its own
#: window: it is a tolerance, and it is the receiver's, not the record's.
DEFAULT_CLOCK_SKEW_SECONDS = 300.0


class _HostKeyMaterialError(RevlError):
    """A key file the HOST itself owns could not be read.

    Distinct from a bare :class:`RevlError` because the two send an operator to
    different machines. This one is the deploy-admit runner's OWN trust
    configuration — the `--key` files on the command line that invoked it, which
    the request never carries (design S2.4). A plain `RevlError` out of
    :func:`serve_deploy_request` is instead a fault in the bundle the CONDUCTOR
    staged (most concretely `attest.load_attestation` on the bundle's own
    `attestation.json`), which is fixed on the conductor's disk, not the
    runner's. The runner's fail-closed reply names which of the two it was, so
    the two are not confusable at the point the reason is written."""

    def __init__(self, path: Path | str, cause: BaseException) -> None:
        # `attest.load_key` reports as a `RevlError`, whose rendering already
        # carries the path; take its plain message so it is not printed twice.
        detail = getattr(cause, "message", None) or str(cause)
        super().__init__(str(path), 0, detail)


def _load_key(path: Path | str) -> bytes:
    """Read a raw HMAC key from a file.

    `attest.load_key`'s rule, delegated to rather than restated: the key is the
    file's bytes with one trailing newline stripped (so a `cat`- or `echo`-built
    key file round-trips), and nothing else is assumed. docs/revl-attest.md is
    the rule, and sharing the implementation is what makes it ONE rule instead
    of two readings of one rule. Every key this module reads off disk (the
    operator's `--key`, the host's `--host-key`, the far host's receipt key)
    used to call `Path(...).read_bytes()` itself, so the same file was two
    different keys: two `key_id`s, and a receipt MACed under one that a
    verifier following the documented rule could not reproduce."""
    return attest.load_key(str(path))


def _receipt_mac(body: Mapping, host_key: bytes) -> str:
    """The receipt MAC: domain-tagged HMAC-SHA256 over the canonical body bytes
    (`body` is the receipt with its `signature` member removed).

    The bytes are `attest._canonical_bytes`'s, the same construction
    `attest._sign` MACs over, deferred to rather than restated (roadmap 428
    F10's successor in this module): a verifier who canonicalizes the way
    docs/revl-attest.md documents recomputes exactly these bytes, which is only
    true while there is one implementation of the spelling. This used to call
    `json.dumps` HERE, with the default `ensure_ascii=True`, so a body carrying
    non-ASCII text (a runtime version, a nonce, a name) was `\\u`-escaped and
    MACed to different bytes than the documented rule, and a valid receipt read
    as invalid by anyone who followed it.

    A body with no canonical byte spelling (a lone surrogate) raises
    `attest.NotCanonicalizable`: :func:`verify_receipt` turns that into a
    refusal, and the signing boundary (:func:`admit`, :func:`commit_receipt`)
    lets it escape, because a body that cannot be MACed has no signature to
    return."""
    return hmac.new(bytes(host_key), RECEIPT_DOMAIN + attest._canonical_bytes(
        {k: v for k, v in body.items() if k != "signature"}),
        hashlib.sha256).hexdigest()


@dataclass(frozen=True)
class TrustStore:
    """What the RECEIVING side independently knows, and admits against.

    The whole security value of §2.4 is that this lives on the receiver: the
    deploying operator does not get to assert "trust me, it is admitted". A
    receiver holds its own verify keys, its own capability ceiling, its own
    freshness policy, and its own backend — and recomputes the chain over the
    staged bytes before anything loads.

    `cross_domain` records whether the signer is a DIFFERENT trust domain than
    this receiver. Under a symmetric signature algorithm that combination is
    refused outright (§5-A1): a verifier that holds the HMAC secret can forge an
    attestation binding arbitrary bytes, so "signer untrusted" would be a
    fiction. Slice 1 is single-host — one trust domain — so the default is
    False and HMAC is honest; the flag is the place the Ed25519 prerequisite
    lands when Slice 2 crosses a domain.

    `clock_skew_seconds` and `not_before` are the receiver's half of freshness.
    `evidence_ttl_seconds` alone bounded the PAST only, so post-dating an
    attestation walked straight past it: the age came out negative and nothing
    compared a negative age with anything. `clock_skew_seconds` is how far into
    this receiver's future a signed instant may sit before it is read as a
    post-date rather than as two clocks disagreeing. `not_before` is an
    independent anchor the receiver SUPPLIES rather than reads off the record
    (a unix timestamp or an ISO-8601 string, typically the instant of the last
    deploy it accepted): evidence older than it is refused whatever its TTL
    says, which is what makes replaying an old-but-in-window attestation fail.

    `require_gauntlet` demands that the signed chain actually carry item-31
    gauntlet evidence. Off (the default) a bundle built where the gauntlet
    machinery was unavailable still admits, since `build_bundle` degrades
    honestly and stages no dossier; on, a chain with no `gauntlet` facet is
    REFUSED rather than admitted on absent evidence. A dossier that IS bound is
    read in full either way: an unreadable one, a verdict that is not
    `admissible`, and one graded over another composition are all refusals.

    `require_conformance` is the same fail-closed opt-in for the item-306
    conformance cert — the chain's `runtime-target` link (§2.3), the portable
    evidence that this backend's artifact means what the reference tier does.
    Off (the default), an absent `conformance/<backend>` facet is unchecked: a
    bundle built without the six-tier suite still admits, exactly as it does with
    no gauntlet, so an honest degrade is not punished. That silence is the whole
    hazard, though — a receiver that WANTS runtime-target evidence got none and
    was told nothing (the `unbound-means-unchecked` shape roadmap 428 F4 named
    and left open for this facet). On, a chain that binds no
    `conformance/<backend>` for this receiver's backend is REFUSED rather than
    admitted on absent evidence. A cert that IS bound is re-hashed against the
    signed facet either way; its own signature is NOT independently trusted —
    Slice 1 trusts it transitively through the bound hash (design R3(d)), so a
    receiver never re-verifies the cert's HMAC, and interpreting the cert's
    per-tier verdict is deferred with the backend-name reconciliation it needs
    (the cert's `tiers` are spelled `py`/`ts`, a deploy backend `python`).

    `recheck_source` is the receiver's answer to "a signature is not a check".
    Off (the default), admission trusts the SIGNER's gate run: the attestation
    is only issuable from a real admitted verdict over this exact
    `composition_hash`, so admission inherits that transitively, and what it
    leaves open is a signer whose frontend was older, patched, or lying. On, the
    receiver re-runs its OWN frontend over the bundle's staged source and
    refuses unless that run admits AND reproduces the staged IR — the receiver
    stops taking the signer's word for the verdict as well as for the bytes.
    """

    keys: Mapping[str, bytes]
    backend: str
    revoked: frozenset = frozenset()
    capability_ceiling: Optional[frozenset] = None
    evidence_ttl_seconds: Optional[float] = None
    cross_domain: bool = False
    recheck_source: bool = False
    require_gauntlet: bool = False
    require_conformance: bool = False
    clock_skew_seconds: float = DEFAULT_CLOCK_SKEW_SECONDS
    not_before: Optional[float | str] = None

    def key_for(self, kid: str | None) -> Optional[bytes]:
        if not isinstance(kid, str):
            return None
        if kid in self.revoked:
            return None
        return self.keys.get(kid)


def _refusal(link: str, reason: str, **extra) -> dict:
    return {"kind": RECEIPT_KIND, "version": RECEIPT_VERSION,
            "verdict": REFUSE, "link": link, "reason": reason, **extra}


def _parse_timestamp(value) -> Optional[float]:
    if not isinstance(value, str):
        return None
    try:
        parsed = datetime.fromisoformat(value)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.timestamp()


def admit(bundle_dir: Path | str, *, trust: TrustStore,
          attestation: Optional[dict] = None, now=None,
          nonce: str | None = None, host_key: Optional[bytes] = None,
          runtime_versions: Optional[Mapping[str, str]] = None) -> dict:
    """Verify the whole attestation chain against the STAGED BYTES and return a
    signed admission verdict. Loads nothing; this is PREPARE (§1.3, step 4/5).

    Every hash on the right-hand side of every comparison is recomputed here,
    from the receiver's own disk:

      * `composition_hash` is re-derived with `attest.canonical_hash` over
        `ir/ir.json` as staged — not read off the attestation's own claim about
        the source;
      * `artifact/<backend>` is re-derived with :func:`artifact_digest` over
        `emitted/<trust.backend>/...` as staged — the bytes this receiver will
        actually execute;
      * `policy` / `lock` / `gauntlet` / `conformance/<backend>` are re-derived
        from their staged files.

    The attestation contributes exactly one thing: the SIGNED left-hand side.
    Members in :data:`SELF_DECLARED_IGNORED` are never read, so an attestation
    that truthfully describes bytes other than the ones in hand still fails —
    a signature proves authorship, not that the artifact on this disk is the
    artifact that was signed. The signature and the re-hash are two independent
    gates and both must pass.

    Returns an ACCEPT receipt (binding the RE-HASHED artifact hash, the
    re-derived composition hash, the receiver's runtime versions and a fresh
    nonce) or a REFUSE receipt naming the failing chain link.
    """
    root = Path(bundle_dir)
    if attestation is None:
        path = root / ATTESTATION_NAME
        if not path.is_file():
            return _refusal(LINK_SIGNATURE,
                            f"the staged bundle carries no {ATTESTATION_NAME}: "
                            "there is no chain to verify, so it is refused "
                            "rather than admitted unattested")
        attestation = attest.load_attestation(str(path))

    # (a) signer: is this key_id one this receiver trusts, and not revoked?
    kid = attestation.get("key_id")
    # The cross-domain refusal reads NOTHING off the attestation. It used to
    # gate on `attestation["sign_alg"] == SIGN_ALG`, which made a self-declared
    # member the decider of the trust-domain question: relabel it `ed25519` and
    # the refusal evaporated, while `verify_attestation` went on MAC-ing with
    # the symmetric key regardless. The algorithm this build can verify is a
    # property of THIS code, so it is read from this code: every attestation
    # `attest.verify_attestation` accepts is HMAC (it now refuses any other
    # `sign_alg`), and a symmetric verifier is a forger, so a declared
    # cross-domain deploy is refused outright.
    if trust.cross_domain:
        return _refusal(
            LINK_SIGNER,
            "this receiver declares the signer a different trust domain, but "
            f"every attestation this build verifies is the symmetric "
            f"{attest.SIGN_ALG!r}. A verifier that holds the secret is also a "
            "forger, so `signer untrusted` would be a fiction. Refusing until "
            "the asymmetric (Ed25519) upgrade lands "
            "(docs/design/118-revl-deploy.md §2.4).")
    key = trust.key_for(kid)
    if key is None:
        known = ", ".join(sorted(trust.keys)) or "(none)"
        revoked = " (REVOKED on this receiver)" if kid in trust.revoked else ""
        return _refusal(LINK_SIGNER,
                        f"signer key_id {kid!r} is not in this receiver's trust "
                        f"store{revoked} (trusted: {known})", key_id=kid)

    # (b) signature: authentic and untampered, before any field is trusted.
    ok, reason = attest.verify_attestation(attestation, key)
    if not ok:
        return _refusal(LINK_SIGNATURE, reason, key_id=kid)

    # (c) RE-HASH the IR that is actually staged here.
    try:
        ir = staged_ir(root)
    except RevlError as error:
        return _refusal(LINK_COMPOSITION, str(error))
    try:
        recomputed_ir = attest.canonical_hash(ir)
    except attest.NotCanonicalizable as error:
        # Staged bytes this receiver cannot canonicalize are unmeasurable, and
        # an unmeasurable input refuses (roadmap 428 F10/F11). `json.loads`
        # will build a lone surrogate out of a `"\ud800"` escape, so a staged
        # `ir/ir.json` can reach this.
        return _refusal(LINK_COMPOSITION,
                        f"the staged {IR_DOCUMENT} cannot be canonically "
                        f"hashed, so it cannot be compared with the signed "
                        f"composition: {error}")
    bound_ir = attestation.get("composition_hash")
    if not hmac.compare_digest(recomputed_ir, str(bound_ir)):
        return _refusal(
            LINK_COMPOSITION,
            "the staged IR is not the attested composition: the signature binds "
            f"{str(bound_ir)[:12]}…, the bytes on this receiver hash to "
            f"{recomputed_ir[:12]}…")

    # (c2) optionally, RE-RUN the frontend here. `admit` re-hashes the IR but a
    # hash is not a verdict: without this the receiver still takes the signer's
    # word that some checker ever admitted the composition. With it, this
    # receiver's own frontend must admit the staged source AND reproduce the
    # staged IR (docs/design/118-revl-deploy.md §2.4, TrustStore.recheck_source).
    if trust.recheck_source:
        local = gate_bundle(root)
        if not local.admitted:
            return _refusal(
                LINK_COMPOSITION,
                "this receiver re-ran its own frontend over the staged source "
                f"and it was NOT admitted: {local.reason}")
        if not hmac.compare_digest(str(local.composition_hash), recomputed_ir):
            return _refusal(
                LINK_COMPOSITION,
                "the staged source does not compile to the staged IR on this "
                f"receiver: its own frontend produced "
                f"{str(local.composition_hash)[:12]}…, the staged ir/ir.json "
                f"hashes to {recomputed_ir[:12]}…")

    bindings = attestation.get("evidence_bindings") or {}

    # (d) backend: the chain must bind an artifact for THIS receiver's backend.
    facet = artifact_facet(trust.backend)
    if facet not in bindings:
        bound = ", ".join(sorted(k for k in bindings if k.startswith("artifact/"))) or "(none)"
        return _refusal(
            LINK_BACKEND,
            f"the signed chain binds no artifact for this receiver's backend "
            f"{trust.backend!r} (bound: {bound}); it was attested for a "
            "different runtime target")

    # (e) RE-HASH the artifact bytes this receiver would execute.
    backend_dir = root / EMITTED_ROOT / trust.backend
    if not backend_dir.is_dir():
        return _refusal(LINK_ARTIFACT,
                        f"the staged bundle has no emitted/{trust.backend}/ "
                        "artifact to execute")
    # Fail CLOSED on a tree this receiver cannot honestly digest: a symlink
    # binding bytes outside the bundle, a non-regular entry, or an empty
    # directory whose digest is `sha256(b"")` and therefore matches without any
    # artifact being present (roadmap 428 F11).
    try:
        recomputed_artifact = artifact_digest(backend_dir)
    except RevlError as error:
        return _refusal(
            LINK_ARTIFACT,
            f"the bytes staged at emitted/{trust.backend}/ cannot be digested "
            f"as an artifact this receiver holds: {error}")
    if not hmac.compare_digest(recomputed_artifact, str(bindings[facet])):
        return _refusal(
            LINK_ARTIFACT,
            f"the artifact bytes staged at emitted/{trust.backend}/ are NOT the "
            f"attested ones: the signature binds {str(bindings[facet])[:12]}…, "
            f"the bytes on this receiver hash to {recomputed_artifact[:12]}…. "
            "The chain is checked against the bytes in hand, never against the "
            "sender's own claim about them.")

    # (f) every other bound facet, re-hashed from the staged file.
    for facet_name, filename in ((FACET_POLICY, POLICY_NAME),
                                 (FACET_LOCK, LOCK_NAME),
                                 (FACET_GAUNTLET, GAUNTLET_NAME)):
        if facet_name not in bindings:
            continue
        path = root / filename
        if not path.is_file():
            return _refusal(LINK_POLICY if facet_name == FACET_POLICY else facet_name,
                            f"the chain binds `{facet_name}` but the staged "
                            f"bundle has no {filename}")
        if not hmac.compare_digest(_file_digest(path), str(bindings[facet_name])):
            return _refusal(
                LINK_POLICY if facet_name == FACET_POLICY else facet_name,
                f"the staged {filename} is not the bound `{facet_name}` facet "
                "(re-hashed on this receiver, and it differs)")
    cert = root / CONFORMANCE_ROOT / f"{trust.backend}.json"
    cert_facet = conformance_facet(trust.backend)
    if cert_facet in bindings:
        if not cert.is_file():
            return _refusal(LINK_EVIDENCE,
                            f"the chain binds {cert_facet} but no conformance "
                            f"cert for {trust.backend} is staged")
        if not hmac.compare_digest(_file_digest(cert), str(bindings[cert_facet])):
            return _refusal(LINK_EVIDENCE,
                            f"the staged conformance cert for {trust.backend} is "
                            "not the bound one (re-hashed here, and it differs)")
    elif trust.require_conformance:
        # Unbound is NOT unchecked when the receiver demands the runtime-target
        # link. The gauntlet facet already fails closed this way (`require_
        # gauntlet` below); the conformance facet was left with the `unbound-
        # means-unchecked` shape roadmap 428 F4 named. Absent runtime-target
        # evidence is refused, never counted as a pass.
        return _refusal(
            LINK_EVIDENCE,
            f"this receiver requires item-306 conformance evidence for its "
            f"backend {trust.backend!r} and the signed chain binds no "
            f"{cert_facet!r} facet; absent runtime-target evidence is refused, "
            "never counted as evidence that the artifact means on this runtime "
            "what the reference tier does")

    # (f2) the gauntlet VERDICT, and the composition it was graded over.
    #
    # (f) above only re-hashes the dossier: it proves the bytes are the signed
    # bytes and says nothing about what they SAY. So a dossier recording
    # `rejected` — the bundle's own evidence that it should not have been built
    # — was hashed, matched, and ACCEPTED, and a genuine `admissible` record
    # produced for a DIFFERENT artifact was accepted too, because the dossier
    # named no composition and there was nothing to check it against.
    # `bundle.build_bundle` now stamps the graded composition into the dossier
    # as it stages it, and both halves are read here.
    #
    # Fail closed throughout: a dossier that will not parse, or that names no
    # composition, is refused rather than read as absent evidence.
    if FACET_GAUNTLET in bindings:
        try:
            dossier = json.loads(
                (root / GAUNTLET_NAME).read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError, UnicodeDecodeError) as error:
            return _refusal(
                FACET_GAUNTLET,
                f"the chain binds `{FACET_GAUNTLET}` but the staged "
                f"{GAUNTLET_NAME} cannot be read as JSON ({error}); unreadable "
                "evidence is refused, never read as evidence that passed")
        if not isinstance(dossier, dict):
            return _refusal(
                FACET_GAUNTLET,
                f"the staged {GAUNTLET_NAME} is not a gauntlet dossier "
                f"(it is a {type(dossier).__name__}, not an object)")
        verdict = dossier.get("verdict")
        if verdict != GAUNTLET_ADMISSIBLE:
            return _refusal(
                FACET_GAUNTLET,
                f"the staged {GAUNTLET_NAME} records the gauntlet verdict "
                f"{verdict!r}, not {GAUNTLET_ADMISSIBLE!r}: the bundle carries "
                "its own evidence that it should not have been built, and an "
                "honest signature over that evidence does not turn it into a "
                "pass")
        graded = dossier.get(GAUNTLET_IDENTITY)
        if not isinstance(graded, str) or not graded:
            return _refusal(
                FACET_GAUNTLET,
                f"the staged {GAUNTLET_NAME} carries no `{GAUNTLET_IDENTITY}`, "
                "so it names no composition: it cannot be shown to be evidence "
                "about the artifact in hand, and unidentified evidence is "
                "refused rather than assumed to be about this one")
        if not hmac.compare_digest(graded, recomputed_ir):
            return _refusal(
                FACET_GAUNTLET,
                f"the staged {GAUNTLET_NAME} was graded over composition "
                f"{graded[:12]}…, but the composition staged here is "
                f"{recomputed_ir[:12]}…: a genuine dossier for a DIFFERENT "
                "artifact hashes correctly into the chain and would otherwise "
                "ride along under an honest signature")
    elif trust.require_gauntlet:
        return _refusal(
            FACET_GAUNTLET,
            "this receiver requires item-31 gauntlet evidence and the signed "
            f"chain binds no `{FACET_GAUNTLET}` facet; absent evidence is "
            "refused, never counted as evidence that passed")

    # (g) capability ceiling: a deploy may not widen authority (§2.2, G1/G9).
    #
    # Measured off `ir/ir.json`, the AUTHORITY, and never off `policy.json`,
    # which is a projection `bundle.build_bundle` derives from that same IR. The
    # ceiling used to read the projection, and a projection is writable by the
    # party the ceiling constrains: deleting `policy.json`, leaving it valid but
    # dropping `capabilities`, emptying the list, or leaving bytes `json.loads`
    # refuses (whose failure was swallowed to `{}`) each gave `wanted = set()`
    # and passed ANY ceiling, all four with a fully valid signature and a
    # matching binding, because every one of them was signed over as staged. The
    # IR is not writable that way: it is re-hashed against the signed
    # `composition_hash` at (c) above, so any edit that lowers the derived
    # surface is a different composition and refuses there first.
    if trust.capability_ceiling is not None:
        try:
            wanted, _derived = capability_surface(ir)
        except RevlError as error:
            # Fail CLOSED. An unreadable surface is not an empty one.
            return _refusal(
                LINK_CAPABILITY,
                "this receiver cannot measure the capability surface of the "
                f"staged composition, so it cannot check its ceiling: {error}")
        over = sorted(wanted - set(trust.capability_ceiling))
        if over:
            return _refusal(
                LINK_CAPABILITY,
                f"the staged composition reaches {', '.join(over)}, outside "
                "this receiver's ceiling "
                f"({', '.join(sorted(trust.capability_ceiling)) or 'none'}); "
                "a deploy may not silently widen authority. Measured from the "
                f"signature-bound {IR_DOCUMENT}, not from {POLICY_NAME}.")
        # `policy.json` stays a checked projection rather than a decorative one:
        # if the chain binds it, it must agree with what the IR derives. It is
        # not what the ceiling was measured against, so a disagreement is a
        # tamper signal and not a bypass.
        if FACET_POLICY in bindings:
            try:
                recorded = json.loads(
                    (root / POLICY_NAME).read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError, UnicodeDecodeError) as error:
                return _refusal(
                    LINK_POLICY,
                    f"the chain binds `{FACET_POLICY}` but the staged "
                    f"{POLICY_NAME} cannot be read as JSON ({error}); it is "
                    "refused rather than read as an empty policy")
            if isinstance(recorded, dict):
                projected = sorted({str(c)
                                    for c in (recorded.get("capabilities") or [])})
            else:
                projected = None
            if projected is None or set(projected) != wanted:
                shown = projected if projected is not None else repr(recorded)
                return _refusal(
                    LINK_POLICY,
                    f"the staged {POLICY_NAME} does not project the staged "
                    f"composition: it records {shown}, the {IR_DOCUMENT} this "
                    f"receiver admitted reaches {sorted(wanted)}")

    # (h) freshness: a signature proves authenticity, never current validity.
    #
    # The timestamp is SIGNER-CHOSEN and `attest._now_iso` passes an ISO string
    # straight through, so post-dating is a one-argument change. A TTL alone
    # bounds only the past: a 2099 stamp gave a NEGATIVE age, which is not
    # greater than any TTL, so it was accepted while a 2019 stamp was refused.
    # Both ends are bounded here, and both bounds are the RECEIVER's — its own
    # clock, its own skew tolerance, its own `not_before` anchor.
    if (trust.evidence_ttl_seconds is not None
            or trust.not_before is not None):
        signed_at = _parse_timestamp(attestation.get("timestamp"))
        if signed_at is None:
            return _refusal(LINK_EVIDENCE,
                            "the attestation carries no readable timestamp, so "
                            "its freshness cannot be checked; refused fail-closed")
        current = now if isinstance(now, (int, float)) else time.time()
        age = current - signed_at
        skew = max(float(trust.clock_skew_seconds), 0.0)
        if age < -skew:
            return _refusal(
                LINK_EVIDENCE,
                f"the attestation is dated {-age:.0f}s in this receiver's "
                f"FUTURE, past its {skew:.0f}s clock-skew tolerance: the "
                "timestamp is signer-chosen, so a post-dated record would "
                "otherwise stay 'fresh' indefinitely and outlive any TTL")
        if (trust.evidence_ttl_seconds is not None
                and age > trust.evidence_ttl_seconds):
            return _refusal(
                LINK_EVIDENCE,
                f"the attestation is {age:.0f}s old, past this receiver's "
                f"{trust.evidence_ttl_seconds:.0f}s freshness TTL; a valid "
                "signature over stale evidence is still refused")
        if trust.not_before is not None:
            floor = (trust.not_before if isinstance(trust.not_before, (int, float))
                     else _parse_timestamp(trust.not_before))
            if floor is None:
                return _refusal(
                    LINK_EVIDENCE,
                    "this receiver's `not_before` anchor is not a readable "
                    f"instant ({trust.not_before!r}), so freshness cannot be "
                    "checked against it; refused fail-closed rather than "
                    "checked against no anchor")
            if signed_at < float(floor):
                return _refusal(
                    LINK_EVIDENCE,
                    "the attestation predates this receiver's own freshness "
                    "anchor, so it is evidence from before the last state this "
                    "receiver accepted; a replay of in-window evidence is "
                    "still a replay")

    receipt = {
        "kind": RECEIPT_KIND,
        "version": RECEIPT_VERSION,
        "verdict": ACCEPT,
        "backend": trust.backend,
        # Both hashes are the RE-COMPUTED ones. A receipt therefore binds what
        # this receiver actually holds, which is what makes a later lie about
        # what it loaded detectable and non-repudiable (§5-A2).
        "composition_hash": recomputed_ir,
        "artifact_hash": recomputed_artifact,
        "key_id": kid,
        "runtime_versions": dict(sorted((runtime_versions or {}).items())),
        "nonce": nonce or os.urandom(16).hex(),
        "admitted_at": attest._now_iso(None) if now is None else str(now),
    }
    if host_key is not None:
        receipt["signature"] = _receipt_mac(receipt, host_key)
    return receipt


def admit_bundle_chain(bundle_dir: Path | str, *,
                       key_paths: Sequence[Path | str] = (),
                       backend: str = "python",
                       require_gauntlet: bool = False,
                       require_conformance: bool = False,
                       now=None) -> dict:
    """Run the §2 attestation-chain admission over a staged bundle from the
    CONDUCTOR's own credentials, and return the admission receipt.

    This is the thin bridge that puts :func:`admit` on the `revl deploy` PREPARE
    path (design §1.3, step 4): before any boundary is opened, the operator's
    own verify key(s) admit the bundle's whole-composition chain against the
    bytes staged on THIS disk. It is effect-free — it loads nothing and spawns
    nothing — so a refusal here is a clean PREPARE-time refusal with nothing to
    roll back.

    `key_paths` are files holding the raw HMAC verify key bytes; each is keyed
    by its :func:`attest.key_id` so the attestation's `key_id` selects the right
    one. With no key the chain cannot be verified, so admission REFUSES at the
    signer link rather than admitting unverified — the same fail-closed shape
    `admit` uses for an absent attestation.

    Single trust domain (Slice 1): the operator who signs is the operator who
    deploys, so the :class:`TrustStore` is NOT `cross_domain` and HMAC is
    honest here (the module docstring's Ed25519 note is the Slice-2 prerequisite
    for crossing a domain).
    """
    keys: dict[str, bytes] = {}
    for path in key_paths:
        raw = _load_key(path)
        keys[attest.key_id(raw)] = raw
    trust = TrustStore(keys=keys, backend=backend,
                       require_gauntlet=require_gauntlet,
                       require_conformance=require_conformance)
    return admit(bundle_dir, trust=trust, now=now)


def verify_receipt(receipt: Mapping, host_key: bytes) -> tuple[bool, str]:
    """Check a receipt's own signature — the receiver signed what it claims to
    hold, so an audit can attribute a lie rather than only notice one.

    The MAC is domain-tagged and the envelope is checked, so an item-127
    attestation signed with this key is NOT a receipt: it fails the MAC (a
    different domain) and, were it not for that, would fail on `kind`. A record
    saying "this composition was admitted" and a record saying "I admitted it"
    are different claims by different parties, and neither may stand in for the
    other."""
    given = receipt.get("signature")
    if not isinstance(given, str):
        return False, "receipt carries no signature"
    try:
        expected = _receipt_mac(receipt, host_key)
    except attest.NotCanonicalizable as error:
        return False, f"receipt cannot be verified: {error}"
    if not hmac.compare_digest(expected, given):
        return False, "receipt signature mismatch"
    if receipt.get("kind") != RECEIPT_KIND:
        return False, (f"not a {RECEIPT_KIND} record: kind is "
                       f"{receipt.get('kind')!r}")
    if receipt.get("version") != RECEIPT_VERSION:
        return False, (f"receipt version is {receipt.get('version')!r}, "
                       f"expected {RECEIPT_VERSION!r}")
    if receipt.get("verdict") not in (ACCEPT, REFUSE, COMMITTED):
        return False, f"receipt verdict is {receipt.get('verdict')!r}"
    return True, "receipt is authentic"


def repin(bundle_dir: Path | str, receipt: Mapping) -> tuple[bool, str]:
    """Re-derive the composition hash and the artifact digest from the staged
    bytes and check them against an ACCEPT `receipt`. Answers `(ok, reason)`.

    :func:`admit` is PREPARE: it verifies and LOADS NOTHING, so everything it
    checked was checked at admission time and nothing re-checked it at the
    moment of execution. Between the two the staged tree is ordinary files on
    ordinary disk, so an ACCEPT receipt can end up describing bytes that have
    since changed or gone (roadmap 428 F11). This is the check a loader runs
    IMMEDIATELY before it executes: same two re-derivations `admit` ran,
    against the receipt this receiver itself signed rather than against the
    sender's attestation.

    It is not a substitute for `admit` and cannot be: a receipt binds only what
    the receiver already admitted. It closes the admit-to-load window, and
    nothing else.

    Fails CLOSED everywhere: a receipt that is not an ACCEPT, one carrying no
    hashes, an IR that cannot be read or canonicalized, and an artifact tree
    that cannot be honestly digested are each a refusal.
    """
    root = Path(bundle_dir)
    if receipt.get("verdict") != ACCEPT:
        return False, (f"the receipt verdict is {receipt.get('verdict')!r}, "
                       f"not {ACCEPT}: there is nothing it authorises loading")
    bound_ir = receipt.get("composition_hash")
    bound_artifact = receipt.get("artifact_hash")
    backend = receipt.get("backend")
    if not (isinstance(bound_ir, str) and isinstance(bound_artifact, str)
            and isinstance(backend, str) and bound_ir and bound_artifact
            and backend):
        return False, ("the receipt does not pin a composition, an artifact and "
                       "a backend, so there is nothing to re-pin against")
    try:
        recomputed_ir = attest.canonical_hash(staged_ir(root))
    except (RevlError, attest.NotCanonicalizable) as error:
        return False, f"the staged {IR_DOCUMENT} cannot be re-hashed: {error}"
    if not hmac.compare_digest(recomputed_ir, bound_ir):
        return False, (f"the staged {IR_DOCUMENT} changed since admission: the "
                       f"receipt pins {bound_ir[:12]}…, the bytes on disk now "
                       f"hash to {recomputed_ir[:12]}…")
    backend_dir = root / EMITTED_ROOT / backend
    if not backend_dir.is_dir():
        return False, (f"the admitted emitted/{backend}/ artifact is gone; the "
                       "receipt describes bytes this receiver no longer holds")
    try:
        recomputed_artifact = artifact_digest(backend_dir)
    except RevlError as error:
        return False, (f"the staged emitted/{backend}/ can no longer be "
                       f"digested as an artifact: {error}")
    if not hmac.compare_digest(recomputed_artifact, bound_artifact):
        return False, (f"the staged emitted/{backend}/ changed since admission: "
                       f"the receipt pins {bound_artifact[:12]}…, the bytes on "
                       f"disk now hash to {recomputed_artifact[:12]}…")
    return True, "the staged bytes are still the admitted ones"


def render_receipt(receipt: Mapping) -> str:
    """One-line-per-fact rendering of an admission verdict."""
    if receipt.get("verdict") == ACCEPT:
        return "\n".join([
            f"admission: ACCEPT ({receipt.get('backend')})",
            f"  composition: {receipt.get('composition_hash')}",
            f"  artifact:    {receipt.get('artifact_hash')}  (re-hashed here)",
            f"  nonce:       {receipt.get('nonce')}",
        ])
    if receipt.get("verdict") == COMMITTED:
        return "\n".join([
            f"commit: COMMITTED ({receipt.get('backend')})",
            f"  composition: {receipt.get('composition_hash')}  (measured at load)",
            f"  artifact:    {receipt.get('artifact_hash')}  (measured at load)",
            f"  loaded_at:   {receipt.get('loaded_at')}",
            f"  nonce:       {receipt.get('nonce')}",
        ])
    return "\n".join([
        f"admission: REFUSE — chain link `{receipt.get('link')}`",
        f"  {receipt.get('reason')}",
    ])


# ---------------------------------------------------------------------------
# §1.3 step 7 / R2. the load-measured COMMIT receipt, and the conductor's
#                   comparison of it
# ---------------------------------------------------------------------------
#
# `admit` (PREPARE) verifies the chain and LOADS NOTHING; `repin` re-derives the
# two hashes at load time but only answers `(ok, reason)` and signs nothing. The
# gap design R2 names is between them: PREPARE proved bytes, COMMIT loads bytes,
# and nothing forced the loaded bytes to equal the verified ones, nor forced the
# conductor to check. Closing it needs two things design R2 spells out:
#
#   1. the COMMIT receipt binds sha256 of the EXACT bytes handed to the runtime,
#      measured FRESH at COMMIT-load time — never an echo of the hash PREPARE
#      verified (:func:`commit_receipt`);
#   2. the CONDUCTOR compares that measured hash against the SIGNED
#      `artifact/<backend>` binding and REFUSES on mismatch — and the comparison
#      gates COMMIT, not only PREPARE's verify (:func:`compare_commit_receipt`).
#
# The guarantee then SPLITS exactly as R2 requires, and neither half is claimed
# to be the other: an honest-but-buggy host that loads the wrong bytes by
# accident is DETECTABLE (the fresh measurement disagrees with the admitted
# binding, and the conductor sees it); a malicious host that signs one hash and
# loads another is only ATTRIBUTABLE / non-repudiable (it signed a statement with
# its own key, so the lie has an owner) and is NOT detectable without hardware
# the host cannot forge (§5-A2). The residual TOCTOU between this measurement and
# the runtime's own `exec` of the bytes is unclosable without that hardware and
# is named here, not papered over.


def commit_receipt(bundle_dir: Path | str, *, backend: str, host_key: bytes,
                   runtime_versions: Optional[Mapping[str, str]] = None,
                   nonce: Optional[str] = None,
                   now: Optional[str] = None) -> dict:
    """The host's signed COMMIT receipt (design R2 step 1 / §1.3 step 7): a FRESH
    measurement of the exact bytes it is about to hand the runtime, bound and
    signed with the host's own key.

    The two hashes are re-derived HERE, from the staged bytes on disk, at the
    moment of COMMIT — the same two re-derivations :func:`admit` and
    :func:`repin` run, but performed NOW rather than read off the admission
    receipt. That is the whole point of R2: an echo of PREPARE's verified hash
    would prove nothing about what COMMIT actually loaded, so a receipt that
    merely copied the admitted value would be a TOCTOU hole with a signature on
    it. The host signs the measurement with its own key (its item-55 mTLS
    identity in the network case, an HMAC key in Slice 1's single trust domain,
    R3/R5), so a later audit can ATTRIBUTE a lie about what it loaded, not merely
    notice one.

    Fails CLOSED: a staged IR that cannot be read or canonicalized, and an
    emitted `backend` tree that is missing or cannot be honestly digested, each
    RAISE :class:`RevlError` rather than yielding a receipt over bytes that could
    not be measured. A host that cannot measure what it is loading has not
    committed, and must report a local COMMIT failure, never a COMMITTED receipt.
    """
    root = Path(bundle_dir)
    if not isinstance(backend, str) or not backend:
        raise RevlError(str(root), 0,
                        "a COMMIT receipt must name the backend whose artifact "
                        "bytes it measured")
    try:
        measured_ir = attest.canonical_hash(staged_ir(root))
    except (RevlError, attest.NotCanonicalizable) as error:
        raise RevlError(
            str(root / IR_DOCUMENT), 0,
            f"the staged {IR_DOCUMENT} cannot be measured at COMMIT-load time: "
            f"{error}; a host that cannot measure what it loads has not "
            "committed") from error
    backend_dir = root / EMITTED_ROOT / backend
    if not backend_dir.is_dir():
        raise RevlError(
            str(backend_dir), 0,
            f"the emitted/{backend}/ artifact is not staged, so there are no "
            "bytes to measure at COMMIT-load time")
    try:
        measured_artifact = artifact_digest(backend_dir)
    except RevlError as error:
        raise RevlError(
            str(backend_dir), 0,
            f"the staged emitted/{backend}/ cannot be digested as an artifact "
            f"at COMMIT-load time: {error}") from error
    receipt = {
        "kind": RECEIPT_KIND,
        "version": RECEIPT_VERSION,
        "verdict": COMMITTED,
        "phase": COMMIT_PHASE,
        "backend": backend,
        # The FRESH load-time measurement, not an echo of the admitted hash.
        "composition_hash": measured_ir,
        "artifact_hash": measured_artifact,
        "runtime_versions": dict(sorted((runtime_versions or {}).items())),
        "nonce": nonce or os.urandom(16).hex(),
        "loaded_at": attest._now_iso(None) if now is None else str(now),
    }
    receipt["signature"] = _receipt_mac(receipt, host_key)
    return receipt


def compare_commit_receipt(admission_receipt: Mapping,
                           commit_receipt: Mapping, *,
                           host_key: bytes) -> tuple[bool, str]:
    """The conductor's HARD COMMIT gate (design R2 step 2 / §5-A2). Answers
    `(ok, reason)`; `ok is False` REFUSES the deploy.

    The comparison is between two records the SAME host signed with its own key:
    the ACCEPT admission receipt it returned in PREPARE (what it verified and was
    admitted to load) and the COMMITTED receipt it returned in COMMIT (what it
    measured at the instant of load). It:

      1. verifies the COMMIT receipt's OWN signature first. A receipt whose MAC
         does not check is `unattributable` — the conductor cannot even pin the
         claim on the host's key, so there is nothing to compare and it refuses.
         This is the attribution R2 leans on: past this point a lie has an owner.
      2. requires the COMMIT receipt to be a COMMITTED, COMMIT-phase record, and
         the admission receipt to be an ACCEPT one binding a composition, an
         artifact and a backend — otherwise there is no admitted binding to
         compare a load against.
      3. compares the load-measured `artifact_hash` and `composition_hash`
         against the SIGNED admission binding with a constant-time compare, and
         REFUSES on either mismatch, naming which link diverged. A backend that
         differs between the two receipts is itself a mismatch.

    A False here is design R2's DETECTABLE case: the host loaded bytes other than
    the ones it was admitted to load, and the conductor caught it at COMMIT
    rather than trusting PREPARE's verify. It does NOT and cannot prove the host
    did not lie about the measurement itself — that is the ATTRIBUTABLE-only
    boundary (§4.2), and closing it needs hardware attestation this slice does
    not have.
    """
    ok, why = verify_receipt(commit_receipt, host_key)
    if not ok:
        return False, (f"the COMMIT receipt is unattributable ({why}); a "
                       "load-time measurement the conductor cannot pin to the "
                       "host's key is refused rather than compared")
    if commit_receipt.get("verdict") != COMMITTED:
        return False, (f"the COMMIT receipt verdict is "
                       f"{commit_receipt.get('verdict')!r}, not {COMMITTED}: an "
                       "admission receipt is not a statement about what was "
                       "loaded")
    if commit_receipt.get("phase") != COMMIT_PHASE:
        return False, (f"the COMMIT receipt is not a {COMMIT_PHASE!r} record "
                       f"(phase is {commit_receipt.get('phase')!r}), so it is "
                       "not a load-time measurement")
    if admission_receipt.get("verdict") != ACCEPT:
        return False, (f"the admission receipt verdict is "
                       f"{admission_receipt.get('verdict')!r}, not {ACCEPT}: "
                       "nothing authorised loading, so there is no binding to "
                       "compare the load against")
    bound_ir = admission_receipt.get("composition_hash")
    bound_artifact = admission_receipt.get("artifact_hash")
    admitted_backend = admission_receipt.get("backend")
    if not (isinstance(bound_ir, str) and isinstance(bound_artifact, str)
            and isinstance(admitted_backend, str)
            and bound_ir and bound_artifact and admitted_backend):
        return False, ("the admission receipt does not bind a composition, an "
                       "artifact and a backend, so there is nothing for the "
                       "load-time measurement to be compared against")
    loaded_backend = commit_receipt.get("backend")
    if loaded_backend != admitted_backend:
        return False, (f"the host was admitted to load the "
                       f"{admitted_backend!r} artifact but measured the "
                       f"{loaded_backend!r} one at COMMIT: a different backend "
                       "is a different artifact")
    loaded_artifact = commit_receipt.get("artifact_hash")
    if not (isinstance(loaded_artifact, str)
            and hmac.compare_digest(loaded_artifact, bound_artifact)):
        return False, (
            f"the bytes the host measured at COMMIT-load time do not match the "
            f"admitted artifact: admission bound {bound_artifact[:12]}…, the "
            f"host loaded {str(loaded_artifact)[:12]}…. The load-time "
            "measurement is the authority, not PREPARE's earlier verify.")
    loaded_ir = commit_receipt.get("composition_hash")
    if not (isinstance(loaded_ir, str)
            and hmac.compare_digest(loaded_ir, bound_ir)):
        return False, (
            f"the composition the host measured at COMMIT-load time does not "
            f"match the admitted one: admission bound {bound_ir[:12]}…, the "
            f"host loaded {str(loaded_ir)[:12]}…")
    return True, ("the bytes the host measured at COMMIT-load time are the "
                  "admitted ones, and the measurement is signed by the host")


# ---------------------------------------------------------------------------
# §1.3 steps 3–5 / S2 slice 1. the remote deploy-admit runner protocol
# ---------------------------------------------------------------------------
#
# Slice 1 (single-host) put :func:`admit` and :func:`admit_bundle_chain` on the
# PREPARE path, but the conductor called `admit` IN ITS OWN PROCESS, over bytes
# on its own disk (`via = local`). The design's cross-machine PREPARE (§1.3
# steps 3–5) is different in one way that does not need a second machine to
# build: the conductor does not run the check itself — it STAGES the sliced
# bundle on the far host, starts `revl deploy-admit` there in ADMIT-ONLY mode,
# and receives back a SIGNED admission verdict that the HOST minted against the
# HOST's own local trust store (S2.4). The trust inversion is the whole point:
# a cross-domain host verifies with keys the conductor does not hold and can
# only be ASKED, never told, to admit.
#
# This slice builds that request/response protocol and its message shapes, plus
# an IN-PROCESS transport stub (:class:`InProcessTransport`) that stands in for
# the SSH/subprocess orchestration channel of §1.2. The stub carries every
# message through its CANONICAL WIRE FORM (`to_wire` -> json -> `from_wire`), so
# it exercises the exact serialization a real transport would and a field that
# does not survive the round trip fails a test here, not in production. The live
# cross-machine leg (staging over scp/rsync, spawning the runner over ssh, the
# pinned host key of §1.3) rides on top of this protocol unchanged and is a
# following slice; it would be verified end-to-end on the two self-hosted
# runners (azure-amd-1 + oracle-arm64).
#
# The protocol is deliberately thin — dict in, dict out — because a real runner
# reads one JSON line off the orchestration channel and writes one back. The
# typed :class:`AdmitRequest` / :class:`AdmitResponse` are the constructors and
# fail-closed validators the two ends use to build and read those lines; the
# authority for a verdict stays :func:`admit`, reused unchanged.

#: A refusal whose failing "link" is the transport itself, not a chain link: a
#: request that did not parse, or a reply that did not answer THIS request. It
#: is distinct from every :data:`LINK_SIGNER`-class chain link because the
#: attestation was never reached — the fault is in the exchange, not the bundle.
LINK_TRANSPORT = "transport"

#: The two message kinds of the orchestration-channel handshake. Domain-distinct
#: strings so a request can never be read as a response (or as a receipt, whose
#: kind is :data:`RECEIPT_KIND`); `from_wire` refuses any other value.
ADMIT_REQUEST_KIND = "revl.deploy.admit-request"
ADMIT_RESPONSE_KIND = "revl.deploy.admit-response"

#: Protocol version of the request/response envelope, bumped when a field's
#: meaning changes. Both ends pin it and refuse a mismatch rather than guessing.
ADMIT_PROTOCOL_VERSION = "1.0"


@dataclass(frozen=True)
class AdmitRequest:
    """The conductor's PREPARE request to a remote deploy-admit runner (§1.3
    steps 3–5).

    It names the STAGED bundle path *on the runner's own filesystem* (the
    conductor put it there in step 2), the `backend` the host will load, the
    evidence the deploy requires, and a `challenge` nonce the runner echoes so
    the conductor can bind the reply to THIS request — an orchestration-channel
    liveness check distinct from the data-plane :class:`TransportReplayGuard`
    (§1.4). It carries NO key: the runner verifies against its OWN local trust
    store (S2.4), so a request can ask for admission but never supply the trust
    that would grant it.

    `require_gauntlet` / `require_conformance` are what the conductor asks the
    host to enforce; the host may only be STRICTER, never looser, than the ask
    (see :func:`serve_admit_request`).
    """

    bundle: str
    backend: str
    challenge: str
    require_gauntlet: bool = False
    require_conformance: bool = False

    def to_wire(self) -> dict:
        return {"kind": ADMIT_REQUEST_KIND,
                "version": ADMIT_PROTOCOL_VERSION,
                "bundle": self.bundle,
                "backend": self.backend,
                "challenge": self.challenge,
                "require_gauntlet": bool(self.require_gauntlet),
                "require_conformance": bool(self.require_conformance)}

    @classmethod
    def from_wire(cls, wire: Mapping) -> "AdmitRequest":
        """Parse a request off the wire, fail-closed. A wrong kind/version or a
        missing/ill-typed field raises :class:`ValueError` rather than being
        read with a default — a runner that guessed at a malformed request
        would be admitting on terms the conductor never stated."""
        if not isinstance(wire, Mapping):
            raise ValueError("admit request is not a mapping")
        if wire.get("kind") != ADMIT_REQUEST_KIND:
            raise ValueError(
                f"not a {ADMIT_REQUEST_KIND} record: kind is "
                f"{wire.get('kind')!r}")
        if wire.get("version") != ADMIT_PROTOCOL_VERSION:
            raise ValueError(
                f"admit request version is {wire.get('version')!r}, expected "
                f"{ADMIT_PROTOCOL_VERSION!r}")
        bundle = wire.get("bundle")
        backend = wire.get("backend")
        challenge = wire.get("challenge")
        for name, value in (("bundle", bundle), ("backend", backend),
                            ("challenge", challenge)):
            if not isinstance(value, str) or not value:
                raise ValueError(
                    f"admit request {name!r} must be a non-empty string, got "
                    f"{value!r}")
        return cls(bundle=bundle, backend=backend, challenge=challenge,
                   require_gauntlet=bool(wire.get("require_gauntlet", False)),
                   require_conformance=bool(
                       wire.get("require_conformance", False)))


@dataclass(frozen=True)
class AdmitResponse:
    """The runner's reply: the signed admission `receipt` (an ACCEPT or REFUSE
    from :func:`admit`) plus the `challenge` echoed back from the request so the
    conductor can confirm the reply answers THIS request and not a replayed
    earlier one."""

    receipt: dict
    challenge: str

    def to_wire(self) -> dict:
        return {"kind": ADMIT_RESPONSE_KIND,
                "version": ADMIT_PROTOCOL_VERSION,
                "challenge": self.challenge,
                "receipt": dict(self.receipt)}

    @classmethod
    def from_wire(cls, wire: Mapping) -> "AdmitResponse":
        """Parse a response off the wire, fail-closed — same discipline as
        :meth:`AdmitRequest.from_wire`: a reply the conductor cannot recognise
        is not a verdict it may act on."""
        if not isinstance(wire, Mapping):
            raise ValueError("admit response is not a mapping")
        if wire.get("kind") != ADMIT_RESPONSE_KIND:
            raise ValueError(
                f"not a {ADMIT_RESPONSE_KIND} record: kind is "
                f"{wire.get('kind')!r}")
        if wire.get("version") != ADMIT_PROTOCOL_VERSION:
            raise ValueError(
                f"admit response version is {wire.get('version')!r}, expected "
                f"{ADMIT_PROTOCOL_VERSION!r}")
        receipt = wire.get("receipt")
        challenge = wire.get("challenge")
        if not isinstance(receipt, Mapping):
            raise ValueError("admit response carries no receipt mapping")
        if not isinstance(challenge, str) or not challenge:
            raise ValueError("admit response carries no challenge")
        return cls(receipt=dict(receipt), challenge=challenge)


def serve_admit_request(request_wire: Mapping, *,
                        key_paths: Sequence[Path | str] = (),
                        host_key: Optional[bytes] = None,
                        require_gauntlet: bool = False,
                        require_conformance: bool = False,
                        runtime_versions: Optional[Mapping[str, str]] = None,
                        now=None) -> dict:
    """Runner side of §1.3 steps 4–5: read one request off the orchestration
    channel, verify the staged bundle's chain LOCALLY against THIS host's own
    trust store, and answer with a signed admission verdict. Loads nothing; this
    is PREPARE. Returns a response WIRE dict (what `revl deploy-admit` writes
    back); the transport moves it, the conductor reads it with
    :meth:`AdmitResponse.from_wire`.

    Two host-authority properties the design (S2.4) requires are enforced here,
    not left to the request:

      * the trust store is built from the HOST's own `key_paths` and
        `host_key`; the request supplies no key, so a request can ask for
        admission but never carry the trust that grants it;
      * the host may be STRICTER than the ask but never looser — the effective
        `require_gauntlet` / `require_conformance` is the host's floor OR the
        request's ask, so a conductor cannot turn a host's evidence requirement
        OFF by omitting it from the request.

    A malformed request fails CLOSED to a :data:`LINK_TRANSPORT` REFUSE (the
    same shape :func:`admit` uses for a bad chain), because a runner that could
    not parse what it was asked to admit must refuse, never admit on a guess.

    A `key_paths` file this runner cannot read is raised as
    :class:`_HostKeyMaterialError`, the one failure on this path that is the
    runner's OWN configuration rather than the conductor's staged bundle — the
    runner's outer loop attributes the two differently (:func:`deploy_admit_command`).
    """
    try:
        request = AdmitRequest.from_wire(request_wire)
    except ValueError as error:
        challenge = ""
        if isinstance(request_wire, Mapping):
            got = request_wire.get("challenge")
            challenge = got if isinstance(got, str) else ""
        receipt = _refusal(LINK_TRANSPORT,
                           f"the deploy-admit request could not be parsed, so "
                           f"nothing was admitted: {error}")
        return AdmitResponse(receipt=receipt, challenge=challenge).to_wire()

    keys: dict[str, bytes] = {}
    for path in key_paths:
        try:
            raw = _load_key(path)
        except (OSError, RevlError) as error:
            raise _HostKeyMaterialError(path, error) from error
        keys[attest.key_id(raw)] = raw
    trust = TrustStore(
        keys=keys, backend=request.backend,
        # The host is the floor: it may add a requirement the conductor did not
        # ask for, but the conductor cannot subtract one the host stands on.
        require_gauntlet=bool(require_gauntlet) or request.require_gauntlet,
        require_conformance=(bool(require_conformance)
                             or request.require_conformance))
    receipt = admit(request.bundle, trust=trust, host_key=host_key,
                    runtime_versions=runtime_versions, now=now)
    return AdmitResponse(receipt=receipt, challenge=request.challenge).to_wire()


def serve_deploy_request(request_wire: Mapping, *,
                         key_paths: Sequence[Path | str] = (),
                         host_key: Optional[bytes] = None,
                         require_gauntlet: bool = False,
                         require_conformance: bool = False,
                         runtime_versions: Optional[Mapping[str, str]] = None,
                         now=None) -> dict:
    """Route ONE request off the orchestration channel to the phase runner that
    serves it, and return that runner's response wire dict.

    This is the single dispatch both the in-process stub (:class:`InProcessTransport`)
    and the real `revl deploy-admit` runner process (:func:`deploy_admit_command`)
    share, so the stub tested on one host and the process a live transport spawns
    route identically: a commit-request (:data:`COMMIT_REQUEST_KIND`) goes to
    :func:`serve_commit_request`, and EVERYTHING ELSE goes to
    :func:`serve_admit_request`, which itself fail-closes on anything it cannot
    parse — so an unknown or malformed kind refuses rather than being silently
    mis-served (a commit mis-read as an admit would run a chain verify instead of
    a load-time measurement, and the reverse would skip the measurement).

    The host's trust configuration (`key_paths`, `host_key`, the evidence floor,
    `runtime_versions`) is the RUNNER's, never the request's (design S2.4): a
    request can ask for admission but never carry the trust that grants it.
    """
    kind = request_wire.get("kind") if isinstance(request_wire, Mapping) else None
    if kind == COMMIT_REQUEST_KIND:
        return serve_commit_request(request_wire, host_key=host_key,
                                    runtime_versions=runtime_versions, now=now)
    return serve_admit_request(request_wire, key_paths=key_paths,
                               host_key=host_key,
                               require_gauntlet=require_gauntlet,
                               require_conformance=require_conformance,
                               runtime_versions=runtime_versions, now=now)


class InProcessTransport:
    """The orchestration channel of §1.2, stubbed to run the runner IN THIS
    PROCESS — no second machine, no ssh, no subprocess. It stands in for the
    real SSH/scp transport so the whole PREPARE→COMMIT handshake is buildable
    and testable on one host; the live cross-machine transport is a following
    slice that implements the same `send` contract.

    `send` carries the request through its canonical wire form and carries the
    reply back the same way (`to_wire` -> json text -> `from_wire`), so the stub
    exercises the identical serialization a real transport puts on the channel —
    a field that does not survive json round-trips fails here, in a unit test,
    rather than on the wire between two machines. It holds the runner-side trust
    configuration (the host's keys and evidence floor), exactly the state a real
    far host owns and the conductor never sees.

    One channel carries BOTH phases, exactly as a real orchestration channel
    does: `send` dispatches on the request `kind`, routing an admit-request to
    :func:`serve_admit_request` (PREPARE) and a commit-request to
    :func:`serve_commit_request` (COMMIT). The COMMIT leg reuses the host's own
    signing key and runtime versions but NOT its trust store — the chain was
    verified at PREPARE, and COMMIT is a fresh load-time measurement, not a
    second chain check (design R2).
    """

    def __init__(self, *, key_paths: Sequence[Path | str] = (),
                 host_key: Optional[bytes] = None,
                 require_gauntlet: bool = False,
                 require_conformance: bool = False,
                 runtime_versions: Optional[Mapping[str, str]] = None) -> None:
        self._key_paths = list(key_paths)
        self._host_key = host_key
        self._require_gauntlet = require_gauntlet
        self._require_conformance = require_conformance
        self._runtime_versions = (dict(runtime_versions)
                                  if runtime_versions is not None else None)

    def send(self, request_wire: Mapping, *, now=None) -> dict:
        """Deliver one request to the runner and return its response wire dict.
        The json round trips are what make this a faithful stub and not just a
        function call: they are the bytes a real channel would carry.

        A commit-request is routed to the COMMIT runner; everything else goes to
        the PREPARE runner (which itself fail-closes on anything it cannot parse,
        so an unknown kind still refuses rather than being silently mis-served)."""
        on_far_side = json.loads(json.dumps(request_wire))
        response_wire = serve_deploy_request(
            on_far_side, key_paths=self._key_paths, host_key=self._host_key,
            require_gauntlet=self._require_gauntlet,
            require_conformance=self._require_conformance,
            runtime_versions=self._runtime_versions, now=now)
        return json.loads(json.dumps(response_wire))


#: The wire kind a :class:`ProcessRunnerTransport` synthesises when the runner
#: process is gone — it never comes off a runner, so `AdmitResponse.from_wire`
#: and `CommitResponse.from_wire` both reject it, turning a dead runner into the
#: same fail-closed :data:`LINK_TRANSPORT` refusal an unparseable reply already
#: is (a conductor must not read a vanished runner as a verdict).
_RUNNER_GONE_KIND = "revl.deploy.runner-terminated"


class ProcessRunnerTransport:
    """The orchestration channel of §1.2 over a real runner PROCESS, spoken to
    on its stdin/stdout with one newline-delimited JSON request per line and one
    reply per line — the shape :func:`deploy_admit_command` (`revl deploy-admit`)
    reads and writes, and the same newline-JSON control channel
    :mod:`revl._deploy_participant` already uses.

    This is the piece between :class:`InProcessTransport` (which runs the runner
    inside the conductor for a one-host test) and the deferred cross-machine leg
    (design R4/R5: scp/rsync staging, a pinned SSH host key). It spawns `argv`
    and speaks the identical protocol regardless of what `argv` is: locally
    :meth:`local` builds ``[python, -m, revl, deploy-admit, ...]`` so the far
    "host" is a child on this machine, and the machine boundary rides on top
    unchanged by prefixing the same command with ``ssh <host>``. The host's trust
    configuration lives entirely in `argv` (the runner's own key files and
    evidence floor), never in the request — the trust inversion S2.4 requires.

    One long-lived process carries BOTH phases (PREPARE admit-requests and COMMIT
    commit-requests), exactly as a real orchestration channel does; the runner
    routes each line by its `kind` (:func:`serve_deploy_request`). It is a
    context manager, and :meth:`close` reaps the child.

    `now` on :meth:`send` is a same-process time hook (for TTL/freshness tests)
    and cannot cross to the child, which measures against real time; the argument
    is accepted for interface parity with :class:`InProcessTransport` and ignored
    on this transport. A runner that dies rather than answering is not an error
    the conductor swallows: :meth:`send` returns a sentinel wire dict that every
    ``from_wire`` rejects, so :func:`request_admission` / :func:`request_commit`
    fail closed to a :data:`LINK_TRANSPORT` refusal.
    """

    def __init__(self, argv: Sequence[str], *, cwd: Optional[Path | str] = None,
                 env: Optional[Mapping[str, str]] = None) -> None:
        self._argv = list(argv)
        self._cwd = str(cwd) if cwd is not None else None
        self._env = dict(env) if env is not None else None
        self._proc: Optional[subprocess.Popen] = None

    @classmethod
    def local(cls, *, key_paths: Sequence[Path | str] = (),
              host_key_path: Optional[Path | str] = None,
              require_gauntlet: bool = False,
              require_conformance: bool = False,
              runtime_versions: Optional[Mapping[str, str]] = None,
              python: Optional[str] = None,
              env: Optional[Mapping[str, str]] = None) -> "ProcessRunnerTransport":
        """Build a transport that runs the `revl deploy-admit` runner as a LOCAL
        child (`python -m revl deploy-admit ...`).

        Key material is passed as FILE PATHS, never as bytes on the command line:
        a secret in `argv` shows up in `ps`, and the far host holds its keys on
        its own disk anyway (design R5). This is the conductor-side helper a
        `via = local` cross-process staging step would call; the SSH form is the
        same argv with an ``ssh <host>`` prefix and remote paths.
        """
        argv = [python or sys.executable, "-m", "revl", "deploy-admit"]
        for path in key_paths:
            argv += ["--key", str(path)]
        if host_key_path is not None:
            argv += ["--host-key", str(host_key_path)]
        if require_gauntlet:
            argv.append("--require-gauntlet")
        if require_conformance:
            argv.append("--require-conformance")
        for name, version in (runtime_versions or {}).items():
            argv += ["--runtime-version", f"{name}={version}"]
        return cls(argv, env=env)

    def __enter__(self) -> "ProcessRunnerTransport":
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    def _ensure(self) -> subprocess.Popen:
        if self._proc is None or self._proc.poll() is not None:
            self._proc = subprocess.Popen(  # noqa: S603 — argv is caller-built
                self._argv, cwd=self._cwd, env=self._env,
                stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                text=True, encoding="utf-8")
        return self._proc

    def send(self, request_wire: Mapping, *, now=None) -> dict:
        """Deliver one request line to the runner child and read one reply line.

        A child that has died, or answers with a closed pipe, is reported as the
        :data:`_RUNNER_GONE_KIND` sentinel rather than raising — a dead runner is
        a transport fault the conductor refuses on, not a crash it propagates.
        """
        del now  # cannot cross the process boundary; the child uses real time
        proc = self._ensure()
        if proc.stdin is None or proc.stdout is None:  # pragma: no cover — PIPE set above
            return {"kind": _RUNNER_GONE_KIND}
        try:
            proc.stdin.write(json.dumps(request_wire) + "\n")
            proc.stdin.flush()
        except (BrokenPipeError, ValueError):
            return {"kind": _RUNNER_GONE_KIND}
        line = proc.stdout.readline()
        if not line:
            return {"kind": _RUNNER_GONE_KIND}
        try:
            reply = json.loads(line)
        except json.JSONDecodeError:
            # A line that is not JSON is not a verdict; refuse it like a dead runner.
            return {"kind": _RUNNER_GONE_KIND}
        return reply if isinstance(reply, dict) else {"kind": _RUNNER_GONE_KIND}

    def close(self) -> None:
        """Close the channel and reap the runner child, if one was spawned."""
        proc, self._proc = self._proc, None
        if proc is None:
            return
        for stream in (proc.stdin, proc.stdout):
            try:
                if stream is not None:
                    stream.close()
            except OSError:  # pragma: no cover
                pass
        if proc.poll() is None:
            try:
                proc.terminate()
                proc.wait(timeout=10)
            except (OSError, subprocess.SubprocessError):  # pragma: no cover
                proc.kill()


def request_admission(transport, request: AdmitRequest, *, now=None) -> dict:
    """Conductor side of §1.3 steps 3–5: send `request` over `transport`,
    receive the runner's signed admission verdict, and CHECK that the runner
    answered THIS request — the `challenge` nonce must round-trip. Returns the
    admission receipt (ACCEPT or REFUSE); the caller verifies its signature
    against the host's known key with :func:`verify_receipt`, exactly as it
    would for a local :func:`admit`.

    A reply that does not echo the challenge, or that cannot be parsed as an
    :class:`AdmitResponse`, fails CLOSED to a :data:`LINK_TRANSPORT` REFUSE: a
    verdict the conductor cannot tie to the request it sent is not a verdict it
    may act on, so the deploy refuses with nothing staged to roll back.
    """
    try:
        response = AdmitResponse.from_wire(transport.send(request.to_wire(),
                                                          now=now))
    except ValueError as error:
        return _refusal(LINK_TRANSPORT,
                       f"the runner's reply could not be read as an admission "
                       f"response, so no verdict was received: {error}")
    if not hmac.compare_digest(response.challenge, request.challenge):
        return _refusal(
            LINK_TRANSPORT,
            "the runner's reply did not echo this request's challenge nonce "
            f"(sent {request.challenge[:12]}…, got "
            f"{response.challenge[:12]}…): a reply that is not bound to this "
            "request is refused rather than mistaken for an answer to it")
    return response.receipt


# ---------------------------------------------------------------------------
# §1.3 step 7 / R2 over the runner protocol. the COMMIT-phase handshake
# ---------------------------------------------------------------------------
#
# PREPARE (above) carries :func:`admit` over the orchestration channel; the load-
# measured COMMIT receipt (:func:`commit_receipt`) and the conductor's hard
# comparison of it (:func:`compare_commit_receipt`) were landed as LOCAL
# primitives, usable only when the conductor and the host shared a process. The
# design's Slice 2 names the remaining wiring precisely: *carrying it over the
# runner protocol*. That is this handshake — the COMMIT twin of §1.3 steps 3–5.
#
# The message shapes mirror the admit ones (dict in, dict out, a challenge nonce
# binding the reply to the request), and the two ends reuse the landed
# primitives unchanged: the runner side (:func:`serve_commit_request`) is
# :func:`commit_receipt` behind a fail-closed wire parse, and the conductor side
# (:func:`request_commit`) sends, binds the challenge, and then runs the landed
# :func:`compare_commit_receipt` gate. That last step is the whole point of the
# COMMIT twin existing at all: PREPARE returns a verdict the caller may or may
# not check, but COMMIT's comparison is design R2's HARD gate — a host that
# measured different bytes than it was admitted to load is caught HERE, at
# COMMIT, not merely at PREPARE's earlier verify. So :func:`request_commit`
# performs the comparison itself and answers `(ok, reason, receipt)`; `ok is
# False` REFUSES the deploy.

#: The two message kinds of the COMMIT-phase handshake. Domain-distinct from the
#: admit kinds and from :data:`RECEIPT_KIND`, so a COMMIT request can never be
#: read as an admit request (which would run a chain verify instead of a
#: measurement) or as a receipt; `from_wire` refuses any other value.
COMMIT_REQUEST_KIND = "revl.deploy.commit-request"
COMMIT_RESPONSE_KIND = "revl.deploy.commit-response"

#: Protocol version of the COMMIT envelope, independent of the admit one so
#: either phase's shape can move without silently changing the other's meaning.
COMMIT_PROTOCOL_VERSION = "1.0"


@dataclass(frozen=True)
class CommitRequest:
    """The conductor's COMMIT request to a remote deploy-admit runner (§1.3 step
    7). It names the STAGED bundle path on the runner's own filesystem and the
    `backend` the host will load, and carries a `challenge` nonce the runner
    echoes so the conductor can bind the reply to THIS request.

    It carries NO admitted hash: an echo of what PREPARE bound would defeat the
    entire purpose of the load-time measurement (design R2), so the request asks
    the host to MEASURE, never tells it what it should have measured. The
    conductor holds the admission receipt and does the comparison itself
    (:func:`request_commit`)."""

    bundle: str
    backend: str
    challenge: str

    def to_wire(self) -> dict:
        return {"kind": COMMIT_REQUEST_KIND,
                "version": COMMIT_PROTOCOL_VERSION,
                "bundle": self.bundle,
                "backend": self.backend,
                "challenge": self.challenge}

    @classmethod
    def from_wire(cls, wire: Mapping) -> "CommitRequest":
        """Parse a COMMIT request off the wire, fail-closed — same discipline as
        :meth:`AdmitRequest.from_wire`."""
        if not isinstance(wire, Mapping):
            raise ValueError("commit request is not a mapping")
        if wire.get("kind") != COMMIT_REQUEST_KIND:
            raise ValueError(
                f"not a {COMMIT_REQUEST_KIND} record: kind is "
                f"{wire.get('kind')!r}")
        if wire.get("version") != COMMIT_PROTOCOL_VERSION:
            raise ValueError(
                f"commit request version is {wire.get('version')!r}, expected "
                f"{COMMIT_PROTOCOL_VERSION!r}")
        bundle = wire.get("bundle")
        backend = wire.get("backend")
        challenge = wire.get("challenge")
        for name, value in (("bundle", bundle), ("backend", backend),
                            ("challenge", challenge)):
            if not isinstance(value, str) or not value:
                raise ValueError(
                    f"commit request {name!r} must be a non-empty string, got "
                    f"{value!r}")
        return cls(bundle=bundle, backend=backend, challenge=challenge)


@dataclass(frozen=True)
class CommitResponse:
    """The runner's COMMIT reply: the signed `receipt` (a COMMITTED load-time
    measurement from :func:`commit_receipt`, or a REFUSE when the host could not
    measure the bytes it was to load) plus the `challenge` echoed back."""

    receipt: dict
    challenge: str

    def to_wire(self) -> dict:
        return {"kind": COMMIT_RESPONSE_KIND,
                "version": COMMIT_PROTOCOL_VERSION,
                "challenge": self.challenge,
                "receipt": dict(self.receipt)}

    @classmethod
    def from_wire(cls, wire: Mapping) -> "CommitResponse":
        """Parse a COMMIT response off the wire, fail-closed — same discipline as
        :meth:`AdmitResponse.from_wire`."""
        if not isinstance(wire, Mapping):
            raise ValueError("commit response is not a mapping")
        if wire.get("kind") != COMMIT_RESPONSE_KIND:
            raise ValueError(
                f"not a {COMMIT_RESPONSE_KIND} record: kind is "
                f"{wire.get('kind')!r}")
        if wire.get("version") != COMMIT_PROTOCOL_VERSION:
            raise ValueError(
                f"commit response version is {wire.get('version')!r}, expected "
                f"{COMMIT_PROTOCOL_VERSION!r}")
        receipt = wire.get("receipt")
        challenge = wire.get("challenge")
        if not isinstance(receipt, Mapping):
            raise ValueError("commit response carries no receipt mapping")
        if not isinstance(challenge, str) or not challenge:
            raise ValueError("commit response carries no challenge")
        return cls(receipt=dict(receipt), challenge=challenge)


def serve_commit_request(request_wire: Mapping, *,
                         host_key: Optional[bytes] = None,
                         runtime_versions: Optional[Mapping[str, str]] = None,
                         now=None) -> dict:
    """Runner side of §1.3 step 7: read one COMMIT request off the orchestration
    channel and answer with a signed load-time measurement of the exact bytes it
    is about to hand the runtime (:func:`commit_receipt`). Returns a response
    WIRE dict; the transport moves it, the conductor reads it with
    :meth:`CommitResponse.from_wire`.

    Unlike PREPARE, COMMIT runs NO chain verify and needs no trust store: the
    chain was verified at admission, and this is a fresh measurement, not a
    second check (design R2). What it does need is the host's OWN signing key —
    the receipt is a claim the host signs so a later audit can ATTRIBUTE a lie
    about what it loaded (R2/R5). With no `host_key` there is no key to make that
    claim attributable, so it REFUSES rather than returning an unsigned "COMMIT".

    Fails CLOSED throughout:

      * a request the runner cannot parse is a :data:`LINK_TRANSPORT` REFUSE — a
        runner that could not read what it was asked to commit must not commit;
      * a bundle whose staged bytes cannot be measured (a missing or un-digestible
        artifact, an unreadable IR) is a local COMMIT failure, reported as a
        :data:`LINK_ARTIFACT` REFUSE — "a host that cannot measure what it loads
        has not committed, and must report a local COMMIT failure, never a
        COMMITTED receipt" (:func:`commit_receipt`).
    """
    try:
        request = CommitRequest.from_wire(request_wire)
    except ValueError as error:
        challenge = ""
        if isinstance(request_wire, Mapping):
            got = request_wire.get("challenge")
            challenge = got if isinstance(got, str) else ""
        receipt = _refusal(LINK_TRANSPORT,
                           f"the deploy commit request could not be parsed, so "
                           f"nothing was committed: {error}")
        return CommitResponse(receipt=receipt, challenge=challenge).to_wire()

    if host_key is None:
        receipt = _refusal(
            LINK_TRANSPORT,
            "the runner holds no signing key, so it cannot mint an attributable "
            "load-time measurement; a COMMIT the conductor could not pin to the "
            "host's key is refused rather than returned unsigned")
        return CommitResponse(receipt=receipt,
                              challenge=request.challenge).to_wire()

    try:
        receipt = commit_receipt(request.bundle, backend=request.backend,
                                 host_key=host_key,
                                 runtime_versions=runtime_versions, now=now)
    except RevlError as error:
        receipt = _refusal(
            LINK_ARTIFACT,
            f"the host could not measure the bytes it was to load at COMMIT, so "
            f"it has NOT committed: {error}")
    return CommitResponse(receipt=receipt,
                          challenge=request.challenge).to_wire()


def request_commit(transport, request: CommitRequest, *,
                   admission_receipt: Mapping, host_key: bytes,
                   now=None) -> tuple[bool, str, dict]:
    """Conductor side of §1.3 step 7: send a COMMIT `request` over `transport`,
    receive the host's signed load-time measurement, CHECK that it answers THIS
    request (the `challenge` must round-trip), and run design R2's HARD gate over
    it. Answers `(ok, reason, receipt)`; `ok is False` REFUSES the deploy.

    This is the COMMIT twin of :func:`request_admission`, but with the
    comparison folded in on purpose. PREPARE returns a verdict the caller checks
    at its discretion; COMMIT's comparison is not discretionary — it is the gate
    that turns "the host loaded different bytes than it was admitted to load"
    from undetectable into DETECTABLE (design R2 / §5-A2). So this function does
    not merely fetch the COMMIT receipt: it compares it, with
    :func:`compare_commit_receipt`, against the `admission_receipt` the host
    signed in PREPARE, using the host's own key.

    Fails CLOSED before ever reaching the gate: a reply that cannot be parsed as
    a :class:`CommitResponse`, or one whose challenge does not echo, is a
    :data:`LINK_TRANSPORT` refusal (`ok is False`) — a measurement the conductor
    cannot tie to the request it sent is not one it may commit on. The `receipt`
    element of the triple is then the transport refusal, so a caller always has a
    structured record of why the COMMIT did not stand.
    """
    try:
        response = CommitResponse.from_wire(transport.send(request.to_wire(),
                                                           now=now))
    except ValueError as error:
        refusal = _refusal(LINK_TRANSPORT,
                          f"the runner's reply could not be read as a commit "
                          f"response, so no load-time measurement was received: "
                          f"{error}")
        return False, refusal["reason"], refusal
    if not hmac.compare_digest(response.challenge, request.challenge):
        refusal = _refusal(
            LINK_TRANSPORT,
            "the runner's commit reply did not echo this request's challenge "
            f"nonce (sent {request.challenge[:12]}…, got "
            f"{response.challenge[:12]}…): a measurement that is not bound to "
            "this request is refused rather than mistaken for an answer to it")
        return False, refusal["reason"], refusal
    ok, reason = compare_commit_receipt(admission_receipt, response.receipt,
                                        host_key=host_key)
    return ok, reason, response.receipt


# ---------------------------------------------------------------------------
# §1.2 / R4. the live cross-machine runner transport (SSH) — slice 1
# ---------------------------------------------------------------------------
#
# :class:`InProcessTransport` ran the runner IN THIS PROCESS. The design's live
# leg (§1.2, the [REMAINS] "live cross-machine transport") spawns `revl
# deploy-admit` on the far host and speaks the SAME `send` contract over its
# stdin/stdout — one JSON request line in, one JSON response line back. This is
# the FOUNDATIONAL first slice of that leg: the process/ssh transport itself and,
# the piece R4 turns on, a PINNED host-key verification that fails CLOSED.
#
# What this slice builds:
#   * :meth:`StdioRunnerTransport.local` -> `python -m revl deploy-admit`, a
#     child of THIS host: the same runner the in-process stub ran, now behind a
#     real pipe so the wire bytes are exercised end to end;
#   * :meth:`StdioRunnerTransport.ssh` -> `ssh <opts> <host> revl deploy-admit`,
#     with host-key checking PINNED to a `known_hosts` file and
#     `StrictHostKeyChecking=yes` / `BatchMode=yes` forced on. R4's whole point:
#     a network MITM that impersonates the target host is refused at connect, so
#     the A2 blast-radius argument holds. `StrictHostKeyChecking=no` (and its
#     `accept-new` trust-on-first-use cousin) is the exact hole this transport
#     exists to close, so it is REFUSED, never offered as a caller option.
#
# The same `send` contract means the conductor-side drivers written for the stub
# — :func:`request_admission`, :func:`request_commit` and their challenge/gate
# discipline — carry over UNCHANGED; only the seam the bytes cross is different.
# A transport-level fault (a spawn that fails, a timeout, a host-key refusal, a
# reply that is not JSON) fails CLOSED to a :data:`LINK_TRANSPORT` REFUSE that
# echoes the request's challenge, so the existing drivers read it as a refusal to
# act on rather than a verdict — a runner the conductor could not reach is never
# mistaken for one that admitted.
#
# Deliberately NOT here, and named so the boundary stays explicit (all §1.2 /
# [REMAINS] or Deferred): STAGING the sliced bundle over scp/rsync (this slice
# assumes the bundle is already staged at the path the request names), the mTLS
# staging identity (R5), the replicated WAL, the partition-safe distributed
# commit coordinator and its two-phase commit/ABORT over > 1 host (S3), the
# container/microVM transport, and the Ed25519 migration a genuinely
# cross-trust-domain deploy needs (S2.4 / S5-A1).

#: The subcommand the far host exposes as the runner. The conductor never trusts
#: it to admit; it ASKS, and the host answers against its OWN trust store (S2.4).
DEPLOY_ADMIT_SUBCOMMAND = "deploy-admit"

#: `ssh` options this transport forces on and a caller may never countermand:
#: `StrictHostKeyChecking=yes` refuses BOTH an unknown host (no trust-on-first-
#: use) and a host whose key does not match the pinned `known_hosts`;
#: `BatchMode=yes` makes ssh ERROR instead of blocking on an interactive prompt.
SSH_PINNED_OPTIONS = ("StrictHostKeyChecking=yes", "BatchMode=yes")

#: The `ssh -o` keys this transport OWNS. A caller-supplied option that sets
#: either is refused: host-key checking and the pinned file are the transport's
#: to set, and a caller that could re-set them could loosen the pin (R4).
_SSH_RESERVED_OPTION_KEYS = frozenset(
    {"stricthostkeychecking", "userknownhostsfile"})

#: Substrings ssh prints when host-key verification fails. Matched (lower-cased)
#: so a changed or unverifiable host key on the wire is reported as the R4 event
#: it is — a possible impersonation — and not as a generic non-zero exit.
_SSH_HOST_KEY_MARKERS = (
    "host key verification failed",
    "remote host identification has changed",
    "no matching host key",
    "differs from the key for the ip address",
    "host key for ",
)


class SshRunnerRefused(RevlError):
    """A runner transport refused to complete an exchange, fail-closed.

    `host_key_failure` is set when the cause was host-key verification: a
    missing / empty / unmatched pin caught BEFORE the connection, or ssh
    reporting a changed or unverifiable host key ON the connection. That is R4's
    event — a possible impersonation of the target host, refused rather than
    served. It is surfaced on the :data:`LINK_TRANSPORT` refusal receipt so an
    audit can tell a host-key refusal apart from an ordinary unreachable runner.
    """

    def __init__(self, message: str, *, host_key_failure: bool = False):
        super().__init__("ssh-runner-transport", 0, message)
        self.host_key_failure = host_key_failure


def _hostname_for_known_hosts(host: str) -> str:
    """The bare hostname ssh records in `known_hosts`: the `user@` prefix is the
    login the operator authenticates as, not part of the host key's identity."""
    return host.split("@", 1)[1] if "@" in host else host


def _known_hosts_pin(path: Path, hostname: str,
                     port: Optional[int]) -> tuple[bool, str]:
    """Fail-closed pre-flight: does `path` pin a host key for `hostname`?

    Distinct from ssh's own check on purpose: ssh would refuse an unpinned host
    at connect time, but a LOCATED refusal here — before a single byte crosses —
    is clearer and testable without a live remote. Plaintext entries are matched
    by name (and by the `[host]:port` spelling ssh uses for a non-default port);
    a HASHED `known_hosts` cannot be matched by name, so its presence is treated
    as "pinned, ssh will verify at connect" rather than guessed at — refusing a
    legitimately hashed pin would be worse than deferring to ssh's own check.
    Answers `(ok_to_proceed, reason)`.
    """
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError as error:
        return False, f"cannot read the pinned known_hosts {path}: {error}"
    tokens = {hostname}
    tokens.add(f"[{hostname}]:{port}" if port and port != 22
               else f"[{hostname}]:22")
    saw_plaintext = False
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        fields = line.split()
        patterns = fields[0]
        # `@cert-authority` / `@revoked` markers push the patterns to field 1.
        if patterns.startswith("@") and len(fields) > 1:
            patterns = fields[1]
        if patterns.startswith("|"):
            # A hashed entry: name-matching is impossible, so defer to ssh.
            return True, ("the pinned known_hosts holds hashed entries; ssh "
                          "verifies the host key against it at connect")
        saw_plaintext = True
        if any(pattern in tokens for pattern in patterns.split(",")):
            return True, "a host key is pinned for this host"
    if not saw_plaintext:
        return False, (f"the pinned known_hosts {path} carries no host-key "
                       "entries (it is empty or all comments); refusing to ssh "
                       "with no pin rather than trusting on first use")
    return False, (f"the pinned known_hosts {path} carries no entry for "
                   f"{hostname!r}; refusing to ssh with no pinned host key for "
                   "this host rather than trusting on first use")


class StdioRunnerTransport:
    """A runner transport that spawns `revl deploy-admit` behind a stdio pipe and
    speaks the same `send(request_wire, *, now=None) -> dict` contract as
    :class:`InProcessTransport`.

    Two shapes, both the same one process-boundary wire:

      * :meth:`local` runs the runner as a child of THIS host
        (`python -m revl deploy-admit`) — useful for exercising the real pipe
        and for a single-host deploy whose "far" side is another local process;
      * :meth:`ssh` runs it on a remote host (`ssh <opts> <host> revl
        deploy-admit`) with host-key checking pinned to a `known_hosts` file and
        `StrictHostKeyChecking=yes` / `BatchMode=yes` forced on (R4). The pin is
        checked twice over: a located pre-flight (:meth:`verify_host_key`) before
        anything is spawned, and ssh's own connect-time check against the same
        file. A caller may ADD `-o` options but may never set the two keys this
        transport owns (:data:`_SSH_RESERVED_OPTION_KEYS`), so the pin cannot be
        loosened through the option list.

    `send` writes the request as one JSON line to the child's stdin and reads its
    reply as JSON from stdout — the identical bytes a real orchestration channel
    carries. Every transport-level fault fails CLOSED to a :data:`LINK_TRANSPORT`
    REFUSE (with the request's `challenge` echoed so the existing conductor-side
    drivers bind and reject it), never to a raised exception the caller must
    remember to catch.
    """

    def __init__(self, argv: Sequence[str], *, host: Optional[str] = None,
                 known_hosts: Optional[Path | str] = None,
                 is_ssh: bool = False, port: Optional[int] = None,
                 timeout: float = 30.0) -> None:
        self._argv = [str(a) for a in argv]
        self._host = host
        self._known_hosts = Path(known_hosts) if known_hosts is not None else None
        self._is_ssh = bool(is_ssh)
        self._port = port
        self._timeout = float(timeout)

    # -- constructors -------------------------------------------------------

    @classmethod
    def local(cls, *, python: Optional[str] = None,
              extra_args: Sequence[str] = (), timeout: float = 30.0
              ) -> "StdioRunnerTransport":
        """The runner as a local child process: `python -m revl deploy-admit`."""
        exe = python or sys.executable
        argv = [exe, "-m", "revl", DEPLOY_ADMIT_SUBCOMMAND, *extra_args]
        return cls(argv, timeout=timeout)

    @classmethod
    def ssh(cls, host: str, *, known_hosts: Path | str,
            ssh_exe: str = "ssh", remote_revl: str = "revl",
            port: Optional[int] = None, options: Sequence[str] = (),
            extra_args: Sequence[str] = (), timeout: float = 30.0
            ) -> "StdioRunnerTransport":
        """The runner on a remote host over ssh, with a PINNED host key (R4).

        `known_hosts` is REQUIRED: host-key checking is never disabled here, so
        there must be a pinned key to check against. `options` are extra `ssh -o`
        settings the caller may add, but never `StrictHostKeyChecking` or
        `UserKnownHostsFile` — those are the transport's, and re-setting them is
        how the pin would be loosened, so an attempt to is refused.
        """
        if not isinstance(host, str) or not host:
            raise ValueError("an ssh runner transport needs a non-empty host")
        if known_hosts is None:
            raise ValueError(
                "an ssh runner transport requires a pinned known_hosts file: "
                "host-key checking is never disabled, so there must be a pinned "
                "key to verify the host against (R4)")
        opts: list[str] = []
        for pinned in SSH_PINNED_OPTIONS:
            opts += ["-o", pinned]
        opts += ["-o", f"UserKnownHostsFile={Path(known_hosts)}"]
        for opt in options:
            key = str(opt).split("=", 1)[0].strip().lower()
            if key in _SSH_RESERVED_OPTION_KEYS:
                raise ValueError(
                    f"the ssh option {opt!r} would re-set a host-key setting "
                    "this transport pins; it is refused rather than allowed to "
                    "loosen the pin (R4 forbids StrictHostKeyChecking=no)")
            opts += ["-o", str(opt)]
        if port is not None:
            opts += ["-p", str(int(port))]
        argv = [ssh_exe, *opts, host, remote_revl, DEPLOY_ADMIT_SUBCOMMAND,
                *extra_args]
        return cls(argv, host=host, known_hosts=Path(known_hosts), is_ssh=True,
                   port=port, timeout=timeout)

    # -- introspection (pinned so a test can assert the argv it will run) ---

    @property
    def argv(self) -> list[str]:
        return list(self._argv)

    # -- host-key verification ---------------------------------------------

    def verify_host_key(self) -> None:
        """Fail-closed pre-flight for the pinned host key (R4). A no-op for a
        local transport; for ssh it refuses — before anything is spawned — when
        the pinned `known_hosts` is missing, unreadable, empty, or carries no
        entry for this host. Raises :class:`SshRunnerRefused` with
        `host_key_failure=True`; ssh's own connect-time check is the second,
        independent gate against the same file."""
        if not self._is_ssh:
            return
        path = self._known_hosts
        if path is None or not path.exists():
            raise SshRunnerRefused(
                f"the pinned known_hosts {path} does not exist; refusing to ssh "
                "with no pinned host key rather than trusting on first use (R4)",
                host_key_failure=True)
        if not path.is_file():
            raise SshRunnerRefused(
                f"the pinned known_hosts {path} is not a regular file, so it is "
                "not a host-key pin this transport can stand on",
                host_key_failure=True)
        hostname = _hostname_for_known_hosts(self._host or "")
        ok, reason = _known_hosts_pin(path, hostname, self._port)
        if not ok:
            raise SshRunnerRefused(reason, host_key_failure=True)

    # -- the send() contract ------------------------------------------------

    def send(self, request_wire: Mapping, *, now=None) -> dict:
        """Deliver one request to the runner and return its response wire dict.
        `now` is accepted for contract parity with :class:`InProcessTransport`
        and is not sent over the wire — the far runner keeps its own clock."""
        kind = (request_wire.get("kind")
                if isinstance(request_wire, Mapping) else None)
        try:
            if not isinstance(request_wire, Mapping):
                raise SshRunnerRefused(
                    "the request is not a mapping, so it cannot be sent to the "
                    "runner")
            if self._is_ssh:
                self.verify_host_key()
            return self._exchange(json.dumps(dict(request_wire)))
        except SshRunnerRefused as error:
            return self._refusal_response(
                kind, request_wire, error.message,
                host_key_failure=error.host_key_failure)

    def _exchange(self, payload: str) -> dict:
        try:
            completed = subprocess.run(
                self._argv, input=payload + "\n", capture_output=True,
                text=True, timeout=self._timeout)
        except FileNotFoundError as error:
            raise SshRunnerRefused(
                f"the runner command {self._argv[0]!r} could not be launched: "
                f"{error}") from None
        except subprocess.TimeoutExpired:
            raise SshRunnerRefused(
                f"the runner did not reply within {self._timeout:.0f}s; the "
                "exchange is refused rather than left hanging") from None
        except OSError as error:
            raise SshRunnerRefused(
                f"the runner command {self._argv[0]!r} could not be launched: "
                f"{error}") from None
        if completed.returncode != 0:
            stderr = (completed.stderr or "").strip()
            host_key = self._is_ssh and _looks_like_host_key_failure(
                completed.returncode, stderr)
            raise SshRunnerRefused(
                f"the runner exited {completed.returncode}: "
                f"{stderr or '(no stderr)'}", host_key_failure=bool(host_key))
        out = (completed.stdout or "").strip()
        if not out:
            raise SshRunnerRefused(
                "the runner produced no output on stdout, so there is no verdict "
                "to read")
        parsed = _first_json_object(out)
        if parsed is None:
            raise SshRunnerRefused(
                "the runner's reply was not a JSON object the transport could "
                f"read: {out[:200]!r}")
        return parsed

    def _refusal_response(self, kind, request_wire, reason: str, *,
                          host_key_failure: bool = False) -> dict:
        challenge = ""
        if isinstance(request_wire, Mapping):
            got = request_wire.get("challenge")
            if isinstance(got, str):
                challenge = got
        extra = {"host_key_failure": True} if host_key_failure else {}
        receipt = _refusal(LINK_TRANSPORT, reason, **extra)
        if kind == COMMIT_REQUEST_KIND:
            return CommitResponse(receipt=receipt, challenge=challenge).to_wire()
        return AdmitResponse(receipt=receipt, challenge=challenge).to_wire()


def _looks_like_host_key_failure(returncode: int, stderr: str) -> bool:
    """Whether an ssh non-zero exit is a host-key verification failure. ssh exits
    255 on connection errors generally, so the exit code alone is not proof; the
    stderr markers are what tell an impersonation apart from an ordinary
    unreachable host."""
    low = stderr.lower()
    return any(marker in low for marker in _SSH_HOST_KEY_MARKERS)


def _first_json_object(text: str) -> Optional[dict]:
    """The first JSON OBJECT in `text`, tolerant of a leading ssh banner line.
    The runner writes one JSON line; a login banner or motd on the channel would
    otherwise make the whole capture unparseable."""
    try:
        whole = json.loads(text)
        return whole if isinstance(whole, dict) else None
    except (json.JSONDecodeError, ValueError):
        pass
    for line in text.splitlines():
        line = line.strip()
        if not line.startswith("{"):
            continue
        try:
            candidate = json.loads(line)
        except (json.JSONDecodeError, ValueError):
            continue
        if isinstance(candidate, dict):
            return candidate
    return None


# ---------------------------------------------------------------------------
# §1.3 step 2. staging the attested bundle onto the far host (R4/R5)
# ---------------------------------------------------------------------------
#
# PREPARE and COMMIT verify bytes on the RUNNER's own disk, which means the bytes
# have to get there first. Staging is that step, and it rides the SAME pinned-
# host-key ssh identity the runner transport uses (`scp` here, the ssh companion
# tool): `StrictHostKeyChecking=yes` / `BatchMode=yes` forced on and the pinned
# `UserKnownHostsFile`, none of which a caller may loosen. It is a copy, not a
# trust anchor: nothing it moves is believed until the runner RE-HASHES it under
# the attestation chain, so a byte that changes in transit is caught at PREPARE
# on the far side, not here. The `scp_exe` seam mirrors `StdioRunnerTransport`'s
# `ssh_exe` so the whole path is unit-testable through a shim, no live remote.


class BundleStageRefused(RevlError):
    """Staging the attested bundle onto the far host failed, fail-closed.

    `host_key_failure` is set when the cause was host-key verification on the
    stage channel — the same R4 event the runner transport marks — so a deploy
    that could not even copy the bundle under a pinned key refuses audibly rather
    than proceeding to a PREPARE it has nothing staged for."""

    def __init__(self, message: str, *, host_key_failure: bool = False):
        super().__init__("bundle-stage", 0, message)
        self.host_key_failure = host_key_failure


def stage_bundle_over_ssh(local_bundle: Path | str, *, host: str,
                          remote_bundle: str, known_hosts: Path | str,
                          scp_exe: str = "scp", port: Optional[int] = None,
                          options: Sequence[str] = (),
                          extra_args: Sequence[str] = (),
                          timeout: float = 60.0) -> str:
    """Copy the attested bundle DIRECTORY `local_bundle` to `remote_bundle` on
    `host` over scp, under the pinned host key `known_hosts` (design §1.3 step 2,
    R4/R5). Returns the remote bundle path on success; raises
    :class:`BundleStageRefused` fail-closed on any failure.

    The pin is the runner transport's pin: `StrictHostKeyChecking=yes` and
    `BatchMode=yes` are forced on and the pinned `UserKnownHostsFile` is set, and
    an `options` entry that would re-set either is refused rather than allowed to
    loosen it. `scp_exe` is the injectable seam (a shim standing in for `scp`);
    the source and destination are the LAST two argv words so a shim can read
    them positionally regardless of the option list before them.

    Staging is not a trust step: the runner re-hashes what lands (`admit` /
    `commit_receipt`), so this never verifies bytes itself — a corruption in
    transit is the far side's PREPARE refusal, not a check here.
    """
    src = Path(local_bundle)
    if not src.is_dir():
        raise BundleStageRefused(
            f"the attested bundle {src} is not a directory on this host, so "
            f"there is nothing to stage to {host!r}")
    if not isinstance(host, str) or not host:
        raise BundleStageRefused("staging needs a non-empty ssh host")
    if not isinstance(remote_bundle, str) or not remote_bundle:
        raise BundleStageRefused(
            "staging needs a non-empty `remote_bundle` destination path on the "
            "far host")
    kh = Path(known_hosts)
    if not kh.is_file():
        raise BundleStageRefused(
            f"the pinned known_hosts {kh} is not a readable file; refusing to "
            "stage the bundle with no pinned host key rather than trusting the "
            "host on first use (R4)", host_key_failure=True)
    ok, reason = _known_hosts_pin(kh, _hostname_for_known_hosts(host), port)
    if not ok:
        raise BundleStageRefused(reason, host_key_failure=True)

    opts: list[str] = []
    for pinned in SSH_PINNED_OPTIONS:
        opts += ["-o", pinned]
    opts += ["-o", f"UserKnownHostsFile={kh}"]
    for opt in options:
        key = str(opt).split("=", 1)[0].strip().lower()
        if key in _SSH_RESERVED_OPTION_KEYS:
            raise BundleStageRefused(
                f"the scp option {opt!r} would re-set a host-key setting the "
                "stage step pins; it is refused rather than allowed to loosen "
                "the pin (R4 forbids StrictHostKeyChecking=no)")
        opts += ["-o", str(opt)]
    if port is not None:
        opts += ["-P", str(int(port))]
    # `-r` recurses the bundle directory; source and destination are last so a
    # shim reads them as argv[-2] and argv[-1].
    argv = [scp_exe, *opts, *[str(a) for a in extra_args], "-r",
            str(src), f"{host}:{remote_bundle}"]
    try:
        completed = subprocess.run(  # noqa: S603 — argv built above, no shell
            argv, capture_output=True, text=True, timeout=timeout)
    except FileNotFoundError as error:
        raise BundleStageRefused(
            f"the stage command {scp_exe!r} could not be launched: "
            f"{error}") from None
    except subprocess.TimeoutExpired:
        raise BundleStageRefused(
            f"staging the bundle to {host!r} did not finish within "
            f"{timeout:.0f}s; the deploy is refused rather than left hanging"
            ) from None
    except OSError as error:
        raise BundleStageRefused(
            f"the stage command {scp_exe!r} could not be launched: "
            f"{error}") from None
    if completed.returncode != 0:
        stderr = (completed.stderr or "").strip()
        host_key = _looks_like_host_key_failure(completed.returncode, stderr)
        raise BundleStageRefused(
            f"staging the bundle to {host}:{remote_bundle} failed (scp exited "
            f"{completed.returncode}: {stderr or '(no stderr)'})",
            host_key_failure=bool(host_key))
    return remote_bundle


# ---------------------------------------------------------------------------
# §1.4. distributed effect correlation, authenticated against the peer
# ---------------------------------------------------------------------------

CORRELATION_FIELD = "correlation"
AUTH_FIELD = "auth"

#: Why a correlation envelope was rejected. Distinct reasons, because they are
#: distinct attacks: a peer speaking under someone else's name, a peer replaying
#: an envelope, a peer this receiver has no identity for.
REJECT_MALFORMED = "malformed-envelope"
REJECT_UNKNOWN_PEER = "unknown-peer"
REJECT_FORGED = "forged-envelope"
REJECT_PEER_MISMATCH = "peer-identity-mismatch"
REJECT_DUPLICATE = "duplicate-envelope"


@dataclass(frozen=True)
class Correlation:
    """The identity every call crossing a seam carries (§1.4).

    `peer_identity` is the item-55 per-process identity of the CALLER — the
    same token the mTLS certificate is minted for on a network seam. It is part
    of the envelope because dedup is scoped BY it (Addendum 3b): one peer's
    idempotency key namespace is not another's, so a peer can neither collide
    with nor replay a sibling's crossing.
    """

    composition_id: str
    generation: int
    peer_identity: str
    effect_id: str
    realm: str | None = None
    idempotency_key: str | None = None
    parent_effect: str | None = None

    def to_wire(self) -> dict:
        return {"composition_id": self.composition_id,
                "generation": int(self.generation),
                "peer_identity": self.peer_identity,
                "effect_id": self.effect_id,
                "realm": self.realm,
                "idempotency_key": self.idempotency_key,
                "parent_effect": self.parent_effect}

    @classmethod
    def from_wire(cls, wire: Mapping) -> "Correlation":
        key = wire.get("idempotency_key")
        if key is not None and not isinstance(key, str):
            # The idempotency key is half of a dedup scope, and a scope is a
            # dict key. A peer-supplied list or object would raise
            # `unhashable type` inside the ledger — past every caller written
            # to read an `(ok, reason)` verdict, taking the seam down instead
            # of refusing one envelope (roadmap 428 F10's class). It has no
            # scope, so it is malformed, and both guards already turn a
            # `TypeError` here into that refusal.
            raise TypeError("idempotency_key must be a string or absent")
        return cls(composition_id=str(wire["composition_id"]),
                   generation=int(wire["generation"]),
                   peer_identity=str(wire["peer_identity"]),
                   effect_id=str(wire["effect_id"]),
                   realm=wire.get("realm"),
                   idempotency_key=key,
                   parent_effect=wire.get("parent_effect"))

    def dedup_key(self) -> tuple:
        """The scope duplicate detection runs on: `(peer_identity,
        composition_id, generation, idempotency_key)` — exactly the tuple the
        design's binding rule names, no wider and no narrower."""
        return (self.peer_identity, self.composition_id,
                int(self.generation), self.idempotency_key)


def _envelope_bytes(wire: Mapping) -> bytes:
    """Canonical bytes of an envelope, excluding its own auth tag. Literally
    `attest._canonical_bytes`, so the tag is a pure function of the envelope's
    content and not of member order — and so an envelope with no canonical
    spelling raises `attest.NotCanonicalizable` here rather than a raw
    `UnicodeEncodeError` out of a guard whose contract is `(ok, reason)`
    (roadmap 428 F10). This used to inline the same `json.dumps`, which is how
    the two copies drifted into having the same defect twice."""
    return attest._canonical_bytes({k: v for k, v in wire.items()
                                    if k != AUTH_FIELD})


def seal(correlation: Correlation, secret: bytes) -> dict:
    """The wire envelope with its authentication tag: HMAC over the canonical
    envelope bytes under the CALLER's own per-process secret.

    That secret is what makes `peer_identity` a claim the receiver can check
    rather than a string the caller chose. On a network seam the mTLS peer
    certificate authenticates the same identity independently, and
    :meth:`CorrelationGuard.admit` requires the two to agree — so a leaked
    secret still cannot speak from the wrong TLS session, and a valid TLS
    session still cannot speak under another process's name.
    """
    wire = correlation.to_wire()
    wire[AUTH_FIELD] = hmac.new(bytes(secret), _envelope_bytes(wire),
                                hashlib.sha256).hexdigest()
    return wire


class DedupLedger:
    """Seen `(peer_identity, composition_id, generation, idempotency_key)`
    tuples. An envelope with no idempotency key is not deduplicated — there is
    nothing declaring the call re-deliverable (item 309), so silently dropping
    a repeat would be a guess."""

    def __init__(self) -> None:
        self._seen: set = set()

    def admit(self, correlation: Correlation) -> bool:
        """True the first time this scope is seen, False on a replay."""
        if correlation.idempotency_key is None:
            return True
        key = correlation.dedup_key()
        if key in self._seen:
            return False
        self._seen.add(key)
        return True

    def seen(self, correlation: Correlation) -> bool:
        return correlation.dedup_key() in self._seen

    def __len__(self) -> int:
        return len(self._seen)


class CorrelationGuard:
    """What a provider runs on every seam request before it dispatches.

    Holds the identity -> secret table the conductor distributed (one secret per
    process, in that process's spec, owner-only) and a :class:`DedupLedger`. It
    answers `(ok, reason)`; a provider turns a `False` into an error reply and
    never reaches the service.
    """

    def __init__(self, secrets: Mapping[str, bytes],
                 ledger: Optional[DedupLedger] = None) -> None:
        self._secrets = dict(secrets)
        self.ledger = ledger if ledger is not None else DedupLedger()

    def admit(self, wire: Any, *, transport_identity: str | None = None
              ) -> tuple[bool, str]:
        """Authenticate one envelope and check it is not a replay.

        Four gates, in the order that makes each meaningful:

          1. **shape** — an envelope missing a required member is refused, not
             defaulted;
          2. **known peer** — an identity this receiver holds no secret for
             cannot be authenticated, so it is refused rather than trusted;
          3. **authenticity** — the tag must verify under THAT peer's secret,
             and, when the transport authenticated an identity of its own (the
             mTLS peer certificate), the two must agree. Either half alone is
             forgeable by the other's holder; both together are not;
          4. **freshness** — a replay of an already-seen
             `(peer, composition, generation, idempotency_key)` is refused.
        """
        if not isinstance(wire, Mapping):
            return False, REJECT_MALFORMED
        try:
            correlation = Correlation.from_wire(wire)
        except (KeyError, TypeError, ValueError):
            return False, REJECT_MALFORMED
        secret = self._secrets.get(correlation.peer_identity)
        if secret is None:
            return False, REJECT_UNKNOWN_PEER
        given = wire.get(AUTH_FIELD)
        if not isinstance(given, str):
            return False, REJECT_FORGED
        # An envelope with no canonical byte spelling (a lone surrogate, a
        # value that will not serialize) cannot be authenticated, so it is
        # MALFORMED. It is peer-supplied, and this method's contract is
        # `(ok, reason)`: a crash here would escape past every caller written
        # to read a verdict and take the seam down (roadmap 428 F10).
        try:
            envelope = _envelope_bytes(wire)
        except attest.NotCanonicalizable:
            return False, REJECT_MALFORMED
        expected = hmac.new(bytes(secret), envelope, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected, given):
            return False, REJECT_FORGED
        if (transport_identity is not None
                and transport_identity != correlation.peer_identity):
            return False, REJECT_PEER_MISMATCH
        if not self.ledger.admit(correlation):
            return False, REJECT_DUPLICATE
        return True, "authenticated"


# ---------------------------------------------------------------------------
# §1.4b. the same question on a NETWORK seam, and the honest answer
# ---------------------------------------------------------------------------
#
# :class:`CorrelationGuard` above is four gates: shape, KNOWN PEER (a closed,
# enumerated identity table), AUTHENTICITY (an HMAC under that peer's own
# per-process secret, cross-checked against the transport identity when the
# transport proved one), and FRESHNESS (the dedup ledger). On a local UDS seam
# the transport authenticates nothing — `bridge.peer_identity` returns None for
# a Unix socket — so the HMAC is the *only* thing binding the claimed
# `peer_identity` to a real caller, and the ledger is the only replay defence.
# That is what "sealed" means, and it is why the guard is worth running there.
#
# A TCP+mTLS seam cannot carry the same property, and the reason is structural
# rather than an omission:
#
#   * The secret is `secrets.token_bytes(32)`, minted fresh by the conductor at
#     every `run_placement()` and delivered only inside the process specs of
#     ITS OWN children. A network provider may also be dialled by an item-151
#     cross-composition consumer, which runs under a DIFFERENT conductor, on a
#     different machine, and can never hold that secret. There is no
#     distribution channel for it, and inventing one is item 118 Slice 2's
#     replicated control plane, not this plane. Demanding a sealed envelope
#     from a peer that cannot produce one does not harden the seam, it refuses
#     the legitimate caller — the same mistake as installing the guard in front
#     of a consumer tier whose bridge cannot seal.
#
# What a network seam CAN carry is the gate the UDS seam cannot: the mTLS
# handshake proves the peer's identity with a CA-signed private key, per
# session, and `bridge.peer_identity` reads it off the certificate. What is
# missing there is not authentication but a CLOSED SET: `verify_mode =
# CERT_REQUIRED` against a shared CA admits every identity that CA ever signed,
# so the receiver knows *who* is calling and has no opinion about whether that
# one may. :class:`PeerAllowlist` is that opinion, and it needs no secret
# distribution at all — only names, which an operator can declare. It also
# needs nothing from the caller's bridge, which is why it works for a py
# consumer, a node consumer and a cross-composition stranger alike.
#
# The FRESHNESS gate is the part of this section that used to read "goes with
# the secret", and that was wrong. Re-derive it from what each gate needs:
#
#   * dedup needs a KEY that names one crossing, and an IDENTITY to scope that
#     key by, so one caller's idempotency-key namespace is not another's;
#   * the HMAC exists to bind a CLAIMED identity to a real caller, which is
#     load-bearing on UDS precisely because `bridge.peer_identity` is None
#     there — the claim is otherwise unchecked;
#   * on TCP+mTLS the transport has ALREADY bound that identity, per session,
#     with a CA-signed private key. So the scoping identity is available
#     without any shared secret: it is read off the peer certificate, not off
#     the request body.
#
# :class:`TransportReplayGuard` is that gate. It keys dedup on
# `(TRANSPORT identity, composition_id, generation, idempotency_key)` — the
# first member from the handshake, never from the payload, because a replayer
# controls its payload and does not control the mTLS session it speaks in. It
# holds NO secret, so it needs no distribution channel and refuses no
# cross-composition caller: an item-151 consumer under another conductor
# already holds the one credential this gate reads.
#
# It is still weaker than sealing in one direction, and the vocabulary says so:
# a crossing that declares no `idempotency_key` is not deduplicated (item 309 —
# nothing declares it re-deliverable), and the ledger is BOUNDED, so the window
# is finite. See :class:`BoundedReplayLedger` for exactly what that costs.

#: The transport proved no identity at all (no TLS, or a session with no peer
#: certificate). Distinct from :data:`REJECT_UNKNOWN_PEER`, which is a peer that
#: named itself and is not on the list.
REJECT_UNAUTHENTICATED_PEER = "unauthenticated-peer"

#: The peer-admission level a seam ACHIEVED — never the one it wanted. The
#: vocabulary is `bundle.verify`'s OK / cannot-verify: a surface that cannot
#: prove its property says so.
ADMISSION_SEALED = "sealed"
#: mTLS identity checked against a declared allowlist AND keyed crossings
#: replay-checked against that transport-proven identity. Stronger than
#: :data:`ADMISSION_PEER_PINNED`, weaker than :data:`ADMISSION_SEALED` (an
#: unkeyed crossing is not deduplicated, and the ledger window is finite).
ADMISSION_PEER_BOUND = "peer-bound"
ADMISSION_PEER_PINNED = "peer-pinned"
ADMISSION_UNVERIFIED = "unverified"

#: Rendered for the level, so a reader never has to remember which is stronger.
ADMISSION_MEANING = {
    ADMISSION_SEALED: "peer authenticated by per-process secret, replays refused",
    ADMISSION_PEER_BOUND: "mTLS peer identity checked against a declared allowlist, "
                          "and a keyed crossing replay-checked against that proven "
                          "identity over a bounded window",
    ADMISSION_PEER_PINNED: "mTLS peer identity checked against a declared allowlist; "
                           "NOT replay-checked",
    ADMISSION_UNVERIFIED: "cannot verify who may call",
}


class PeerAllowlist:
    """What a NETWORK provider runs on every connection before it answers one.

    The mTLS handshake has already proved an identity by the time this is
    consulted; this decides whether that identity is one the placement declared
    may call. It holds NAMES, not secrets — that is the whole reason it works
    across a composition boundary where :class:`CorrelationGuard` cannot.

    It answers `(ok, reason)` in the same shape the correlation guard does, so a
    provider treats the two verdicts identically. It deliberately does NOT
    dedup: an allowlist has no envelope to dedup on, and pretending otherwise
    would be the claim this whole plane exists to avoid.
    """

    def __init__(self, identities: Iterable[str]) -> None:
        self.identities = frozenset(str(i) for i in identities)

    def admit(self, transport_identity: str | None) -> tuple[bool, str]:
        if not transport_identity:
            return False, REJECT_UNAUTHENTICATED_PEER
        if transport_identity not in self.identities:
            return False, REJECT_UNKNOWN_PEER
        return True, "peer-pinned"

    def __len__(self) -> int:
        return len(self.identities)


#: The verdict a :class:`TransportReplayGuard` returns for a crossing it
#: admitted and DID dedup, and for one it admitted without deduping because the
#: caller declared no idempotency key. Two spellings, because they are two
#: different properties and a caller reading the verdict should not have to
#: guess which one it got.
ADMITTED_REPLAY_CHECKED = "replay-checked"
ADMITTED_UNKEYED = "admitted-unkeyed"

#: Default bound on :class:`BoundedReplayLedger`: keys remembered per peer, and
#: peers remembered at once. The product is the hard ceiling on entries, so the
#: state a long-lived provider carries is bounded by construction rather than by
#: hoping the seam goes quiet.
REPLAY_WINDOW_PER_PEER = 1024
REPLAY_WINDOW_PEERS = 64


class BoundedReplayLedger:
    """Seen `(composition_id, generation, idempotency_key)` scopes, per peer,
    with a HARD bound on both dimensions.

    :class:`DedupLedger` is an unbounded `set`, which is correct for the process
    seam it was written for (one boot, a known handful of local children) and
    wrong for a network provider that may answer a peer for weeks. So this one
    is two nested LRUs:

      * at most `per_peer` scopes remembered for one identity, oldest evicted
        first;
      * at most `max_peers` identities remembered at once, least-recently-used
        evicted first.

    **What eviction costs, stated rather than hidden.** A replay is refused only
    while the original crossing is still remembered. Past `per_peer` keyed
    crossings from the same identity, the oldest scope ages out and a replay of
    *that* crossing would be admitted again. :attr:`evicted` counts every
    forgotten scope, so an operator can see the window was exceeded instead of
    inferring it.

    The alternative — refusing everything once full — is not fail-closed, it is
    a self-service denial of service: any peer could fill the window and take
    the seam down for everyone. Bounded memory with a counted, finite window is
    the honest trade, and it is per-identity so a chatty peer cannot age out a
    quiet peer's history (which would otherwise hand a stolen-key replayer a
    way to make room for its own replay).
    """

    def __init__(self, per_peer: int = REPLAY_WINDOW_PER_PEER,
                 max_peers: int = REPLAY_WINDOW_PEERS) -> None:
        if per_peer < 1 or max_peers < 1:
            raise ValueError("a replay window of zero remembers nothing and "
                             "would admit every replay; give a positive bound")
        self.per_peer = int(per_peer)
        self.max_peers = int(max_peers)
        self.evicted = 0
        self._peers: "OrderedDict[str, OrderedDict[tuple, None]]" = OrderedDict()

    def admit(self, identity: str, scope: tuple) -> bool:
        """True the first time `scope` is seen for `identity`, False on a
        replay. Records the scope either way (a refused replay does not need
        re-recording; it is already there)."""
        seen = self._peers.get(identity)
        if seen is None:
            seen = OrderedDict()
            self._peers[identity] = seen
            while len(self._peers) > self.max_peers:
                _, dropped = self._peers.popitem(last=False)
                self.evicted += len(dropped)
        self._peers.move_to_end(identity)
        if scope in seen:
            return False
        seen[scope] = None
        while len(seen) > self.per_peer:
            seen.popitem(last=False)
            self.evicted += 1
        return True

    def seen(self, identity: str, scope: tuple) -> bool:
        return scope in self._peers.get(identity, ())

    def __len__(self) -> int:
        return sum(len(seen) for seen in self._peers.values())


class TransportReplayGuard:
    """Replay protection for a NETWORK seam, keyed on the identity the mTLS
    handshake proved (§1.4b).

    :class:`CorrelationGuard` cannot run here: its per-process secret is minted
    by one conductor for its own children, and an item-151 cross-composition
    caller can never hold it. This guard holds NO secret. It reads the scoping
    identity off the peer certificate — `bridge.peer_identity`, the value the
    transport proved — so it needs no distribution channel and refuses no
    legitimate caller that mTLS already admitted.

    Three gates:

      1. **a proven identity** — no transport identity means nothing to scope a
         key by, and scoping by a caller-asserted name would dedup in a
         namespace the caller chooses. Refused as
         :data:`REJECT_UNAUTHENTICATED_PEER` rather than keyed on the payload.
      2. **agreement** — when the crossing names a `peer_identity`, it must be
         the one the handshake proved. This is what stops peer B from replaying
         a captured envelope of peer A: verbatim it is a
         :data:`REJECT_PEER_MISMATCH`, and rewritten to B's own name it is
         simply B's own first crossing, in B's own namespace, which B was
         allowed to make anyway.
      3. **freshness** — a repeat of an already-seen `(transport identity,
         composition_id, generation, idempotency_key)` is
         :data:`REJECT_DUPLICATE`. The first member comes from the transport;
         only the last three are read off the envelope, and a caller varying
         those is not defeating the gate, it is declaring a different crossing
         (which it could do anyway by minting a fresh key — dedup answers
         re-DELIVERY, not a caller that means to call twice).

    A request with no correlation member, or one that declares no
    `idempotency_key`, is ADMITTED and not deduplicated: nothing declares it
    re-deliverable (item 309), and refusing it would refuse every caller built
    before this envelope existed — the cross-composition failure mode this
    plane exists to avoid. The verdict says which of the two it was
    (:data:`ADMITTED_REPLAY_CHECKED` / :data:`ADMITTED_UNKEYED`), so a seam
    never reports a freshness check it did not run.
    """

    def __init__(self, ledger: Optional[BoundedReplayLedger] = None, *,
                 per_peer: int = REPLAY_WINDOW_PER_PEER,
                 max_peers: int = REPLAY_WINDOW_PEERS) -> None:
        self.ledger = (ledger if ledger is not None
                       else BoundedReplayLedger(per_peer, max_peers))

    def admit(self, wire: Any, *, transport_identity: str | None = None
              ) -> tuple[bool, str]:
        if not transport_identity:
            return False, REJECT_UNAUTHENTICATED_PEER
        if wire is None:
            return True, ADMITTED_UNKEYED
        if not isinstance(wire, Mapping):
            return False, REJECT_MALFORMED
        try:
            correlation = Correlation.from_wire(wire)
        except (KeyError, TypeError, ValueError):
            return False, REJECT_MALFORMED
        if correlation.peer_identity != transport_identity:
            return False, REJECT_PEER_MISMATCH
        if correlation.idempotency_key is None:
            return True, ADMITTED_UNKEYED
        # NOTE the identity in this key: the one the handshake proved, not
        # `correlation.peer_identity`. They are equal here only because gate 2
        # just required it; keying on the transport value is what keeps that
        # true if gate 2 ever loosens.
        scope = (correlation.composition_id, int(correlation.generation),
                 correlation.idempotency_key)
        if not self.ledger.admit(transport_identity, scope):
            return False, REJECT_DUPLICATE
        return True, ADMITTED_REPLAY_CHECKED

    def __len__(self) -> int:
        return len(self.ledger)


@dataclass(frozen=True)
class SeamAdmission:
    """One seam's achieved peer-admission level, for the conductor's audit.

    `provider` is the process that serves the seam, `transport` is `"uds"` or
    `"tcp+mtls"`, `level` is one of the three above and `detail` says why that
    level and not a stronger one. `peers` is the closed set when there is one.
    """

    provider: str
    transport: str
    level: str
    detail: str
    peers: tuple[str, ...] = ()

    @property
    def verified(self) -> bool:
        return self.level != ADMISSION_UNVERIFIED

    def render(self) -> str:
        head = f"  seam admission {self.provider} ({self.transport}): "
        if self.level == ADMISSION_UNVERIFIED:
            head += f"UNVERIFIED — {self.detail}"
        else:
            head += f"{self.level} — {self.detail}"
        if self.peers:
            head += f"  peers: {', '.join(self.peers)}"
        return head


def render_seam_admissions(admissions: Sequence["SeamAdmission"]) -> list[str]:
    """The conductor's admission block: one line per cross-process seam in
    placement declaration order (so a reader finds a process by name, not by
    rank), then a count of the ones that proved nothing. An empty list renders
    nothing, so a placement with no cross-process seam prints no block."""
    if not admissions:
        return []
    unverified = [a for a in admissions if not a.verified]
    lines = [a.render() for a in admissions]
    if unverified:
        lines.append(
            f"  seam admission: {len(unverified)} of {len(admissions)} seam(s) "
            "UNVERIFIED — see the lines above; a seam is only as closed as the "
            "peer set it can name")
    return lines


# ---------------------------------------------------------------------------
# §3. the coordinated cross-process commit/abort protocol
# ---------------------------------------------------------------------------

#: Per-participant outcomes. The vocabulary mirrors `bundle.verify`'s
#: OK/MISMATCH/cannot-verify: it never claims an atomicity it did not achieve.
NEVER_COMMITTED = "never-committed"
APPLIED = "applied"
ROLLED_BACK_CLEAN = "rolled-back-clean"
ROLLED_BACK_WITH_RESIDUE = "rolled-back-with-residue"
UNRESOLVED = "unresolved"

#: Aggregate verdicts.
DEPLOY_APPLIED = "applied"
DEPLOY_REFUSED = "refused"
DEPLOY_ABORTED_CLEAN = "aborted-clean"
DEPLOY_ABORTED_WITH_RESIDUE = "aborted-with-residue"

#: The protocol tag every report carries, so a reader can tell at a glance that
#: this was a coordinated protocol and NOT a lifted in-process theorem.
PROTOCOL = "coordinated-two-phase"


class Unreachable(RuntimeError):
    """A participant could not be reached for a phase. Its own inverses are in
    its own process; the coordinator cannot run them, so the honest report is
    `unresolved`, never `rolled-back`."""


class Participant:
    """One process taking part in a deploy.

    The coordinator talks to a participant and NOTHING ELSE. It does not hold
    the participant's inverses, cannot enumerate them, and never runs one — the
    whole reason §3.1 says the in-process rollback theorem does not cross a
    seam. `abort` is a *request*: the participant runs its own local LIFO
    unwind, in its own process, and reports what it settled to.
    """

    # Subclasses carry an `identity` (the item-55 per-process identity). It is
    # deliberately NOT declared here, even as a class attribute: a dataclass
    # subclass would inherit it as a defaulted field and be unable to declare
    # any required field of its own after it.

    def prepare(self) -> dict:  # pragma: no cover — interface
        raise NotImplementedError

    def commit(self) -> dict:  # pragma: no cover — interface
        raise NotImplementedError

    def abort(self) -> dict:  # pragma: no cover — interface
        raise NotImplementedError


@dataclass
class _LedgerEntry:
    """One row of the coordinator's commit ledger: WHO committed, in what
    ORDER, and the receipt they returned. Deliberately not an inverse — this is
    the entire cross-process state the coordinator is entitled to hold."""

    identity: str
    order: int
    receipt: dict


def run_deploy(participants: Sequence[Participant], *,
               approval_path: Optional[str] = None,
               federation_id: str = "deploy",
               generation: int = 0,
               on_event: Optional[Callable[[str, str, dict], None]] = None
               ) -> dict:
    """Drive PREPARE / COMMIT / ABORT across co-located participant processes.

    PREPARE is effect-free, so a refusal there is not a rollback at all: every
    participant is `never-committed` and the deploy fails clean (§3.2). This is
    the common failure case and it costs zero unwinding.

    COMMIT is where the coordination is real. Each participant applies its own
    slice with its own `apply`, in its own process, and the coordinator appends
    a row to its **commit ledger**. That ledger is the only cross-process state
    it holds — no inverses, no accumulator, nothing it could replay itself. On
    a failure it:

      1. records a durable ABORT decision (when `approval_path` is given), so a
         participant that is stranded mid-flight can settle against a record
         rather than a guess;
      2. sends ABORT to committed participants in REVERSE LEDGER ORDER — the
         cross-process LIFO is an ordering over *messages*, and each unwind is
         performed by the participant that owns the inverses;
      3. collects each participant's own settled verdict, and reports one it
         could not reach as `unresolved(...)`, never as rolled back.

    The aggregate verdict is `applied` only when every participant applied;
    `aborted-clean` only when every committed participant reported
    `rolled-back-clean`; otherwise `aborted-with-residue`, with the residue
    enumerated.
    """
    def emit(phase: str, identity: str, detail: dict) -> None:
        if on_event is not None:
            on_event(phase, identity, detail)

    outcomes: dict[str, dict] = {p.identity: {"outcome": NEVER_COMMITTED}
                                 for p in participants}
    prepared: list[dict] = []
    for participant in participants:
        try:
            report = participant.prepare()
        except Unreachable as error:
            report = {"ok": False, "reason": f"unreachable during PREPARE: {error}"}
        except Exception as error:  # noqa: BLE001 — any prepare failure refuses
            report = {"ok": False,
                      "reason": f"{type(error).__name__}: {error}"}
        emit("prepare", participant.identity, report)
        prepared.append(report)
        if not report.get("ok"):
            return {
                "protocol": PROTOCOL,
                "verdict": DEPLOY_REFUSED,
                "phase": "prepare",
                "refusedBy": participant.identity,
                "reason": report.get("reason"),
                "participants": outcomes,
                "commitLedger": [],
                "residue": {"clean": True, "outstanding": [],
                            "proof": "PREPARE has no runtime effects, so a "
                                     "refusal there is not a rollback: no "
                                     "participant activated anything and there "
                                     "is nothing to undo."},
            }

    ledger: list[_LedgerEntry] = []
    failure: Optional[dict] = None
    for participant in participants:
        try:
            report = participant.commit()
        except Unreachable as error:
            report = {"ok": False, "reason": f"unreachable during COMMIT: {error}",
                      "unresolved": True}
        except Exception as error:  # noqa: BLE001
            report = {"ok": False, "reason": f"{type(error).__name__}: {error}"}
        emit("commit", participant.identity, report)
        if report.get("ok"):
            ledger.append(_LedgerEntry(participant.identity, len(ledger), report))
            outcomes[participant.identity] = {"outcome": APPLIED, "receipt": report}
            continue
        if report.get("unresolved"):
            # We asked it to commit and never heard back. It may or may not have
            # applied; only that process's own WAL settles it.
            outcomes[participant.identity] = {
                "outcome": UNRESOLVED, "reason": report.get("reason"),
                "settleWith": "run `revl recover` on that participant's own WAL"}
        else:
            # Its LOCAL apply failed, so it ALREADY unwound its own slice LIFO
            # and proved its own no-residue before answering (apply.py, per
            # process). Nothing cross-process to do for this one.
            outcomes[participant.identity] = {
                "outcome": NEVER_COMMITTED, "reason": report.get("reason"),
                "localRollback": report.get("residue")}
        failure = {"identity": participant.identity,
                   "reason": report.get("reason")}
        break

    if failure is None:
        if approval_path is not None:
            write_commit_approval(approval_path, federation_id=federation_id,
                                  generation=generation,
                                  participants=[p.identity for p in participants])
        return {
            "protocol": PROTOCOL,
            "verdict": DEPLOY_APPLIED,
            "phase": "commit",
            "participants": outcomes,
            "commitLedger": [{"identity": e.identity, "order": e.order}
                             for e in ledger],
            "residue": {"clean": True, "outstanding": [],
                        "proof": "every participant applied its own slice and "
                                 "returned a receipt; nothing was aborted."},
        }

    # Durable decision FIRST: a participant stranded from here on settles by
    # reading a record, never by guessing (Addendum 2 / §3.4).
    if approval_path is not None:
        write_abort_decision(approval_path, federation_id=federation_id,
                             generation=generation, reason=failure["reason"],
                             failed=failure["identity"])

    by_identity = {p.identity: p for p in participants}
    unresolved: list[dict] = []
    residue: list[dict] = []
    for entry in reversed(ledger):        # reverse commit order: the cross-
        participant = by_identity[entry.identity]   # process LIFO, over MESSAGES
        try:
            report = participant.abort()
        except Unreachable as error:
            outcomes[entry.identity] = {
                "outcome": UNRESOLVED, "reason": str(error),
                "lastReceipt": entry.receipt,
                "settleWith": "run `revl recover` on that participant's own WAL"}
            unresolved.append({"identity": entry.identity, "reason": str(error)})
            emit("abort", entry.identity, {"ok": False, "unresolved": True})
            continue
        except Exception as error:  # noqa: BLE001
            outcomes[entry.identity] = {
                "outcome": UNRESOLVED, "reason": f"{type(error).__name__}: {error}",
                "lastReceipt": entry.receipt}
            unresolved.append({"identity": entry.identity, "reason": str(error)})
            emit("abort", entry.identity, {"ok": False, "unresolved": True})
            continue
        emit("abort", entry.identity, report)
        clean = bool((report.get("residue") or {}).get("clean"))
        outcomes[entry.identity] = {
            "outcome": ROLLED_BACK_CLEAN if clean else ROLLED_BACK_WITH_RESIDUE,
            "residue": report.get("residue"),
            # Recorded per participant: the unwind ran THERE, in that process.
            "unwoundBy": report.get("pid"),
        }
        if not clean:
            residue.append({"identity": entry.identity,
                            "outstanding": (report.get("residue") or {}).get("outstanding")})

    clean = not unresolved and not residue
    return {
        "protocol": PROTOCOL,
        "verdict": DEPLOY_ABORTED_CLEAN if clean else DEPLOY_ABORTED_WITH_RESIDUE,
        "phase": "abort",
        "failedAt": failure["identity"],
        "reason": failure["reason"],
        "participants": outcomes,
        "commitLedger": [{"identity": e.identity, "order": e.order} for e in ledger],
        "abortOrder": [e.identity for e in reversed(ledger)],
        "residue": {
            "clean": clean,
            "outstanding": unresolved + residue,
            "proof": _abort_proof(ledger, unresolved, residue),
        },
    }


def _abort_proof(ledger: list, unresolved: list, residue: list) -> str:
    if not ledger:
        return ("no participant had committed when the failure was reported, so "
                "the abort had nothing to unwind.")
    if not unresolved and not residue:
        return (f"{len(ledger)} committed participant(s) were sent ABORT in reverse "
                "commit order; each ran its OWN local LIFO unwind in its own "
                "process and proved its own no-residue. The coordinator held only "
                "the commit ledger — it never held or ran an inverse.")
    parts = []
    if unresolved:
        parts.append(f"{len(unresolved)} participant(s) UNRESOLVED (unreachable "
                     "for ABORT). Their inverses live in their own processes, so "
                     "this is reported, not resolved: settle each from its own WAL")
    if residue:
        parts.append(f"{len(residue)} participant(s) rolled back but reported "
                     "residue of their own")
    return "; ".join(parts) + ". No participant is claimed rolled back that did not say so."


# ---------------------------------------------------------------------------
# co-located federation atomicity (the second CRITICAL)
# ---------------------------------------------------------------------------

#: The durable record whose PRESENCE authorizes crossing an irreversible effect.
#: Deliberately the same spelling `recovery.py` already keys roll-forward off
#: (`commit-approved`), prefixed for the federation scope, so `settle_stranded`
#: can hand the rule to `recovery.recover` VERBATIM rather than re-deciding it.
FEDERATION_APPROVED = "federation-commit-approved"
FEDERATION_ABORTED = "federation-abort-decided"

#: Why a plan is refused admission into a federation update.
REFUSE_IRREVERSIBLE = "non-deferrable-irreversible-crossing"
REFUSE_CONTRACT = "contract-break"
#: A pinned contract naming a provider this update does not carry. It used to
#: be SKIPPED, in a function whose whole posture is refuse-as-one-unit: a pin
#: the federation cannot check is not a pin the federation satisfied (roadmap
#: 428 F13).
REFUSE_UNKNOWN_PROVIDER = "contract-provider-not-in-update"


def reached_emissions(ir: dict) -> list[dict]:
    """Every emission-extern CALL SITE a composition reaches, with whether it is
    deferrable.

    Reachability, not declaration — the same discipline
    `session_commit._reached_deferred_calls` uses, and for the same reason: a
    declared-but-never-called extern crosses nothing. An `emission` extern
    carrying `deferred` is item 245's class (b): PREPARE can HOLD it in the
    deferral queue and flush it only after the durable federation decision, so
    it is deferrable. A bare `emission` extern is class (c) — it fires at the
    call, with no inverse — so reaching one means the composition NECESSARILY
    crosses an irreversible effect during its local commit. `witnessed` and
    `acquire` externs are absent from this list by construction: their
    reversibility is a registered inverse or an effect bracket.

    Read off `query.Composition`'s per-scope facts: the SAME surface `revl
    audit` prints and `erase_report._crossings` folds, so this gate can never
    disagree with the boundary the audit shows. Roadmap item 419b: the earlier
    walk keyed on an `emit` STEP wrapper carrying a `kind: "fn"` expression,
    and missed two shapes that are ordinary revl.

    * A provide-method whose body IS the emit (`fn put(k, v) = emit host(v)`)
      lowers to a `return` step (the `emit` marker does not survive), so a
      provider that necessarily crosses an irreversible emission was admitted.
      The scope facts key on the CALLED NAME instead, which is sound because
      `emit` is the only spelling that may reach an emission extern, and they
      also carry what a pure fn reaches transitively.
    * An emission mediated through a required service's capability-scoped
      operation (`emit store.put(..)` against `emission[host_put] fn put`) was
      not enumerated at all. It is now, tagged with `via` (`"<key>.<method>"`).

    A mediated crossing is counted only when the key resolves to NO local
    provider: an external/federated provider, item 151's shape. When the
    provider is a component of this same composition its provide-method scope
    is walked in its own right, with the extern's TRUE deferrability, so
    counting the consumer's call again would double-count and, worse, would
    downgrade a genuinely `deferred` extern to class (c) and refuse a plan that
    is fine. An unresolved key is class (c) by item 245 Decision 2, which
    `erase_report._crossings` already applies verbatim: deferral is a property
    of an extern DECLARATION and is not spellable on a service method, so the
    operation fires at the call and this composition cannot prove the far side
    holds it.

    Each row is `{component, extern, deferrable, idempotency_key, via}`; `via`
    is `None` for a direct call site. `extern` is the capability the service
    method declares (`emission[host_put]`); it is `None` for an `emission`
    method that names no capability, and `via` is then the only name available.
    """
    from .query import Composition  # noqa: PLC0415 - lazy, avoids a cycle

    index = Composition(ir)
    found: list[dict] = []
    seen: set = set()

    def add(component: str, extern, deferrable: bool, via) -> None:
        mark = (component, extern, via)
        if mark in seen:
            return
        seen.add(mark)
        decl = index.externs.get(extern) or {}
        found.append({
            "component": component, "extern": extern,
            "deferrable": deferrable,
            "idempotency_key": decl.get("idempotency_key"),
            "via": via,
        })

    for comp in ir.get("components") or []:
        component = comp.get("name") or "?"
        for scope_id in index.scopes_of.get(component) or []:
            facts = index.scopes[scope_id]["facts"]
            for fact in facts["externs"]:
                if fact.get("emission"):
                    add(component, fact["name"], bool(fact.get("deferred")), None)
            for fact in facts["emissions"]:
                key, method = fact["key"], fact["method"]
                if index.method_scope(component, key, method) is not None:
                    continue
                spec = (((index.services.get(fact.get("service")) or {})
                         .get("methods") or {}).get(method) or {})
                for capability in spec.get("capabilities") or [None]:
                    add(component, capability, False, f"{key}.{method}")
    return found


def federation_admission(plans: Mapping[str, dict], *,
                         contracts: Optional[Sequence[tuple]] = None) -> dict:
    """Admit — or REFUSE — an all-or-nothing update across co-located
    compositions.

    `plans` maps a composition id to the IR it would move to. `contracts` is an
    optional sequence of `(consumer_surface_doc, provider_composition_id)`
    pairs; each is checked with `federation.check` against the provider's NEW
    IR, so a federation update that would break a pinned consumer surface is
    refused as one unit rather than deployed composition by composition. A
    contract naming a provider `plans` does not carry is REFUSED, not skipped:
    it cannot be checked, and a pin that could not be checked is not a pin the
    update satisfied.

    The refusal that matters is the second CRITICAL's: **a plan that
    necessarily crosses a non-deferrable irreversible effect is REFUSED
    admission rather than silently degrading atomicity.** Such a plan cannot
    honour "no composition crosses an irreversible effect before a durable
    federation-commit-approved record exists" — PREPARE has no way to hold a
    class-(c) crossing, so admitting it would leave a late partition able to
    strand that composition with residue while its peers reverted. Refusing is
    the only honest option; the fix is to declare the extern `deferred`
    (item 245 class (b)) so PREPARE can hold it.

    Returns `{"admitted": bool, "refusals": [...], "deferred": [...]}`.
    """
    refusals: list[dict] = []
    deferred: list[dict] = []
    for composition_id in sorted(plans):
        for crossing in reached_emissions(plans[composition_id]):
            row = {"composition": composition_id, **crossing}
            if crossing["deferrable"]:
                deferred.append(row)
                continue
            # a mediated crossing names the service operation it goes through;
            # the author cannot find `host_put` by reading their own component,
            # they wrote `emit store.put(..)` (item 274's standard: a refusal
            # names something the author can act on).
            what = f"emission `{crossing['extern']}`" if crossing["extern"] \
                else "emission"
            where = (f"through `{crossing['via']}` in `{crossing['component']}`"
                     if crossing["via"] else f"in `{crossing['component']}`")
            fix = ("declare the extern `deferred` (item 245 class (b)) so "
                   "PREPARE can hold it")
            if crossing["via"]:
                fix = ("deferral is a property of an extern DECLARATION and is "
                       "not spellable on a service method, so this crossing "
                       "cannot be held: provide the key inside this composition "
                       "so its declaration is in scope, or split the operation "
                       "out of the federated update")
            refusals.append({
                "kind": REFUSE_IRREVERSIBLE,
                **row,
                "reason": (
                    f"`{composition_id}` necessarily crosses the irreversible "
                    f"{what} {where} "
                    "during its local commit. PREPARE cannot hold a class-(c) "
                    "crossing, so this composition could cross before a durable "
                    f"`{FEDERATION_APPROVED}` record exists and be stranded with "
                    "residue while its peers revert. Refused rather than "
                    f"silently degrading the federation's atomicity; {fix}."),
            })
    for consumer_doc, provider_id in (contracts or ()):
        provider_ir = plans.get(provider_id)
        if provider_ir is None:
            # Fail CLOSED. This used to `continue`, so a contract naming a
            # provider outside `plans` — a typo, a composition dropped from the
            # update, a rename on one side only — was checked against nothing
            # and the federation admitted. A pin that could not be checked is
            # not a pin that was satisfied, and "all or nothing" cannot mean
            # "all of the ones we happened to be able to look at".
            named = ", ".join(sorted(plans)) or "(none)"
            refusals.append({
                "kind": REFUSE_UNKNOWN_PROVIDER,
                "composition": provider_id,
                "reason": (
                    f"a pinned consumer surface names `{provider_id}` as its "
                    "provider, but this federation update carries no plan for "
                    f"it (updating: {named}); the pin cannot be checked, so it "
                    "is refused rather than skipped. An all-or-nothing update "
                    "refuses as one unit."),
            })
            continue
        from .federation import check  # noqa: PLC0415 — lazy, avoids a cycle
        verdict = check(consumer_doc, provider_ir)
        if not verdict["satisfied"]:
            refusals.append({
                "kind": REFUSE_CONTRACT,
                "composition": provider_id,
                "consumer": verdict.get("consumer"),
                "breaks": verdict["breaks"],
                "reason": (f"the federation update would break {verdict.get('consumer')}"
                           f"'s pinned surface on `{provider_id}`; an all-or-nothing "
                           "update refuses as one unit, it does not deploy the "
                           "compatible half."),
            })
    return {"admitted": not refusals, "refusals": refusals, "deferred": deferred}


def _fsync_append(path: str, record: dict) -> None:
    """Append one durable record, fsync'd — the same discipline the WAL writer
    and `recovery._append_discharge` use. Appending fires nothing, so it is safe
    on any path."""
    from .wal import seal_torn_tail  # noqa: PLC0415 — tier-agnostic core
    seal_torn_tail(path)  # a torn tail must never merge with this record (#535)
    with open(path, "a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, sort_keys=True) + "\n")
        handle.flush()
        try:
            os.fsync(handle.fileno())
        except (OSError, ValueError):  # pragma: no cover — e.g. a pipe target
            pass


def write_commit_approval(path: str, *, federation_id: str, generation: int,
                          participants: Sequence[str]) -> dict:
    """Make the federation's COMMIT decision durable, BEFORE any participant is
    allowed to flush a held irreversible emission. This record's existence is
    the whole anti-split-brain property: every stranded participant reads the
    same record and reaches the same verdict."""
    record = {"record": FEDERATION_APPROVED, "federation": federation_id,
              "generation": int(generation),
              "participants": sorted(participants),
              "at": attest._now_iso(None)}
    _fsync_append(path, record)
    return record


def write_abort_decision(path: str, *, federation_id: str, generation: int,
                         reason: str | None, failed: str | None = None) -> dict:
    """Make the federation's ABORT decision durable. Written BEFORE any abort
    message goes out, so a participant stranded during the abort still settles
    against a record."""
    record = {"record": FEDERATION_ABORTED, "federation": federation_id,
              "generation": int(generation), "reason": reason,
              "failed": failed, "at": attest._now_iso(None)}
    _fsync_append(path, record)
    return record


def read_decision(path: str) -> tuple[str | None, dict | None]:
    """Read the durable federation decision: `(FEDERATION_APPROVED |
    FEDERATION_ABORTED | None, record)`.

    A file that does not exist is `None` — the decision was never made, which
    is a definite answer (roll back). A file that exists but cannot be parsed
    raises: that is NOT a definite answer, and guessing between roll-forward and
    roll-back is exactly the split-brain the record exists to prevent.
    """
    if not os.path.exists(path):
        return None, None
    decision: str | None = None
    record: dict | None = None
    with open(path, encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            entry = json.loads(line)   # a torn decision record fails closed
            kind = entry.get("record")
            if kind in (FEDERATION_APPROVED, FEDERATION_ABORTED):
                decision, record = kind, entry
    return decision, record


def settle_stranded(wal_path: str, decision_path: str, *, world=None) -> dict:
    """Settle a participant that was stranded mid-federation-update.

    The rule is `recovery.py`'s, applied VERBATIM — this function decides
    nothing on its own:

      * the durable `federation-commit-approved` record is PRESENT: the
        federation committed. The participant's own WAL is given the
        `commit-approved` marker recovery already keys roll-forward off, and
        `recovery.recover` rolls it forward (replaying no inverse, reporting any
        owed flush honestly).
      * the record is ABSENT (or an explicit abort decision): the federation did
        not commit. `recovery.recover` reads the WAL unchanged and rolls back
        LIFO, reporting residue exactly as it does today.
      * the record is UNREADABLE: there is no definite answer. Fails CLOSED with
        `unresolved` and settles nothing — a guess here is the split-brain.
    """
    from .recovery import recover  # noqa: PLC0415 — lazy, keeps import cheap

    try:
        decision, record = read_decision(decision_path)
    except (OSError, json.JSONDecodeError, UnicodeDecodeError) as error:
        return {
            "verdict": UNRESOLVED,
            "decision": (
                "the durable federation decision record could not be read "
                f"({error}). Recovery will NOT guess between roll-forward and "
                "roll-back: guessing is exactly the split-brain the record "
                "exists to prevent. Fails closed."),
            "residue": {"clean": False, "outstanding": [decision_path],
                        "proof": "no decision was read, so nothing was settled."},
        }
    if decision == FEDERATION_APPROVED:
        # Hand recovery the marker it already keys roll-forward off, then let
        # recovery.py decide. The rule is not re-implemented here.
        _fsync_append(wal_path, {"record": "commit-approved",
                                 "hash": (record or {}).get("federation"),
                                 "federation": (record or {}).get("federation"),
                                 "generation": (record or {}).get("generation")})
        settled = recover(wal_path, world=world)
        settled["federationDecision"] = FEDERATION_APPROVED
        return settled
    settled = recover(wal_path, world=world)
    settled["federationDecision"] = decision or "none"
    return settled


# ---------------------------------------------------------------------------
# a participant driven over a child process's stdin/stdout
# ---------------------------------------------------------------------------


@dataclass
class ProcessParticipant(Participant):
    """A :class:`Participant` that is a real OS process, spoken to over
    newline-delimited JSON on its stdin/stdout — the same control-channel shape
    `_process_runner.py` already uses for `repoint`.

    Every effect, every inverse and the whole durable WAL live in the CHILD.
    This object holds a pipe and a name. That is the point: when `abort` is
    sent, the unwind happens over there, and this side learns only what the
    child reports.
    """

    identity: str
    process: Any
    timeout: float = 20.0

    def _rpc(self, op: str, **payload) -> dict:
        proc = self.process
        if proc.poll() is not None or proc.stdin is None or proc.stdin.closed:
            raise Unreachable(
                f"participant {self.identity!r} is gone (exit "
                f"{proc.poll()}); its inverses were in that process, so this "
                "side cannot run them")
        try:
            proc.stdin.write(json.dumps({"op": op, **payload}) + "\n")
            proc.stdin.flush()
        except (BrokenPipeError, ValueError) as error:
            raise Unreachable(
                f"participant {self.identity!r} closed its control channel: "
                f"{error}") from None
        line = proc.stdout.readline()
        if not line:
            raise Unreachable(
                f"participant {self.identity!r} answered nothing to {op!r} "
                "(it died mid-phase); only its own WAL can settle it")
        return json.loads(line)

    def prepare(self) -> dict:
        return self._rpc("prepare")

    def commit(self) -> dict:
        return self._rpc("commit")

    def abort(self) -> dict:
        return self._rpc("abort")

    def status(self) -> dict:
        return self._rpc("status")

    def stop(self) -> None:
        proc = self.process
        try:
            if proc.stdin is not None and not proc.stdin.closed:
                proc.stdin.close()
        except (OSError, ValueError):
            pass
        try:
            proc.wait(timeout=self.timeout)
        except Exception:  # noqa: BLE001 — best-effort teardown
            proc.kill()


class RemoteParticipant(Participant):
    """A :class:`Participant` whose PREPARE and COMMIT cross a runner transport —
    a local stdio pipe or an ssh channel (:class:`StdioRunnerTransport`) — rather
    than a same-host process pipe. :func:`run_deploy` drives it EXACTLY like a
    :class:`ProcessParticipant`; the only difference is the seam the phase
    messages cross, which is the whole point of the `send` contract being the
    same on both transports.

    `prepare` carries :func:`request_admission`: the HOST verifies the staged
    chain against its OWN local trust store (S2.4) and signs an ACCEPT / REFUSE,
    which this side both binds to its challenge and verifies against the host's
    key. `commit` carries :func:`request_commit`, whose
    :func:`compare_commit_receipt` gate is INTEGRAL — a host that loaded
    different bytes than it was admitted to load REFUSES the commit here (design
    R2), so the seam does not weaken the load-measured guarantee.

    `abort` is honest about this slice's boundary. The runner protocol carries
    PREPARE and COMMIT but has no ABORT leg yet (that is the [REMAINS] two-phase
    commit/abort over more than one host, S3), so the coordinator cannot drive a
    remote unwind and MUST NOT report a rollback it did not obtain. It raises
    :class:`Unreachable`, which :func:`run_deploy` records as `unresolved(...)` —
    the same fail-closed verdict it gives any participant it cannot settle, to be
    resolved by that host's own WAL, never a false `rolled-back`.
    """

    def __init__(self, identity: str, transport, *,
                 admit_request: "AdmitRequest",
                 commit_request: "CommitRequest",
                 host_key: bytes, now=None) -> None:
        self.identity = identity
        self._transport = transport
        self._admit_request = admit_request
        self._commit_request = commit_request
        self._host_key = bytes(host_key)
        self._now = now
        self._admission_receipt: Optional[dict] = None

    def prepare(self) -> dict:
        receipt = request_admission(self._transport, self._admit_request,
                                    now=self._now)
        if receipt.get("verdict") != ACCEPT:
            return {"ok": False, "receipt": receipt,
                    "reason": (f"the runner refused admission at "
                               f"`{receipt.get('link')}`: "
                               f"{receipt.get('reason')}")}
        ok, why = verify_receipt(receipt, self._host_key)
        if not ok:
            return {"ok": False, "receipt": receipt,
                    "reason": ("the runner's admission receipt did not verify "
                               f"against this host's key: {why}")}
        self._admission_receipt = receipt
        return {"ok": True, "receipt": receipt}

    def commit(self) -> dict:
        if self._admission_receipt is None:
            return {"ok": False,
                    "reason": ("COMMIT was reached without a verified admission "
                               "receipt from PREPARE, so there is nothing to "
                               "commit against")}
        ok, reason, receipt = request_commit(
            self._transport, self._commit_request,
            admission_receipt=self._admission_receipt,
            host_key=self._host_key, now=self._now)
        if not ok:
            return {"ok": False, "reason": reason, "receipt": receipt}
        return {"ok": True, "receipt": receipt}

    def abort(self) -> dict:
        raise Unreachable(
            "the cross-machine ABORT leg is a later slice: the runner protocol "
            "carries PREPARE and COMMIT but no ABORT, so this coordinator cannot "
            "drive a remote unwind and will not report a rollback it did not "
            f"obtain; settle participant {self.identity!r} against its own WAL")


# ---------------------------------------------------------------------------
# §5. the deploy map, and the boundary a deploy may actually cross
#     (roadmap item 118, Slice 2a)
# ---------------------------------------------------------------------------
#
# Slice 1 built the protocol and handed the caller the job of constructing
# `Participant`s in Python. There was no way to WRITE a deploy down, and so no
# way for the conductor to refuse one before it started spawning things.
#
# Slice 2a adds the written form — the item-56 placement map with one new
# per-process `[deploy]` table (design §1.2) — and, more importantly, the
# plan-time admission of it. The order matters: the deploy map is
# **unauthenticated operator input** (design R4). It is not inside the attested
# bundle, nothing signs it, and it is the file that says which machine gets to
# run the composition. So every question it can get wrong is asked before any
# boundary is opened, and every one of them fails in the refusing direction.
#
# The boundary vocabulary is the point of this section. `via` names a launch
# mechanism; what a deploy can PROMISE is a function of the boundary that
# mechanism crosses, not of the mechanism:
#
#   process    — the conductor's own child on this kernel. Slice 1's case.
#   container  — a separate namespace set on THIS machine, on this filesystem.
#   machine    — a different kernel, reached over a network.
#
# Only the first two are crossable here, and :data:`TEARDOWN_PROMISE` says what
# each one is worth when the deploy has to come back down.


VIA_LOCAL = "local"
VIA_CONTAINER = "container"
VIA_SSH = "ssh"
#: A verifiable private peer pool target (issue #480, design note
#: docs/design/461-verifiable-private-peer-pool.md). This is SLICE 0: the word
#: is in the vocabulary so it is refused BY NAME — pointing at the design and
#: the missing network seam — rather than as an `unknown-via` or, worse, as a
#: plain local child. The offer record, dispatcher and formal binding (slices
#: 1-4) are gated on the seam and do not land here.
VIA_PEER = "peer"

#: Every `via` this build knows how to reason about. A `via` outside this set is
#: REFUSED, never treated as `local`: "the operator wrote a word we do not
#: implement" and "the operator wants a plain child process" are different
#: statements, and guessing the second from the first is the fail-open shape.
#: `peer` is IN this set even though it never admits: it is a `via` this build
#: reasons about (by refusing it with its own reason, :data:`admit_deploy_map`'s
#: `peer-pool-unavailable`), not one it fails to recognize.
KNOWN_VIA = (VIA_LOCAL, VIA_CONTAINER, VIA_SSH, VIA_PEER)

BOUNDARY_PROCESS = "process"
BOUNDARY_CONTAINER = "container"
BOUNDARY_MACHINE = "machine"

#: `via` -> the boundary it crosses. The teardown promise is keyed off the
#: boundary, so two mechanisms that cross the same boundary cannot accidentally
#: acquire different guarantees.
VIA_BOUNDARY = {
    VIA_LOCAL: BOUNDARY_PROCESS,
    VIA_CONTAINER: BOUNDARY_CONTAINER,
    VIA_SSH: BOUNDARY_MACHINE,
    #: A peer is a machine boundary (design §7: "A peer is a machine
    #: boundary."). Its teardown promise is the machine one — nothing — which is
    #: half of why slice 0 refuses it.
    VIA_PEER: BOUNDARY_MACHINE,
}

#: What a deploy can and cannot promise about TEARDOWN across each boundary.
#:
#: G7 (DESIGN.md §4) is LIFO-complete over the **registered** entries of an
#: accumulator. That quantifier is the whole answer here: completeness is a
#: statement about a set, and each boundary changes which set survives long
#: enough to be unwound.
TEARDOWN_PROMISE = {
    BOUNDARY_PROCESS: (
        "the participant runs its own G7 unwind, newest-first, over the entries "
        "IT registered, and reports clean or names its residue. The conductor "
        "never substitutes its own unwind: a participant it cannot reach is "
        "`unresolved`, never `rolled-back`."),
    BOUNDARY_CONTAINER: (
        "identical to a process boundary while the container is alive — the "
        "control channel is stdio and the participant unwinds in there. When "
        "the container is DESTROYED, the accumulator and every closure-only "
        "inverse die with it, so the conductor's verdict is `unresolved` and "
        "never `rolled-back`. What the container boundary adds over a machine "
        "one is that the WAL is on a mount the conductor ALSO holds, so the "
        "target is still SETTLE-able: `recovery.py` reads that WAL and applies "
        "its existing rule over the RECORDED entries, reporting each "
        "closure-only inverse as residue. Settling is a separate step from the "
        "deploy verdict, and the deploy never claims it happened."),
    BOUNDARY_MACHINE: (
        "nothing. A machine that goes away takes the accumulator, the closures "
        "AND the WAL with it: there is no set on this side for G7 to be "
        "complete over, and the conductor holds no inverse it could run. The "
        "only honest verdict is `unresolved`, naming the target for a human. "
        "That is why this slice REFUSES a machine boundary outright instead of "
        "shipping a best-effort one — a deploy that cannot promise teardown "
        "must not be the thing that quietly discovers it."),
}


def teardown_promise(boundary: str) -> str:
    """What teardown is worth across `boundary`. Unknown boundaries raise: a
    silent default here would be a promise nobody wrote down."""
    try:
        return TEARDOWN_PROMISE[boundary]
    except KeyError:
        raise RevlError(
            f"no teardown promise is recorded for boundary {boundary!r}; the "
            f"known boundaries are {', '.join(sorted(TEARDOWN_PROMISE))}") from None


@dataclass(frozen=True)
class DeployTarget:
    """One `[processes.<p>.deploy]` table, parsed.

    `raw` keeps the operator's table verbatim so a diagnostic can quote what was
    actually written rather than a normalized shadow of it.
    """

    process: str
    via: str
    image: Optional[str] = None
    host: Optional[str] = None
    runner: Optional[str] = None
    trust: Optional[str] = None
    raw: Mapping[str, Any] = field(default_factory=dict)

    @property
    def boundary(self) -> str:
        return VIA_BOUNDARY.get(self.via, BOUNDARY_MACHINE)

    @property
    def crosses_boundary(self) -> bool:
        return self.boundary != BOUNDARY_PROCESS


#: The `[deploy]` keys this build reads. An unrecognized key is refused for the
#: same reason an unknown `via` is: an operator who writes `hostkey` meaning
#: `host_key` must not silently get an unpinned deploy.
#:
#: The `via = ssh` cross-machine leg adds the fields the transport and the stage
#: step need (design §1.3 R4/R5): `known_hosts` (the PINNED host-key file, so
#: host-key checking is never trust-on-first-use), `host_key` (a conductor-side
#: copy of the far host's receipt-signing key, so the conductor can VERIFY the
#: signed admission/COMMIT receipts it gets back), `remote_bundle` (the path on
#: the far host the attested bundle is staged to and the runner re-hashes), and
#: `port` / `extra_args` (the runner's own trust flags, `--key`/`--host-key`/
#: `--runtime-version`, naming files on ITS disk — S2.4). `runner` doubles as the
#: remote `revl` command name (`StdioRunnerTransport.ssh(remote_revl=...)`).
DEPLOY_KEYS = ("via", "image", "host", "runner", "trust",
               "known_hosts", "host_key", "remote_bundle", "port", "extra_args")


def parse_deploy_map(placement: Mapping) -> tuple[dict, Optional[str]]:
    """Read every `[processes.<p>.deploy]` table out of an item-56 placement
    mapping. Returns `(targets, None)` or `({}, diagnostic)`.

    A placement with no `[deploy]` table anywhere parses to `{}` and is a
    perfectly good deploy map: it says "every process is my own child", which is
    exactly what `run_placement` does today. That back-compat is deliberate —
    a deploy map is a placement map, byte-identical when nothing is remote.
    """
    processes = placement.get("processes") or {}
    if not isinstance(processes, Mapping):
        return {}, "placement `[processes]` is not a table"
    targets: dict[str, DeployTarget] = {}
    for pname in sorted(processes):
        pconf = processes[pname] or {}
        raw = pconf.get("deploy")
        if raw is None:
            continue
        if not isinstance(raw, Mapping):
            return {}, f"[processes.{pname}.deploy] is not a table"
        unknown = sorted(set(raw) - set(DEPLOY_KEYS))
        if unknown:
            return {}, (
                f"[processes.{pname}.deploy] has unrecognized key(s) "
                f"{', '.join(repr(k) for k in unknown)}; this build reads "
                f"{', '.join(DEPLOY_KEYS)}. A misspelled key is refused rather "
                f"than ignored — an ignored key in a deploy map is an operator "
                f"believing they configured something they did not.")
        via = raw.get("via")
        if via is None:
            return {}, (
                f"[processes.{pname}.deploy] gives no `via`; say which launch "
                f"mechanism this target uses ({', '.join(KNOWN_VIA)})")
        targets[pname] = DeployTarget(
            process=pname, via=str(via),
            image=(str(raw["image"]) if raw.get("image") is not None else None),
            host=(str(raw["host"]) if raw.get("host") is not None else None),
            runner=(str(raw["runner"]) if raw.get("runner") is not None else None),
            trust=(str(raw["trust"]) if raw.get("trust") is not None else None),
            raw=dict(raw))
    return targets, None


@dataclass(frozen=True)
class DeployMapVerdict:
    """The plan-time verdict on a whole deploy map.

    `ok` is true only when EVERY target was admitted. There is no partial
    admission: a deploy map that half-admits is a deploy that opens some
    boundaries and then discovers it cannot open the rest, which is the
    partial-deploy state §3 exists to avoid entering.
    """

    ok: bool
    targets: dict
    refusals: tuple
    boundaries: dict

    def render(self) -> list[str]:
        lines: list[str] = []
        for pname in sorted(self.targets):
            target = self.targets[pname]
            lines.append(
                f"  deploy target {pname} via {target.via}: crosses the "
                f"{target.boundary} boundary")
        for refusal in self.refusals:
            lines.append(
                f"  deploy REFUSED [{refusal['rule']}] {refusal['process']}: "
                f"{refusal['reason']}")
        for boundary in sorted({t.boundary for t in self.targets.values()}):
            lines.append(f"  teardown across the {boundary} boundary: "
                         f"{teardown_promise(boundary)}")
        return lines


def _map_refusal(process: str, rule: str, reason: str) -> dict:
    return {"process": process, "rule": rule, "reason": reason}


def admit_deploy_map(placement: Mapping, *,
                     seams: Optional[Mapping] = None) -> DeployMapVerdict:
    """Admit a deploy map BEFORE any boundary is opened.

    `seams` maps a process name to the seam keys it carries across a process
    boundary (what `run_placement` already computes as a process's proxied +
    served keys). It is not optional for a container target: a container target
    must be PROVEN seam-free, and "the conductor did not tell me" is not a
    proof. Omitting it refuses those targets rather than assuming the happy
    case — this is the same shape as :func:`federation_admission` refusing an
    unknown provider instead of skipping it.

    Every refusal below is a refusal, not a downgrade. The ones that would
    otherwise be tempting to soften:

    * a **machine** boundary is refused outright. Not "best effort", not
      "unpinned but warned". There is no landed cross-machine control plane
      (no staged bundle, no remote ``deploy-admit``, no load-measured signed
      receipt, no pinned SSH host key), and per :data:`TEARDOWN_PROMISE` there
      is no teardown to promise across it either.
    * a **container** target that carries a cross-boundary seam is refused with
      the measured fact behind it, the same one
      `sandbox_runtime.ContainerDriver.preflight` refuses on: the seam is a
      Unix socket and a Unix socket does not cross a container bind mount
      portably.
    * a target that serves a **network** seam is refused, because the address it
      binds is a contract other machines hold. `revl swap` already refuses to
      re-tier a network provider for exactly this reason; a deploy that moved
      one across a boundary would be that same re-tier by another route.
    """
    targets, error = parse_deploy_map(placement)
    if error:
        return DeployMapVerdict(False, {}, (_map_refusal("-", "map", error),), {})

    processes = placement.get("processes") or {}
    admitted: dict[str, DeployTarget] = {}
    refusals: list[dict] = []

    for pname in sorted(targets):
        target = targets[pname]
        pconf = processes.get(pname) or {}

        if target.via not in KNOWN_VIA:
            refusals.append(_map_refusal(
                pname, "unknown-via",
                f"`via = {target.via!r}` is not a launch mechanism this build "
                f"implements ({', '.join(KNOWN_VIA)}). An unimplemented `via` "
                f"is refused, never quietly run as a local child: the boundary "
                f"the operator asked for would not be the boundary they got."))
            continue

        if target.via == VIA_PEER:
            # SLICE 0 of the verifiable private peer pool (issue #480, design
            # note docs/design/461-verifiable-private-peer-pool.md §5). A peer
            # IS a machine boundary, so the generic `machine-boundary` refusal
            # below would already catch it — but a peer target is refused with
            # its OWN reason, naming the design and the seam it waits on, so an
            # operator who wrote `via = peer` learns why the pool is not open
            # yet rather than reading a generic SSH-flavoured refusal. It is
            # emphatically NOT treated as `local`: the boundary the operator
            # asked for would not be the boundary they got.
            refusals.append(_map_refusal(
                pname, "peer-pool-unavailable",
                f"`via = peer` places {pname!r} on a verifiable private peer "
                f"pool (design docs/design/461-verifiable-private-peer-pool.md, "
                f"issue #480). A peer is a MACHINE boundary, and the network "
                f"seam a peer is dispatched over — item 56/#107 (the 411 T3 "
                f"seam transport across a container/machine boundary, and its "
                f"peer admission) — has not landed. Until it does, `via = peer` "
                f"is refused BY NAME and never quietly run as a local child: "
                f"the pool the operator asked for would not be the boundary "
                f"they got. This is slice 0 of the design; the signed offer "
                f"record, the lawful-retry dispatcher and the "
                f"authority-monotonicity binding (slices 1-4) are gated on the "
                f"same seam and do not ship here. Teardown across the boundary "
                f"promises nothing either: {TEARDOWN_PROMISE[BOUNDARY_MACHINE]}"))
            continue

        if target.boundary == BOUNDARY_MACHINE:
            raw = target.raw or {}
            # The cross-machine leg is now landed for `via = ssh`, but ONLY
            # under a pinned host key: the whole point of R4 is that host-key
            # checking is never trust-on-first-use, so an ssh target with no
            # `known_hosts` is refused with the same machine-boundary reason as
            # before (the missing pin is precisely half of what that reason
            # names). A pinned target with a `host` is admitted; the transport,
            # the stage step and the runner enforce the rest.
            if target.via == VIA_SSH and raw.get("known_hosts") and target.host:
                admitted[pname] = target
                continue
            refusals.append(_map_refusal(
                pname, "machine-boundary",
                f"`via = {target.via}` crosses a MACHINE boundary. A machine "
                f"target is only opened under a PINNED host key: `via = ssh` "
                f"needs both a `host` and a `known_hosts` (the pinned host-key "
                f"file), without which impersonating the target costs sitting on "
                f"the network path rather than owning the machine — host-key "
                f"checking is never trust-on-first-use (R4). Teardown across the "
                f"boundary still promises nothing: "
                f"{TEARDOWN_PROMISE[BOUNDARY_MACHINE]}"))
            continue

        if target.via == VIA_LOCAL:
            stray = sorted(k for k in ("image", "host", "trust")
                           if (target.raw or {}).get(k) is not None)
            if stray:
                refusals.append(_map_refusal(
                    pname, "local-with-remote-fields",
                    f"`via = local` is the conductor's own child process, but "
                    f"the table also gives {', '.join(stray)}. Those describe a "
                    f"boundary this target does not cross; a deploy map is "
                    f"refused rather than run with half of it ignored."))
                continue
            admitted[pname] = target
            continue

        # --- from here: a target that crosses a boundary (container).
        if pconf.get("address"):
            addr = pconf["address"]
            refusals.append(_map_refusal(
                pname, "network-provider",
                f"process {pname!r} serves a NETWORK seam "
                f"({addr.get('host')}:{addr.get('port')}), and its address is a "
                f"contract other machines already hold. Moving it across the "
                f"{target.boundary} boundary is a re-tier of a network provider "
                f"— the operation `revl swap` refuses for this exact reason — "
                f"so a deploy map may not do it either. Deploy the process that "
                f"CONSUMES the seam, or stand the provider up in its own "
                f"placement."))
            continue

        if not target.trust:
            refusals.append(_map_refusal(
                pname, "no-trust-store",
                f"a target across the {target.boundary} boundary needs `trust` "
                f"(the signer trust store the far side verifies the attestation "
                f"chain against). Without one there is nothing for `admit` to "
                f"check the staged bytes against, and a deploy whose receiver "
                f"cannot verify the chain is a copy, not a deploy."))
            continue

        if target.via == VIA_CONTAINER:
            if not target.image:
                refusals.append(_map_refusal(
                    pname, "container-without-image",
                    "`via = container` needs an `image`; an image resolved "
                    "later turns a missing image into a dead child instead of "
                    "a refusal."))
                continue
            if seams is None:
                refusals.append(_map_refusal(
                    pname, "seam-set-unknown",
                    f"a container target must be PROVEN seam-free, and the "
                    f"conductor supplied no seam set for {pname!r}. "
                    f"\"Not told\" is not \"none\": the map refuses rather than "
                    f"assuming the target carries no seam."))
                continue
            carried = sorted(seams.get(pname) or ())
            if carried:
                refusals.append(_map_refusal(
                    pname, "container-seam",
                    f"process {pname!r} is deployed into a container but "
                    f"carries cross-boundary seam(s) ({', '.join(carried)}): "
                    f"the seam is a Unix socket in the placement directory, and "
                    f"a Unix socket does not cross a container bind mount "
                    f"portably (measured non-functional in both directions on a "
                    f"Docker Desktop bind mount; `sandbox_runtime` refuses the "
                    f"same shape). The per-rung seam transport is the "
                    f"prerequisite; until it lands a container target must be "
                    f"seam-free. Co-locate {pname!r} with the process it talks "
                    f"to, or deploy it `via = local`."))
                continue
            admitted[pname] = target
            continue

        refusals.append(_map_refusal(  # pragma: no cover — KNOWN_VIA is exhausted above
            pname, "unhandled-via",
            f"`via = {target.via!r}` is known but has no admission rule in this "
            f"build; refusing rather than falling through."))

    ok = not refusals
    return DeployMapVerdict(
        ok=ok,
        targets=(admitted if ok else {}),
        refusals=tuple(refusals),
        boundaries={p: t.boundary for p, t in admitted.items()} if ok else {})


# ---------------------------------------------------------------------------
# §5a-cli. `revl deploy MAP --dry-run` — the plan-time admission surface
# ---------------------------------------------------------------------------


def _load_deploy_map(path: str) -> dict:
    """Read a deploy map (a placement map, docs/network-placement.md format,
    with the one new `[processes.<p>.deploy]` table) from TOML or JSON.

    Mirrors `placement._load_placement` deliberately: a deploy map IS a
    placement map, byte-identical when nothing is remote, and reading it must
    not diverge from how the conductor reads a placement.
    """
    text = Path(path).read_text(encoding="utf-8")
    if path.endswith(".json"):
        return json.loads(text)
    import tomllib  # noqa: PLC0415 — stdlib, py3.11+

    return tomllib.loads(text)


def _runtime_versions_from_args(pairs: Optional[Sequence[str]]) -> Optional[dict]:
    """Parse repeated ``--runtime-version name=ver`` flags into the mapping the
    runner reports on its verdicts. Returns ``None`` when none were given (the
    runner then omits the versions rather than reporting an empty set)."""
    if not pairs:
        return None
    versions: dict[str, str] = {}
    for pair in pairs:
        name, sep, version = pair.partition("=")
        if not sep or not name:
            raise ValueError(
                f"--runtime-version must be NAME=VERSION, got {pair!r}")
        versions[name] = version
    return versions


def deploy_admit_command(args) -> int:
    """`revl deploy-admit [--key PATH]... [--host-key PATH] [--require-gauntlet]
    [--require-conformance] [--runtime-version NAME=VER]...` — the far-side runner
    of the deploy orchestration channel (design §1.3 steps 4–5 / step 7).

    It reads one JSON request per line off stdin, serves each with the host's OWN
    trust configuration (the key files and evidence floor named on THIS command
    line, never anything the request carries — the S2.4 trust inversion), and
    writes one JSON reply per line to stdout. A PREPARE admit-request runs the
    chain verify (:func:`serve_admit_request`); a COMMIT commit-request runs the
    load-time measurement (:func:`serve_commit_request`); the routing is
    :func:`serve_deploy_request`, the same dispatch :class:`InProcessTransport`
    uses, so this process and the one-host stub behave identically. One process
    serves BOTH phases over its lifetime, exactly as a real channel does.

    This is the process a live transport spawns: locally as
    ``python -m revl deploy-admit ...`` (see :meth:`StdioRunnerTransport.local`),
    and across a machine boundary as the same command behind ``ssh <host>`` once
    the deferred staging + pinned-host-key leg (design R4/R5) lands. It stages and
    verifies; it never drives the local `apply` — that is the conductor's
    coordinated protocol (:func:`run_deploy`), unchanged.

    A line that is not a JSON object is answered with a fail-closed
    :data:`LINK_TRANSPORT` refusal rather than skipped: a runner that could not
    read what it was asked must refuse audibly, so the conductor fails closed on
    a reply it cannot tie to its request instead of the exchange hanging.

    The reason names the failure that actually occurred. Only a key file this
    runner owns (`--key`) is reported as unreadable key material
    (:class:`_HostKeyMaterialError`); everything else out of
    :func:`serve_deploy_request` — a corrupt staged bundle the CONDUCTOR
    supplied, most concretely `attest.load_attestation` on the bundle's own
    `attestation.json` — is reported as what it is, because the two faults are
    fixed on different machines and one wording for both sends an operator to
    debug the host when the conductor's bytes are wrong.
    """
    key_paths = list(getattr(args, "key", None) or [])
    host_key = None
    host_key_path = getattr(args, "host_key", None)
    if host_key_path is not None:
        try:
            host_key = _load_key(host_key_path)
        except (OSError, RevlError) as error:
            print(f"error: cannot read --host-key {host_key_path!r}: {error}",
                  file=sys.stderr)
            return 1
    try:
        runtime_versions = _runtime_versions_from_args(
            getattr(args, "runtime_version", None))
    except ValueError as error:
        print(f"error: {error}", file=sys.stderr)
        return 1
    require_gauntlet = bool(getattr(args, "require_gauntlet", False))
    require_conformance = bool(getattr(args, "require_conformance", False))

    for raw in sys.stdin:
        line = raw.strip()
        if not line:
            continue
        try:
            request_wire = json.loads(line)
        except json.JSONDecodeError as error:
            reply = _refusal(
                LINK_TRANSPORT,
                f"the deploy-admit runner could not parse a request line, so "
                f"nothing was served: {error}")
        else:
            if not isinstance(request_wire, dict):
                reply = _refusal(
                    LINK_TRANSPORT,
                    "the deploy-admit runner received a request line that is "
                    "not a JSON object, so nothing was served")
            else:
                try:
                    reply = serve_deploy_request(
                        request_wire, key_paths=key_paths, host_key=host_key,
                        require_gauntlet=require_gauntlet,
                        require_conformance=require_conformance,
                        runtime_versions=runtime_versions)
                except _HostKeyMaterialError as error:
                    # A `--key` file on THIS command line is unreadable, so the
                    # host has no trust store to admit against. The runner's own
                    # configuration, never anything the request carried.
                    reply = _refusal(
                        LINK_TRANSPORT,
                        f"the deploy-admit runner could not read its own key "
                        f"material, so nothing was served: {error}")
                except (OSError, RevlError) as error:
                    # Everything else: the request could not be SERVED, and the
                    # error names the path it failed on. Most often the staged
                    # bundle is unreadable — bytes the CONDUCTOR supplied, so
                    # blaming the runner's key material would send an operator
                    # to the wrong machine.
                    reply = _refusal(
                        LINK_TRANSPORT,
                        f"the deploy-admit runner could not serve the request, "
                        f"so nothing was served: {error}")
                # Either way the reply is a fail-closed LINK_TRANSPORT refusal:
                # it is a RECEIPT_KIND record with no `challenge`, so the
                # conductor's `AdmitResponse.from_wire` rejects it on the kind
                # guard and `request_admission` fails closed on a reply it
                # cannot tie to its request. One line in, one line out — the
                # exchange never hangs.
        sys.stdout.write(json.dumps(reply, sort_keys=True) + "\n")
        sys.stdout.flush()
    return 0


def deploy_command(args) -> int:
    """`revl deploy MAP [--dry-run] [--json]` — admit a deploy map and, without
    `--dry-run`, drive the coordinated deploy over its LOCAL participants.

    `--dry-run` is the deploy analogue of `revl plan` (design §1.1): it runs the
    whole fallible, EFFECT-FREE half — parse the map, admit every `[deploy]`
    target against the boundary rules (:func:`admit_deploy_map`) — and prints the
    verdict each target would return WITHOUT opening any boundary. A machine
    boundary is refused outright, an unknown `via` is refused rather than read
    as local, and a container target whose seam set this plan cannot prove
    seam-free fail-closes to `seam-set-unknown` — every rule refuses rather than
    downgrades, because the map is unauthenticated operator input (design R4).

    When `--bundle` names an attested bundle, its whole-composition attestation
    chain is verified on the PREPARE path FIRST (:func:`admit_bundle_chain`,
    design §1.3 step 4): the receiver re-hashes the staged IR and artifact bytes
    and checks them against the signed chain under the operator's own key(s),
    before any boundary opens. A refused chain refuses the whole deploy with
    nothing to roll back, and `--dry-run` runs this fallible half too.

    Without `--dry-run`, the admitted map is DEPLOYED over the coordinated
    PREPARE/COMMIT/ABORT protocol (:func:`run_deploy`), and the coordinator holds
    only the commit ledger — on any COMMIT failure it aborts in reverse commit
    order. A map of process-boundary targets goes through :func:`deploy_local_map`;
    a map that admits a `via = ssh` target goes through :func:`deploy_ssh_map`,
    which STAGES the attested `--bundle` onto each far host under its pinned host
    key and drives the SAME protocol over :class:`StdioRunnerTransport.ssh` +
    :class:`RemoteParticipant`. A cross-machine deploy requires `--bundle` (the
    far host re-hashes staged bytes), and a remote the coordinator cannot settle
    on ABORT is `unresolved`, never a false rollback. The container launch
    orchestration remains a following slice.
    """
    try:
        placement = _load_deploy_map(args.map)
    except (OSError, ValueError) as error:
        # ValueError covers tomllib.TOMLDecodeError and json.JSONDecodeError.
        print(f"error: cannot read deploy map {args.map!r}: {error}",
              file=sys.stderr)
        return 1

    verdict = admit_deploy_map(placement)
    as_json = getattr(args, "json", False)
    dry_run = getattr(args, "dry_run", False)

    # PREPARE, §2: if an attested bundle is named, verify its whole-composition
    # chain against the bytes on THIS disk BEFORE any boundary opens (design
    # §1.3 step 4, load-only-after-verify). It is effect-free, so a refusal is a
    # clean PREPARE-time refusal — nothing was staged or spawned. `--dry-run`
    # runs this half too: it is exactly the fallible check the deploy analogue
    # of `revl plan` is meant to make observable.
    chain: Optional[dict] = None
    chain_ok = True
    bundle_arg = getattr(args, "bundle", None)
    if bundle_arg is not None:
        try:
            chain = admit_bundle_chain(
                bundle_arg, key_paths=getattr(args, "key", None) or [],
                backend=getattr(args, "backend", None) or "python",
                require_gauntlet=getattr(args, "require_gauntlet", False),
                require_conformance=getattr(args, "require_conformance", False))
        except (OSError, RevlError) as error:
            print(f"error: cannot admit bundle {bundle_arg!r}: {error}",
                  file=sys.stderr)
            return 1
        chain_ok = chain.get("verdict") == ACCEPT

    # The plan-time surface: `--dry-run`, ANY map refusal, or a REFUSED
    # attestation chain reports the admission plan and stops before opening a
    # boundary.
    if dry_run or not verdict.ok or not chain_ok:
        if as_json:
            print(json.dumps({
                "ok": verdict.ok and chain_ok,
                "targets": {p: {"via": t.via, "boundary": t.boundary}
                            for p, t in verdict.targets.items()},
                "refusals": [dict(r) for r in verdict.refusals],
                "boundaries": verdict.boundaries,
                "chain": chain,
            }, indent=2))
        else:
            ok = verdict.ok and chain_ok
            n = len(verdict.targets) if verdict.ok else 0
            head = (f"deploy map {args.map}: admitted, {n} boundary-crossing "
                    f"target(s)" if ok
                    else f"deploy map {args.map}: REFUSED")
            print(head)
            for line in verdict.render():
                print(line)
            if chain is not None:
                if chain_ok:
                    print(f"  chain: ADMITTED (backend "
                          f"{chain.get('backend')!r}, artifact "
                          f"{str(chain.get('artifact_hash'))[:12]}...)")
                else:
                    print(f"  chain REFUSED [{chain.get('link')}]: "
                          f"{chain.get('reason')}")
        return 0 if (verdict.ok and chain_ok) else 1

    # COMMIT: drive the coordinated protocol. A map that admits a `via = ssh`
    # target opens the cross-machine leg (stage + ssh transport); an all-local
    # map stays on the process-boundary path. The choice is the admitted verdict,
    # not a flag, so a map can never open a boundary it did not admit.
    from . import wal  # noqa: PLC0415 — lazy; only the COMMIT path needs a WAL dir

    state_dir = (Path(wal.default_wal_dir()) / "deploy"
                 / Path(args.map).stem / str(0))
    has_ssh = any(t.via == VIA_SSH for t in verdict.targets.values())
    if has_ssh:
        report = deploy_ssh_map(
            placement, local_bundle=bundle_arg,
            backend=getattr(args, "backend", None) or "python",
            state_dir=state_dir, federation_id=Path(args.map).stem, generation=0,
            ssh_exe=getattr(args, "ssh_exe", None) or "ssh",
            scp_exe=getattr(args, "scp_exe", None) or "scp")
    else:
        report = deploy_local_map(placement, state_dir=state_dir,
                                  federation_id=Path(args.map).stem, generation=0)
    if as_json:
        print(json.dumps(report, indent=2))
    else:
        for line in _render_deploy_report(args.map, report):
            print(line)
    return 0 if report.get("verdict") == DEPLOY_APPLIED else 1


# ---------------------------------------------------------------------------
# §5b. a participant on the far side of a container boundary
# ---------------------------------------------------------------------------


@dataclass
class ContainerParticipant(ProcessParticipant):
    """A :class:`Participant` running inside a container, spoken to over the
    container's own stdio.

    It is a :class:`ProcessParticipant` and nothing more, which is the finding:
    the coordinated protocol §3 defines does not care what kind of boundary the
    other end is behind, because it never held an inverse in the first place.
    What the boundary changes is TEARDOWN, and that lives in
    :data:`TEARDOWN_PROMISE`, not in the protocol.

    `container` is the runtime's name for the container, so an operator (or an
    incident) can find it, and so :meth:`stop` can force-remove one that `--rm`
    did not reap.
    """

    container: str = ""
    docker: str = "docker"

    def stop(self) -> None:
        super().stop()
        # `--rm` normally reaps it; a wedged or killed container may survive,
        # and a leaked container is a boundary nobody is watching any more.
        if self.container:
            try:
                subprocess.run([self.docker, "rm", "-f", self.container],
                               capture_output=True, timeout=30, check=False)
            except (OSError, subprocess.SubprocessError):  # pragma: no cover
                pass



def _spec_paths_reachable(target: "DeployTarget", spec_path: Path,
                          state_dir: Path) -> Optional[str]:
    """Refuse a spec whose state paths will not exist inside the boundary.

    Mounts are identity-mapped, so a path in the spec resolves inside the
    container only if it resolves to the same string on this side. A spec that
    names `/var/...` on a host where `/var` is a symlink to `/private/var` gets
    a mount at the canonical path and a participant looking at the other one:
    PREPARE succeeds (it reads nothing), and the participant dies MID-COMMIT
    with a FileNotFoundError, which the conductor can only report as
    `unresolved`. Turning that into a refusal before the boundary opens is the
    same discipline as resolving the image up front.
    """
    try:
        spec = json.loads(spec_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        return (f"target {target.process!r}: the participant spec {spec_path} "
                f"is unreadable ({error})")
    for key in ("world", "wal"):
        raw = spec.get(key)
        if not raw:
            return (f"target {target.process!r}: the participant spec names no "
                    f"{key!r}; a participant across a boundary must own a "
                    f"durable {key} inside the mounted state directory")
        given = Path(str(raw))
        resolved = given.resolve()
        if str(given) != str(resolved):
            return (
                f"target {target.process!r}: the spec's {key} path {str(given)!r} "
                f"is not canonical (it resolves to {str(resolved)!r}). Container "
                f"mounts are identity-mapped, so a non-canonical path names a "
                f"file that does not exist inside the boundary — and it would "
                f"not fail until the participant tried to write it, mid-COMMIT, "
                f"where the only verdict left is `unresolved`. Write canonical "
                f"paths into the spec.")
        if state_dir not in resolved.parents:
            return (
                f"target {target.process!r}: the spec's {key} path "
                f"{str(resolved)!r} is outside the mounted state directory "
                f"{str(state_dir)!r}, so it is not writable inside the boundary. "
                f"The participant owns its world and its WAL; both live in the "
                f"one read-write mount.")
    return None


def launch_container_participant(
        target: DeployTarget, *, spec_path: Path | str, state_dir: Path | str,
        participant_module: Optional[Path | str] = None,
        docker: Optional[str] = None,
        timeout: float = 30.0) -> tuple[Optional[ContainerParticipant], Optional[str]]:
    """Open a container boundary and put one participant behind it.

    Returns `(participant, None)` or `(None, diagnostic)`. A diagnostic is a
    REFUSAL and the caller must not proceed: every way this can fail — no
    runtime, an unreachable daemon, an image that does not resolve — is a
    boundary that was not established, and Slice 1's rule that a declared
    isolation is never downgraded to an unconfined process holds here too.

    `state_dir` is mounted READ-WRITE and holds the participant's world file and
    its WAL. That the conductor can also read that directory is what makes the
    container boundary's teardown promise better than the machine boundary's:
    when the container is destroyed the accumulator dies with it, but the WAL
    is still on this filesystem and `recovery.py` can roll back what it
    RECORDED. It does not make the destroyed container `rolled-back`.
    """
    from . import sandbox_runtime  # noqa: PLC0415 — optional, runtime-only

    if target.via != VIA_CONTAINER:
        return None, (f"target {target.process!r} is `via = {target.via}`, not "
                      f"`{VIA_CONTAINER}`; this launcher opens container "
                      f"boundaries only")
    if not target.image:
        return None, f"target {target.process!r} has no `image`"

    exe = docker or shutil.which("docker")
    if not exe:
        return None, (
            f"target {target.process!r} deploys into a container, but no "
            f"container runtime is on PATH (`docker`). The boundary cannot be "
            f"established, and a deploy never falls back to running the "
            f"participant unconfined on the conductor's own kernel.")
    rc, out, err = sandbox_runtime._run([exe, "version", "--format",
                                         "{{.Server.Version}}"])
    if rc != 0:
        return None, (
            f"target {target.process!r}: the container runtime is not usable "
            f"(`{Path(exe).name} version` failed: "
            f"{sandbox_runtime._tail(err) or sandbox_runtime._tail(out)}). Is "
            f"the daemon running? The deploy refuses rather than opening a "
            f"boundary it cannot see.")
    if subprocess.run([exe, "image", "inspect", target.image],
                      capture_output=True, timeout=timeout,
                      check=False).returncode != 0:
        pull = subprocess.run([exe, "pull", target.image], capture_output=True,
                              text=True, timeout=max(timeout, 300), check=False)
        if pull.returncode != 0:
            return None, (
                f"target {target.process!r}: image {target.image!r} is neither "
                f"present locally nor pullable "
                f"({sandbox_runtime._tail(pull.stderr)}). Pin an image that "
                f"exists (by digest); the deploy refuses rather than launching "
                f"into an image it could not resolve.")

    module = Path(participant_module) if participant_module is not None else (
        Path(__file__).resolve().parent / "_deploy_participant.py")
    if not module.is_file():  # pragma: no cover — a broken checkout/wheel
        return None, (f"the participant runner {module} is missing, so nothing "
                      f"can be put behind the boundary")

    spec_path = Path(spec_path).resolve()
    state_dir = Path(state_dir).resolve()
    spec_problem = _spec_paths_reachable(target, spec_path, state_dir)
    if spec_problem:
        return None, spec_problem
    name = f"revl-deploy-{target.process}-{os.urandom(4).hex()}"
    # Identity-mapped mounts (the same rule `sandbox_runtime` uses): a path the
    # conductor wrote into the spec resolves to the same file inside. The
    # participant runner and the spec are read-only; only the state directory
    # the participant OWNS is writable.
    mounts = [(str(state_dir), "rw"), (str(module), "ro")]
    if spec_path.parent != state_dir:
        mounts.append((str(spec_path.parent), "ro"))
    env = {"isolation": VIA_CONTAINER, "image": target.image, "fs": [],
           # the participant speaks stdio and owns a local file; it needs no
           # network, and a deploy participant that could reach one would be a
           # seam this boundary is refused for carrying.
           "net": "none"}
    argv = ([exe, "run"]
            + sandbox_runtime.container_flags(env, name=name, mounts=mounts,
                                              interactive=True)
            + [target.image, "python3", str(module), str(spec_path)])
    try:
        process = subprocess.Popen(  # noqa: S603 — argv built above, no shell
            argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, text=True)
    except OSError as error:
        return None, (f"target {target.process!r}: could not start the "
                      f"container ({error})")
    return ContainerParticipant(identity=target.process, process=process,
                                container=name, docker=exe), None


# ---------------------------------------------------------------------------
# §5c. the local (process-boundary) participant, and the CLI's COMMIT path
#      (roadmap item 118, Slice 2b)
# ---------------------------------------------------------------------------
#
# Slice 1 built `run_deploy` and left the caller to construct `Participant`s in
# Python; Slice 2a added the written map and its plan-time admission but wired
# the CLI to only the effect-free `--dry-run` half. This slice closes the gap
# the two left: it drives the coordinated PREPARE/COMMIT/ABORT protocol from a
# map, over the ONE boundary Slice 1 actually proved out — the process boundary
# (`via = local`). A container target is opened by `launch_container_participant`
# and a machine boundary never admits; both stay outside this entry point, which
# is honest because `admit_deploy_map` (called with no seam set here) admits only
# `via = local` targets, so every participant this path builds is the conductor's
# own child on this kernel.
#
# What is deliberately NOT here, and named so the boundary is explicit:
#   * the attested-bundle staging and the host-side chain verify (§2, `admit`):
#     PREPARE here is the landed effect-free admission, not the attestation half;
#   * cross-machine / container launch orchestration;
#   * a real `apply.py`-backed load of backend runtime — a local participant
#     activates its declared components as reversible boundary state with its own
#     WAL and LIFO teardown (the `_deploy_participant` model item 118 runs behind
#     every boundary, container included), which is exactly enough to exercise
#     the coordinated protocol end-to-end from a map.


def _local_participant_spec(process: str, components: Sequence[str],
                            state_dir: Path) -> Path:
    """Write one LOCAL process's participant spec, derived from its declared
    components.

    Each component becomes a reversible boundary-state activation the child
    OWNS, recorded in its own world file and WAL under `state_dir`. On ABORT the
    child runs its own newest-first unwind over exactly these — the conductor
    holds only a pipe and a name (`TEARDOWN_PROMISE[BOUNDARY_PROCESS]`).
    """
    state_dir.mkdir(parents=True, exist_ok=True)
    spec = {
        "identity": process,
        "world": str((state_dir / f"{process}.world.json").resolve()),
        "wal": str((state_dir / f"{process}.wal").resolve()),
        "effects": [{"name": str(c), "reversible": True} for c in components],
    }
    spec_path = state_dir / f"{process}.spec.json"
    spec_path.write_text(json.dumps(spec, sort_keys=True, indent=1) + "\n",
                         encoding="utf-8")
    return spec_path


def launch_local_participant(
        target: DeployTarget, *, spec_path: Path | str,
        python: Optional[str] = None,
        participant_module: Optional[Path | str] = None,
        timeout: float = 20.0
        ) -> tuple[Optional[ProcessParticipant], Optional[str]]:
    """Open a PROCESS boundary and put one participant behind it — the
    conductor's own child on this kernel (`via = local`, design §1.3 step 2's
    "path handoff, no copy").

    The mirror of :func:`launch_container_participant` for the boundary Slice 1
    proved out. It runs the same `_deploy_participant` runner (stdlib-only, so no
    PYTHONPATH plumbing is needed — the file is invoked by path) as a plain
    child; the coordinator then speaks the newline-JSON control channel to it
    exactly as it does across a container's stdio.

    Returns `(participant, None)` or `(None, diagnostic)`; a diagnostic is a
    REFUSAL and the caller must not proceed — a boundary that could not be
    established is never downgraded to running the slice inline in the
    conductor's own process.
    """
    if target.via != VIA_LOCAL:
        return None, (f"target {target.process!r} is `via = {target.via}`, not "
                      f"`{VIA_LOCAL}`; this launcher opens the process boundary "
                      f"only")
    module = Path(participant_module) if participant_module is not None else (
        Path(__file__).resolve().parent / "_deploy_participant.py")
    if not module.is_file():  # pragma: no cover — a broken checkout/wheel
        return None, (f"the participant runner {module} is missing, so nothing "
                      f"can be put behind the boundary")
    spec_path = Path(spec_path).resolve()
    if not spec_path.is_file():
        return None, (f"target {target.process!r}: the participant spec "
                      f"{spec_path} does not exist, so the boundary has nothing "
                      f"to run behind it")
    exe = python or sys.executable
    argv = [exe, "-u", str(module), str(spec_path)]
    try:
        process = subprocess.Popen(  # noqa: S603 — argv built above, no shell
            argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, text=True)
    except OSError as error:
        return None, (f"target {target.process!r}: could not start the local "
                      f"participant ({error})")
    return ProcessParticipant(identity=target.process, process=process,
                              timeout=timeout), None


def deploy_local_map(placement: Mapping, *, state_dir: Path | str,
                     approval_path: Optional[str] = None,
                     federation_id: str = "deploy",
                     generation: int = 0,
                     python: Optional[str] = None,
                     on_event: Optional[Callable[[str, str, dict], None]] = None
                     ) -> dict:
    """Drive the coordinated PREPARE/COMMIT/ABORT protocol (:func:`run_deploy`)
    over the LOCAL process participants a deploy map declares.

    This is the CLI's COMMIT path (design §1.3, `via = local`). It:

      1. admits the map (:func:`admit_deploy_map`) — the effect-free half that
         refuses a machine boundary, an unknown `via`, a network provider, and
         (with no seam set supplied here) every container target, so the only
         thing left to build is a process-boundary child;
      2. builds one :class:`ProcessParticipant` per process from that process's
         declared components (:func:`_local_participant_spec`);
      3. hands the ordered list to :func:`run_deploy`, which owns the commit
         ledger and drives ABORT in REVERSE commit order on any COMMIT failure,
         each unwind performed by the participant that holds the inverses.

    Returns the :func:`run_deploy` report unchanged on the happy/rollback paths,
    or a `DEPLOY_REFUSED` report when admission refuses or a participant will not
    even spawn (a PREPARE-time refusal: nothing committed, nothing to undo).
    """
    verdict = admit_deploy_map(placement)
    if not verdict.ok:
        return {
            "protocol": PROTOCOL,
            "verdict": DEPLOY_REFUSED,
            "phase": "admit",
            "reason": "the deploy map did not admit; no boundary was opened",
            "refusals": [dict(r) for r in verdict.refusals],
        }

    # After a clean admission with no seam set, every admitted target is
    # `via = local` (a container needs a proven-seam-free set this entry point
    # does not supply, and a machine boundary is refused outright), so a process
    # with no `[deploy]` table and one that wrote `via = local` are the same
    # process-boundary child here.
    processes = placement.get("processes") or {}
    state_dir = Path(state_dir)
    participants: list[ProcessParticipant] = []
    for pname in sorted(processes):
        pconf = processes.get(pname) or {}
        components = pconf.get("components") or []
        target = verdict.targets.get(pname) or DeployTarget(
            process=pname, via=VIA_LOCAL, raw={})
        spec_path = _local_participant_spec(pname, components, state_dir)
        participant, error = launch_local_participant(
            target, spec_path=spec_path, python=python)
        if error is not None:
            for started in participants:
                started.stop()
            return {
                "protocol": PROTOCOL,
                "verdict": DEPLOY_REFUSED,
                "phase": "launch",
                "refusedBy": pname,
                "reason": error,
                "proof": ("a participant that could not be spawned is a "
                          "PREPARE-time refusal: no participant committed, so "
                          "there is nothing to roll back."),
            }
        participants.append(participant)

    try:
        report = run_deploy(participants, approval_path=approval_path,
                            federation_id=federation_id, generation=generation,
                            on_event=on_event)
    finally:
        for participant in participants:
            participant.stop()
    return report


# ---------------------------------------------------------------------------
# §5d. the cross-machine (`via = ssh`) COMMIT path (roadmap item 118, toward #79)
# ---------------------------------------------------------------------------
#
# `deploy_local_map` drives the coordinated protocol over the process boundary.
# This is its cross-machine sibling: a map that admits a `via = ssh` target is
# staged and driven over :class:`StdioRunnerTransport.ssh` + :class:`RemoteParticipant`,
# reusing :func:`run_deploy` UNCHANGED. Nothing here is a second protocol — the
# RemoteParticipant carries PREPARE (`request_admission`) and COMMIT
# (`request_commit`, whose `compare_commit_receipt` gate is integral), and its
# `abort` is the honest cross-machine one: the runner protocol has no ABORT leg,
# so a committed remote is reported `unresolved`, never a rollback the conductor
# did not obtain. The conductor holds only the commit ledger, exactly as for a
# local deploy.
#
# The bundle is staged to each ssh host FIRST (design §1.3 step 2), over the same
# pinned identity. A stage or a pre-flight host-key failure is a PREPARE-time
# refusal: nothing was activated, so there is nothing to roll back — the same
# fail-closed shape as a local participant that will not even spawn.


def _new_challenge() -> str:
    """A fresh orchestration-channel nonce: the runner echoes it so the conductor
    can bind a reply to the request it sent (not a replayed earlier one)."""
    return os.urandom(16).hex()


def _ssh_participant(target: "DeployTarget", *, local_bundle: Path | str,
                     backend: str, ssh_exe: str, scp_exe: str
                     ) -> tuple[Optional["RemoteParticipant"], Optional[str]]:
    """Stage the attested bundle onto `target`'s host under its pinned key, then
    build the :class:`RemoteParticipant` that drives PREPARE/COMMIT over ssh.

    Returns `(participant, None)` or `(None, diagnostic)`; a diagnostic is a
    PREPARE-time REFUSAL — the boundary was not opened and nothing committed, so
    the caller aborts the whole deploy with nothing to unwind. Every failure mode
    (an absent field the map should have carried, an unpinned host key, a stage
    that would not complete) refuses rather than proceeding under a boundary it
    could not establish.
    """
    raw = target.raw or {}
    host = target.host
    known_hosts = raw.get("known_hosts")
    if not host or not known_hosts:
        return None, (f"target {target.process!r} is `via = ssh` but names no "
                      f"{'host' if not host else 'known_hosts'}; a machine "
                      f"target is only opened under a pinned host key")
    host_key_path = raw.get("host_key")
    if not host_key_path:
        return None, (
            f"target {target.process!r} names no `host_key`: the conductor needs "
            f"a copy of the far host's receipt-signing key to VERIFY the signed "
            f"admission and COMMIT receipts it gets back (R5). Without it a "
            f"reply cannot be attributed to the host, so the deploy refuses "
            f"rather than trusting an unverifiable receipt.")
    remote_bundle = raw.get("remote_bundle")
    if not remote_bundle:
        return None, (
            f"target {target.process!r} names no `remote_bundle`: the far host "
            f"re-hashes the bytes on ITS disk, so the deploy must say where to "
            f"stage them. A cross-machine deploy with nowhere to stage is "
            f"refused rather than run against unstaged bytes.")
    try:
        host_key = _load_key(host_key_path)
    except (OSError, RevlError) as error:
        return None, (f"target {target.process!r}: cannot read the far host's "
                      f"receipt key {host_key_path!r}: {error}")

    port = raw.get("port")
    port = int(port) if port is not None else None
    remote_revl = target.runner or "revl"
    extra_args = [str(a) for a in (raw.get("extra_args") or [])]

    try:
        transport = StdioRunnerTransport.ssh(
            str(host), known_hosts=str(known_hosts), ssh_exe=ssh_exe,
            remote_revl=remote_revl, port=port, extra_args=extra_args)
    except ValueError as error:
        return None, f"target {target.process!r}: {error}"

    # Located pre-flight BEFORE staging: refuse an unpinned/wrong-host key here,
    # so a boundary that would not verify is never even copied to.
    try:
        transport.verify_host_key()
    except SshRunnerRefused as error:
        return None, (f"target {target.process!r}: {error.message}")

    # Stage over the SAME pinned identity (design §1.3 step 2).
    try:
        staged = stage_bundle_over_ssh(
            local_bundle, host=str(host), remote_bundle=str(remote_bundle),
            known_hosts=str(known_hosts), scp_exe=scp_exe, port=port)
    except BundleStageRefused as error:
        return None, (f"target {target.process!r}: {error.message}")

    participant = RemoteParticipant(
        target.process, transport,
        admit_request=AdmitRequest(bundle=staged, backend=backend,
                                   challenge=_new_challenge()),
        commit_request=CommitRequest(bundle=staged, backend=backend,
                                     challenge=_new_challenge()),
        host_key=host_key)
    return participant, None


def deploy_ssh_map(placement: Mapping, *, local_bundle: Path | str,
                   backend: str = "python", state_dir: Path | str,
                   approval_path: Optional[str] = None,
                   federation_id: str = "deploy", generation: int = 0,
                   ssh_exe: str = "ssh", scp_exe: str = "scp",
                   python: Optional[str] = None,
                   on_event: Optional[Callable[[str, str, dict], None]] = None
                   ) -> dict:
    """Drive the coordinated PREPARE/COMMIT/ABORT protocol (:func:`run_deploy`)
    over a deploy map that admits at least one `via = ssh` target (design §1.3,
    the cross-machine leg toward #79).

    The cross-machine sibling of :func:`deploy_local_map`. It admits the map,
    then builds one participant per process — a :class:`RemoteParticipant` over a
    staged, pinned ssh channel for a `via = ssh` target, and a local
    :class:`ProcessParticipant` for a `via = local` one, so a mixed map deploys
    as one coordinated unit — and hands the ordered list to :func:`run_deploy`,
    unchanged. The conductor holds only the commit ledger and drives ABORT in
    reverse commit order on any COMMIT failure; a remote it cannot settle is
    `unresolved`, never a false rollback.

    A cross-machine deploy REQUIRES an attested `local_bundle`: the bytes are
    staged and re-hashed on the far host, and there is nothing to stage without
    one. A staging or admission refusal is a PREPARE-time refusal (nothing
    committed) and returns a `DEPLOY_REFUSED` report.
    """
    verdict = admit_deploy_map(placement)
    if not verdict.ok:
        return {
            "protocol": PROTOCOL,
            "verdict": DEPLOY_REFUSED,
            "phase": "admit",
            "reason": "the deploy map did not admit; no boundary was opened",
            "refusals": [dict(r) for r in verdict.refusals],
        }
    if local_bundle is None:
        return {
            "protocol": PROTOCOL,
            "verdict": DEPLOY_REFUSED,
            "phase": "stage",
            "reason": ("a cross-machine (`via = ssh`) deploy needs an attested "
                       "`--bundle`: the far host re-hashes staged bytes, and a "
                       "deploy with nothing to stage is refused rather than run "
                       "against bytes it never verified."),
        }

    processes = placement.get("processes") or {}
    state_dir = Path(state_dir)
    participants: list[Participant] = []
    local_started: list[ProcessParticipant] = []
    for pname in sorted(processes):
        pconf = processes.get(pname) or {}
        target = verdict.targets.get(pname) or DeployTarget(
            process=pname, via=VIA_LOCAL, raw={})
        if target.via == VIA_SSH:
            participant, error = _ssh_participant(
                target, local_bundle=local_bundle, backend=backend,
                ssh_exe=ssh_exe, scp_exe=scp_exe)
        else:
            components = pconf.get("components") or []
            spec_path = _local_participant_spec(pname, components, state_dir)
            participant, error = launch_local_participant(
                target, spec_path=spec_path, python=python)
            if participant is not None:
                local_started.append(participant)
        if error is not None:
            for started in local_started:
                started.stop()
            return {
                "protocol": PROTOCOL,
                "verdict": DEPLOY_REFUSED,
                "phase": "stage" if target.via == VIA_SSH else "launch",
                "refusedBy": pname,
                "reason": error,
                "proof": ("a boundary that could not be established (staged / "
                          "spawned) is a PREPARE-time refusal: nothing "
                          "committed, so there is nothing to roll back."),
            }
        participants.append(participant)

    try:
        report = run_deploy(participants, approval_path=approval_path,
                            federation_id=federation_id, generation=generation,
                            on_event=on_event)
    finally:
        for participant in local_started:
            participant.stop()
    return report


def _render_deploy_report(map_path: str, report: Mapping) -> list[str]:
    """Human-readable form of a :func:`deploy_local_map` / :func:`run_deploy`
    report: the aggregate verdict, each participant's outcome, the commit ledger
    and — on an abort — the reverse-order teardown and any residue."""
    lines = [f"deploy map {map_path}: {report.get('verdict')} "
             f"({report.get('protocol')})"]
    if report.get("reason"):
        lines.append(f"  {report['reason']}")
    if report.get("refusedBy"):
        lines.append(f"  refused by: {report['refusedBy']}")
    for refusal in report.get("refusals") or ():
        lines.append(f"  REFUSED [{refusal.get('rule')}] "
                     f"{refusal.get('process')}: {refusal.get('reason')}")
    participants = report.get("participants") or {}
    for identity in sorted(participants):
        lines.append(f"  participant {identity}: "
                     f"{participants[identity].get('outcome')}")
    ledger = report.get("commitLedger") or []
    if ledger:
        lines.append("  commit ledger: "
                     + " -> ".join(f"{e['identity']}(#{e['order']})"
                                   for e in ledger))
    if report.get("failedAt"):
        lines.append(f"  COMMIT failed at: {report['failedAt']}")
    if report.get("abortOrder"):
        lines.append("  abort order (reverse commit): "
                     + " -> ".join(report["abortOrder"]))
    residue = report.get("residue") or {}
    if residue:
        lines.append("  residue: "
                     + ("clean" if residue.get("clean") else "PRESENT"))
        for item in residue.get("outstanding") or ():
            lines.append(f"    outstanding: {item}")
    return lines
