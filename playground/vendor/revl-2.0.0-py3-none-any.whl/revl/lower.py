"""Checking and lowering: typed AST -> backend IR (docs/backend-ir.md).

Guarantee enforcement map (DESIGN.md §4):
  G1 undeclared access        -> _lower_postfix name resolution
  G2 provision disjointness   -> link()
  G3 dependency cycles        -> link()
  G4 inverse-or-emit          -> parser (missing undo) + emission checks here
  G5 no teardown registration -> by construction (undo is an expression;
                                 there is no syntactic position for effects)
  G6 purity outside effects   -> by construction (statement grammar)
  A2 no acquisition after provide -> check_component body scan
"""

from __future__ import annotations

import contextlib
import copy
import dataclasses
import keyword
import os
import re
from collections import deque

from . import holes, ownership
from ._paths import stdlib_root
from .errors import RevlError, RevlErrors
from .hostfile import _contained
from .why import CHAIN, SET, TraceStep, WhyTrace
from .typecheck import (
    CASES_KEY,
    _reject_float_literal_range,
    FN_HEAD,
    FNS_KEY,
    PRINCIPAL,
    PRINCIPAL_PRODUCER_HINT,
    _SIZED_HEADS,
    check_ast,
    refuse_self_declared_async,
    _mentions_async,
    collect_tparams,
    validate_explicit_tparams,
    render_type,
    widen_bottom,
    mark_tparams,
    check_type_wellformed,
    check_config_field_is_data,
    compatible,
    format_type,
    host_check,
    _HOST_ACQUIRE_VERBS,
    _HOST_FAMILIES,
    _HOST_RESULT_SIG,
    check_ir,
    infer_ast,
    infer_ir,
    mismatch,
    pin_hole,
    null_error,
    parse_type,
    POISON,
    structural_fields,
    substitute,
    unify,
    _is_wildcard,
    _check_method_namespace_disjoint,
)
from .taint import (
    extract_and_normalize,
    fold_ambient_composition,
    check_taint,
    splice_declassifiers,
    strip_qualifiers,
)
from .mcp.schema import (
    _parse_type as _schema_parse_type,
    expressibility_reason,
    fully_expressible,
    has_revl_stub,
    json_schema_for,
)
from .resources import (
    DELEGATE_HEAD,
    NO_HANDLE_RETURNS,
    _callee_name,
    acquire_return_is_nominal_handle,
    closing_ops,
    resource_in,
    resource_taint,
)
from .parser import (
    NESTING_LIMIT,
    recursion_headroom,
    _describe_expr,
    missing_undo_refusal,
    AbortStmt,
    AdvanceStmt,
    AssertStmt,
    AssignStmt,
    AwaitStmt,
    BreakStmt,
    CallStmt,
    ComponentDecl,
    ContinueStmt,
    EffectStmt,
    EmitExpr,
    EmitStmt,
    FailStmt,
    ExprArrow,
    ExprBin,
    ExprBlockArm,
    ExprCall,
    ExprEndorse,
    ExprField,
    ExprHole,
    ExprIf,
    ExprIndex,
    ExprList,
    ExprLit,
    ExprMatch,
    ExprOptCall,
    ExprOptField,
    ExprAsset,
    ExprRecord,
    ExprRecordUpdate,
    ExprStmt,
    ExprUn,
    ExprVar,
    FnDecl,
    FnParam,
    ForStmt,
    HandoffStmt,
    IfStmt,
    Interp,
    InterceptStmt,
    IsolateStmt,
    LeaseAcquire,
    LetApprovalStmt,
    LetEffect,
    LetPatternStmt,
    LetStmt,
    LoadStmt,
    ListPattern,
    Lit,
    Postfix,
    Program,
    ProvideStmt,
    RecordPattern,
    ResidueStmt,
    ReturnStmt,
    RouteStmt,
    ServiceDecl,
    SpawnExpr,
    StreamIterStmt,
    StreamMergeExpr,
    SubscribeExpr,
    TestDecl,
    TimerStmt,
    TypeDecl,
    UnloadStmt,
    WhileStmt,
    LIST_TRANSFORMS,
    desugar_list_transform,
)

IR_VERSION = 1

# item 384: foreign-construct redirect table (name-resolver half).
#
# A large share of first-try authorship failures used a known-foreign idiom
# that LEXES as an ordinary identifier — `and`/`or`/`not`, `True`/`False`,
# `const`, `len(...)`, `print`, `throw` — and so fell through to the generic
# G1 "`X` is not declared … declare it with `let`/`var`". That message
# ACTIVELY MISLEADS: it tells the author to declare a variable when the real
# fix is a different construct. This table implements syntax-2.0 §0/§10's
# exclusion-diagnostic philosophy (already done for `null`/`class`/`switch`/
# `let`-reassign) for the identifier-shaped holes: when an undeclared name is
# a known foreign idiom, the resolver names the idiom and the revl spelling
# instead of emitting G1.
#
# PRECISION: the redirect fires ONLY on an *undeclared* name. None of these
# is a revl keyword, so an author who genuinely binds one (`let and = …`,
# `fn len(...) { … }`) shadows the entry and never sees the redirect — the
# resolver reaches this table only after `scope`/`callables` lookup has
# already missed. So no valid revl program changes behaviour; only the
# message on an already-failing program does. Each value is (message, hint).
_FOREIGN_NAME_REDIRECTS = {
    "and": ("`and` is not a revl operator",
            "use `&&` for boolean conjunction (syntax-2.0 §3.2)"),
    "or": ("`or` is not a revl operator",
           "use `||` for boolean disjunction (syntax-2.0 §3.2)"),
    "not": ("`not` is not a revl operator",
            "use the prefix `!` for boolean negation (syntax-2.0 §3.2)"),
    "True": ("revl booleans are lowercase",
             "use `true`, not `True` (syntax-2.0 §3.2)"),
    "False": ("revl booleans are lowercase",
              "use `false`, not `False` (syntax-2.0 §3.2)"),
    "const": ("revl has no `const`",
              "use `let` (single-assignment) or `var` (mutable) (syntax-2.0 §3.5)"),
    "len": ("revl has no `len(...)`",
            "a list's length is `xs.length()` (docs/stdlib-2.0.md)"),
    "print": ("revl has no `print`",
              "pure code has no I/O — emit output through a service effect "
              "(syntax-2.0 §4)"),
    "throw": ("revl has no `throw`",
              "a pure function returns a `Result`; a component activation body "
              "signals failure with `fail` (syntax-2.0 §3.3, §4b.5)"),
    "def": ("revl has no `def`",
            "a function is declared with `fn` (syntax-2.0 §3.1)"),
    "lambda": ("revl has no `lambda`",
               "an anonymous function is an arrow `x => …` (syntax-2.0 §3.2)"),
    "elif": ("revl has no `elif`",
             "chain with `else if` (syntax-2.0 §3.2)"),
}


def _reject_foreign_name(name, filename, line):
    """If `name` is a known foreign idiom that lexes as an identifier, raise
    the specific redirect instead of the generic, misleading G1 (item 384).
    Returns None (and the caller falls through to G1) for any other name."""
    hit = _FOREIGN_NAME_REDIRECTS.get(name)
    if hit is not None:
        message, hint = hit
        raise RevlError(filename, line, message, hint=hint)


# finding 6: the specified stdlib surface (docs/stdlib-2.0.md). Method calls
# on values must name one of these (arity-checked); everything else is a
# compile error — never a verbatim pass-through to whatever the host object
# happens to have. Names are chosen to be collision-free with the v1 host
# stub objects (open/close/query/execute/new/get/insert/remove/drop).
_BUILTIN_METHODS = {
    "length": 0, "push": 1, "slice": 2, "charAt": 1,
    "charCodeAt": 1, "codepoint_at": 1, "indexOf": 1, "concat": 1,
    "split": 1, "join": 1, "repeat": 1,
    # The prefix/suffix probes (FR-6, docs/stdlib-2.0.md §Str.startsWith):
    # Str-only, one Str argument.
    "startsWith": 1, "endsWith": 1,
    # Single-character ASCII classification (item 233, docs/stdlib-2.0.md
    # §Str.is_alnum): Str-only, no argument. Cuts the self-host lexer's
    # per-byte revl-fn-call + code-point-range tax to a native inline test.
    "is_alnum": 0, "is_digit": 0, "is_alpha": 0, "is_space": 0,
    # Integer division and modulo. `/` and `%` keep the meaning TypeScript
    # gives them (§0); these name what they do, so no tier has to guess and
    # none can quietly pick its host's convention (docs/arithmetic.md).
    "div_trunc": 1, "div_floor": 1, "div_euclid": 1, "mod": 1,
    # Int/Int32 width conversions (docs/arithmetic.md). `to_int` widens an
    # Int32 to Int (lossless); `to_int32` narrows an Int to Int32 (checked,
    # traps out of the 32-bit range).
    "to_int": 0, "to_int32": 0,
    # The total forms (docs/arithmetic.md): a zero divisor is the *point*
    # here, so these are deliberately absent from _DIVIDES_BY below — a
    # literal zero argument is refused for the faulting operations only.
    "checked_div_trunc": 1, "checked_div_floor": 1,
    "checked_div_euclid": 1, "checked_mod": 1,
    # The Map value type (docs/stdlib-2.0.md §Map). Names disjoint from the
    # host verb set (open/close/query/execute/new/get/insert/remove/drop):
    # the two method namespaces stay collision-free by construction.
    "set": 2, "lookup": 1, "has": 1,
    # The iteration/remove step (docs/stdlib-2.0.md §Map): same namespace
    # discipline — disjoint from the host verb set by construction.
    "size": 0, "keys": 0, "remove": 1,
    # The rendering builtin (docs/stdlib-2.0.md §Int.to_str).
    "to_str": 0,
    # The Value dot-method accessors (roadmap item 189): receiver-first sugar
    # for stdlib/value.rvl's `value_*` free functions. `.field(k)` takes one
    # Str; `.str()`/`.list()`/`.keys()` take none (`keys` arity already set by
    # the Map row above — the two share the name, disambiguated by the receiver
    # type at lower time). Each is rewritten to a plain CALL of its `value_*`
    # equivalent below (`_VALUE_ACCESSORS`), so it emits byte-identically to the
    # nested free-function form and needs NO new IR expr-kind.
    "field": 1, "str": 0, "list": 0,
}

# The Value dot-accessor method -> the `value_*` free function it desugars to
# (roadmap item 189, stdlib/value.rvl). `node.field("k").str()` lowers to the
# SAME call IR as `value_str(value_field(node, "k"))`, so it is pure sugar: the
# emitted code is byte-identical on every tier value.rvl runs on, with zero
# per-backend work (the existing call-rendering path handles all six tiers).
_VALUE_ACCESSORS = {
    "field": "value_field", "str": "value_str",
    "list": "value_list", "keys": "value_keys",
}

# The disjointness this comment block promises is a *checked* claim, enforced
# at module load (table-edit time), not at golden-diff time: editing this
# table with a name from the host stub surface reclassifies every host call
# site of that name and surfaces only as broken tests across the suite
# (roadmap 75(b) tooling half; dogfood/findings-mapiter.md §2). `remove` is
# the ONE sanctioned overlap (docs/stdlib-2.0.md §Map) — dispatch by receiver
# kind is what makes it safe.
_check_method_namespace_disjoint(_BUILTIN_METHODS, "_BUILTIN_METHODS")


# item 246: a reserved key on the `types` table (like FNS_KEY/CASES_KEY) carrying
# the declaration-owned approval facts so `_lower_emit_step` can consult them
# without a signature change to `_lower_component`. `{"required": {cap, ...},
# "externs": {name: entry}}`.
APPROVAL_KEY = "__approval__"


def _approval_index(externs: list) -> dict:
    """The declaration-owned approval facts (item 246). `required` is the set of
    capability tokens whose crossing needs a covering `with e` edge — a host
    emission extern contributes its NAME (the token the G8 audit and the boundary
    policy already use for it). `externs` indexes the lowered entries so a single
    emit's crossed capabilities can be resolved at the crossing site."""
    by_name = {e["name"]: e for e in externs}
    required = {e["name"] for e in externs if e.get("requires_approval")}
    return {"required": required, "externs": by_name}


def _approval_covers(scope: str, token: str) -> bool:
    """Whether an `Approval[scope]` covers a crossing of capability `token`:
    `token` is within `scope`'s reach. Exact match, or a glob scope
    (`prod.*`) matching the token (Decision 3, `C within C'`'s scope)."""
    from fnmatch import fnmatchcase  # noqa: PLC0415 — stdlib, only on a crossing
    return scope == token or fnmatchcase(token, scope)


def _emit_crossed_caps(node: dict, env: "Env") -> list:
    """The capability token(s) a single `emit <call>` crosses. A req-target
    service emission contributes the method's `emission[...]` scope (or `*` when
    bare); a direct host emission extern contributes its name (or its declared
    scope). The same tokens the G8 boundary surface names, resolved for ONE
    crossing so the approval obligation is per-crossing, not per-method."""
    kind = node.get("kind")
    target = node.get("target")
    if kind == "call" and isinstance(target, dict) and target.get("kind") == "req":
        service = env.requires.get(target.get("name"))
        svc = env.services.get(service) if service else None
        spec = svc.methods.get(node.get("method")) if svc is not None else None
        caps = getattr(spec, "capabilities", None) if spec is not None else None
        return list(caps) if caps else ["*"]
    # a direct host-extern emission call: `{"kind": "fn", "name": <extern>}`.
    if kind == "fn":
        index = (env.types.get(APPROVAL_KEY) or {}).get("externs") or {}
        entry = index.get(node.get("name"))
        if entry is not None and entry.get("class") == "emission":
            return list(entry.get("capabilities") or [node.get("name")])
    return []


# Integer division and modulo are undefined at zero, and every tier says so
# differently — python raises, rust and wasm trap, java throws, and TypeScript
# used to hand back Infinity. A *literal* zero divisor is never a program
# anyone meant to write, so it does not need to reach any of them.
_DIVIDES_BY = ("div_trunc", "div_floor", "div_euclid", "mod")


def _refuse_zero_divisor(method: str, args, filename: str, line: int) -> None:
    from .parser import ExprLit as _Lit

    if method not in _DIVIDES_BY or not args:
        return
    divisor = args[0]
    if isinstance(divisor, _Lit) and divisor.value == 0:
        raise RevlError(
            filename, line,
            f"`{method}` by a literal zero is undefined",
            hint="integer division and modulo have no value at zero; guard the "
                 "divisor (`if (b == 0) { ... }`) or use a non-zero constant")


def _refuse_unpinned_stdlib_method(method: str, recv_t: str | None,
                                   filename: str, line: int) -> None:
    """The stdlib-named-method sliver (roadmap 75(b), docs/contract-errata.md
    "Typing gaps"): a method call on a receiver whose type no constructor pins
    must not lower as the builtin. At runtime the value is whatever the host
    returned (or whatever the type parameter was instantiated with), not a
    Str/List/Int/Int32/Bytes/Map value, so the builtin dispatch misbehaves on
    every tier. Only a receiver the checker can *prove* is a stdlib value may
    take the builtin table; everything else stays on the G8 audit surface,
    refused here with the same HOST-METHOD diagnostic the family surface uses."""
    shown = render_type(recv_t) or "unknown"
    raise RevlError(
        filename, line,
        f"stdlib method `{method}` on a value of {shown} type — no constructor "
        "pins this receiver as a Str/List/Int/Int32/Bytes/Map value, so the "
        "checker refuses to lower the call as the builtin",
        hint="host-object results carry no type (G8): annotate the binding "
             "(`let v: Str = ...`) or route the value through a declared type "
             "before calling methods on it",
        code="HOST-METHOD", category="host-boundary",
    )


def _is_host_valued(expr, scope) -> bool:
    """A receiver holding a HOST object (Map.new(), Pool.open(...), or a let
    bound to one): its methods belong to the host stub, not the stdlib
    table, and stay verbatim."""
    from .parser import ExprCall as _C, ExprField as _F, ExprVar as _V

    if isinstance(expr, _V):
        return scope.get(expr.name) == "host"
    if isinstance(expr, _C) and isinstance(expr.callee, _F)             and isinstance(expr.callee.target, _V):
        # `Map.empty()` is the Map VALUE constructor (docs/stdlib-2.0.md
        # §Map) — a pure value, not a host acquisition. Its constructor ROOT
        # is a host callable, so without this exclusion a `let m =
        # Map.empty()` bound the name as "host" and every later
        # m.set/m.lookup/m.has lowered as a verbatim *field* call: unchecked
        # at compile time, AttributeError-shaped at runtime.
        if expr.callee.target.name == "Map" and expr.callee.name == "empty":
            return False
        return expr.callee.target.name in _HOST_CALLABLES
    return False
IR_VERSION_V2 = 2  # emitted only when a compiled component uses realms/interception
IR_VERSION_V3 = 3  # emitted when a program uses full-language features (fn/type)

# The immutable set of IR schema revisions this frontend understands (roadmap
# item 479). A staged IR document stamps exactly one of these onto `ir_version`;
# the wire codec that carries a revision is only ever emitted at a member of
# this set. A document whose `ir_version` is a revision outside it was produced
# by a schema revision this frontend does not know (a newer/forked emitter, or a
# drifted gate crate): the IR-boundary decode REFUSES it BY NAME rather than
# best-effort decoding an unknown revision, which is exactly how a
# gate-crate/frontend skew would slip past. Add a new revision here in the same
# change that starts emitting it.
IR_SCHEMA_REVISIONS = frozenset({IR_VERSION, IR_VERSION_V2, IR_VERSION_V3})

# The complete top-level surface of a compiled IR document (roadmap item 479).
# Every member `check_and_lower` (below) and `compile_source`/`compile_files`
# (compiler.py) can stamp onto the returned document, in one place beside the
# code that produces it. This is the frontend's authoritative answer to "what
# top-level fields does a staged IR document know?" — a field outside this set
# is one this schema revision has never emitted, so the IR-boundary decode
# REFUSES it BY NAME rather than silently ignoring it (which is exactly how a
# gate-crate/frontend skew would go undetected). Keep it in lockstep with the
# `result`/`document` assembly: a new optional member must be added here in the
# same change that starts emitting it, or the frontend refuses its own output.
IR_TOPLEVEL_FIELDS = frozenset({
    "ir_version",     # the schema revision this document was emitted at
    "services",       # the service interface table
    "components",     # the newly compiled components
    "manifest",       # the composition manifest (whole resulting composition)
    "types",          # user-declared types (present only when declared)
    "functions",      # module-level fns (present only when declared)
    "externs",        # host requirements (present only when declared)
    "secrets",        # manifest-visible secret bindings (name + capability)
    "tests",          # lowered `test` bodies
    "prop_tests",     # lowered `prop test` bodies
    "fault_tests",    # lowered fault-injection tests
    "holes",          # the obligation ledger (present only for a draft)
    "stdlib_shadow",  # item 422: a shadowed stdlib module, when one was used
    "rows",           # item 426 S1: the composition row table, emitted onto the
                      # document and copied onto the manifest, so it re-enters
                      # the frontend at the S3 admit round-trip
})


def _ir_params(named_types, secret_params=()) -> list:
    """The IR `params` list for a declaration, carrying the `Secret[T]` marking.

    `named_types` yields `(name, type)` pairs; `secret_params` is the index set
    `taint.extract_and_normalize` stamped on the declaration for the positions
    the author declared `Secret[T]`.

    The qualifier itself is stripped from `type` before lowering (orthogonality:
    the base checker and every emitter see bare types), so this flag is the ONLY
    surviving statement that position `i` is a declared disclosure receiver. The
    recorder reads it back to decide what a crossing's argument is allowed to
    look like in the WAL and in an MCP response — the runtime cannot re-derive
    confidentiality from a value.

    Additive: absent unless the author wrote `Secret[T]`, so every existing IR
    document stays byte-identical."""
    secret = frozenset(secret_params or ())
    return [{"name": name, "type": type_name,
             **({"secret": True} if index in secret else {})}
            for index, (name, type_name) in enumerate(named_types)]


def _ir_config_field(field) -> dict:
    """The IR entry for one component config field, carrying the `Secret[T]`
    marking `taint.extract_and_normalize` stamped on it.

    Same reason as `_ir_params`: the qualifier is stripped off `type` before
    lowering, so the flag is the only surviving statement that this field holds
    a credential. The emitted `ConfigSchema` reads it back to keep the value out
    of the `<name>.config` trace line, which `revl run` prints and the MCP
    session captures. Absent unless declared, so existing IR is byte-identical."""
    return {"name": field.name, "type": field.type, "default": field.default,
            **({"secret": True} if getattr(field, "secret", False) else {}),
            # item 350: the declared admission bound on a boot component's
            # environment-contract field. Absent unless declared, so every
            # existing config field's IR entry is byte-identical.
            **({"bound": getattr(field, "bound", None)}
               if getattr(field, "bound", None) else {})}

# ── IR expression-kind schema (roadmap item 76a) ─────────────────────────────
# The complete set of expression kinds this frontend can lower, split by the
# positions in which each can appear. This is the *registration point* for a
# new expression kind: adding one to the lowering MUST add it to the position
# set(s) that match where the frontend can produce it — which automatically
# adds it to EXPR_KINDS — and then
# tests/test_expr_dispatcher_conformance.py fails until every backend declares
# where it handles or deliberately refuses the kind in each dispatcher. A kind
# that ships without a registration is exactly the "patched one of two paths"
# failure the test exists to turn red.
#
#   FN        — a pure-function body (``_lower_pure_expr``).
#   COMPONENT — a component body / provide-method body / block-effect setup
#               (``_lower_component_pure_expr`` + component step lowering).
#
# The split is factual, not aspirational: `len` and `interp` are produced only
# in fn bodies (component positions spell `.length` as a `field` and templates
# as `format`), while `name`/`config`/`req`/`host`/`format`/`fn`/`spawn`/
# `instance-get` are produced only in component positions. Everything else can
# appear in both.
EXPR_KINDS_FN: frozenset[str] = frozenset({
    "adt", "arrow", "bin", "builtin", "call", "field", "hole", "if", "index",
    "interp", "len", "list", "lit", "maplit", "match", "optcall", "optfield",
    "record", "record_update", "un", "var",
})
EXPR_KINDS_COMPONENT: frozenset[str] = frozenset({
    "adt", "arrow", "bin", "builtin", "call", "config", "field", "fn",
    "format", "hole", "host", "if", "index", "instance-get", "list", "lit",
    "maplit", "match", "name", "optcall", "optfield", "record",
    "record_update", "req", "spawn", "un", "var",
})
EXPR_KINDS: frozenset[str] = EXPR_KINDS_FN | EXPR_KINDS_COMPONENT

# the default shared realm (paper Def. 28: an unisolated key resolves to
# its own realm); rendered as "shared" in diagnostics
SHARED_REALM = ""

# multi-realm require routing strategies (roadmap item 162). The name is an
# annotation the runtime router (item 161) consumes to pick a distribution
# policy across the bound realms; the frontend validates it against this
# closed set so a typo (`strategy(round_robbin)`) is a compile-time refusal,
# not a silent runtime fallback. `None` (strategy omitted) records "router's
# default" and is always accepted.
KNOWN_STRATEGIES: frozenset[str] = frozenset({
    "round_robin",   # rotate across the realms in declaration order
    "least_loaded",  # route to the realm whose provider reports least load
    "random",        # uniform random pick
    "sticky",        # pin a caller-derived key to one realm (session affinity)
})

# key namespacing (docs/namespacing.md): a provision key may be written
# `ns::local`. The *full* string is the key's wiring identity — G2
# disjointness, injection resolution and the admission gate all compare the
# qualified string, so two authors' `acme::db` and `bcorp::db` never collide.
# The trailing segment is the code-facing binding name a `requires` introduces
# (the consumer still writes `db.query(...)` in its body). An unqualified key
# has an empty namespace and a binding equal to itself, so v1 programs are
# unaffected in every respect.
KEY_NAMESPACE_SEP = "::"


def _key_binding(key: str) -> str:
    """The code-facing local name of a (possibly namespaced) provision key.

    `acme::db` binds `db`; an unqualified `db` binds itself. This is the name
    a `requires` clause introduces into the component body and type env."""
    return key.rsplit(KEY_NAMESPACE_SEP, 1)[-1]

# A3: identifiers that must never appear verbatim in emitted code on either
# host. Python keywords come from the keyword module; the rest is a curated
# union of TS reserved words and backend-adapter names.
#
# item 406 (cross-tier consistency): every name the TS emitter reserves for its
# own scaffolding (backends/typescript/emit.py `EMITTER_RESERVED` = ctx, config,
# rawConfig, host, Context) is renamed HERE, at the tier-agnostic frontend, so a
# user binding of one of them is made host-safe once and compiles uniformly on
# every tier. `ctx`/`config` were always in this set; `rawConfig`/`host`/
# `Context` were not, so a component/fn binding one of them (e.g. `let host = …`,
# as selfhost/emit_java.rvl itself does) type-checked and ran on py/rust/java/go/
# wasm but died LATE at TS emit with "collides with emitter scaffolding". They
# are the cross-tier analogue of the py emitter's own reserved bare-names, made
# to compile by item 160's aliasing rather than refused: a name that only a
# backend's scaffolding claims is renamed, never rejected, because it is a
# perfectly ordinary identifier the author is entitled to use.
_HOST_RESERVED = {
    "ctx", "config", "frame", "fiber", "self",
    "rawConfig", "host", "Context",
    "function", "var", "let", "const", "new", "class", "this", "typeof",
    "delete", "in", "of", "instanceof", "void", "export", "default",
    "require", "module", "exports", "import", "yield", "async", "await",
    "true", "false", "null", "undefined", "NaN",
}


# A3, the REMAINDER (issue #320). Items 160/165/406 made every host *keyword*
# safe verbatim: each backend injectively renames a user identifier that spells
# one of ITS keywords (`func`/`class`/`type`/…). What they missed is the rest of
# the host namespace a bare identifier can still collide with — names that are
# NOT keywords and so slip past every per-tier keyword rename:
#
#   * builtins the emitter emits verbatim next to the user's name (`len(x)`,
#     `str(x)`, `isinstance(...)` on python; `Number`/`String`/`Object`/`JSON`/
#     `Array` on TS),
#   * predeclared globals and imported package names (`float64`/`int64`/
#     `strconv`/`testing`/`panic` on go, the JS globals above),
#   * the emitter's own helper names (`revlLen`/`revlEq`/`revlStrLen`, wasm's
#     `alloc`/`f64_to_str`/`memory`),
#   * the host-root and ADT-constructor spellings (`Map`/`Pool`/`Job`,
#     `Some`/`None`/`Ok`/`Err`) — legal identifiers a user may bind.
#
# A3 says "backends may assume every name is safe verbatim", so this remainder
# is renamed HERE, once, at the tier-agnostic frontend — exactly as the keyword
# families already are per tier. The set is deliberately DISJOINT from every
# backend's keyword-rename set (`_ALL_HOST_KEYWORDS` below): a name a backend
# already renames must NOT be pre-escaped here too, or the two passes compose
# and double-escape (`func` -> `func_` -> `func__`), the bug PR #374 hit. Because
# the set is disjoint from every keyword rename, a name escaped here has a root
# no backend keyword-mangle touches, so it survives verbatim on every tier and
# the backends need no change.
#
# `_ALL_HOST_KEYWORDS` mirrors the six backends' keyword sets
# (`backends/*/emit.py`); `tests/test_reserved_lexicon_sweep.py` asserts the
# mirror still matches. Filtering the candidate set through it means an
# accidental keyword in the candidates is simply dropped (left to its backend
# rename) rather than double-escaped.
_ALL_HOST_KEYWORDS: frozenset[str] = frozenset({
    # go (_GO_KEYWORDS)
    "type", "range", "func", "map", "chan", "select", "go", "defer",
    "return", "var", "const", "package", "import",
    # java (_JAVA_RESERVED)
    "abstract", "assert", "boolean", "break", "byte", "case", "catch", "char",
    "class", "continue", "default", "do", "double", "else", "enum", "extends",
    "final", "finally", "float", "for", "goto", "if", "implements",
    "instanceof", "int", "interface", "long", "native", "new", "private",
    "protected", "public", "short", "static", "strictfp", "super", "switch",
    "synchronized", "this", "throw", "throws", "transient", "try", "void",
    "volatile", "while", "record", "yield",
    # rust (_RUST_RESERVED)
    "as", "crate", "extern", "false", "fn", "impl", "in", "let", "loop",
    "match", "mod", "move", "mut", "pub", "ref", "self", "Self", "struct",
    "trait", "true", "unsafe", "use", "where", "async", "await", "dyn",
    # rust reserved-for-future keywords (#552 B1); `abstract`/`do`/`final`/
    # `try`/`yield` are already listed under java, `typeof` under ts.
    "become", "box", "gen", "macro", "override", "priv", "unsized", "virtual",
    # ts (JS_RESERVED)
    "debugger", "delete", "export", "function", "null", "throw", "typeof",
    "with",
})


def _host_keyword(name: str) -> bool:
    """True when a backend already renames `name` as one of ITS keywords, so
    the frontend must NOT also escape it (that would double-escape). Python
    keywords are included because `backends/python/emit.py::_mangle` renames
    them too."""
    return (name in _ALL_HOST_KEYWORDS
            or keyword.iskeyword(name)
            or keyword.issoftkeyword(name))


# Candidate remainder names. Any that is also a host keyword is filtered out
# below (kept with its backend rename); the rest form `_HOST_PREDECLARED`. The
# set is kept to names that DEMONSTRABLY collide — a builtin an emitter writes
# verbatim next to the user's name, an issue-#320 identifier, a host root, or an
# ADT constructor — so it is a no-op on ordinary programs (which is what keeps
# every golden and the byte-agreement corpus unchanged). Speculative builtins an
# emitter never actually writes are deliberately excluded: they would rename
# harmlessly but pointlessly, and only widen the corpus-collision surface.
#
# NOTE: `int`/`float`/`new`/`class`/… are host BUILTINS on some tier yet also
# KEYWORDS on another (java), so they cannot be added here without double-
# escaping on the keyword tier. Making a name that is BOTH still safe verbatim
# needs the full item-320 coordinated fix (backends drop their keyword rename
# too); those stay a documented remainder — see the module docstring of
# tools/reserved_lexicon_sweep.py.
_PREDECLARED_CANDIDATES: frozenset[str] = frozenset({
    # python builtins the emitter emits verbatim (backends/python/emit.py):
    # a user identifier of the same spelling shadows the call the emitter makes.
    "len", "str", "isinstance", "abs", "ord", "sorted", "range",
    # JS/TS predeclared globals + emitter helpers the emitted code names
    # verbatim (issue #320's typescript list).
    "Number", "String", "Object", "JSON", "Array", "TypeError",
    "eval", "arguments", "revlLen", "revlEq", "revlStrLen",
    # vitest harness global the TS emitter injects INTO a `test` block body:
    # an in-file `test` lowers `assert a == b` to `expect(revlEq(...)).toBe(...)`
    # (backends/typescript/emit.py `_v3_stmt` "assert"). A user binding named
    # `expect` in that scope (`let expect = 2`) would shadow the vitest import
    # and the harness's own `expect(...)` call fails with "expect is not a
    # function". Renamed here so the binding is safe and the harness call is
    # untouched. `it` is the other vitest import, but it is only ever *called*
    # around the block, never referenced from inside a body, so a binding named
    # `it` cannot shadow it — `it` stays a fn-NAME-position remainder only (see
    # tests/test_reserved_lexicon_sweep.py::KNOWN_FNNAME_REMAINDER).
    "expect",
    # go predeclared / imported package names (issue #320's go list).
    "strconv", "float64", "int64",
    # host roots and ADT constructors — legal identifiers a user may bind, but
    # spelled the same as a builtin the emitter constructs directly.
    "Map", "Pool", "Job", "Stream", "Some", "None", "Ok", "Err",
})

# The frontend-owned remainder lexicon: candidates minus anything a backend
# already renames as a keyword (so the two escaping passes never compose).
_HOST_PREDECLARED: frozenset[str] = frozenset(
    n for n in _PREDECLARED_CANDIDATES if not _host_keyword(n))


def _predeclared_mangle(name: str) -> str:
    """Escape a value/binding identifier that spells a host predeclared name so
    it is safe verbatim on every tier (issue #320).

    Same injective ladder-shift the backends use for keywords, but over the
    keyword-DISJOINT `_HOST_PREDECLARED`: escape a name iff the name — or any
    name reachable from it by dropping trailing `_` — is a predeclared name, by
    exactly one `_`. Pure and injective, so a declaration and its use sites
    agree without threading a map, and it composes with the backends' keyword
    renames because the two name-sets are disjoint. Identity on every other
    name, so a program that binds no predeclared name is byte-identical."""
    root = name
    while root:
        if root in _HOST_PREDECLARED:
            return name + "_"
        if not root.endswith("_"):
            break
        root = root[:-1]
    return name


def _safe_name(name: str, taken: set[str]) -> str:
    candidate = name
    while (
        candidate in _HOST_RESERVED
        or candidate in _HOST_PREDECLARED
        or keyword.iskeyword(candidate)
        or keyword.issoftkeyword(candidate)
        or candidate in taken
    ):
        candidate += "_"
    return candidate


def _is_dunder_name(name: str) -> bool:
    """True if `name` is a dunder / prototype name like `__init__`, `__proto__`.

    issue #319: such names hijack host protocols when they reach a record field
    or service method — a py dataclass grows an `__init__`/`__getattr__` hook,
    and ts `__proto__` silently drops the value instead of storing it. They are
    refused at the frontend (see `_reject_dunder_name`) so no backend ever emits
    one. This detector is the single authority on what counts as a dunder, kept
    disjoint from the reserved-word / predeclared handling `_safe_name` applies
    (that pass renames legal-but-colliding identifiers; this one refuses names
    that are unsafe on every tier)."""
    return bool(re.match(r"^__\w+__$", name))


def _reject_dunder_name(name: str, kind: str, owner: str,
                        filename: str, line: int) -> None:
    """Refuse a dunder / prototype name in a `kind` (`field`/`method`/`config
    field`) position, naming its `owner` (record / service / component). A no-op
    for every ordinary name, so nothing that compiled before is affected."""
    if _is_dunder_name(name):
        raise RevlError(
            filename, line,
            f"dunder {kind} `{name}` in {owner} is not allowed: dunder / "
            f"prototype names hijack host protocols (e.g. Python dataclass "
            f"`__init__`/`__getattr__`, JS `__proto__`) — rename it (issue #319)")


# item 274: a minimal profile marker `navigate.is_untrusted` reads as the
# untrusted-author view, so a body-level refusal can collapse its navigable map
# without threading the whole `AdmissionProfile` down every lowering path. The
# lowering layer only ever needs the one bit (`env.untrusted`).
class _UntrustedProfile:
    untrusted = True


_UntrustedMark = _UntrustedProfile()


class Env:
    def __init__(self, component: ComponentDecl, services: dict[str, ServiceDecl], filename: str,
                 types: dict | None = None):
        self.component = component
        self.services = services
        self.filename = filename
        self.types = types or {}
        # item 274: whether this compile is under the untrusted-author profile, so
        # a body-level navigable refusal (approval, ownership, ...) redacts its
        # nearest-allowed map to the collapsed verdict. Set by `_lower_component`.
        self.untrusted = False
        # names whose call reaches an irreversible host effect (set by
        # check_and_lower once externs/fns are lowered)
        self.emitting_fns: set = set()
        # the same relation refined to *which* boundaries each one reaches:
        # name -> capability set (docs/capabilities.md)
        self.emitting_caps: dict[str, set] = {}
        # why-trace support for the above (why.py); None when unavailable,
        # in which case rejections carry no derivation but are unchanged
        self.emission_evidence: "_EmissionEvidence | None" = None
        # extern name -> its classification (`pure`/`acquire`/`emission`/
        # `witnessed`/`deferred`), the same table `_lower_externs` builds. Read
        # by `_check_site_inverse_emission` so a SITE-spelled bracket inverse is
        # held to the G5 no-emission-in-teardown bound the DECLARED inverse of a
        # witnessed extern already obeys. Set by `_lower_component`; an empty
        # table simply means no callee is classified, so the walk is inert.
        self.extern_class: dict[str, str] = {}
        # extern name -> the bare callee of its DECLARED inverse, for the
        # externs that declare one at all. Read only by `_lower_effect_step`'s
        # missing-`undo` refusal (item 420(d)): the declared inverse of a
        # non-`witnessed` extern is never replayed, so a bare acquisition of
        # one is still refused, but the refusal must say the inverse was
        # discarded and by which rule rather than claim there is none.
        self.extern_undo: dict[str, str] = {}
        # roadmap item 470 (docs/design/470-intent-refinement.md §4 stage 1):
        # the intent the service operation whose provide-method body is being
        # lowered DECLARES, as `(WithinClause, service_name, method_name)`.
        # `None` everywhere else — the activation body, a module `fn`, and every
        # operation that writes no `within { … }` clause — so the refinement
        # check keyed off it is inert for every program in the tree today and
        # the IR of an unannotated method or emit is unchanged.
        self.declared_intent: tuple | None = None
        # item 470 stage 0: the lowered crossing node of every BINDING in the
        # method being lowered that stated itself with a trailing `acting { … }`
        # clause. An `emit` STEP is recognised structurally by the completeness
        # residue; a stated binding cannot be, because marking it would put a
        # key in the IR and the whole surface is designed to contribute none.
        # So the register is held here, out of band, by object identity, and is
        # reset per method exactly as `declared_intent` is.
        self.stated_crossings: list = []
        # names of `witnessed`-classified externs in scope (item 243, Slice 2,
        # docs/design/243-witnessed-externs.md): set by `_lower_component` so
        # an effect-position acquisition calling one of these lowers to the
        # transactional accumulator entry instead of an ordinary bracket.
        self.witnessed_externs: set = set()
        # async externs in scope (roadmap item 80): name -> its ExternDecl, so
        # the v1 coloring check can name/locate an async extern a method reaches
        # (docs/design/async-extern.md §3). Set alongside the emitting sets.
        self.async_externs: dict = {}
        # the phase-2 async-colored set (async externs + transitively colored
        # fns, docs/design/async-extern.md §3): what a provide-method admission
        # tests membership against. Set alongside `async_externs`.
        self.async_callables: set = set()
        # component-body type environment: safe-name -> type, plus the
        # "config.<field>" and "req.<local>" markers infer_ir resolves
        self.type_env: dict[str, str] = {}
        for cfg_field in component.config:
            # issue #319: refuse dunder / prototype config field names (protocol
            # hijacking) before they reach a backend.
            _reject_dunder_name(cfg_field.name, "config field",
                                f"component `{component.name}`",
                                filename, cfg_field.line)
            self.type_env[f"config.{cfg_field.name}"] = cfg_field.type
        self.config_fields = {f.name for f in component.config}
        self.requires = dict()  # binding (local name) -> service name
        # binding -> the qualified wiring key it resolves against; for an
        # unqualified requirement this is the binding itself (docs/namespacing.md)
        self.require_keys: dict[str, str] = dict()
        # item 296: alias token carry-over. binding -> the consumer-facing
        # capability tokens an emission crossing through this alias contributes
        # (from the `carrying(...)` clause). Empty for every ordinary require,
        # so emission attribution is byte-identical for programs that do not
        # use the feature.
        self.require_carry: dict[str, tuple[str, ...]] = dict()
        _carry_src = getattr(component, "require_carry", None) or {}
        # item 130: the required `Stream[T]` coeffect. binding -> the ELEMENT
        # type of a `requires <k>: Stream[T]` declaration. A required stream is
        # an ordinary requirement on the wiring graph — it rides `self.requires`
        # so it lands in the emitted inject set and an unmet one pends under R2
        # like any other — but it is NOT a service: it has no methods, and the
        # only operation on it is `subscribe`. This map is what every site that
        # would otherwise resolve `env.services[env.requires[k]]` consults first,
        # so a stream requirement is refused BY NAME rather than looked up in a
        # service table it was never in.
        self.stream_requires: dict[str, str] = dict()
        # item 130 §4.5 + §6c: the replay declaration a stream REQUIREMENT
        # carries, binding -> the lowered `{"count": n}` / `{"cursor": name}`.
        # The coeffect twin of `replay_sources`: a locally acquired source states
        # its backlog on its own acquisition, a required one on the requirement,
        # and `_admit_replay` reads whichever applies under ONE rule so the two
        # cannot answer differently. Filled by `_lower_required_replay_decls`
        # once the env is usable (the cursor is an expression).
        self.stream_replay: dict[str, dict] = dict()
        # ... and the position flag that admits a bare read of one: a `Stream[T]`
        # is a capability, not a value, so it is read in a `subscribe` head and
        # nowhere else (`_lower_subscribe_step` scopes this over that head).
        self._stream_head_position = False
        for key, svc, line in component.requires:
            binding = _key_binding(key)
            if binding in self.requires:
                raise RevlError(filename, line, f"duplicate requirement name `{binding}` in {component.name}")
            if svc.startswith("Stream["):
                # the parser has already validated the shape (one argument, no
                # state index, not optional), so the element is the bracketed
                # text verbatim.
                self.stream_requires[binding] = svc[len("Stream["):-1]
            elif svc not in services:
                raise RevlError(filename, line, f"unknown service `{svc}` in `requires` of {component.name}")
            self.requires[binding] = svc
            self.require_keys[binding] = key
            self.type_env[f"req.{binding}"] = svc
            carried = _carry_src.get(key) or _carry_src.get(binding)
            if carried:
                self.require_carry[binding] = tuple(carried)
        self.locals: dict[str, str] = {}  # surface name -> host-safe IR name (A3)
        self.params: dict[str, str] = {}
        self._taken: set[str] = set()
        # host provenance (docs/stdlib-2.0.md §Map): component locals bound to
        # a host acquisition (`let store = effect Map.new()`), mapping the
        # host-safe IR name to the host family it belongs to (`Map`/`Pool`/
        # `Job`). Their method calls belong to the host stub surface and stay
        # verbatim — checked BEFORE the stdlib builtin table, so a value-type
        # method that shares a spelling with a host verb (`remove`) cannot
        # capture them, and checked AGAINST that family surface so an unknown
        # verb (`store.frobnicate(k)`) is refused here rather than compiled as
        # a pass-through that only fails at the host runtime (item 401, the
        # item-84 crash shape).
        self.host_locals: dict[str, str] = {}
        # PROVISION PROVENANCE (GHSA cluster, the aliasing arm). A spawn-handle
        # provision read (`w.task`) lowers to an `instance-get` node, and every
        # analysis that judges a crossing through a handle — the G4 marker
        # check, `revl audit`'s boundary fold, cardinality, parallel — asks for
        # that node by SHAPE at the call site. Binding the read to a name
        # (`let t = w.task`) put a `name` node there instead, so `t.run(...)`
        # was judged as an opaque host call: no `emit` marker demanded, no audit
        # line, while the emitted code performed the very same crossing. The
        # binding is not the crossing, so the fix is not a new refusal but
        # provenance: the safe IR name maps back to the `instance-get` it was
        # bound to, and every later use resolves to it, making the aliased
        # spelling lower to exactly the IR the direct spelling lowers to. One
        # entry, and all four consumers judge the alias without knowing it is one.
        self.provision_locals: dict[str, dict] = {}
        # ARROW PROVENANCE, the function-value arm of the same problem. A
        # teardown slot's reach is judged by resolving its callee, and a callee
        # that is a locally-bound arrow resolved to nothing at all — so
        # `let f = (x) => send(x)` then `undo f(key)` ran an emission during
        # teardown with no diagnostic. Keyed by SURFACE name (the teardown walk
        # runs on the AST, before the slot is lowered, so the refusal can name
        # what the author wrote); scoped to the body being lowered.
        self.local_arrows: dict = {}
        # VALUE PROVENANCE, the third arm of the same problem and the one that
        # decides whether the walk asks about the SPELLING or the VALUE. A
        # teardown slot's reach must be a question about what the inverse
        # dispatches, and a value bound to a name dispatches exactly what the
        # expression it was bound to dispatches — but the walk reads the `undo`
        # AST, and the `let` that bound the name is not in it. So
        # `undo dispatch1(w.task.run)` was refused while the identical crossing
        # one `let` away — `let r = w.task.run; undo dispatch1(r)` — was
        # admitted, and so was every container and `if`/`match` arm holding one.
        # Keyed by SURFACE name to the AST value it was bound to, so the walk
        # reads the value the author bound, transitively (`let s = r`) and
        # through what holds it (a record field, a list index, an arm); scoped
        # to the body being lowered, exactly like `local_arrows`.
        self.provision_values: dict = {}
        # item 130: stream lifecycle tracking. `terminal_stream_sources` holds
        # the safe names of stream sources (`let s = effect Stream.source() undo
        # s.close()`) whose inverse CLOSES the source — the terminal-delivering
        # providers rule 3.6 admits a subscription against. `subscribed_sources`
        # holds the sources already `subscribe`d, so a second subscription on one
        # source is refused (rule 3.1, single-consumer).
        self.terminal_stream_sources: set[str] = set()
        self.subscribed_sources: set[str] = set()
        # item 130 §4.5: the PROVIDER-side replay declarations in scope, safe
        # name -> the lowered `{"count": n}` / `{"cursor": name}` claim. A
        # `subscribe … replay(…)` is admitted ONLY against an entry here —
        # replay is a durability claim only the provider can make, so an
        # undeclared request is the §4.5 compile error.
        self.replay_sources: dict = {}
        # item 130 Slice 4: the subscriptions an `every … in` already iterates.
        # A subscription is SINGLE-CONSUMER (rule 3.1), and an iteration consumes
        # it to its terminal, so a second `every` on the same handle is a second
        # consumer of one subscription and is refused.
        self.iterated_subs: set[str] = set()

    def bind_local(self, name: str, line: int) -> str:
        if name in self.locals or name in self.requires or name in self.params:
            raise RevlError(self.filename, line, f"name `{name}` is already bound in {self.component.name}")
        safe = _safe_name(name, self._taken)
        self._taken.add(safe)
        self.locals[name] = safe
        return safe

    def bind_params(self, names: list[str], line: int) -> dict[str, str]:
        params: dict[str, str] = {}
        taken = set(self._taken)
        for name in names:
            if name in params:
                raise RevlError(self.filename, line, f"duplicate parameter `{name}`")
            safe = _safe_name(name, taken)
            taken.add(safe)
            params[name] = safe
        return params


# ---------------------------------------------------------------------------
# v2.0: type declarations & pure functions (docs/syntax-2.0.md §2–§3)
# ---------------------------------------------------------------------------

# builtin (non-record) type heads: destructuring a value of one of these with
# a record/list pattern is a type error, not a host pass-through
_BUILTIN_NONRECORD = {"Str", "Int", "Int32", "Bool", "Float", "Bytes", "Unit",
                      "List", "Map", "Opt", "Result",
                      # roadmap item 441 / issue #120 (docs/design/458-...): the
                      # two termination marker heads. Reserved builtin heads with
                      # no constructor, so a record pattern over one is a type
                      # error rather than a host pass-through; they never denote a
                      # value (a service-operation return erases them to
                      # `Opt[Bool]` in the parser), so this is inert for every
                      # program and refused outright by L4 elsewhere.
                      "Criterion", "Guard"}

# host roots a pure fn may call without an explicit binding (DESIGN §7 builtins).
# `Stream` (item 130) is the reference stream provider host: `Stream.source()`
# opens a provider whose `close`/`fault`/`emit` verbs drive a single-consumer
# stream (docs/design/130-stream-reactive-types.md §4.6).
_HOST_CALLABLES = {"Map", "Pool", "Job", "Stream"}

# The host-Map iteration surface (items 84/86/88, docs/stdlib-2.0.md §Map).
# `size`/`keys` are backed by EVERY tier's host Map runtime (py runtime.py
# `Map.size`/`Map.keys`, ts `MapHandle.size`/`keys`, and their go/rust/java
# mirrors), so they are legal verbs on a host-provenance local — but they
# share a spelling with the VALUE-Map builtins and so live in
# `_BUILTIN_METHODS`, not `_HOST_ARG_SIG` (whose names must stay disjoint from
# the builtin table — the disjointness check at import time enforces it). On a
# host local they dispatch as host verbs (a plain `call` node, selected by
# receiver kind), the same dual dispatch the sanctioned `remove` overlap rides.
# Kept beside `_HOST_CALLABLES` so the host-Map surface — `_HOST_FAMILIES`'s
# `Map` row plus this — is enumerable in one place; maps verb -> arity.
_HOST_MAP_ITER_VERBS: dict[str, int] = {"size": 0, "keys": 0}


def _host_result_type(acquire: dict, env: "Env") -> str | None:
    """The declared RESULT type of a result-declared host verb call on a host
    local, or `None` when `acquire` is not such a call (item 397).

    The host frontier types arguments and deliberately not results, except for
    the one-verb-wide result column `_HOST_RESULT_SIG` (today: `Map.
    insert_if_absent -> Bool`). A lowered host-verb call is
    `{"kind": "call", "target": {"kind": "name", "id": <safe>}, "method": ...}`
    where the target names a host local (its family lives in `env.host_locals`).
    This is the compare-and-set (CAS) shape whose Bool the program consumes with
    a pure `if` — the classification is a host verb in the effect stratum,
    spelled as an acquisition, whose let-effect binding is TYPED
    (docs/design/397-insert-if-absent.md §Classification)."""
    if not isinstance(acquire, dict) or acquire.get("kind") != "call":
        return None
    target = acquire.get("target")
    if not isinstance(target, dict) or target.get("kind") != "name":
        return None
    family = env.host_locals.get(target.get("id"))
    if family is None:
        return None
    return _HOST_RESULT_SIG.get(f"{family}.{acquire.get('method')}")


def _check_host_verb(family: str, verb: str, argc: int,
                     filename: str | None, line: int) -> None:
    """Admit a verb call on a host-provenance local (item 401).

    The known surface is the family's stub verbs (`_HOST_FAMILIES`, derived
    from `_HOST_ARG_SIG`) plus, for a host Map, the iteration verbs
    (`_HOST_MAP_ITER_VERBS`). A verb in neither is refused with the same named
    HOST-METHOD diagnostic the constructor-tracked receiver path uses, naming
    the FULL surface — so a typo or a value-Map method wrongly aimed at a host
    Map (`store.lookup(k)`, which no host runtime backs) is a compile error
    here rather than an unchecked pass-through that only crashes at the host
    runtime (the item-84 shape).

    Only the VERB NAME and ARITY are checked, never the argument TYPES: a host
    Map's key and value are generically typed on the tiers that genericized it
    (`Map[V]`; items 113/176), the checker's `["Str","Str"]` row is the known
    frontier/emitter disagreement the host boundary already carries opaquely
    (`_HOST_ARG_SIG` header; docs/design/397-insert-if-absent.md), and the
    pre-item-401 pass-through type-checked nothing here. Enforcing the row's
    `Str` would reject valid programs (`m.insert(k, double(v))` with a non-Str
    value/key), which is a separate frontier decision, not item 401's.
    """
    family_surface = _HOST_FAMILIES.get(family, {})
    iter_verbs = _HOST_MAP_ITER_VERBS if family == "Map" else {}
    if verb in family_surface:
        arity = len(family_surface[verb])
    elif verb in iter_verbs:
        arity = iter_verbs[verb]
    else:
        if filename:
            surface = ", ".join(sorted(set(family_surface) | set(iter_verbs)))
            raise RevlError(
                filename, line,
                f"`{family}` has no method `{verb}` (its surface: {surface})",
                hint="host objects are checked against the stub surface spelled "
                     "in docs/stdlib-2.0.md — a misspelled method compiles on "
                     "every tier and only fails at the host runtime",
                code="HOST-METHOD", category="host-boundary")
        return
    if filename and argc != arity:
        raise RevlError(
            filename, line,
            f"host `{family}.{verb}` takes {arity} argument"
            f"{'' if arity == 1 else 's'}, got {argc}",
            hint=f"the signature is `.{verb}("
                 f"{', '.join(family_surface.get(verb, [])) if verb in family_surface else ''})`",
            code="HOST-ARITY", category="host-boundary")


# item 395 / Stage 5 gate of docs/design/378-sync-extern-service-reach.md: the
# backend tiers whose emitter HAS the extern config-injection seam (binds
# `_revl_config` in the extern body from the plug-time composition config map).
# Item 378 landed option (b) py-ONLY; Stage 5 grew the seam to ts/go/java/rust,
# each emitting a module-global config map + a fail-loud lookup that mirrors the
# py `_REVL_EXTERN_CONFIG` / `_revl_extern_config` shape. wasm stays OUT: its
# extern body is raw WAT and its only config channel is a scalar-only, spawn-
# time runtime import, with no plug-time config dict to bind (see the design's
# Stage 5 note and backends/wasm/emit.py config refusal). A config extern that
# carries a host body for a tier NOT in this set is refused at compile
# (`_lower_externs`), because that tier would emit the body with `_revl_config`
# unbound: a late, mis-attributed failure. The key is the @-body spelling
# (`py`/`ts`/`go`/`java`/`rs`).
_CONFIG_INJECTION_TIERS = {"py", "ts", "go", "java", "rs"}
# item 396 option B: the tiers on which a host-module `ref` is native (py, ts).
# Imported from `hostref` so the compile-time gate and the resolver agree; a ref
# on go/rust/java/wasm is refused in `_lower_externs`.
from .hostref import EXTERN_REF_TIERS as _EXTERN_REF_TIERS  # noqa: E402
from .hostref import require_resolved_asset as _require_resolved_asset  # noqa: E402
# Opt/Result constructors, recognized so `Some(x)`/`Ok(r)` resolve (syntax-2.0 §2)
_BUILTIN_CONSTRUCTORS = {"Some", "None", "Ok", "Err"}
# taint declassifier operators (roadmap item 249, Decision 3.2): `endorse(v)` is
# the audited downgrade of an `Untrusted[T]` to a `Trusted[T]`. It is recognized
# as a callable so it lowers through the ordinary call machinery; it is identity
# on its argument's base type (typed and unwrapped as such), so after the taint
# verdict runs it is spliced out of the IR and no emitter ever sees it.
_DECLASSIFY_BUILTINS = {"endorse"}


def _endorse_node(inner: dict, expr: "ExprEndorse", approval: dict | None) -> dict:
    """Build the IR node for a scoped `endorse[<origin>](v, reason=...)` (item
    249, Slice C). It keeps the SAME `call`-to-`endorse` shape Slice A produced —
    so base typing (identity on the argument), the callable resolution, and the
    post-verdict splice are all unchanged — and rides an additive `endorse`
    metadata dict the taint checker reads: the declared origin it downgrades, its
    mandatory reason, its source line, and any `with` approval edge. The whole
    node splices out before any emitter sees it, metadata and all."""
    meta: dict = {"origin": expr.origin, "reason": expr.reason,
                  "line": expr.line}
    if approval is not None:
        meta["approval"] = approval
    return {"kind": "call", "callee": {"kind": "var", "name": "endorse"},
            "args": [inner], "endorse": meta}


# Builtin heads a `type X = Y` right-hand side may name. `Any`/`Never` are the
# type algebra's wildcards; the rest are the declared builtin surface.
_ALIASABLE_BUILTINS = _BUILTIN_NONRECORD | {"Any", "Never"}


def _alias_target(decl: TypeDecl, declared: set[str]) -> str | None:
    """The type `type X = Y` aliases, or None when the decl is a real variant.

    `type X = Y` is TypeScript's alias spelling, and syntax-2.0's governing
    principle is that no construct may exist in both languages with silently
    different meaning. So the split follows TypeScript's own:

    - Where TypeScript *compiles* it — `Y` names an existing type — revl means
      what TypeScript means: a transparent alias. `type Sku = Str` used to
      declare a one-case variant whose case was named `Str`, which made the
      author's own alias unusable (`f("abc")` was refused for a `Sku`
      parameter) while `return Str` was accepted as a case constructor.
    - Where TypeScript *rejects* it — `Y` is undeclared (TS2304) — revl is free
      to mean something else, because there is no shared meaning to diverge
      from. `type Status = Pending` keeps its one-case-variant reading, which
      is how an opaque nominal is spelled today.

    A payload makes it a newtype (`type W = Wrap(Int)`), never an alias.
    """
    if decl.fields or len(decl.cases) != 1:
        return None
    case = decl.cases[0]
    if case.payload is not None:
        return None
    head, args = parse_type(case.name)
    if args:
        return case.name  # a type application; the parser only builds these here
    if head in _ALIASABLE_BUILTINS or head in declared:
        return case.name
    return None


def _resolve_type_aliases(program: Program, filename: str) -> None:
    """Erase transparent type aliases from the program, in place.

    Aliases are substituted at every declaration site and their declarations
    dropped, so nothing downstream — the type table, the checker, the IR, the
    backends — ever sees the alias name. That is what `transparent` means, and
    it is the reading TypeScript has: `Sku` and `Str` are interchangeable in
    both directions. A *nominal* alias would be a distinct type needing
    construction syntax revl does not have, and would re-commit the very sin
    this fixes (both languages compiling `type X = Y` with different meanings).
    """
    declared = {d.name for d in program.type_decls}
    aliases: dict[str, TypeDecl] = {}
    for decl in program.type_decls:
        target = _alias_target(decl, declared)
        if target is None:
            continue
        if decl.params:
            raise RevlError(
                filename, decl.line,
                f"type alias `{decl.name}` cannot declare type parameters",
                hint="an alias is substituted verbatim, so it has nothing to "
                     "instantiate — drop the parameters, or declare a variant "
                     "with named cases (syntax-2.0 §2)",
            )
        # an alias is a declaration, so its right-hand side is checked here
        # rather than only where the alias happens to be used
        check_type_wellformed(filename, decl.line, target)
        aliases[decl.name] = decl
    if not aliases:
        return

    def expand(type_name: str, stack: tuple) -> str:
        head, args = parse_type(type_name)
        if args:
            return format_type(head, [expand(a, stack) for a in args])
        if head not in aliases:
            return head
        if head in stack:
            chain = " -> ".join(stack[stack.index(head):] + (head,))
            raise RevlError(
                filename, aliases[head].line,
                f"type alias cycle: {chain}",
                hint="an alias is substituted verbatim, so a cycle has no "
                     "expansion — break it, or declare one of them as a variant",
            )
        return expand(_alias_target(aliases[head], declared), stack + (head,))

    resolved = {name: expand(_alias_target(decl, declared), (name,))
                for name, decl in aliases.items()}

    def subst(type_name):
        if not type_name:
            return type_name
        head, args = parse_type(type_name)
        if args:
            return format_type(head, [subst(a) for a in args])
        return resolved.get(head, head)

    # every declaration site that carries a type annotation; kept in step with
    # `_validate_declared_types` below, which enumerates the same surface
    for fn in program.fn_decls:
        for p in fn.params:
            p.type = subst(p.type)
        fn.returns = subst(fn.returns)
    for ext in program.externs:
        for p in ext.params:
            p.type = subst(p.type)
        ext.returns = subst(ext.returns)
    for svc in program.services:
        for m in svc.methods.values():
            m.params = [(pname, subst(ptype)) for pname, ptype in m.params]
            m.returns = subst(m.returns)
    for decl in program.type_decls:
        for fld in decl.fields:
            fld.type = subst(fld.type)
        for case in decl.cases:
            case.payload = subst(case.payload)
    for comp in program.components:
        for cfg in comp.config:
            cfg.type = subst(cfg.type)
        for stmt in comp.body:
            if not isinstance(stmt, ProvideStmt):
                continue
            for method in stmt.methods:
                method.param_types = [subst(t) for t in method.param_types]
                method.returns = subst(method.returns)
                _subst_body_annotations(method.body, subst)
    for fn in program.fn_decls:
        _subst_body_annotations(fn.body, subst)
    for test in program.tests:
        _subst_body_annotations(test.body, subst)

    program.type_decls = [d for d in program.type_decls if d.name not in aliases]


def _subst_body_annotations(stmts: list, subst) -> None:
    """Expand type aliases in the annotations a *body* can carry.

    `let g: Handler = …` and `(v: Handler) => …` are type annotations like any
    other, but they live inside statements rather than at a declaration site,
    so the declaration sweep above cannot reach them — and an alias that
    survived here would reach the checker as an undeclared type name."""
    def walk_expr(expr) -> None:
        if isinstance(expr, ExprArrow):
            # the author's annotations — `(v: Handler): Handler => …`. The
            # checker's resolved fields are still empty here (alias expansion
            # runs before checking, which is the whole point: an alias must not
            # reach the checker as an undeclared type name).
            expr.written_param_types = [subst(t) for t in expr.written_param_types]
            expr.written_returns = subst(expr.written_returns)
            walk_expr(expr.body)
        elif isinstance(expr, ExprBin):
            walk_expr(expr.left)
            walk_expr(expr.right)
        elif isinstance(expr, ExprUn):
            walk_expr(expr.operand)
        elif isinstance(expr, ExprCall):
            walk_expr(expr.callee)
            for arg in expr.args:
                walk_expr(arg)
        elif isinstance(expr, (ExprField, ExprOptField)):
            walk_expr(expr.target)
        elif isinstance(expr, ExprOptCall):
            walk_expr(expr.target)
            for arg in expr.args:
                walk_expr(arg)
        elif isinstance(expr, ExprIndex):
            walk_expr(expr.target)
            walk_expr(expr.index)
        elif isinstance(expr, ExprIf):
            walk_expr(expr.cond)
            walk_expr(expr.then)
            walk_expr(expr.otherwise)
        elif isinstance(expr, ExprRecord):
            for _, value in expr.fields:
                walk_expr(value)
        elif isinstance(expr, ExprRecordUpdate):
            walk_expr(expr.base)
            for _, value in expr.updates:
                walk_expr(value)
        elif isinstance(expr, ExprList):
            for item in expr.items:
                walk_expr(item)
        elif isinstance(expr, ExprMatch):
            walk_expr(expr.scrutinee)
            for _, _, body in expr.arms:
                walk_expr(body)
                if isinstance(body, ExprBlockArm):
                    for stmt in body.stmts:
                        walk_expr(stmt.value)
                    walk_expr(body.tail)
        elif isinstance(expr, Interp):
            for kind, part in expr.parts:
                if kind == "expr":
                    walk_expr(part)

    def walk_stmt(stmt) -> None:
        if isinstance(stmt, LetStmt):
            stmt.type = subst(stmt.type)
            walk_expr(stmt.value)
        elif isinstance(stmt, (LetPatternStmt, AssignStmt)):
            walk_expr(stmt.value)
        elif isinstance(stmt, (ExprStmt, AssertStmt, FailStmt, AwaitStmt)):
            walk_expr(stmt.expr)
        elif isinstance(stmt, ReturnStmt):
            if stmt.expr is not None:
                walk_expr(stmt.expr)
        elif isinstance(stmt, IfStmt):
            walk_expr(stmt.cond)
            for child in list(stmt.then) + list(stmt.otherwise or []):
                walk_stmt(child)
        elif isinstance(stmt, WhileStmt):
            walk_expr(stmt.cond)
            for child in stmt.body:
                walk_stmt(child)
        elif isinstance(stmt, ForStmt):
            walk_expr(stmt.iterable)
            for child in stmt.body:
                walk_stmt(child)

    for stmt in stmts:
        walk_stmt(stmt)


def _validate_delegate_service(filename: str, line: int, ptype: str | None,
                               service_names: set[str]) -> None:
    """item 442 (issue #121): the argument of a `Delegate[S]` parameter must
    name a declared service. `S` is the interface the delegated reference
    exposes, so a `Delegate[Int]` or a `Delegate[Nope]` is meaningless and is
    refused here (arity and position are already enforced by
    `check_type_wellformed`)."""
    if not ptype:
        return
    head, args = parse_type(ptype)
    if head != DELEGATE_HEAD or len(args) != 1:
        return
    inner_head, _ = parse_type(args[0])
    if inner_head not in service_names:
        raise RevlError(
            filename, line,
            f"`Delegate[{args[0]}]` must name a declared service — `{args[0]}` "
            "is not a service in this composition",
            hint="a delegated reference exposes a service interface; write "
                 "`Delegate[S]` where `S` is a `service` this composition "
                 "declares (item 442, docs/design/442-typed-delegation.md §4.1)",
            code="G1", category="delegation",
        )


def _validate_declared_types(program: Program, filename: str) -> None:
    """Reject malformed type annotations (bare builtin generics like `Opt`,
    `List[]`) at every declaration site before checking begins — otherwise a
    zero-arg generic reaches the type algebra and crashes it."""
    for fn in program.fn_decls:
        for p in fn.params:
            # A module `fn` parameter is the one v1 position that admits an
            # async function type `(…) -> Async[T]` (item 92).
            check_type_wellformed(filename, p.line, p.type,
                                  allow_async_param=not fn.verified)
        check_type_wellformed(filename, fn.line, fn.returns)
    for ext in program.externs:
        for p in ext.params:
            check_type_wellformed(filename, p.line, p.type)
        check_type_wellformed(filename, ext.line, ext.returns)
    # item 442 (issue #121): a service method is the one v1 position that admits
    # a `Delegate[S]` parameter — a bounded, revocable view of an authority the
    # caller holds, handed for the duration of one call. `S` must name a service
    # this composition declares (the interface the delegated reference exposes).
    service_names = {svc.name for svc in program.services}
    for svc in program.services:
        for m in svc.methods.values():
            for _, ptype in m.params:
                check_type_wellformed(filename, m.line, ptype,
                                      allow_delegate_param=True)
                _validate_delegate_service(filename, m.line, ptype,
                                           service_names)
            check_type_wellformed(filename, m.line, m.returns)
    for decl in program.type_decls:
        for field in decl.fields:
            check_type_wellformed(filename, field.line, field.type)
        for case in decl.cases:
            check_type_wellformed(filename, case.line, case.payload)
    # item 378: a config value is injected as static data at plug/spawn/load
    # time, so a config field's declared type must be built, transitively, out of
    # data, never an arrow type (a live callable) or a `service` (a capability).
    # Resolve nominal record/ADT/alias heads through a lightweight type-table and
    # the set of declared service names. A duplicate type/field is reported by the
    # dedicated lowering pass; `setdefault` here just avoids raising twice.
    # (`service_names` was computed above for the item-442 `Delegate[S]` check.)
    config_type_defs: dict[str, dict] = {}
    for decl in program.type_decls:
        if decl.fields:
            config_type_defs.setdefault(
                decl.name,
                {"kind": "record", "params": list(decl.params or ()),
                 "fields": {f.name: f.type for f in decl.fields}})
        else:
            config_type_defs.setdefault(
                decl.name,
                {"kind": "variant", "params": list(decl.params or ()),
                 "cases": [{"name": c.name, "payload": c.payload}
                           for c in decl.cases]})

    def _check_config(owner: str, fields) -> None:
        for cfg in fields:
            check_type_wellformed(filename, cfg.line, cfg.type)
            check_config_field_is_data(
                filename, cfg.line, cfg.name, owner, cfg.type,
                service_names=service_names, type_defs=config_type_defs)

    for comp in program.components:
        _check_config(f"component `{comp.name}`", comp.config)
    # item 379: an extern's typed config schema was NEVER wellformed-checked, so
    # `extern pure fn thing(x) config { handler: (Str) -> Str }` compiled and its
    # body could invoke the injected callable past every authority fold. Check it
    # at the same data-only bar as a component's config.
    for ext in program.externs:
        if ext.config:
            _check_config(f"extern `{ext.name}`", ext.config)


#: every identifier in a written type expression. Deliberately a lexical walk
#: rather than `parse_type`, because a declared result may be an arrow type
#: (`(Str) -> Principal`) or a nested generic, and the question here is only
#: whether the word `Principal` occurs anywhere inside it.
_TYPE_WORD_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")


def _type_words(type_name: str | None) -> set[str]:
    """Every identifier written in `type_name` (`Result[Principal, ApiError]`
    yields `Result`, `Principal`, `ApiError`)."""
    return set(_TYPE_WORD_RE.findall(type_name or ""))


def _principal_mentioning_types(program: Program) -> set[str]:
    """The declared record/variant types whose definition carries `Principal`,
    directly or through another such type.

    Transitive because a box produces a principal too: `type Box = { who:
    Principal }` is a harmless consumer on its own, but a declaration whose
    result is `Box` mints a principal exactly as surely as one whose result is
    `Principal` spelled out."""
    direct = {
        decl.name: (
            {w for fld in decl.fields for w in _type_words(fld.type)}
            | {w for case in decl.cases for w in _type_words(case.payload)}
        )
        for decl in program.type_decls
    }
    mentioning: set[str] = set()
    growing = True
    while growing:
        growing = False
        for name, words in direct.items():
            if name in mentioning:
                continue
            if PRINCIPAL in words or words & mentioning:
                mentioning.add(name)
                growing = True
    return mentioning


def _is_shipped_stdlib(file: str) -> bool:
    """True when `file` is a module of the shipped, pinned `stdlib/`.

    Containment, not a name match: a local `stdlib/auth.rvl` that shadows the
    shipped one is an application module and does not qualify."""
    try:
        return _contained(os.path.realpath(file),
                          os.path.realpath(str(stdlib_root())))
    except (OSError, ValueError):
        return False


def _check_principal_producers(program: Program, filename: str) -> None:
    """item 457 S2 (docs/design/457-endpoint-one-definition.md, "Authorization:
    explicit, and not derivable"): `Auth.validate` is the SOLE producer of a
    `Principal`, and that is what makes a dropped auth step a REFUSAL at
    admission rather than a failure at runtime.

    `_lower_type_decls` reserves the NAME, so `type Principal = ...` cannot hand
    it a constructor. That alone is not the invariant: `Principal` is an
    undeclared opaque nominal, so nothing objected to a *signature* that RETURNS
    one. `extern pure fn mint() -> Result[Principal, ApiError]` compiled, and so
    did a plain `fn mint() -> Result[Principal, ApiError]` wrapping such an
    extern — a shape whose call site names no extern at all, and which therefore
    reads to a reviewer as ordinary revl. Either hands a body a principal it
    never authorized, which is precisely what the admission refusal exists to
    make impossible.

    So a result that carries `Principal` may be declared only in the shipped
    `stdlib/auth.rvl` (the `Auth.validate` signature and the `host_validate`
    extern behind it). Every other module — including a local `stdlib/` that
    shadows the shipped one — is refused, and the refusal names the sole
    producer so it reads as the missing authorization STEP."""
    mentioning = _principal_mentioning_types(program)

    def produces(returns: str | None) -> bool:
        words = _type_words(returns)
        return PRINCIPAL in words or bool(words & mentioning)

    def check(decl, line: int, what: str, returns: str | None) -> None:
        if not produces(returns):
            return
        file = program.decl_files.get(id(decl), filename)
        if _is_shipped_stdlib(file):
            return
        raise RevlError(
            file, line,
            f"{what} declares a result carrying `Principal`, the reserved "
            f"opaque authorization principal — only the shipped "
            f"`Auth.validate` (stdlib/auth.rvl) may produce one, and a second "
            f"producer hands a body an authorization it never obtained",
            hint=PRINCIPAL_PRODUCER_HINT, code="G4", category="route")

    for fn in program.fn_decls:
        check(fn, fn.line, f"`fn {fn.name}`", fn.returns)
    for ext in program.externs:
        check(ext, ext.line, f"`extern {ext.name}`", ext.returns)
    for svc in program.services:
        for m in svc.methods.values():
            check(svc, m.line, f"`{svc.name}.{m.name}`", m.returns)


def _lower_type_decls(program: Program, filename: str) -> dict:
    types: dict[str, dict] = {}
    for decl in program.type_decls:
        if decl.name in types:
            raise RevlError(filename, decl.line, f"duplicate type `{decl.name}`")
        if decl.name == PRINCIPAL:
            # item 457 S2 (docs/design/457-endpoint-one-definition.md,
            # "Authorization: explicit, and not derivable"): `Principal` is the
            # opaque authorization principal, produced only by `Auth.validate`
            # (stdlib/auth.rvl). A `type Principal = ...` declaration would give
            # it a constructor and let a body MINT one — passing every
            # user-scoped guard without authorizing. Reserve the name so the
            # opacity is enforced, not merely conventional.
            raise RevlError(
                filename, decl.line,
                "`Principal` is the reserved opaque authorization principal and "
                "cannot be declared as a revl type",
                hint=PRINCIPAL_PRODUCER_HINT, code="G4", category="route")
        if decl.fields:
            fields: dict[str, str] = {}
            for field in decl.fields:
                # issue #319: refuse dunder / prototype field names before they
                # reach a backend (protocol hijacking). Complementary to the
                # reserved-word renaming `_safe_name` applies at binding sites.
                _reject_dunder_name(field.name, "field", f"record `{decl.name}`",
                                    filename, field.line)
                if field.name in fields:
                    raise RevlError(filename, field.line,
                                    f"duplicate field `{field.name}` in record `{decl.name}`")
                fields[field.name] = field.type
            types[decl.name] = {"params": decl.params, "kind": "record", "fields": fields}
        else:
            cases: list[dict] = []
            seen: set[str] = set()
            for case in decl.cases:
                if case.name in seen:
                    raise RevlError(filename, case.line,
                                    f"duplicate case `{case.name}` in type `{decl.name}`")
                seen.add(case.name)
                cases.append({"name": case.name, "payload": case.payload})
            types[decl.name] = {"params": decl.params, "kind": "variant", "cases": cases}
    return types


# item 130 Slice 5: the typed-event contract table, keyed like `FNS_KEY` /
# `CASES_KEY` so it rides the shared `types` dict without a second parameter on
# every lowering seam. `__`-prefixed, so `_lower_program` filters it out of the
# emitted IR's `types` map and a program that declares no event is byte-
# identical (an event's contract reaches the emitters on the ONE step that uses
# it, the `stream-iter` handler, not as a global table).
EVENTS_KEY = "__events__"

# item 130 §6: the default bounded dedup window — how many recently admitted
# keys a handler remembers. Bounded by construction and CONSTANT per handler,
# never one entry per delivered item (the unbounded shape §4.7 refuses). A
# redelivery further apart than the window than this runs the handler again, so
# the window is a collapse of redeliveries, NOT a durable exactly-once claim;
# that needs the §4.5 durable cursor, which is a later slice.
_EVENT_DEDUP_WINDOW = 64


def _lower_event_decls(program: Program, types: dict, filename: str) -> dict:
    """Check every `event` declaration and build the contract table (item 130
    Slice 5, docs/design/130-stream-reactive-types.md §6).

    An event is a `Stream[T]` element with a contract, so its RECORD half is
    already done by the time this runs: the parser contributed a `TypeDecl`, and
    `_lower_type_decls` type-checked it like any other record (duplicate name,
    duplicate field, field types). This function checks only what events ADD:

    * the key names a declared FIELD of the event, and its type is scalar-
      serializable (`Str`/`Int`) — item 309's rule for `idempotent(key: p)`,
      applied on the consumer side of the same idea. A key that is a record, a
      list or a host handle has no stable identity to dedup on;
    * the event's schema is derivable EXACTLY. The handler validates every
      delivered item against it at the boundary (§6, "schema compatibility"), and
      item 257 §3.3 already settled what an inexact schema is worth there: an
      unconstrained schema validates nothing while reading as safe, so it is
      refused at compile time rather than shipped as a vacuous guarantee.
    """
    events: dict[str, dict] = {}
    for decl in getattr(program, "event_decls", ()):
        spec = types.get(decl.name) or {}
        fields = spec.get("fields") or {}
        if decl.key not in fields:
            listed = ", ".join(sorted(fields)) or "(none)"
            raise RevlError(
                filename, decl.line,
                f"`event {decl.name}` declares `key: {decl.key}`, but "
                f"`{decl.key}` is not one of its fields ({listed})",
                hint="the key names the FIELD carrying the event's identity — the "
                     "value a duplicate delivery repeats — so it must resolve "
                     "against the event's own record (item 130 §6; the role is "
                     "item 309's idempotency key)",
                code="G4", category="idempotent")
        key_type = fields[decl.key]
        if key_type not in ("Str", "Int"):
            raise RevlError(
                filename, decl.line,
                f"`event {decl.name}` key `{decl.key}` has type `{key_type}`, "
                f"which is not scalar-serializable",
                hint="a duplicate is recognised by comparing key VALUES across "
                     "deliveries, so the key must be a serializable scalar "
                     "(`Str` or `Int`), not a compound type or a host handle "
                     "(item 130 §6, item 309 §1b)",
                code="G4", category="idempotent")
        if not fully_expressible(decl.name, types):
            reason = expressibility_reason(decl.name, types) or "is not expressible"
            raise RevlError(
                filename, decl.line,
                f"`event {decl.name}` {reason}, so its delivered items cannot be "
                f"checked against a schema",
                hint="an event's handler validates every item at the boundary "
                     "before the body runs, and an unconstrained schema validates "
                     "nothing while reading as safe — so an inexact event shape is "
                     "refused at compile time rather than shipped as a vacuous "
                     "guarantee (item 130 §6, item 257 §3.3)",
                code="G4", category="validated")
        schema = json_schema_for(decl.name, types, validated=True)
        if has_revl_stub(schema):  # pragma: no cover — predicate/renderer drift
            raise RevlError(
                filename, decl.line,
                f"internal: `event {decl.name}` derived an unconstrained schema "
                f"despite passing the expressibility gate (item 130 §6)")
        events[decl.name] = {
            "key": decl.key,
            "window": decl.window if decl.window is not None
            else _EVENT_DEDUP_WINDOW,
            "schema": schema,
        }
    return events


def _fn_call_graph(program: Program) -> dict[str, set[str]]:
    """Direct-call graph over the file's functions.

    Host roots and constructors are not function declarations, so they are
    ignored: only `ExprVar` callees whose name is another `fn` are edges.
    """
    fn_names = {fn.name for fn in program.fn_decls}
    graph = {fn.name: set() for fn in program.fn_decls}

    def collect_expr(expr) -> None:
        if isinstance(expr, ExprCall):
            if isinstance(expr.callee, ExprVar) and expr.callee.name in fn_names:
                graph[decl.name].add(expr.callee.name)
            collect_expr(expr.callee)
            for arg in expr.args:
                collect_expr(arg)
        elif isinstance(expr, ExprBin):
            collect_expr(expr.left)
            collect_expr(expr.right)
        elif isinstance(expr, ExprUn):
            collect_expr(expr.operand)
        elif isinstance(expr, ExprField):
            collect_expr(expr.target)
        elif isinstance(expr, ExprIndex):
            collect_expr(expr.target)
            collect_expr(expr.index)
        elif isinstance(expr, ExprIf):
            collect_expr(expr.cond)
            collect_expr(expr.then)
            collect_expr(expr.otherwise)
        elif isinstance(expr, ExprRecord):
            for _, value in expr.fields:
                collect_expr(value)
        elif isinstance(expr, ExprRecordUpdate):
            collect_expr(expr.base)
            for _, value in expr.updates:
                collect_expr(value)
        elif isinstance(expr, ExprList):
            for item in expr.items:
                collect_expr(item)
        elif isinstance(expr, ExprArrow):
            collect_expr(expr.body)

    def collect_stmt(stmt) -> None:
        if isinstance(stmt, LetStmt):
            collect_expr(stmt.value)
        elif isinstance(stmt, LetPatternStmt):
            collect_expr(stmt.value)
        elif isinstance(stmt, AssignStmt):
            collect_expr(stmt.value)
        elif isinstance(stmt, ReturnStmt):
            if stmt.expr is not None:
                collect_expr(stmt.expr)
        elif isinstance(stmt, IfStmt):
            collect_expr(stmt.cond)
            for branch in (stmt.then, stmt.otherwise or []):
                for child in branch:
                    collect_stmt(child)
        elif isinstance(stmt, WhileStmt):
            collect_expr(stmt.cond)
            for child in stmt.body:
                collect_stmt(child)
        elif isinstance(stmt, ForStmt):
            collect_expr(stmt.iterable)
            for child in stmt.body:
                collect_stmt(child)
        elif isinstance(stmt, (ExprStmt, AssertStmt)):
            collect_expr(stmt.expr)

    for decl in program.fn_decls:
        for stmt in decl.body:
            collect_stmt(stmt)
    return graph


def _reaches_self(start: str, graph: dict[str, set[str]]) -> bool:
    seen: set[str] = set()
    stack = [start]
    while stack:
        node = stack.pop()
        for succ in graph.get(node, ()):
            if succ == start:
                return True
            if succ not in seen:
                seen.add(succ)
                stack.append(succ)
    return False


def _check_verified_totality(program: Program, filename: str) -> None:
    """Totality gate for `verified fn` (syntax-2.0 §7).

    This first cut is deliberately conservative: a verified function may not
    participate in any cycle in the direct-call graph, because the checker
    cannot currently prove structural descent. Loop bodies are traversed so
    recursion through `while`/`for` is still caught.
    """
    verified = [fn for fn in program.fn_decls if fn.verified]
    if not verified:
        return
    graph = _fn_call_graph(program)
    for decl in verified:
        if _reaches_self(decl.name, graph):
            raise RevlError(
                filename,
                decl.line,
                f"verified fn `{decl.name}` is not total: it participates in "
                "direct or mutual recursion (verified totality, syntax-2.0 §7)",
                hint="use structural recursion on a structurally smaller value, "
                     "or a syntactically bounded loop",
            )


def _has_return(stmts) -> bool:
    """True when a `return` appears anywhere in this statement tree."""
    for stmt in stmts:
        if isinstance(stmt, ReturnStmt):
            return True
        if isinstance(stmt, IfStmt):
            if _has_return(stmt.then) or _has_return(stmt.otherwise or []):
                return True
        elif isinstance(stmt, (WhileStmt, ForStmt)):
            if _has_return(stmt.body):
                return True
    return False


def _loop_has_targeting_break(stmts) -> bool:
    """True when a bare `break` in `stmts` targets the loop these statements are
    the body of — i.e. a `break` at any statement depth that is not itself
    inside a nested `while`/`for` (a nested loop captures its own `break`). With
    only unlabeled `break`, "targets this loop" is exactly "not shadowed by a
    nearer loop" (JLS 14.21's reachability rule for the same conservative
    analysis, docs/design/379-break-continue.md)."""
    for stmt in stmts:
        if isinstance(stmt, BreakStmt):
            return True
        if isinstance(stmt, IfStmt):
            if (_loop_has_targeting_break(stmt.then)
                    or _loop_has_targeting_break(stmt.otherwise or [])):
                return True
        # a nested while/for is NOT descended: a `break` inside it targets that
        # inner loop, not this one.
    return False


def _definitely_returns(stmts) -> bool:
    """True when control cannot reach the end of `stmts` without returning.

    Deliberately the same conservative rule Java and Rust apply, so a body this
    accepts is a body those tiers accept:

    - a `return` terminates;
    - an `if` terminates only when it has an `else` *and* both arms terminate
      (a bare `if` may be skipped);
    - `for` and a conditional `while` may run zero times, so neither terminates;
    - `while (true)` diverges — and so terminates the path — *iff* its body has
      no reachable `break` that targets it (item 379,
      docs/design/379-break-continue.md). A `while (true)` with a reachable
      `break` may leave the loop and fall through, so it does NOT terminate;
      one with no such `break` never exits, exactly as Java (JLS 14.21) and Rust
      (`loop {}` : `!`) judge it, and no tier needs a fallthrough value.
    """
    for stmt in stmts:
        if isinstance(stmt, ReturnStmt):
            return True
        if isinstance(stmt, IfStmt):
            if (stmt.otherwise is not None
                    and _definitely_returns(stmt.then)
                    and _definitely_returns(stmt.otherwise)):
                return True
        elif isinstance(stmt, WhileStmt):
            if (isinstance(stmt.cond, ExprLit) and stmt.cond.value is True
                    and not _loop_has_targeting_break(stmt.body)):
                return True
    return False


def _check_returns_on_every_path(decl: FnDecl, filename: str) -> None:
    """A fn with a declared return type must return on every path.

    Falling off the end is a portability trap, not a nicety: Python (the
    reference backend) silently yields `None`, TypeScript yields `undefined`,
    while Rust refuses with E0308 and Java with "missing return statement". A
    program the checker accepts must compile on every tier, so the strict
    reading is the frontend's.
    """
    if not decl.returns or _definitely_returns(decl.body):
        return
    last_line = getattr(decl.body[-1], "line", decl.line) if decl.body else decl.line
    if not _has_return(decl.body):
        raise RevlError(
            filename, decl.line,
            f"`{decl.name}` is declared to return `{decl.returns}` but its body "
            f"never returns a value",
            hint=f"end the body with `return <{decl.returns}>`, or drop the "
                 f"`-> {decl.returns}` annotation if the fn produces nothing — "
                 "revl has no implicit result (rust E0308, java \"missing return "
                 "statement\")",
            code="T1", category="type-mismatch",
            expected=decl.returns, actual=None,
        )
    raise RevlError(
        filename, last_line,
        f"`{decl.name}` is declared to return `{decl.returns}` but control can "
        f"reach the end of its body without a `return`",
        hint="every path must return: give the trailing `if` an `else` that "
             "returns, or add a final `return` after it — a `for`/`while` may "
             "run zero times and never counts (rust E0308, java \"missing "
             "return statement\")",
        code="T1", category="type-mismatch",
        expected=decl.returns, actual=None,
    )


def _same_file_two_copies(a: str, b: str) -> bool:
    """True when `a` and `b` are distinct paths to a byte-identical file with
    the same basename — the "two copies of one module" case (roadmap 394)."""
    if os.path.basename(a) != os.path.basename(b):
        return False
    if os.path.abspath(a) == os.path.abspath(b):
        return False
    try:
        with open(a, "rb") as fa, open(b, "rb") as fb:
            return fa.read() == fb.read()
    except OSError:
        return False


def _duplicate_symbol_message(kind: str, name: str,
                              first_file: str, second_file: str) -> str:
    """A duplicate-symbol message that names BOTH declaring files by absolute
    path (roadmap 394, revl-harness F-H39.3).

    The two files that declare `name` are frequently the same module reached
    under two `use` spellings — a search-path spelling (`use "stdlib/str.rvl"`)
    and a vendored byte-identical copy (`use "../../stdlib/str.rvl"`). Naming
    only one path reads as a bug in revl's own stdlib; naming both — and, when
    they are byte-identical copies of one file, saying so — makes "you have two
    copies of the same module" self-evident.
    """
    a = os.path.abspath(first_file)
    b = os.path.abspath(second_file)
    msg = (f"duplicate {kind} `{name}` — declared in both\n"
           f"    {a}\n"
           f"  and\n"
           f"    {b}")
    if _same_file_two_copies(a, b):
        msg += ("\n  these are byte-identical copies of the same file under two "
                "paths: you have two copies of one module (often a vendored "
                "copy reached under two `use` spellings) — delete one copy, or "
                "`use` a single shared path so it loads as one module")
    return msg


def _lower_fns(program: Program, filename: str, types: dict | None = None) -> list:
    _check_verified_totality(program, filename)
    types = types or {}
    default_callables = (
        _HOST_CALLABLES
        | _BUILTIN_CONSTRUCTORS
        | _DECLASSIFY_BUILTINS
        | {fn.name for fn in program.fn_decls}
        | {ext.name for ext in program.externs}
    )
    fns: list[dict] = []
    # name -> the file that first declared it, so a duplicate names BOTH files
    # (roadmap 394): a same-named fn reached under two `use` spellings loads as
    # two modules, and the diagnostic must show both resolved paths.
    seen: dict[str, str] = {}
    # Install the block-arm lift sink for the duration of fn-body lowering: a
    # statement-block match arm is lambda-lifted into a synthetic helper fn
    # (`_lift_block_arm`) collected here, then appended to `fns` below. `taken`
    # seeds the fresh-name search so a helper never shadows a user fn/extern.
    # setdefault installs the sink into `types` for the duration of fn-body
    # lowering (drained below); `_lift_block_arm` reads it back via
    # `types.get(LIFT_SINK)`, so the return value is not needed here.
    types.setdefault(LIFT_SINK, {
        "fns": [],
        "n": 0,
        "taken": ({fn.name for fn in program.fn_decls}
                  | {ext.name for ext in program.externs}),
    })
    for decl in program.fn_decls:
        # In a multi-file composition `filename` is only the first source
        # (paths[0]); a fn parsed from a LATER file carries its own `source`, so
        # its diagnostics must name that file, not paths[0] (roadmap 312).
        decl_file = decl.source or filename
        if decl.name in seen:
            first_file = seen[decl.name]
            if os.path.abspath(first_file) == os.path.abspath(decl_file):
                # two fns of one name in ONE file: the terse message already
                # points at the sole file, so keep it byte-identical (roadmap
                # 394 only widens the CROSS-FILE case).
                raise RevlError(decl_file, decl.line,
                                f"duplicate function `{decl.name}`")
            raise RevlError(
                decl_file, decl.line,
                _duplicate_symbol_message("function", decl.name,
                                          first_file, decl_file))
        seen[decl.name] = decl_file
        # the body sees the *marked* signature: this fn's own type parameters
        # are wildcards inside it (they are universally quantified there), while
        # a one-letter nominal type stays checked
        sig = (types.get(FNS_KEY) or {}).get(decl.name) or {}
        marked_params = sig.get("params") or [p.type for p in decl.params]
        marked_returns = sig.get("returns", decl.returns)
        scope: dict[str, bool] = {}
        type_env: dict[str, str] = {}
        for param, marked in zip(decl.params, marked_params):
            if param.name in scope:
                raise RevlError(decl_file, param.line,
                                f"duplicate parameter `{param.name}` in fn {decl.name}")
            scope[param.name] = False
            type_env[param.name] = marked
        module_callables = program.fn_scopes.get(id(decl), default_callables)
        callables = _HOST_CALLABLES | _BUILTIN_CONSTRUCTORS | _DECLASSIFY_BUILTINS | set(module_callables) | {ext.name for ext in program.externs}
        alias_fns = program.fn_alias_scopes.get(id(decl), {})
        check_list_index_bounds(decl.body, decl_file)
        body: list[dict] = []
        for stmt in decl.body:
            _lower_pure_stmt(stmt, scope, callables, alias_fns, body, decl_file, type_env, types,
                             expected_return=marked_returns)
        _check_returns_on_every_path(decl, decl_file)
        # phase-2 async coloring (docs/design/async-extern.md §3): a module
        # `fn` that reaches an async extern — directly or transitively — is no
        # longer refused here; it becomes async-colored by the `_async_callables`
        # fixed point in `check_and_lower`, which then stamps `"async": True` on
        # this entry. First-class *value* use of an async callable stays refused
        # (an arrow type carries no color), also in that post-pass once the
        # colored set is known. This function is now pure lowering.
        entry = {
            "name": decl.name,
            # the `Secret[T]` marking rides here exactly as it does on an extern
            # or a service operation (item 256 §7a): `extract_and_normalize`
            # strips the qualifier off `p.type` before lowering, so without this
            # a `Secret[T]` fn parameter left NO trace in the IR at all. Item 444
            # reads it back (`taint.declares_confidential_surface`) to decide
            # whether a composition can mint the `confidential` origin anywhere.
            # Additive: absent unless the author wrote `Secret[T]`, so every
            # existing IR document stays byte-identical.
            # issue #320: a fn parameter that spells a host predeclared name
            # (`len`, `str`, `Some`, `Map`, …) is renamed here, once, so it is
            # safe verbatim on every tier. The body's references resolve through
            # the same pure `_predeclared_mangle` (see `_lower_pure_expr`'s
            # in-scope `var` case), so declaration and use stay in agreement
            # without a table. Extern params are NOT renamed (their verbatim
            # `@backend` bodies reference the raw spelling).
            "params": _ir_params(((_predeclared_mangle(p.name), p.type)
                                  for p in decl.params),
                                 getattr(decl, "secret_params", ())),
            "returns": decl.returns,
            "public": decl.public,
            "body": body,
        }
        if decl.verified:
            entry["verified"] = True
        # item 310: a `cache pure` fn memoizes on its structural args digest. The
        # metadata rides the IR (validated in `_check_cache_declarations` — only
        # `cache pure`, crossing-free, survives to here). Absent unless declared,
        # so every existing fn's IR is byte-identical.
        if getattr(decl, "cache", None) is not None:
            entry["cache"] = _cache_ir(decl.cache)
        if decl.source:
            _retarget_holes(entry["body"], decl.source)
        fns.append(entry)
    # Drain the lift sink: synthetic arm helpers join the functions list, so the
    # async-coloring and emission fixed points that run over `fns` see them.
    lifted = types.pop(LIFT_SINK, None)
    if lifted and lifted["fns"]:
        fns.extend(lifted["fns"])
    return fns


def _signature_table(program: Program, types: dict | None = None) -> dict:
    """{name: {"params": [type...], "returns": type|None, "tparams": set}} for
    fns + externs.

    Each signature's type parameters are marked here, once, so the rest of the
    checker can tell a universally quantified `T` from a nominal type that
    merely has a one-letter name. The set is the explicit `fn id[T](...)`
    names the decl carries (validated for shadowing here — see
    `validate_explicit_tparams`), plus — only when the decl carries NO list —
    the implicit single-uppercase names (roadmap 75(c): an explicit list
    turns the heuristic off; declared means declared).
    Marked types never reach the IR — this table is the checker's view, and
    `_lower_fns`/`_lower_externs` emit the author's spelling, byte-identical
    whether a parameter was implicit or explicit."""
    declared = {name: spec for name, spec in (types or {}).items()
                if not name.startswith("__")}
    sigs: dict = {}
    for decl in list(program.fn_decls) + list(program.externs):
        raw_params = [p.type for p in decl.params]
        explicit = validate_explicit_tparams(
            getattr(decl, "type_params", ()) or (), declared,
            program.filename, decl.line)
        tparams = collect_tparams(raw_params + [decl.returns], declared,
                                  explicit=explicit)
        # default-value expressions (roadmap item 187), aligned with `params`.
        # `None` for a parameter without a default; the ordering invariant
        # (defaults are trailing) is enforced in the parser, so `required` is
        # simply the count of leading non-defaulted parameters. Externs never
        # carry defaults (`FnParam.default` stays `None` there), so this is a
        # no-op for the extern half of the table.
        defaults = [getattr(p, "default", None) for p in decl.params]
        required = next((i for i, d in enumerate(defaults) if d is not None),
                        len(defaults))
        sigs[decl.name] = {
            "params": [mark_tparams(t, tparams) for t in raw_params],
            "returns": mark_tparams(decl.returns, tparams),
            "tparams": tparams,
            "defaults": defaults,
            "required": required,
        }
    return sigs


def _with_default_args(callee_name: str, given: list, types: dict, lower_one):
    """Append default-value IR for omitted trailing parameters (item 187).

    Call-site resolution: the emitters only ever see a fully-supplied argument
    list, so no tier needs default-parameter machinery. `given` is the
    already-lowered actual arguments; `lower_one` lowers one default
    *expression* AST to IR in the caller's context (a default is a pure
    expression that closes over nothing, so the caller's scope is immaterial).
    A signature with no defaults, or a call that supplies every argument,
    returns `given` unchanged — byte-identical to before item 187."""
    sig = (types.get(FNS_KEY) or {}).get(callee_name)
    if not sig:
        return given
    defaults = sig.get("defaults") or []
    if len(given) >= len(defaults):
        return given
    out = list(given)
    for d in defaults[len(given):]:
        # `d` is non-None here: the arity check admitted this call only because
        # every omitted trailing parameter carries a default.
        out.append(lower_one(d))
    return out


def _case_table(types: dict) -> dict:
    """ADT constructor table: case name -> {"adt", "payload"}. Builtins first;
    ambiguous user cases (same name in two ADTs) are dropped to stay silent."""
    cases: dict = {
        "Some": {"adt": "Opt[Any]", "payload": None},
        "None": {"adt": "Opt[Any]", "payload": None},
        "Ok": {"adt": "Result[Any, Any]", "payload": None},
        "Err": {"adt": "Result[Any, Any]", "payload": None},
    }
    ambiguous: set = set()
    for type_name, spec in types.items():
        if type_name.startswith("__") or spec.get("kind") != "variant":
            continue
        for case in spec.get("cases", []):
            name = case["name"]
            # `Some`/`None` are reserved for `Opt` (host-null representation);
            # a user ADT reusing them is ambiguous and dropped.
            if name in ("Some", "None"):
                ambiguous.add(name)
                cases.pop(name, None)
                continue
            # a user ADT may reuse `Ok`/`Err`: the user's declaration shadows
            # the built-in `Result` (the docs' own `type Outcome = Ok(Row) | …`
            # does exactly this).
            if name in ("Ok", "Err") and cases.get(name, {}).get("adt", "").startswith("Result"):
                cases[name] = {"adt": type_name, "payload": case["payload"]}
                continue
            if name in cases or name in ambiguous:
                ambiguous.add(name)
                cases.pop(name, None)
                continue
            cases[name] = {"adt": type_name, "payload": case["payload"]}
    return cases


def _arrow_param_types(expr) -> list:
    """An arrow's parameter types, one per parameter (None where unknown).

    The checker writes what it resolved back onto the AST node
    (`typecheck.py::_resolve_arrow`), so this is either the author's `(v: Int)`
    annotations, the types the expected function type supplied, or Nones when
    the arrow is still on the unchecked frontier."""
    resolved = list(getattr(expr, "param_types", None) or [])
    resolved += [None] * (len(expr.params) - len(resolved))
    return resolved[:len(expr.params)]


def _arrow_declared_param_types(expr) -> list:
    """An arrow's parameter types, preferring the checker-resolved
    `param_types` and falling back to the author's own annotations
    (`written_param_types`) where the checker never resolved the arrow.

    A stratum-3 arrow (in a provide-method or component body) is not checked,
    so `param_types` stays None even when every parameter was annotated; the
    annotations survive on `written_param_types`. This reads the type the
    author declared regardless of stratum, without moving what goes into the
    IR (that stays gated on `_arrow_signature_known`)."""
    resolved = _arrow_param_types(expr)
    written = list(getattr(expr, "written_param_types", None) or [])
    written += [None] * (len(expr.params) - len(written))
    return [r if r is not None else written[i] for i, r in enumerate(resolved)]


def _arrow_signature_known(expr) -> bool:
    """May this arrow's signature go into the IR?

    item 75(a) §4 — "the frontend gets stricter, the IR does not move". The two
    keys go in iff EVERY parameter type is known, which keeps the node
    byte-identical for every arrow that carries one today, keeps an arrow with
    no signature carrying neither key, and stops a *partially* annotated arrow
    from emitting `"param_types": ["Int", null], "returns": null` — a shape
    docs/backend-ir-v3.md's "absent together" contract never admitted, and
    which no emitter is written against.

    The checker's richer partial knowledge stays in the frontend. Carrying a
    partial signature into the IR is a separate, demand-driven change: it needs
    a contract edit plus a decision per tier, and two tiers (java, wasm) have no
    representation for `Any` at all."""
    if getattr(expr, "param_types", None) is None:
        return False  # the checker never resolved this arrow
    return all(p is not None for p in _arrow_param_types(expr))


def _assert_colour_is_positional(expr, filename: str | None) -> None:
    """Rule C2, enforced where the `async` flag is set.

    `node["async"]` is derived from `expr.returns`, which only the checker
    writes and only from a checking position, so the flag stays the certificate
    the leak scan and the callee-collection stop set read it as. The author's
    `written_returns` must never be able to reach it. Rule C1 refuses the
    annotation in the checker, but the component path (stratum 3) does not run
    the checker over arrows at all, so the refusal is restated here rather than
    assumed — an `assert` alone would strip under `-O` and would not cover that
    path in the first place."""
    refuse_self_declared_async(expr, filename)
    assert not (filename and _mentions_async(getattr(expr, "written_returns", None))), (
        "C2: a written arrow return annotation must never reach the async flag")


def _expr_static_type(expr, type_env: dict, types: dict) -> str | None:
    """Best-effort static type of a pure expression.

    match exhaustiveness is a best-effort check: when the scrutinee's type is
    not recoverable from the local type environment, lowering still proceeds
    (the Python emitter adds a runtime fallback for those cases).
    """
    # delegated to the bidirectional checker's inference (non-raising form)
    return infer_ast(expr, type_env, types)


def _map_key_value_types(target, type_env: dict,
                         types: dict) -> tuple[str | None, str | None]:
    """The declared `(K, V)` of a subscript target that is a `Map[K, V]`, else
    ``(None, None)`` (issue #957).

    This is what tells a backend that `m[k]` is a map lookup rather than a
    positional read. The decision has to be made HERE, from the container's
    declared type: an emitter sees only the index expression, and every one of
    them read a subscript as the `List` read it was written for, which is how a
    `Str` key ended up cast to an integer on four tiers.

    ``(None, None)`` covers every other target — a `List`, a `Str` (refused by the
    checker), and the `Any`/host receiver whose string-literal subscript is a
    property read — so those lowerings are untouched.
    """
    target_type = _expr_static_type(target, type_env, types)
    if not target_type:
        return (None, None)
    head, args = parse_type(target_type)
    if head == "Map" and args:
        return (args[0], args[1] if len(args) > 1 else None)
    return (None, None)


def _field_declared_type(target_type: str | None, field_name: str,
                         types: dict) -> str | None:
    """The DECLARED type of ``target_type.field_name`` when the target resolves
    to a record (structural or nominal), else ``None``.

    Used to decide whether a field read is TOTAL: a field whose declared type is
    ``Opt[T]`` reads back the empty Opt on absence rather than raising, so the
    designed spelling `e.kind ?? default` means the same on every tier (item
    380). A structural literal record binding is checked first (item 71 keeps
    those field-checkable), then the nominal record table.
    """
    if not target_type:
        return None
    struct = structural_fields(target_type)
    if struct is not None:
        return struct.get(field_name)
    head, _ = parse_type(target_type)
    spec = types.get(head or "")
    if spec is not None and spec.get("kind") == "record":
        return (spec.get("fields") or {}).get(field_name)
    return None


def _field_is_opt(target_type: str | None, field_name: str, types: dict) -> bool:
    """Whether ``target_type.field_name`` is declared ``Opt[...]`` — the trigger
    for a TOTAL field read (item 380)."""
    declared = _field_declared_type(target_type, field_name, types)
    return bool(declared) and parse_type(declared)[0] == "Opt"


def _type_arg(type_name: str | None, base: str) -> str | None:
    """Best-effort inner type of ``base[...]``."""
    if type_name and type_name.startswith(base + "["):
        return type_name[len(base) + 1 : -1]
    return None


def _is_sized_type(type_name: str | None) -> bool:
    return type_name in ("Str", "Bytes") or bool(type_name and type_name.startswith("List["))


def _variant_case_payload(types: dict, type_name: str | None, case_name: str) -> str | None:
    spec = types.get(type_name or "")
    if spec is None or spec.get("kind") != "variant":
        return None
    for case in spec.get("cases", []):
        if case["name"] == case_name:
            return case["payload"]
    return None


def _arm_payload_type(scrutinee_type: str | None, pattern: str, types: dict) -> str | None:
    """The payload type bound by a match arm. User variants come from the case
    table; built-in Opt/Result payloads come from the scrutinee's type args
    (`Opt[T]` -> Some binds T; `Result[T, E]` -> Ok binds T, Err binds E)."""
    user = _variant_case_payload(types, scrutinee_type, pattern)
    if user is not None:
        return user
    head, args = parse_type(scrutinee_type)
    if head == "Opt" and pattern == "Some" and args:
        return args[0]
    if head == "Result" and args and len(args) == 2:
        if pattern == "Ok":
            return args[0]
        if pattern == "Err":
            return args[1]
    return None


def _check_match_exhaustiveness(expr: ExprMatch, type_env: dict, types: dict, filename: str) -> None:
    type_name = _expr_static_type(expr.scrutinee, type_env, types)
    spec = types.get(type_name or "")
    if spec is None or spec.get("kind") != "variant":
        return
    # An arm naming something that is not a case of the scrutinee's ADT has no
    # meaning on any tier: Java emits a `case` label for a constant that does
    # not exist ("cannot find symbol") and the Rust emitter raises EmitError.
    # Python/TS silently never take the arm, so the divergence is a portability
    # bug rather than a compile error there — which is exactly what revl exists
    # to refuse.
    declared = [case["name"] for case in spec.get("cases", [])]
    for pattern, _, _ in expr.arms:
        if pattern != "_" and pattern not in declared:
            raise RevlError(
                filename, expr.line,
                f"`{pattern}` is not a case of `{type_name}` "
                f"(cases: {', '.join(f'`{c}`' for c in declared)})",
                hint="a match arm names one of the ADT's declared cases, or `_` for "
                     "a catch-all — a bare name is not a binding pattern "
                     "(syntax-2.0 §3.3); check the spelling or add the case to "
                     f"`type {type_name}`",
            )
    covered = {pattern for pattern, _, _ in expr.arms if pattern != "_"}
    if "_" in {pattern for pattern, _, _ in expr.arms}:
        return
    missing = [case["name"] for case in spec.get("cases", []) if case["name"] not in covered]
    if not missing:
        return
    if len(missing) == 1:
        rendered = f"`{missing[0]}`"
        plural = "case"
    else:
        rendered = ", ".join(f"`{name}`" for name in missing)
        plural = "cases"
    raise RevlError(filename, expr.line, f"non-exhaustive match: missing {plural} {rendered}")


def _mutable_free_vars(expr, scope: dict, bound: set[str] | None = None) -> set[str]:
    """Mutable `var` names referenced by ``expr`` and not shadowed by a
    lambda parameter.  Arrow literals snapshot these by value."""
    bound = set(bound or ())
    if isinstance(expr, ExprVar):
        if expr.name not in bound and scope.get(expr.name) is True:
            return {expr.name}
        return set()
    if isinstance(expr, ExprArrow):
        return _mutable_free_vars(expr.body, scope, bound | set(expr.params))
    if isinstance(expr, ExprBin):
        return _mutable_free_vars(expr.left, scope, bound) | _mutable_free_vars(expr.right, scope, bound)
    if isinstance(expr, ExprUn):
        return _mutable_free_vars(expr.operand, scope, bound)
    if isinstance(expr, ExprCall):
        found = _mutable_free_vars(expr.callee, scope, bound)
        for arg in expr.args:
            found |= _mutable_free_vars(arg, scope, bound)
        return found
    if isinstance(expr, ExprField):
        return _mutable_free_vars(expr.target, scope, bound)
    if isinstance(expr, ExprIndex):
        return _mutable_free_vars(expr.target, scope, bound) | _mutable_free_vars(expr.index, scope, bound)
    if isinstance(expr, ExprIf):
        return (
            _mutable_free_vars(expr.cond, scope, bound)
            | _mutable_free_vars(expr.then, scope, bound)
            | _mutable_free_vars(expr.otherwise, scope, bound)
        )
    if isinstance(expr, ExprRecord):
        found: set[str] = set()
        for _, value in expr.fields:
            found |= _mutable_free_vars(value, scope, bound)
        return found
    if isinstance(expr, ExprRecordUpdate):
        found = _mutable_free_vars(expr.base, scope, bound)
        for _, value in expr.updates:
            found |= _mutable_free_vars(value, scope, bound)
        return found
    if isinstance(expr, ExprList):
        found = set()
        for item in expr.items:
            found |= _mutable_free_vars(item, scope, bound)
        return found
    if isinstance(expr, ExprMatch):
        found = _mutable_free_vars(expr.scrutinee, scope, bound)
        for _, bind, body in expr.arms:
            arm_bound = set(bound)
            if bind is not None:
                arm_bound.add(bind)
            found |= _mutable_free_vars(body, scope, arm_bound)
        return found
    return set()


# ---------------------------------------------------------------------------
# By-value capture for a DERIVED INVERSE (docs/syntax-2.0.md §3.5,
# docs/closures.md).
#
# An arrow literal snapshots the mutable names it reads: the lowering computes
# them into the IR `captures` list (`_mutable_free_vars` above) and every
# emitter binds them to their current values at arrow-creation time. A derived
# inverse -- the `undo` of an `effect` / `let-effect`, the `compensate` of an
# `emit` -- is NOT an arrow node, so it never went through that path. Each
# emitter instead wraps the raw undo EXPRESSION in a closure of its own, which
# in Python, TypeScript and Go captures the enclosing local by REFERENCE.
#
# That matters only in a provide-method body, the one place `var` and `effect`
# coexist (`var` is fn-local, so an activation body has none, and item 399
# refuses `effect` in a plain `fn` body). There, the inverse runs LATER -- at
# teardown, or on abort -- so a `var` the body reassigns after the effect
# registers changes what the inverse acts on:
#
#     var k = key
#     effect store.insert(k, "v") undo store.remove(k)
#     k = "zz"                       # the inverse now removes "zz"
#
# The accumulator entry is not the inverse of the effect that ran. G7's
# LIFO-completeness holds over the wrong set, A8's revert-and-contain replays
# against a value the forward step never used, and the R4 residue report still
# reads clean because the runtime has no way to know.
#
# The fix gives the derived inverse the same contract the arrow already has:
# the lowering names the mutable locals it reads on the step itself, under
# `undo_captures` / `compensate_captures`, and each emitter binds them to their
# current values where it builds the inverse closure -- the same division of
# labour `captures` already has, and the one docs/closures.md §Backends already
# describes. The names, not the binding idiom, are the part that has to agree
# across tiers, so the front end owns them and no backend re-derives them.
#
# Naming them rather than rewriting the body keeps this invisible to everything
# that reads the IR positionally: no step is inserted, so no effect LABEL moves
# (the rust tier derives `C.set.effect.N` from the step index, and those labels
# are observable in trace records), and a tier that already snapshots by other
# means -- rust clones each free name into its `move` closure before the
# reassignment can land -- keeps emitting byte-identical code.


def _ir_name_reads(node, out: set, bound: frozenset = frozenset()) -> None:
    """Every local name an IR expression READS, minus the ones an inner arrow
    parameter shadows. Both spellings the lowering emits for a name reference
    are covered: the component path's `{"kind": "name", "id": …}` and the pure
    path's `{"kind": "var", "name": …}`."""
    if isinstance(node, list):
        for item in node:
            _ir_name_reads(item, out, bound)
        return
    if not isinstance(node, dict):
        return
    kind = node.get("kind")
    if kind == "name" and isinstance(node.get("id"), str):
        if node["id"] not in bound:
            out.add(node["id"])
    elif kind == "var" and isinstance(node.get("name"), str):
        if node["name"] not in bound:
            out.add(node["name"])
    elif kind == "arrow":
        bound = bound | frozenset(node.get("params") or [])
    for value in node.values():
        _ir_name_reads(value, out, bound)


def _pin_inverse_captures(body: list) -> None:
    """Name, on each step that carries a derived inverse, the mutable locals that
    inverse reads -- the ones an emitter must bind BY VALUE where it builds the
    inverse closure (see the note above). Mutates `body` in place.

    A step whose inverse reads no mutable local is left untouched, so the IR of
    every program that never had the problem is byte-identical."""
    mutable: set = set()
    for step in body:
        for slot in ("undo", "compensate"):
            inverse = step.get(slot) if mutable else None
            if inverse is None:
                continue
            reads: set = set()
            _ir_name_reads(inverse, reads)
            pinned = sorted(reads & mutable)
            if pinned:
                step[f"{slot}_captures"] = pinned
        if step.get("step") == "let" and isinstance(step.get("name"), str):
            if step.get("mutable"):
                mutable.add(step["name"])
            else:
                mutable.discard(step["name"])


def _block_arm_unimplemented(filename: str, line: int) -> RevlError:
    """Block-bodied match arms lower by lambda-lifting into a synthetic helper
    fn (`_lift_block_arm`), which needs a lift sink in scope. A position without
    one (e.g. an extern undo expression) cannot lift, so it refuses loudly
    rather than half-emit."""
    return RevlError(
        filename, line,
        "a block-bodied match arm (`=> { … ; expr }`) is not lowerable here",
        hint="block arms lower inside a module `fn` body; lift the block into a "
             "named helper `fn` for this position (docs/records.md §6)",
    )


# The lift sink threads a synthetic-fn accumulator through fn-body lowering
# under a private (`__`-prefixed, so never serialised) key on the shared
# `types` dict. `_lower_fns` installs it and drains it into the functions list.
LIFT_SINK = "__arm_lift__"


def _pattern_binds(pattern) -> list[str]:
    """The names a `let`-pattern binds (record fields, list binds, list rest)."""
    names = list(getattr(pattern, "fields", None) or [])
    names += list(getattr(pattern, "binds", None) or [])
    rest = getattr(pattern, "rest", None)
    if rest:
        names.append(rest)
    return names


def _collect_arm_names(node, referenced: set[str], bound: set[str]) -> None:
    """Collect the names a block-arm subtree *reads* into ``referenced`` and the
    names it *declares* into ``bound``, so `_lift_block_arm` can capture exactly
    the enclosing bindings the arm uses.

    A generic AST walk: only the name-reading node (`ExprVar`, and the target of
    an assignment) and the name-binding nodes (`let`/`var`, `let`-pattern, `for`)
    are special-cased; every other node recurses over its dataclass fields."""
    if isinstance(node, (list, tuple)):
        # A tuple carries names exactly as a list does. The case that matters is
        # `Interp.parts`, a list of `("text", str)` / `("expr", <ast>)` tuples:
        # the interpolated `${...}` expression rides in the tuple's second slot,
        # so a walk that stops at the tuple never sees the names a template
        # reads. That left every capture inside a template in a block-bodied
        # match arm uncollected, so the lifted helper missed the parameter and
        # the arm was refused with "`x` is not declared in this function" (#548
        # item 8). The scalar slots (the `"text"`/`"expr"` tag, line ints)
        # recurse to the scalar no-op below, so recursing over every element is
        # safe.
        for item in node:
            _collect_arm_names(item, referenced, bound)
        return
    if isinstance(node, ExprVar):
        referenced.add(node.name)
        return
    if isinstance(node, LetStmt):
        _collect_arm_names(node.value, referenced, bound)
        bound.add(node.name)
        return
    if isinstance(node, LetPatternStmt):
        _collect_arm_names(node.value, referenced, bound)
        for name in _pattern_binds(node.pattern):
            bound.add(name)
        return
    if isinstance(node, ForStmt):
        _collect_arm_names(node.iterable, referenced, bound)
        bound.add(node.bind)
        _collect_arm_names(node.body, referenced, bound)
        return
    if isinstance(node, AssignStmt):
        # the target names an existing binding the block writes into
        referenced.add(node.name)
        _collect_arm_names(node.value, referenced, bound)
        return
    if dataclasses.is_dataclass(node):
        for field in dataclasses.fields(node):
            _collect_arm_names(getattr(node, field.name), referenced, bound)
        return
    # scalars (str/int/None) carry no names


def _lift_block_arm(expr, scope: dict, callables: set, alias_fns: dict,
                    filename: str, type_env: dict, types: dict) -> dict:
    """Lower a statement-block match arm by lambda-lifting it into a synthetic
    helper fn (docs/records.md §6).

    The arm's statements become the helper's body, its final expression becomes
    the helper's `return`, and every enclosing name the block reads becomes a
    parameter. The arm's value is then a *call* to that helper — an expression,
    so the IR arm-body-as-expression invariant holds and every backend that
    emits a fn call emits the arm without new emit support.

    The body is lowered with the ordinary fn-body machinery (`_lower_pure_stmt`),
    so the arm obeys exactly the purity/effect rules of any pure value block: an
    effect statement, or an assignment to a captured (now immutable) name, is
    refused just as it would be in a normal block that produces a value."""
    sink = types.get(LIFT_SINK)
    if sink is None:
        raise _block_arm_unimplemented(filename, expr.line)

    referenced: set[str] = set()
    bound: set[str] = set()
    for stmt in expr.stmts:
        _collect_arm_names(stmt, referenced, bound)
    _collect_arm_names(expr.tail, referenced, bound)
    captures = sorted(n for n in referenced if n in scope and n not in bound)

    params: list[dict] = []
    arm_scope: dict = {}
    arm_type_env: dict = {}
    for cap in captures:
        ctype = type_env.get(cap)
        if ctype is None:
            raise RevlError(
                filename, expr.line,
                f"a match block arm reads `{cap}`, whose type is not known here",
                hint="annotate the binding this arm reads so the lifted arm "
                     "helper can type its parameter (docs/records.md §4)")
        params.append({"name": cap, "type": ctype})
        # a captured `var` enters the helper as an immutable parameter: reading
        # it is fine, assigning to it is refused, which is exactly the purity a
        # value-producing block owes its enclosing scope.
        arm_scope[cap] = "host" if scope.get(cap) == "host" else False
        arm_type_env[cap] = ctype

    arm_body: list = []
    for stmt in expr.stmts:
        _lower_pure_stmt(stmt, arm_scope, callables, alias_fns, arm_body,
                         filename, arm_type_env, types)
    ret_type = infer_ast(expr.tail, arm_type_env, types, filename)
    arm_body.append({
        "step": "return",
        "expr": _lower_pure_expr(expr.tail, arm_scope, callables, alias_fns,
                                 filename, arm_type_env, types),
    })

    # A fresh, backend-safe helper name: no leading underscore (emitters reserve
    # that for scaffolding) and never a user fn/extern name.
    taken = sink["taken"]
    name = f"match_arm_{sink['n']}"
    while name in taken:
        sink["n"] += 1
        name = f"match_arm_{sink['n']}"
    sink["n"] += 1
    taken.add(name)
    sink["fns"].append({
        "name": name,
        "params": params,
        "returns": ret_type,
        "public": False,
        "body": arm_body,
    })
    return {"kind": "call",
            "callee": {"kind": "var", "name": name},
            "args": [{"kind": "var", "name": cap} for cap in captures]}


class _LaxScope(dict):
    """Permissive scope for extern undo/compensate refs.

    Host blocks are verbatim text; their undo/compensate expressions are
    host-level names (e.g. `close(socket)`) and are not checked against revl
    function scope.
    """

    def __contains__(self, key) -> bool:
        return True


def _lower_extern_expr(expr, filename: str) -> dict:
    return _lower_pure_expr(expr, _LaxScope(), set(), {}, filename)


_SITE_INVERSE_GUIDANCE = (
    "a site `undo` is the teardown that actually RUNS on abort, while the "
    "activation is already unwinding, so its call is held to the callee's "
    "declared signature exactly like the extern's own slot. To release what "
    "was acquired: in an activation body bind the acquisition and name the "
    "binding (`let h = effect <acquire>(...) undo <inverse>(h)`); at a "
    "provide-method seam, where no acquisition may be bound and `result` is "
    "not in scope, declare the extern `witnessed` and drop the site `undo`, "
    "so its DECLARED `undo <inverse>(result)` is the one that replays, once "
    "per acquisition, with `result` bound to the handle that was actually "
    "acquired (docs/design/243-witnessed-externs.md)")


def _site_inverse_refusal(err: RevlError, slot: str) -> RevlError:
    """Re-raise an inverse-slot argument refusal with the slot named.

    The MESSAGE stays the stratum checker's verbatim ("`f` takes 1
    argument(s), 3 given"; "argument 1 of `f(...)` expects `T`, got `Str`"),
    so the T1 shape every consumer classifies on is unchanged. Only the hint
    is rewritten, because the POSITION is what makes the refusal navigable
    (item 274): the author needs to know this is teardown, and which spelling
    releases the handle that was actually acquired."""
    detail = f"{err.hint}; " if err.hint else ""
    return RevlError(err.filename, err.line, err.message,
                     hint=f"{detail}{_SITE_INVERSE_GUIDANCE} (`{slot}` slot)",
                     code=err.code or "T1",
                     category=err.category or "type-mismatch",
                     expected=err.expected, actual=err.actual,
                     navigate=err.navigate)


def _check_inverse_args(expr, *, where: str, filename: str,
                        tenv: dict | None = None,
                        types: dict | None = None) -> None:
    """The EXTERN slot's half of the one inverse-slot argument judgment.

    An inverse slot - the extern's DECLARED `undo`/`compensate`, and the
    SITE-spelled `undo` of an `effect`/`subscribe` (and the site `compensate`
    of an `emit`) - must call a declared callable at its declared arity, with
    arguments of the declared types. Only the extern slot ever had that
    judgment: `_check_extern_undo` ran the expression through `check_ast`,
    while every site slot lowered and stopped. And the gap was never a
    missing checker; it was a missing FILENAME. Both stratum checkers are
    documented to raise only when handed one (`infer_ast`: "with `filename`,
    definite operator/branch/argument mismatches raise"; `infer_ir`: the same
    sentence), and the component lowering calls `infer_ir` in its
    non-raising oracle mode everywhere.

    The two slots hold their expression in different STRATA, which is why
    they enter the judgment at different points rather than sharing one call:
    an extern slot keeps the parser AST (its names resolve against the slot's
    own tenv - `result`, or nothing), while a site slot has already lowered
    through the component machinery, where names are safe names and host
    verbs, service methods and spawn handles are resolved shapes no
    `infer_ast` arm models. What IS shared is everything the judgment
    consults: one signature table (`FNS_KEY`), one arity rule, one `unify`,
    one `mismatch` renderer.

    The site stratum's entry is `_lower_site_inverse` below, which rides on
    item 423's general component-body call check."""
    check_ast(expr, None, tenv or {}, types or {}, filename, where)


def _lower_site_inverse(expr, env: "Env", *, slot: str):
    """Lower a SITE-spelled inverse slot with the slot named on `env`.

    Item 423 argument-checks EVERY component-body call, at the one place a
    component-stratum `fn` node is built (`_check_component_call`), so the
    site slot needs no argument sweep of its own: its calls are judged as they
    are built, bottom-up, at their own line, including the ones nested under
    an opaque host `call` node whose arguments `infer_ir` deliberately does
    not visit (`undo store.insert("k", note(42))`), which a root-only sweep
    could not reach.

    What that general check cannot know on its own is the POSITION, and the
    position is what makes this particular refusal navigable (item 274). A
    site `undo` is the teardown that actually runs on abort, and the generic
    hint offers advice the author cannot take there: at a provide-method seam
    the acquisition cannot be bound and `result` is not in scope, so the only
    move that releases the acquired handle is `witnessed`. So the slot rides
    on `env` for the duration of the lowering - the same idiom `_lower_expr`
    already uses for the expression mode - and `_check_component_call` renders
    the slot-naming, spelling-listing refusal while it is set, the generic one
    otherwise. One judgment, one message table, two hints."""
    saved = getattr(env, "_inverse_slot", None)
    env._inverse_slot = slot
    try:
        return _lower_expr(expr, env, mode="undo")
    finally:
        env._inverse_slot = saved


def _check_extern_undo(expr, decl_name: str, slot: str, types: dict,
                       filename: str, result_type: str | None = None) -> None:
    """The extern-level `undo`/`compensate` slot, checked.

    Component-site `effect ... undo ...` runs through the component
    expression machinery, so it resolves every name against the bindings
    in scope at the effect site. An extern declares no bindings, so the
    slot's variable namespace is almost empty — with ONE exception. The
    `undo` of an acquire extern with a declared return type binds `result`,
    the acquired value: the teardown exists to release exactly what the
    acquisition produced (the WIT resource model is the canonical user —
    `extern acquire fn r_new(...) -> R undo r_drop(result)`). Nothing else
    is visible: the extern's own parameters are *not* implicitly captured
    (no tier defines teardown parameter capture; inventing that here would
    be unsound speculation), and `compensate` — a best-effort follow-up to
    a one-way emission, not an inverse — binds nothing at all. What the
    slot must satisfy mirrors the component-site rules plus the arity/type
    rigor of every other call:

    1. the callee is a plain call to a DECLARED callable (fn/extern via the
       shared signature table, host builtin, ADT constructor);
    2. self-reference is refused — the teardown exists to INVERT the
       acquisition; calling the extern again would re-acquire mid-cleanup;
    3. arity and argument types are checked against the declared signature,
       with `result: T` in scope exactly when described above.
    """
    from .parser import ExprCall, ExprField, ExprVar

    def _walk(e):
        if isinstance(e, ExprVar):
            if e.name == "result":
                if result_type is not None:
                    return  # the one implicit binding: the acquired value
                if slot == "compensate":
                    raise RevlError(
                        filename, e.line,
                        f"`result` is not bound in the `compensate` slot of "
                        f"extern `{decl_name}`",
                        hint="`result` names the value an acquire returns; a "
                             "compensation follows a one-way emission, which "
                             "acquires nothing — compensate from constants or "
                             "other declared fns")
                raise RevlError(
                    filename, e.line,
                    f"`result` does not exist here — extern `{decl_name}` "
                    "declares no return type, so there is no acquired value "
                    "to bind",
                    hint="declare `-> T` on the extern to give the teardown "
                         "its `result`, or tear down from constants")
            # any other bare name: the only implicit binding is `result`
            # (undo of an acquire) — locals don't exist, and the extern's
            # own parameters are not visible (no tier defines teardown
            # parameter capture)
            if result_type is not None:
                raise RevlError(
                    filename, e.line,
                    f"`{e.name}` is not declared — the `{slot}` slot of "
                    f"extern `{decl_name}` sees only the implicit `result` "
                    "binding",
                    hint="`result` is the acquired value; the extern's own "
                         "parameters are not visible to its teardown, so "
                         "anything else must travel as constants or through "
                         "other declared fns")
            raise RevlError(
                filename, e.line,
                f"`{e.name}` is not declared — the `{slot}` slot of extern "
                f"`{decl_name}` runs with no variables in scope",
                hint="an extern's own parameters are not visible to its "
                     "teardown; the undo must work from constants or from "
                     "other declared fns")
        if isinstance(e, ExprCall):
            if isinstance(e.callee, ExprVar):
                name = e.callee.name
                if name == decl_name:
                    raise RevlError(
                        filename, e.line,
                        f"extern `{decl_name}`'s `{slot}` cannot call the "
                        "extern itself",
                        hint="the teardown runs to invert this acquisition — "
                             "calling it again would re-acquire during "
                             "cleanup; call the declared inverse instead")
                if (name not in (types.get(FNS_KEY) or {})
                        and name not in (types.get(CASES_KEY) or {})
                        and name not in _HOST_CALLABLES
                        and name not in _BUILTIN_CONSTRUCTORS):
                    raise RevlError(
                        filename, e.line,
                        f"`{name}` is not declared — the `{slot}` slot of "
                        f"extern `{decl_name}` may only call a declared fn, "
                        "extern, or host builtin",
                        hint="an extern binds no callables (only the acquire's "
                             "`result` value is ever in scope), so every "
                             "callee must be a module-level declaration")
            elif isinstance(e.callee, ExprField):
                raise RevlError(
                    filename, e.line,
                    f"the `{slot}` slot of extern `{decl_name}` must be a "
                    "plain call to a declared fn or extern",
                    hint="host objects cannot be acquired inside a teardown "
                         "expression; call the declared inverse directly")
            for a in e.args:
                _walk(a)
            return
        # generic recursion over the dataclass children (bin operands, record
        # fields, match arms, template parts, ...)
        for f in type(e).__dataclass_fields__:
            v = getattr(e, f)
            if hasattr(v, "__dataclass_fields__"):
                _walk(v)
            elif isinstance(v, (list, tuple)):
                for x in v:
                    if hasattr(x, "__dataclass_fields__"):
                        _walk(x)
                    elif isinstance(x, (list, tuple)):
                        for y in x:
                            if hasattr(y, "__dataclass_fields__"):
                                _walk(y)

    _walk(expr)
    # the tenv carries exactly what the slot binds: `result: T` for the undo
    # of an acquire with a declared return, nothing otherwise — so argument
    # type-checking sees the acquired value at its declared type
    tenv = {"result": result_type} if result_type is not None else {}
    _check_inverse_args(expr, where=f"{slot} of extern `{decl_name}`",
                        filename=filename, tenv=tenv, types=types)


_UNIT_RETURNS = (None, "Unit")


def _check_deferred_extern(decl, filename: str) -> None:
    """The `deferred` checker obligations (docs/design/245-session-commit.md,
    Decision 2). Every rule keeps class (b) — the deferrable emission — an exact
    type judgment: the checker can enforce the abort/commit semantics only
    because these hold at declaration.

    1. `deferred` only on an `emission`. `pure` has nothing to defer; `acquire`
       and `witnessed` must run mid-session (their return is the resource or the
       witness).
    2. A deferred emission returns `Unit`. The call completes before the action
       fires, so no value can flow back; a non-Unit return would be a lie the
       program could branch on. This is also the mechanical (b)/(c) boundary: an
       emission whose response the task needs mid-session cannot type `deferred`.
    3. `deferred` and `compensate` are mutually exclusive. A compensation offsets
       a fired emission on abort; a deferred emission's abort drops the queue
       (nothing fired, nothing to offset), so the pair is dead code.
    4. `deferred` and `async` are mutually exclusive (v1): there is no response
       to await.
    """
    if decl.classification != "emission":
        raise RevlError(
            filename, decl.line,
            f"`deferred` is only valid on an `emission` extern; `{decl.name}` is "
            f"`{decl.classification}`",
            hint="a `pure` extern has nothing to defer, and an `acquire` or "
                 "`witnessed` extern must run mid-session — its return is the "
                 "resource or the witness (docs/design/245-session-commit.md)",
            code="G4", category="deferred")
    if decl.returns not in _UNIT_RETURNS:
        raise RevlError(
            filename, decl.line,
            f"a `deferred` emission must return `Unit`; `{decl.name}` returns "
            f"`{decl.returns}`",
            hint="a deferred emission returns before the world changes, so no "
                 "value can flow back from it — an emission whose response the "
                 "task needs mid-session stays an immediate emission (drop "
                 "`deferred`)",
            code="G4", category="deferred")
    if decl.compensate is not None:
        raise RevlError(
            filename, decl.line,
            f"a `deferred` emission cannot declare `compensate`; `{decl.name}` "
            f"declares both",
            hint="a compensation offsets a fired emission on abort, but a "
                 "deferred emission's abort drops the queue — nothing fired, so "
                 "there is nothing to offset. The pair is dead code by "
                 "construction (docs/design/245-session-commit.md)",
            code="G5", category="deferred")
    if decl.async_:
        raise RevlError(
            filename, decl.line,
            f"a `deferred` emission cannot be `async` (v1); `{decl.name}` is both",
            hint="a deferred emission returns Unit at the call and fires later at "
                 "the session commit, so there is no response to await",
            code="G4", category="deferred")


def _check_poly_extern(decl, filename: str) -> None:
    """The `fn|async` (caller-decided colour) checker obligations
    (docs/design/388-caller-decided-extern-colour.md, option a, stages 2 and 7).

    A poly extern is one authored host body whose colour is decided at the CALL
    SITE — a sync call site clones it to a `def`/`function`, an async call site
    to an `async def`/`async function`. That is sound only for a colour-agnostic
    (await-free) body, which the compiler cannot verify inside opaque host text
    (G8, item 24; the body is not sandboxed, docs/design/329-untrusted-author-
    profile.md). So these are the honest-by-review envelope plus one cheap lint:

    1. `fn|async` only on an `emission`. The colour it wears is the async/sync
       emission colour; `pure`/`acquire`/`witnessed` have no async story (they
       run on pure or synchronous teardown paths), exactly as a fixed `async`
       extern is emission-only (lower.py async-validity block).
    2. `fn|async` and a fixed `async` are mutually exclusive. A fixed `async`
       already picks the colour, so pairing it with the "either colour" marker is
       contradictory.
    3. `fn|async` and `deferred` are mutually exclusive. A deferred emission
       returns Unit at the call and fires later, so there is no call-site colour
       to decide (the same reason `deferred` and `async` are exclusive).
    4. A poly extern cannot declare `compensate`, exactly as a fixed `async`
       extern cannot (the compensation seam is synchronous on every tier).
    5. The `await`-keyword lint: refuse a `fn|async` `@py`/`@ts` body whose text
       contains the tier's suspend keyword (`await`). A colour-agnostic body
       cannot suspend, so its sync clone would be invalid host code (an `await`
       outside an `async def` is a Python SyntaxError). Stated honestly as a LINT,
       not a proof: a body can suspend without the keyword (an event-loop
       `run_until_complete`), and the keyword can appear inside a string literal.
    """
    if decl.classification != "emission":
        raise RevlError(
            filename, decl.line,
            f"`fn|async` (caller-decided colour) is only valid on an `emission` "
            f"extern; `{decl.name}` is `{decl.classification}`",
            hint="the marker chooses the sync-vs-async EMISSION colour at the call "
                 "site; a `pure` extern is callable from pure positions with no "
                 "async story, and an `acquire`/`witnessed` extern runs on the "
                 "synchronous teardown path (docs/design/388-caller-decided-"
                 "extern-colour.md)")
    if decl.async_:
        raise RevlError(
            filename, decl.line,
            f"extern `{decl.name}` is both `async` and `fn|async` — a fixed "
            f"`async` already picks the colour",
            hint="drop the `async` modifier to let the call site decide the "
                 "colour, or drop `|async` to fix it async (item 388)")
    if decl.deferred:
        raise RevlError(
            filename, decl.line,
            f"a `fn|async` emission cannot be `deferred`; `{decl.name}` is both",
            hint="a deferred emission returns Unit at the call and fires at the "
                 "session commit, so there is no call-site colour to decide "
                 "(item 388)")
    if decl.compensate is not None:
        raise RevlError(
            filename, decl.line,
            f"a `fn|async` emission cannot declare `compensate`; `{decl.name}` "
            f"declares both",
            hint="the compensation seam is synchronous on every tier, exactly as "
                 "for a fixed `async` extern (item 388)")
    for body in decl.bodies:
        # word-boundary match so `await` the keyword is caught while an
        # identifier like `awaited_result` or `no_await` is not.
        if re.search(r"\bawait\b", body.text):
            raise RevlError(
                filename, body.line,
                f"the `fn|async` extern `{decl.name}` has an `@{body.backend}` "
                f"body containing `await`, but a caller-decided-colour body must "
                f"be colour-agnostic (await-free)",
                hint="a `fn|async` body is cloned into a sync `def`/`function` at "
                     "sync call sites, where an `await` is invalid — author the "
                     "suspending work as a fixed `async` extern instead, or (once "
                     "item 373 lands) share only the await-free span through a "
                     "host-body fragment (item 388)")


def _check_deferred_not_in_teardown(program, filename: str) -> None:
    """Rule: deferred emissions are refused in teardown positions — the `undo`
    and `compensate` slots (docs/design/245-session-commit.md, Decision 2).
    Teardown runs at or after the verdict; enqueueing into a queue that is
    already flushing or dropped is unanswerable (the same spirit as 247's "a
    compensation emits and returns; it does not accumulate")."""
    from .parser import ExprCall, ExprVar

    deferred = {d.name for d in program.externs if d.deferred}
    if not deferred:
        return

    def _scan(expr, decl_name: str, slot: str) -> None:
        if isinstance(expr, ExprCall):
            callee = expr.callee
            if isinstance(callee, ExprVar) and callee.name in deferred:
                raise RevlError(
                    filename, callee.line,
                    f"the `{slot}` slot of extern `{decl_name}` calls deferred "
                    f"emission `{callee.name}` — deferred emissions are refused "
                    f"in teardown positions",
                    hint="teardown runs at or after the session verdict; a "
                         "deferred emission would enqueue into a queue that is "
                         "already flushing or dropped, which is unanswerable "
                         "(docs/design/245-session-commit.md)",
                    code="G5", category="deferred")
            for arg in expr.args or []:
                _scan(arg, decl_name, slot)

    for decl in program.externs:
        if decl.undo is not None:
            _scan(decl.undo, decl.name, "undo")
        if decl.compensate is not None:
            _scan(decl.compensate, decl.name, "compensate")


def _service_emission_op(binding: str, method: str, env) -> str | None:
    """`<binding>.<method>` when it names an `emission` operation of a service
    this body requires, else None.

    The AST twin of `_is_emission_call`'s `req` arm: a service operation
    crossing is spelled `db.execute(...)`, an `ExprCall` whose callee is an
    `ExprField`, so the extern-name walk below (which only reads `ExprVar`
    callees) cannot see it. Both readings consult the same
    `ServiceDecl.methods[...].emission` bit, so they cannot disagree."""
    svc_name = (getattr(env, "requires", None) or {}).get(binding)
    if svc_name is None:
        return None
    svc = (getattr(env, "services", None) or {}).get(svc_name)
    if svc is None:
        return None
    decl = (getattr(svc, "methods", None) or {}).get(method)
    if decl is not None and getattr(decl, "emission", False):
        return f"{binding}.{method}"
    return None


def _handle_provision_op(expr, env) -> tuple[str, object] | None:
    """`(spelling, MethodDecl)` when the AST expression `expr` is a provision
    method READ off a spawn handle — `w.<key>.<method>` or, through the alias
    provenance, `t.<method>` where `let t = w.<key>` — else None.

    The AST twin of `_instance_get_call`, which reads the same
    `ServiceDecl.methods[...]` bit off the LOWERED node. A teardown slot is
    walked on the AST (before its undo is lowered, so the refusal can name the
    callee the author wrote), so the same resolution has to exist here; both
    readings consult one table, so they cannot disagree."""
    from .parser import ExprField, ExprVar
    if env is None or not isinstance(expr, ExprField):
        return None
    services = getattr(env, "services", None) or {}

    def _method(service_name, spelling):
        svc = services.get(service_name)
        decl = (getattr(svc, "methods", None) or {}).get(expr.name) if svc else None
        return (spelling, decl) if decl is not None else None

    target = expr.target
    if not isinstance(target, ExprVar):
        # `w.<key>.<method>`: the receiver is itself a provision read
        if isinstance(target, ExprField) and isinstance(target.target, ExprVar):
            comp = _handle_component_name(target.target.name, env)
            if comp is None:
                return None
            reg = getattr(env, "spawn_reg", None)
            decl = reg["by_name"].get(comp) if reg else None
            provides = {k: svc for k, svc, _l in (decl.provides if decl else [])}
            service = provides.get(target.name)
            if service is None:
                return None
            return _method(service,
                           f"{target.target.name}.{target.name}.{expr.name}")
        return None
    # `t.<method>` where `t` was bound to a provision read
    safe = (getattr(env, "params", None) or {}).get(target.name) \
        or (getattr(env, "locals", None) or {}).get(target.name)
    inst = (getattr(env, "provision_locals", None) or {}).get(safe)
    if inst is None:
        return None
    return _method(inst.get("service"), f"{target.name}.{expr.name}")


def _handle_component_name(surface: str, env) -> str | None:
    """The component a surface name holds a spawn handle to (`Instance[C]`),
    else None."""
    safe = (getattr(env, "params", None) or {}).get(surface) \
        or (getattr(env, "locals", None) or {}).get(surface)
    if safe is None:
        return None
    head, args = parse_type((getattr(env, "type_env", None) or {}).get(safe))
    return args[0] if head == "Instance" and args else None


#: `_project`'s answer for "no value is known for this node": it stands for
#: itself and every arm of the walk reads it as written.
_UNRESOLVED = object()


def _walk_inverse_emissions(expr, extern_class: dict, emitting_fns: set,
                            emitting_witness: dict, *, refuse, env=None,
                            refuse_opaque=None) -> None:
    """The ONE teardown-slot emission walk (G5), shared by every inverse.

    Two callers, one traversal: `_check_witnessed_inverse` holds a witnessed
    extern's DECLARED inverse to rule 3 (docs/design/243-witnessed-externs.md),
    and `_check_site_inverse_emission` holds a SITE-spelled bracket inverse
    (`effect … undo …`, `subscribe … undo …`) to the same no-emission-in-
    teardown bound (docs/design/teardown-contract.md: a bracket inverse "may
    emit in teardown: no (G5)"). The rule is one rule, so it is one walker;
    only the diagnostic differs, which is what `refuse` supplies.

    Three shapes reach a boundary and all three are found here:

    * a direct call to an `emission`/`witnessed` extern (`extern_class`);
    * a call to a plain top-level `fn` whose body transitively reaches one —
      `emitting_fns` is the emission-reach fixed point over the fn call graph
      (emission_analysis.py), so one membership test follows the whole chain,
      and `_emission_chain` renders the derivation;
    * a call to an `emission` service operation off a required binding, when
      an `env` is supplied (`_service_emission_op`).

    THREE MORE reach a boundary through an INDIRECTION, and each was invisible
    to the shape tests above until the callee was resolved through it:

    * a provision method call off a SPAWN HANDLE (`w.task.run(…)`), or off a
      local aliasing one (`let t = w.task; t.run(…)`). The service-operation arm
      matched only `<binding>.<method>`, so the handle form — one `ExprField`
      deeper — fell into the generic recursion and the emission ran in teardown
      with no diagnostic at all (`_handle_provision_op`);
    * a call through a FIRST-CLASS FUNCTION VALUE bound in this scope
      (`let f = (x) => send(x); undo f(key)`). The callee is not a name in
      `extern_class` or `emitting_fns`, so nothing matched; the arrow's BODY is
      walked instead, which follows the indirection precisely rather than
      refusing every indirect call (`arrows`);
    * a first-class REFERENCE to an emitting callable passed as an argument
      (`undo app(wrap, key)`, `fn app(f, x) = f(x)`). The reference is not a
      call, so no arm saw it; it is judged exactly as
      `_method_emissions` judges the same shape — the value may be dispatched
      by whoever receives it, so it counts as reaching what it names.

    All three indirections above are asked about the VALUE the slot dispatch-
    es, which is why a binding is resolved rather than read as a name. A
    fourth arm completes that reading: a value bound to a `let` and reached
    through the name (`let r = w.task.run; undo dispatch1(r)`), through a
    second binding (`let s = r`), through a container (`let box = { f:
    w.task.run }; undo dispatch1(box.f)`, `let ts = [w.task.run]; undo
    dispatch1(ts[0])`) or through an `if`/`match` arm (`let g = if c { w.task.run
    } else { pure1 }; undo dispatch1(g)`). Every one of those crosses the same
    boundary as the direct spelling — the reviewer's counterexample to the
    spelling-only reading of this rule — so the walk substitutes the bound
    value (`_project`, over `Env.provision_values`) and the arms below judge it;
    a container is traversed, so a record field and a list element are read too.
    No arm of this walk is on the spelling of an emission rather than on the
    value that reaches it.

    `refuse(node, name, terminal_class, chain)` is called with the offending
    call, the callee as written, the classification of the boundary actually
    reached, and the fn path to it; it must raise.

    `refuse_opaque(node, name)`, when supplied, is called for a call through a
    callee this scope cannot resolve at all — a function-typed parameter, a
    binding whose arrow is not in view. Nothing can bound what runs there, so a
    teardown slot refuses it; `_check_witnessed_inverse` supplies no such
    callback (an extern's declared inverse has no local scope to resolve
    against, and its callee table is closed).

    `arrows` maps a surface name to the `ExprArrow` it was bound to in the
    enclosing scope, and `known` is every name a call may legitimately
    name (declared fns/externs, host roots, ADT cases) — both read off `env`."""
    from .parser import (ExprArrow, ExprCall, ExprField, ExprIndex, ExprList,
                         ExprLit, ExprRecord, ExprVar)

    arrows = (getattr(env, "local_arrows", None) or {}) if env is not None else {}
    bound = (getattr(env, "provision_values", None) or {}) if env is not None else {}
    in_scope = set()
    if env is not None:
        in_scope = set(getattr(env, "params", None) or {}) \
            | set(getattr(env, "locals", None) or {})

    def _project(e, seen=frozenset()):
        """The VALUE `e` holds, with every name replaced by what `let` bound it
        to; `_UNRESOLVED` when nothing is known and `e` must be read as written.

        A teardown slot's reach is a question about the value the inverse
        dispatches, so `let r = w.task.run` has to answer exactly as
        `w.task.run` does. The binding is resolved transitively (`let s = r`
        costs nothing) and through what holds the value — a record field, a list
        element, and (returned as written, so the arms below read every one of
        them) an `if`/`match` arm, whose union is the verdict. `seen` is the
        chain already followed, which bounds the recursion however the names
        nest and leaves a cycle unresolved rather than spinning."""
        if not bound:
            return _UNRESOLVED
        if isinstance(e, ExprVar):
            if e.name in seen or e.name not in bound:
                return _UNRESOLVED
            held = _project(bound[e.name], seen | {e.name})
            return bound[e.name] if held is _UNRESOLVED else held
        if isinstance(e, ExprField):
            base = _project(e.target, seen)
            if base is _UNRESOLVED:
                return _UNRESOLVED
            if isinstance(base, ExprRecord):
                for key, item in base.fields:
                    if key == e.name:
                        held = _project(item, seen)
                        return item if held is _UNRESOLVED else held
                # the record is bound and does not hold the field: the read has
                # no value, and it is NOT the rest of the record either
                return None
            return _UNRESOLVED
        if isinstance(e, ExprIndex):
            base = _project(e.target, seen)
            if base is _UNRESOLVED:
                return _UNRESOLVED
            if isinstance(base, ExprList):
                index = e.index
                if isinstance(index, ExprLit) and isinstance(index.value, int) \
                        and not isinstance(index.value, bool):
                    if not 0 <= index.value < len(base.items):
                        return None
                    item = base.items[index.value]
                    held = _project(item, seen)
                    return item if held is _UNRESOLVED else held
                # an index the walk cannot pin down leaves every element a
                # candidate, so hand the list back and let the sweep take them
                # all — the same union rule the `if`/`match` arms get
                return base
            return _UNRESOLVED
        return _UNRESOLVED

    def _field_boundary(e):
        """`(spelling, "emission")` when the AST field expression `e` READS an
        `emission` service operation — `net.send`, `w.task.run` — else None.

        One resolution for both positions: `w.task.run(…)` and `f(w.task.run)`
        name the same operation, so the arm that reads the call reads the
        reference too. A reference the receiver may dispatch is a crossing one
        indirection later, exactly as `_method_emissions` judges the same
        shape in a method body (the G4 arm spells its verdict "passed as a
        function value"); a rule that only saw the called form was a way
        around the rule."""
        if env is None or not isinstance(e, ExprField):
            return None
        if isinstance(e.target, ExprVar):
            op = _service_emission_op(e.target.name, e.name, env)
            if op is not None:
                return op, "emission"
        found = _handle_provision_op(e, env)
        if found is not None and getattr(found[1], "emission", False):
            return found[0], "emission"
        return None

    def _walk(e, _seen=(), _computed=False):
        if e is None:
            return
        held = _project(e)
        if held is not _UNRESOLVED and held is not e:
            # the value the author bound, read in place of the name (or of the
            # read off a bound record/list) that stands for it. A bound name is
            # its value and nothing else, so this replaces the read rather than
            # adding to it — which is also what keeps a record PROJECTION from
            # being judged as the whole record.
            #
            # `_computed` carries the one thing the substitution cannot read off
            # the value itself: WHERE that value was computed. The `let` that
            # binds it sits in the method body, ahead of the bracket, so a call
            # inside it ran there and not in this slot — `let t = emit
            # mint_token(u)` followed by `undo store.remove(t)` hands the
            # inverse a token it is entitled to use, and reading the call as
            # though it were written in the slot refuses a program whose
            # emission never crossed the boundary. Only the call arm below
            # consults the flag: a REFERENCE is a reference however it was
            # bound, because the receiver dispatches the value it was handed
            # (`let r = w.task.run; undo dispatch1(r)`), and that indirection is
            # what this walk exists to close.
            _walk(held, _seen, True)
            return
        if isinstance(e, ExprVar) and e.name in emitting_fns:
            # a first-class reference in VALUE position: the callee it names may
            # be dispatched by whoever receives it, so it reaches what it names,
            # one indirection later (the same verdict `_method_emissions` gives
            # this shape, and it is the same set — `emitting_fns` holds the
            # emission externs too, so `f(hsend)` and `f(emit_wrapper)` are one
            # rule, not two).
            chain = _emission_chain(e.name, emitting_witness)
            refuse(e, e.name, extern_class.get(chain[-1]) or "emission", chain)
        if isinstance(e, ExprCall):
            callee = e.callee
            if not _computed:
                # a call WRITTEN in the slot runs in teardown, so whatever it
                # reaches is a crossing; the same call read out of a binding the
                # body already evaluated is a value, and `_computed` is the
                # whole of that difference.
                if isinstance(callee, ExprVar):
                    name = callee.name
                    bad = extern_class.get(name)
                    if bad in ("emission", "witnessed"):
                        refuse(e, name, bad, [name])
                    elif bad is None and name in emitting_fns:
                        chain = _emission_chain(name, emitting_witness)
                        refuse(e, name, extern_class.get(chain[-1]), chain)
                    elif name in arrows and name not in _seen:
                        # follow the arrow: whatever ITS body reaches, this call
                        # reaches. Resolved, not over-approximated, so a teardown
                        # calling a host-local arrow still compiles.
                        _walk(arrows[name].body, _seen + (name,), _computed)
                    elif refuse_opaque is not None and bad is None \
                            and name not in emitting_fns and name in in_scope:
                        refuse_opaque(e, name)
                elif env is not None and isinstance(callee, ExprField):
                    hit = _field_boundary(callee)
                    if hit is not None:
                        refuse(e, hit[0], hit[1], [hit[0]])
            for a in e.args:
                _walk(a, _seen, _computed)
            return
        if isinstance(e, ExprField):
            # the same read, NOT called: `undo dispatch1(w.task.run)`. Nothing
            # about the crossing changed — the receiver dispatches the value it
            # was handed — so it is refused here with the same diagnostic.
            hit = _field_boundary(e)
            if hit is not None:
                refuse(e, hit[0], hit[1], [hit[0]])
        if isinstance(e, ExprArrow):
            # an arrow's body is DEFERRED: it runs where the value is INVOKED,
            # not where the `let` sits, so a dispatched arrow emits in teardown
            # and its body is judged as slot code however the arrow was bound
            # (`_project` hands back `let f = (x) => send(x)` for `undo
            # dispatch1(f)`, and that is a crossing, not a value).
            _walk(e.body, _seen, False)
            return
        for f in type(e).__dataclass_fields__:
            v = getattr(e, f)
            if hasattr(v, "__dataclass_fields__"):
                _walk(v, _seen, _computed)
            elif isinstance(v, (list, tuple)):
                _walk_held(v, _seen, _computed)

    def _walk_held(v, _seen, _computed=False):
        """Sweep a list of expressions OR of the `(name, value)` pairs a record
        literal and a `match` arm are written as.

        The sweep above descends into entries that are themselves AST nodes, so
        a record's `[(field, value)]` and a `match`'s `[(pattern, bind, body)]`
        read as opaque tuples: an emission inside a record field or a `match`
        arm was invisible to every arm, in an inline literal exactly as in a
        value bound to one."""
        for x in v:
            if hasattr(x, "__dataclass_fields__"):
                _walk(x, _seen, _computed)
            elif isinstance(x, (list, tuple)):
                for y in x:
                    if hasattr(y, "__dataclass_fields__"):
                        _walk(y, _seen, _computed)

    _walk(expr)


def _check_site_inverse_emission(undo_expr, env, filename: str, line: int,
                                 *, slot: str = "undo") -> None:
    """G5 for a SITE-spelled bracket inverse (docs/design/teardown-contract.md,
    "may emit in teardown | no (G5)").

    `_check_witnessed_inverse` closed exactly this hole for a witnessed extern's
    DECLARED inverse and named the remaining gap in its own docstring: the
    inverse an author writes at the acquisition site (`let p = effect
    Pool.open(…) undo send_email(…)`, and the subscription bracket's `undo`)
    got no such walk, so a direct, fn-wrapped, or service-operation emission ran
    during teardown. A bracket inverse replays on clean unload AND on abort,
    at or after the session verdict, so a crossing there is unanswerable: it is
    invisible to the emission fold, to the capability declarations, and to the
    246 approval gate, and it cannot be rolled back. The same walk, the same
    bound, at the second slot that has one.

    Inert for every inverse that reaches no boundary (`p.close()`, a pure fn),
    so a program with an honest teardown is byte-identical."""
    if undo_expr is None:
        return
    extern_class = getattr(env, "extern_class", None) or {}
    emitting = getattr(env, "emitting_fns", None) or set()
    witness = getattr(getattr(env, "emission_evidence", None), "witness", None) or {}

    def _refuse(node, name, terminal, chain):
        kind = "itself witnessed" if terminal == "witnessed" else "an emission"
        if len(chain) > 1:
            reached = chain[-1]
            path = " -> ".join(chain)
            message = (f"the `{slot}` of this bracket calls `{name}`, a fn that "
                       f"reaches {kind} `{reached}` (through {path}) — a bracket "
                       f"inverse runs in teardown and may not cross a boundary "
                       f"(G5)")
        else:
            message = (f"the `{slot}` of this bracket calls `{name}`, which is "
                       f"{kind} — a bracket inverse runs in teardown and may not "
                       f"cross a boundary (G5)")
        raise RevlError(
            filename, getattr(node, "line", 0) or line, message,
            hint="a bracket inverse replays on clean unload and on abort, at or "
                 "after the session verdict, so a crossing there is unanswerable "
                 "and invisible to the emission fold and the approval gate; keep "
                 "the inverse a host-local release, and move the crossing into "
                 "the forward path (an `emit`) or a `compensate` slot, which is "
                 "the audit surface that MAY emit in teardown "
                 "(docs/design/teardown-contract.md)",
            code="G5", category="teardown")

    def _refuse_opaque(node, name):
        raise RevlError(
            filename, getattr(node, "line", 0) or line,
            f"the `{slot}` of this bracket calls `{name}`, a function VALUE "
            f"this scope cannot resolve — teardown may not dispatch through an "
            f"indirection whose reach is unknown (G5)",
            hint="a bracket inverse must be a host-local release the checker "
                 "can bound; a call through a function-typed parameter or an "
                 "out-of-scope binding hides whatever it dispatches to, "
                 "including a boundary crossing. Name the release directly "
                 "(`h.close()`), or move the indirection into the forward path "
                 "(docs/design/teardown-contract.md)",
            code="G5", category="teardown")

    _walk_inverse_emissions(undo_expr, extern_class, emitting, witness,
                            refuse=_refuse, env=env, refuse_opaque=_refuse_opaque)


def _check_criterion_readonly(body_stmts, kind: str, op_name: str, svc_name: str,
                              env, filename: str, line: int) -> None:
    """L1 (roadmap item 441 / issue #120,
    docs/design/458-termination-language-surface.md §3): a termination criterion
    or guard body reaches NO emission and NO witnessed extern.

    A criterion is the agent's honest READING of whether the goal is met; if its
    body could cross a boundary it could cause its own satisfaction — 441's C1,
    "a criterion that causes its own satisfaction". The rule is exactly 243 rule 3
    for a witnessed inverse (an emission may not run in teardown) applied to a new
    body: the SAME teardown-slot walker `_walk_inverse_emissions` resolves the six
    shapes that reach a boundary (a direct `emission`/`witnessed` extern, a plain
    `fn` transitively reaching one, an `emission` service operation off a required
    binding, a spawn-handle provision op, a first-class arrow, a first-class
    reference), so this is a THIRD caller of an already-shared walk that supplies
    only the criterion-naming diagnostic.

    Runs BEFORE the G4 provider upper-bound check (`_method_emissions`) so a
    criterion reaching an emission is refused as a criterion (naming the marked
    operation) rather than as a plain provider, and — unlike G4 — it also refuses
    a WITNESSED extern, which a provide-method body is otherwise allowed to reach
    (item 318). Inert for a criterion whose body is pure or only `acquire`s, so a
    read-only criterion compiles unchanged.

    Filed under G6 (purity outside effect forms): a criterion body is not an
    effect form."""
    extern_class = getattr(env, "extern_class", None) or {}
    emitting = getattr(env, "emitting_fns", None) or set()
    witness = getattr(getattr(env, "emission_evidence", None), "witness", None) or {}

    def _refuse(node, name, terminal, chain):
        crossing = "itself witnessed" if terminal == "witnessed" else "an emission"
        if len(chain) > 1:
            reached = chain[-1]
            path = " -> ".join(chain)
            message = (
                f"the termination {kind} `{svc_name}.{op_name}` calls `{name}`, a "
                f"fn that reaches {crossing} `{reached}` (through {path}) — a "
                f"{kind} may only READ the world (L1)")
        else:
            message = (
                f"the termination {kind} `{svc_name}.{op_name}` reaches {crossing} "
                f"`{name}` — a {kind} may only READ the world (L1)")
        raise RevlError(
            filename, getattr(node, "line", 0) or line, message,
            hint=f"a {kind} is the agent's honest reading of whether the goal is "
                 f"met; if its body could cross a boundary it could cause its own "
                 f"satisfaction (441 C1). Move the crossing into the forward path "
                 f"and let the {kind} observe its RESULT "
                 f"(docs/design/458-termination-language-surface.md §3)",
            code="L1", category="termination")

    for st in body_stmts:
        _walk_inverse_emissions(st, extern_class, emitting, witness,
                                refuse=_refuse, env=env)


def _check_witnessed_inverse(decl, extern_class: dict, emitting_fns: set,
                             emitting_witness: dict, filename: str) -> None:
    """Rule 3 (docs/design/243-witnessed-externs.md): a witnessed extern's
    declared inverse must be classified **non-emission AND non-witnessed**.

    An emission inverse would cross a one-way boundary during teardown — the
    exact thing G5's no-emission-in-undo forbids, and it degrades a proof-grade
    rollback into best-effort residue. A witnessed inverse is infinite regress:
    its own inverse would need registering, and so on. The declared inverse is
    a host-LOCAL restore, so only `pure`/`acquire` callees are admissible.

    `undo some_emission(result)` passes `_check_extern_undo` today (the shared
    `mode="undo"` machinery only checks the callee is *declared*), so this walk
    is the explicit close: every extern a witnessed `undo` calls is held to the
    rule, which also fences the latent acquire hole the same expression opens.

    The extern-name check alone was an escape (the 330->329-transitive shape on
    the teardown path): a callee that is a plain top-level `fn` is not in
    `extern_class`, so it passed, yet a `fn` body may itself reach an emission
    (a legal emitting fn), so the emission still fires on abort, invisible to
    every fold and the approval gate. `emitting_fns` is the emission-reach fixed
    point over the fn call graph (emission_analysis.py): a fn is in it iff its
    call transitively reaches an `emission`/`witnessed` extern. Refusing a
    callee found there follows fn calls transitively, so a fn-wrapped emission in
    an inverse is refused exactly like a direct one. `compensate` is walked
    alongside `undo` so the same escape cannot open on that slot when a backend
    wires it. A pure/local fn (no emission reach) is in neither table and still
    passes.

    The walk itself now lives in `_walk_inverse_emissions`, shared with the SITE
    inverse check (`_check_site_inverse_emission`) so the two teardown slots
    cannot drift apart; this function supplies only the rule-3 phrasing. A
    declared inverse is checked with no `env`: an extern declaration requires no
    services, so there is no service-operation arm to read."""

    def _refuse(node, name, terminal, chain):
        kind = "itself witnessed" if terminal == "witnessed" else "an emission"
        if len(chain) > 1:
            # a plain top-level `fn` whose body transitively reaches an
            # emission: the same boundary crossing as a direct emission
            # inverse, one `fn` indirection later. Name the reached
            # boundary and the fn path so the author reads the derivation.
            reached = chain[-1]
            path = " -> ".join(chain)
            raise RevlError(
                filename, node.line,
                f"the inverse of witnessed extern `{decl.name}` calls "
                f"`{name}`, a fn that reaches {kind} `{reached}` "
                f"(through {path}), so a witnessed inverse must be a "
                f"host-local restore (G5)",
                hint="emissions are one-way boundary crossings and may "
                     "not run in teardown, even through a fn wrapper "
                     "(G5); declare the inverse `pure` or `acquire`, or "
                     "route no emission through it "
                     "(docs/design/243-witnessed-externs.md)",
                code="G5", category="witnessed",
            )
        why = ("emissions are one-way boundary crossings and may not "
               "run in teardown (G5)" if terminal == "emission"
               else "a witnessed inverse would need its own inverse "
                    "registered — infinite regress")
        raise RevlError(
            filename, node.line,
            f"the inverse of witnessed extern `{decl.name}` calls "
            f"`{name}`, which is {kind} — a witnessed inverse must be "
            f"a host-local restore (G5)",
            hint=f"{why}; declare the inverse `pure` or `acquire` "
                 f"(docs/design/243-witnessed-externs.md)",
            code="G5", category="witnessed",
        )

    _walk_inverse_emissions(decl.undo, extern_class, emitting_fns,
                            emitting_witness, refuse=_refuse)
    if decl.compensate is not None:
        _walk_inverse_emissions(decl.compensate, extern_class, emitting_fns,
                                emitting_witness, refuse=_refuse)


# item 309: the idempotency register order (design §2, §"question 4"). The
# register set is exactly `{declared, keyed, read}`. `declared` (a trust-me
# claim) is the floor; `keyed` (dedup-by-construction on a named key) is the
# strong emission register. The 290 `requires register <level>` and 309
# `requires idempotent-teardown(strength)` policies read this order.
# `strong` is a policy FLOOR level only (never an actual IR register): it means
# "any register above the trust-me floor", so it ranks with `keyed` at 1.
# item 440 adds the third tier, `read`, at the TOP of the order: a call that
# changes nothing is re-dispatchable with no key, no fence and no reconciliation,
# which is strictly stronger than dedup-by-key. Only `undo pure` produces it.
# item 207 REMOVED a fourth name, `shape-proven`, which sat here as a peer of
# `keyed` for a check nothing ever ran. See `_idempotent_register` below for why
# the check cannot be written against today's language, and
# `docs/design/207-checkable-extern-body.md` for why the name's absence changes
# no verdict: its designed provenance was an inverse BODY, and every set that
# accepted it grades a forward EMISSION.
_REGISTER_RANK = {"declared": 0, "keyed": 1, "strong": 1, "read": 2}

#: item 440: the registers a fresh-process `recover` may RE-DISPATCH without
#: spending a fence and without escalating to an operator. `read` because the
#: call changes nothing (there is no outcome to be ambiguous about); `keyed`
#: because a second issue is dedup-safe by construction. Every other register —
#: and, crucially, NO register at all — stays fenced.
REDISPATCH_FREE = frozenset({"read", "keyed"})


def _idempotent_register(decl) -> str:
    """The honesty register for `decl`'s idempotency claim (design §2).

    A keyed emission is dedup-safe BY CONSTRUCTION (`keyed`). Every other claim
    (a bare `idempotent` emission, an `undo idempotent` over a host body) is the
    author's `declared` claim, machine-checked only for shape.

    Item 309 slice 4 proposed a fourth register, `shape-proven`, for an inverse
    whose body PASSES a syntactic check (design §2: "every write is
    `set(target, w.field)`, no reads of current state, no deltas, no appends"),
    which is last-writer-wins and therefore idempotent by construction. Item 207
    deleted the name; this function is where the reasons live, because this is
    the function that would have produced it.

    First, the check cannot be written: running it needs a body the checker can
    READ, and there is none.

    * An extern has only HOST bodies. `parser.py::_extern` refuses a declaration
      with no `@backend { ... }` (or `file`/`ref`) body, so every extern body is
      G8-opaque by construction — the exact thing the design's own ledger row
      says revl "cannot prove anything about".
    * The undo SLOT holds an expression, not a body, and every world-touching
      leaf of that expression is a call to another extern. `stdlib/fs.rvl`'s
      inverses are the first-party case the design named as the prerequisite, and
      they are `@py` blocks: 244 landed the revl-expressed CATALOG, not
      revl-expressed bodies. So the prerequisite is not met by 244 and is not
      met by anything else in the tree.
    * The classification cannot stand in for the body. `pure` is checked for
      SHAPE only — the same trap item 440 recorded for the `read` tier — and
      `stdlib/fs.rvl` proves it concretely: `restore`, `unrm` and
      `rmdir_if_empty` are all `extern pure fn` and all unlink or rename real
      files. Deriving `shape-proven` from `pure` would promote mutating inverses
      into the free-replay tier, which is unsound in the unsafe direction.
    * Even GIVEN a revl body, those same fs inverses would FAIL the design's
      shape rule: each branches on `lexists_confined(...)`, which is a read of
      current state, and the rule excludes exactly that. So the first adopters
      would not have earned the tier anyway.

    So this function returns `declared` for every native `undo idempotent` body,
    which is the fail-closed direction the whole lattice is built on: on any
    ambiguity, fall back to the weaker claim.

    Second, and this is why item 207 deleted the name rather than leaving it
    parked: the tier would not have bought a verdict even fully built. Its
    provenance is an inverse BODY, and the register field is provenance-disjoint
    by classification — `idempotent` is emission-only and an emission cannot
    declare `undo` — so an inverse-family register can never appear on the owed
    DEFERRED EMISSION that `REDISPATCH_FREE`, the audit's `owed-emission` branch
    and the Temporal backend's `_RETRY_EARNING_REGISTERS` all grade. And in the
    one consumer that does read an inverse's register,
    `recovery.py::_replay_tier`, a shape-proven inverse and a declared-idempotent
    one both replay `free`. `tests/test_207_checkable_extern_body.py` asserts
    each of those structurally, and is the tripwire that fails if a future change
    makes them false.

    The gap underneath the proposal is real and NOT closed by the deletion: no
    local MUTATING inverse can reach a strong policy floor, because `keyed` is
    emission-only and `read` requires the inverse to change nothing. The answer
    to that already ships and needs no language change — pair the register floor
    with an evidence floor, `capability fs requires register declared` plus
    `requires evidence [inverse-roundtrip pass, attestation valid]`, which runs
    309's own value-aware double-undo against the real `@py` body and catches a
    lying declaration. A syntactic shape rule could not: it grades declared leaf
    algebras rather than behaviour, and its own "no reads of current state" rule
    rejects all four of `stdlib/fs.rvl`'s inverses, each of which branches on
    `lexists_confined`. See `docs/crash-recovery.md` §4b and
    `docs/design/207-checkable-extern-body.md`.

    item 440: `undo pure <inverse>(result)` is the READ tier — the author states
    the inverse OBSERVES and does not mutate, so re-issuing it is observationally
    free. It outranks `keyed`: a keyed call still crosses (and leans on a remote's
    dedup contract), a read crosses nothing at all."""
    if decl.undo_read:
        return "read"
    if decl.idempotency_key is not None:
        return "keyed"
    return "declared"


def _register_satisfies(actual: str | None, floor: str) -> bool:
    """True when the register `actual` meets or exceeds the policy `floor` under
    309's order. `None` (no idempotency claim) never satisfies a floor. The floor
    names a MINIMUM rank, so `strong` and `keyed` are interchangeable at rank 1
    and 440's `read` satisfies both."""
    if actual is None:
        return False
    return _REGISTER_RANK.get(actual, -1) >= _REGISTER_RANK.get(floor, 0)


def _undo_callee_name(expr) -> str | None:
    """The name an extern `undo`/`compensate` slot's top-level call names, or
    None when the slot is not a plain call to a bare name (item 440).

    Only used to hold an `undo pure` claim to a `pure`-classified callee; every
    other shape falls through to the refusal, which is the fail-closed direction
    (an unresolvable inverse never earns the read tier)."""
    from .parser import ExprCall, ExprVar
    if isinstance(expr, ExprCall) and isinstance(expr.callee, ExprVar):
        return expr.callee.name
    if isinstance(expr, ExprVar):
        return expr.name
    return None


def _witnessed_extern_names(program: Program) -> set[str]:
    """Names of every `witnessed`-classified extern declared in *program*
    (docs/design/243-witnessed-externs.md). Shared by the effect-position
    refusal (rule 1) below and the call-site transactional lowering
    (Slice 2, `_lower_component`)."""
    return {ext.name for ext in program.externs if ext.classification == "witnessed"}


def _refuse_effect_position_bound_externs_in_fn_body(
        program: Program, filename: str) -> None:
    """One walk over every `fn`/`test` body, refusing the three extern kinds
    whose effect machinery exists only in effect position — a bare call from a
    plain fn/test body would silently drop it:

    * `witnessed` (rule 1, docs/design/243-witnessed-externs.md): the teardown
      accumulator that auto-registers the declared inverse exists only in a
      component activation; a fn/test body has none, so the mutation would be
      irreversible — the one outcome the classification exists to prevent.
    * `acquire` with an `undo` (item 399): the same accumulator would auto-
      register that `undo`; without it the acquisition is silently irreversible.
    * a `deferred` emission (item 400): a fn/test body has no session commit for
      the deferral to fire at, so it fires immediately, bypassing the commit
      queue (`deferred` fires at commit; an abort drops the queue, item 245).

    Every extern is otherwise callable from a fn/test body (they seed the
    `callables` set), so these are explicit refusals, checked over the author's
    AST where the call site still has a line.

    These were three sequential passes, each re-walking the identical set of
    fn/test bodies (P-9, #543). Folded into one traversal here. Diagnostic order
    is preserved verbatim: the walk records the FIRST violation of each kind (in
    the same fn-then-test, definition-order recursion the passes used) and then
    reports them witnessed-before-(acquire/deferred) — exactly what running the
    witnessed pass to completion before the teardown pass produced. An extern
    carries one classification, so the `witnessed` and `acquire` sets are
    disjoint; `acquire` is checked before `deferred`, matching the original
    first-`if`-raises order."""
    from .parser import ExprCall, ExprVar

    witnessed = _witnessed_extern_names(program)
    acquire_undo = {
        ext.name for ext in program.externs
        if ext.classification == "acquire" and ext.undo is not None}
    deferred = {ext.name for ext in program.externs if ext.deferred}
    if not witnessed and not acquire_undo and not deferred:
        return

    first_witnessed: RevlError | None = None
    first_teardown: RevlError | None = None

    def _walk(node, where: str):
        nonlocal first_witnessed, first_teardown
        if isinstance(node, ExprCall) and isinstance(node.callee, ExprVar):
            name = node.callee.name
            if first_witnessed is None and name in witnessed:
                first_witnessed = RevlError(
                    filename, node.line,
                    f"witnessed extern `{name}` cannot be called in {where} "
                    f"— a witnessed mutation is only valid in effect position (G4)",
                    hint="its declared inverse is auto-registered by the teardown "
                         "accumulator, which exists only in a component activation; a "
                         "fn/test body has none, so the mutation would be irreversible "
                         "(docs/design/243-witnessed-externs.md)",
                    code="G4", category="witnessed",
                )
            elif first_teardown is None and name in acquire_undo:
                first_teardown = RevlError(
                    filename, node.line,
                    f"`acquire` extern `{name}` cannot be called in {where}; its "
                    f"declared `undo` teardown would be dropped, leaving the "
                    f"acquisition irreversible (G4)",
                    hint="an `acquire` extern's `undo` is auto-registered by the "
                         "teardown accumulator, which exists only in a component "
                         "activation or provide-method body; call it from there so "
                         "the teardown can run (docs/design/243-witnessed-"
                         "externs.md)",
                    code="G4", category="acquire",
                )
            elif first_teardown is None and name in deferred:
                first_teardown = RevlError(
                    filename, node.line,
                    f"`deferred` emission extern `{name}` cannot be called in "
                    f"{where}; a fn/test body has no session commit for the "
                    f"deferral to fire at (G4)",
                    hint="a deferred emission enqueues onto the session deferral "
                         "queue and fires at commit; that queue exists only inside "
                         "a component activation or provide-method body, so call it "
                         "from there (docs/design/245-session-commit.md)",
                    code="G4", category="deferred",
                )
        if hasattr(node, "__dataclass_fields__"):
            for f in type(node).__dataclass_fields__:
                _walk(getattr(node, f), where)
        elif isinstance(node, (list, tuple)):
            for x in node:
                _walk(x, where)

    for fn in program.fn_decls:
        for stmt in fn.body:
            _walk(stmt, f"the body of fn `{fn.name}`")
    for test in program.tests:
        for stmt in test.body:
            _walk(stmt, f"the body of test `{test.name}`")

    if first_witnessed is not None:
        raise first_witnessed
    if first_teardown is not None:
        raise first_teardown


def _refuse_host_acquire_in_component_reachable_fn(program: Program, filename: str) -> None:
    """A host acquire verb (`Pool.open`, `Map.new`, `Stream.source`) in a `fn`
    body a COMPONENT can reach, refused (G4).

    A `fn` body has no acquisition bracket, so the release verb is never
    registered anywhere. What makes that a soundness break rather than a style
    question is the caller: a component activation PROMISES no residue — the
    teardown accumulator runs every registered inverse on unload and on abort,
    and `assert no_residue` is a proof obligation the runtime checks. A helper
    the activation calls acquires inside that promise while contributing
    nothing to it, so the activation tears down clean and the pool stays open
    (`pool#1 (open() with no close())`, R1) on a program the checker admitted.

    The reach qualifier is the invariant, not a carve-out. Residue is defined
    against an activation; a `pub fn` no component reaches is a library entry
    point whose lifecycle belongs to the foreign caller that invoked it (the
    java scenario corpus drives exactly such functions from a JVM harness),
    and revl promises nothing about it. So the rule is: inside the promise, a
    host acquisition must be bracketed; outside it, there is no promise to
    break.

    The COMPONENT-stratum positions of the same rule (a provide-method `let`,
    an `undo`/`compensate` slot, an `emit` expression) are refused where they
    lower, by `_refuse_unbracketed_host_acquire`. This pass exists because a fn
    body is lowered without knowing who calls it.
    """
    from .parser import ExprCall, ExprField, ExprVar

    fns = {fn.name: fn for fn in program.fn_decls}
    if not fns:
        return

    def _named_calls(node, out: set) -> None:
        if isinstance(node, ExprCall) and isinstance(node.callee, ExprVar):
            out.add(node.callee.name)
        if hasattr(node, "__dataclass_fields__"):
            for f in type(node).__dataclass_fields__:
                _named_calls(getattr(node, f), out)
        elif isinstance(node, (list, tuple)):
            for x in node:
                _named_calls(x, out)

    # seed: every fn a component body names, directly
    reached: set = set()
    frontier: set = set()
    for comp in program.components:
        _named_calls(comp.body, frontier)
    frontier &= set(fns)
    # ... closed over the fn call graph, so a two-hop helper is reached too
    while frontier:
        name = frontier.pop()
        if name in reached:
            continue
        reached.add(name)
        callees: set = set()
        _named_calls(fns[name].body, callees)
        frontier |= (callees & set(fns)) - reached

    def _scan(node, fn_name: str) -> None:
        if isinstance(node, ExprCall) and isinstance(node.callee, ExprField) \
                and isinstance(node.callee.target, ExprVar):
            dotted = f"{node.callee.target.name}.{node.callee.name}"
            if dotted in _HOST_ACQUIRE_VERBS:
                _refuse_unbracketed_host_acquire(
                    node.callee.target.name, node.callee.name,
                    f"`fn {fn_name}`, which a component body reaches",
                    filename, node.line)
        if hasattr(node, "__dataclass_fields__"):
            for f in type(node).__dataclass_fields__:
                _scan(getattr(node, f), fn_name)
        elif isinstance(node, (list, tuple)):
            for x in node:
                _scan(x, fn_name)

    for name in sorted(reached):
        _scan(fns[name].body, name)


def _validated_response_schema(name: str, returns: str | None, is_emission: bool,
                               types: dict, filename: str, line: int,
                               kind_word: str) -> dict:
    """Item 257 (§2, §3): check a `validated` emission and derive its boundary
    schema, refusing at COMPILE TIME when the response type is not fully
    expressible.

    Two surface rules (the same place the sibling modifier-validity rules live):
    `validated` is EMISSION-ONLY (a `pure`/`acquire`/`witnessed` classification
    has no response to validate at a one-way boundary), and a validated emission
    must declare a NON-`Unit` return type (there is nothing to validate
    otherwise). Then the return type must be `fully_expressible` (§3.3), derived
    on the QUALIFIER-STRIPPED type (§3.1, HIGH-2) so the secure default spelling
    `-> Untrusted[AgentTurn] validated` derives the same union as
    `-> AgentTurn validated`. `extract_and_normalize` already strips the
    qualifier in place before lowering; `strip_qualifiers` here is idempotent and
    makes the derivation self-documenting and order-robust.
    """
    if not is_emission:
        raise RevlError(
            filename, line,
            f"`validated` {kind_word} `{name}` is not an emission",
            hint="`validated` opts a boundary crossing into response validation, "
                 "so it is emission-only: a pure/acquire/witnessed classification "
                 "has no one-way response to validate "
                 "(docs/design/257-typed-model-boundary.md, §2)",
            code="G4", category="validated")
    stripped = strip_qualifiers(returns)
    if not stripped or stripped == "Unit":
        raise RevlError(
            filename, line,
            f"`validated` emission `{name}` must declare a non-`Unit` return type",
            hint="a validated emission validates its RESPONSE against a schema "
                 "derived from the return type; a `Unit` (or absent) return has "
                 "nothing to validate (§2)",
            code="G4", category="validated")
    if not fully_expressible(stripped, types):
        reason = expressibility_reason(stripped, types) or "is not expressible"
        raise RevlError(
            filename, line,
            f"`validated` emission `{name}` has response type `{stripped}`, which "
            f"{reason}",
            hint="a validating boundary refuses a response type it cannot derive an "
                 "EXACT schema for (an unconstrained or ambiguous schema validates "
                 "nothing while reading as safe). Refuse it at compile time rather "
                 "than ship a vacuous guarantee "
                 "(docs/design/257-typed-model-boundary.md, §3.3)",
            code="G4", category="validated")
    schema = json_schema_for(stripped, types, validated=True)
    # Defense in depth (§3.3): the `fully_expressible` predicate already accepted
    # this type, so the renderer must leave no unconstrained `x-revlType` stub. A
    # firing here means the predicate and the renderer have drifted (a renderer
    # bug), caught loudly rather than shipping an unconstrained boundary.
    if has_revl_stub(schema):
        raise RevlError(
            filename, line,
            f"internal: `validated` emission `{name}` derived an unconstrained "
            f"schema for `{stripped}` despite passing the expressibility gate "
            f"(renderer/predicate drift, item 257 §3.3)")
    return schema


def _validated_retry_ir(name: str, validated: bool, retry: int, filename: str,
                        line: int, kind_word: str) -> dict:
    """Item 257 (Slice 2, §5.2): the additive `retry` IR key for a `validated`
    emission's validation-retry budget, or `{}` (byte-identical) when no `retry`
    clause was written (budget 0, one attempt).

    `retry N` is legal ONLY alongside `validated`: there is no validation fault to
    re-issue on a non-`validated` emission, and it must never ride item 44's
    idempotent-delivery path (a completion is not idempotent, §5.1). A `retry`
    without `validated` is refused here, the same place the sibling
    modifier-validity rules live."""
    if retry <= 0:
        return {}
    if not validated:
        raise RevlError(
            filename, line,
            f"`retry` {kind_word} `{name}` is not `validated`",
            hint="`retry N` sets the VALIDATION-retry budget of a `validated` "
                 "emission (re-issue the completion on a malformed response, §5.2); "
                 "without `validated` there is no validation fault to retry. It is "
                 "NOT item 44's idempotent-delivery retry — a completion is a read "
                 "with a cost, not an idempotent write "
                 "(docs/design/257-typed-model-boundary.md, §5.1)",
            code="G4", category="validated")
    return {"retry": retry}


def _method_validated_ir(m, types: dict, filename: str) -> dict:
    """Item 257: the additive `validated` + `response_schema` (+ Slice 2 `retry`)
    IR keys for a service-method emission, or `{}` (byte-identical) when the method
    is neither `validated` nor carries a `retry` clause. Refuses an unexpressible
    return type, and a `retry` without `validated`, at compile time. `m.returns` is
    already qualifier-stripped in place by `extract_and_normalize`."""
    retry_ir = _validated_retry_ir(
        m.name, getattr(m, "validated", False), getattr(m, "retry", 0),
        filename, m.line, "operation")
    if not getattr(m, "validated", False):
        return {}
    schema = _validated_response_schema(
        m.name, m.returns, m.emission, types, filename, m.line, "operation")
    return {"validated": True, "response_schema": schema, **retry_ir}


# ------------------------------------------------------------ item 457: routes

#: the scalar surface types a path segment or a query parameter may bind to. A
#: path template `{name}` is a single URL segment, and a query value is a single
#: string field, so both are limited to the JSON scalars a boundary can carry as
#: text (docs/design/457-endpoint-one-definition.md, "Binding rules").
_ROUTE_SCALARS = ("Str", "Int", "Bool")

#: the six HTTP verbs the `route` clause admits — exactly `stdlib/http.rvl`'s
#: `Method` variant (`method_str`), so the derived route table and the typed
#: `Request.method` cannot disagree. `get`/`head`/`delete` are the SAFE-shaped
#: verbs whose remaining parameters bind from the query string; `post`/`put`/
#: `patch` take a single record body.
_ROUTE_METHODS = ("get", "post", "put", "patch", "delete", "head")
_ROUTE_QUERY_METHODS = ("get", "head", "delete")
_ROUTE_BODY_METHODS = ("post", "put", "patch")


def _route_scalar(type_name: str | None) -> bool:
    return type_name in _ROUTE_SCALARS


def _route_opt_scalar(type_name: str | None) -> str | None:
    """The inner scalar of `Opt[scalar]`, or `None` when `type_name` is not one."""
    head, args = _schema_parse_type(type_name)
    if head == "Opt" and len(args) == 1 and _route_scalar(args[0]):
        return args[0]
    return None


def _route_template_names(path: str) -> list[str]:
    """The `{name}` placeholders of a path template, in order. Raises on a
    malformed placeholder (empty or non-identifier)."""
    names: list[str] = []
    for match in re.finditer(r"\{([^{}]*)\}", path):
        names.append(match.group(1))
    return names


def _method_route_ir(m, types: dict, filename: str, service_name: str) -> dict:
    """Item 457: the additive `route` IR key for a service operation that heads a
    `route <method> "<path>"` clause, or `{}` (byte-identical) when it does not.

    Resolves the bind table (docs/design/457-endpoint-one-definition.md,
    "Binding rules") by parameter TYPE and NAME, and the return rules, refusing at
    COMPILE TIME — naming the operation and the parameter — anything the
    projection cannot express deterministically:

      * a path `{name}` that is not a scalar parameter, or a scalar parameter the
        template does not name;
      * a `Bearer` / `Request` parameter appearing more than once;
      * a non-scalar / non-`Opt[scalar]` query parameter on a safe verb;
      * anything other than exactly one record body on an unsafe verb;
      * a body / query / path type that is not `fully_expressible` (item 257);
      * a `Result[T, E]` return whose `E` is not `ApiError`.

    The result is `{"route": {"method", "path", "bind", "response", ["auth"]}}`.
    """
    route = getattr(m, "route", None)
    if not route:
        return {}
    method = route["method"]
    path = route["path"]
    line = route.get("line", m.line)
    where = f"routed operation `{service_name}.{m.name}`"

    def refuse(message: str, hint: str | None = None):
        raise RevlError(filename, line, message, hint=hint,
                        code="G4", category="route")

    try:
        template = _route_template_names(path)
    except ValueError:
        template = []
    for tname in template:
        if not tname.isidentifier():
            refuse(f"{where} has a malformed path placeholder `{{{tname}}}`",
                   hint='a placeholder names a scalar parameter, e.g. `"/notes/{id}"`')

    params = list(m.params)  # (name, type)
    by_name = dict(params)
    template_set = set(template)

    # every template name must be a scalar parameter
    for tname in template:
        if tname not in by_name:
            refuse(f"{where} names `{{{tname}}}` in its path, but has no "
                   f"parameter `{tname}` to bind it from",
                   hint="every path placeholder must be a parameter of the "
                        "operation")
        if not _route_scalar(by_name[tname]):
            refuse(f"{where} binds path parameter `{tname}` of type "
                   f"`{by_name[tname]}`, which is not a scalar",
                   hint="a path segment binds a `Str`, `Int` or `Bool` only")

    bind: dict[str, dict] = {}
    body_params: list[str] = []
    bearer_params: list[str] = []
    request_params: list[str] = []
    for pname, ptype in params:
        if pname in template_set:
            bind[pname] = {"kind": "path", "type": ptype}
            continue
        if ptype == "Bearer":
            bearer_params.append(pname)
            bind[pname] = {"kind": "header", "type": ptype}
            continue
        if ptype == "Request":
            request_params.append(pname)
            bind[pname] = {"kind": "request", "type": ptype}
            continue
        if method in _ROUTE_QUERY_METHODS:
            if not (_route_scalar(ptype) or _route_opt_scalar(ptype)):
                refuse(f"{where} binds query parameter `{pname}` of type "
                       f"`{ptype}`, which is not a scalar or `Opt[scalar]`",
                       hint=f"a `{method}` request has no body, so each remaining "
                            "parameter binds from the query string and must be a "
                            "`Str`/`Int`/`Bool` or an `Opt` of one")
            bind[pname] = {"kind": "query", "type": ptype}
        else:
            body_params.append(pname)
            bind[pname] = {"kind": "body", "type": ptype}

    if len(bearer_params) > 1:
        refuse(f"{where} declares {len(bearer_params)} `Bearer` parameters "
               f"({', '.join(bearer_params)}); a route carries at most one",
               hint="the bearer credential binds from the single `Authorization` "
                    "header")
    if len(request_params) > 1:
        refuse(f"{where} declares {len(request_params)} `Request` parameters "
               f"({', '.join(request_params)}); a route carries at most one")

    if method in _ROUTE_BODY_METHODS:
        if len(body_params) > 1:
            refuse(f"{where} has {len(body_params)} body candidates "
                   f"({', '.join(body_params)}); give the body one record type",
                   hint=f"a `{method}` request has exactly one JSON body")
        for pname in body_params:
            ptype = by_name[pname]
            spec = types.get(ptype)
            if not spec or spec.get("kind") != "record":
                refuse(f"{where} binds body parameter `{pname}` of type "
                       f"`{ptype}`, which is not a record type",
                       hint="the request body IS one record; declare the body "
                            "parameter with a record type")

    # every non-path scalar/body/query type must be fully expressible so the
    # boundary can validate it (item 257 §3.3) — refuse, never a vacuous schema.
    for pname, entry in bind.items():
        if entry["kind"] in ("path", "query", "body"):
            ptype = strip_qualifiers(entry["type"])
            # a bare `Opt[scalar]` query is expressible via its inner scalar
            check_type = _route_opt_scalar(ptype) or ptype
            if entry["kind"] == "query" and _route_opt_scalar(ptype):
                entry["optional"] = True
                check_type = _route_opt_scalar(ptype)
            if not fully_expressible(check_type, types):
                reason = expressibility_reason(check_type, types) \
                    or "is not expressible"
                refuse(f"{where} binds `{pname}` to `{entry['type']}`, which "
                       f"{reason}",
                       hint="a routed boundary validates every bound input against "
                            "an EXACT derived schema; refuse an unexpressible type "
                            "at compile time (item 257 §3.3)")
            entry["schema"] = json_schema_for(check_type, types, validated=True)

    response = _route_response_ir(m.returns, types, refuse, where)

    route_ir = {"method": method, "path": path, "bind": bind,
                "response": response}
    # item 457, the authorization HOOK (S1 shape): a `Bearer`-bearing operation
    # is marked so `revl export openapi` can carry a DOCUMENTATION-ONLY
    # `x-revl-auth: bearer` marker and NO `security` requirement. Authorization
    # itself is never in the clause — it is the explicit `auth.validate` step the
    # handler makes on the required `Auth` service, whose `Principal` result is
    # the only key to user data. The `Principal`/`Auth` machinery (and the
    # admission refusal for a handler that skips the step) is S2; this marker is
    # the forward-compatible slot it fills, carrying no grant of its own.
    if bearer_params:
        route_ir["auth"] = "bearer"
    return {"route": route_ir}


def _route_response_ir(returns: str | None, types: dict, refuse, where: str) -> dict:
    """The return-rule classification for a routed operation
    (docs/design/457-endpoint-one-definition.md, "Return rules").

    `T` -> `{"kind": "plain", "type": T}` (200, or 204 for `Unit`);
    `Result[T, ApiError]` -> `{"kind": "result", "ok": T}` (Ok 200, Err status);
    `Response` -> `{"kind": "response"}` (the handler owns the wire).
    A `Result[T, E]` with `E != ApiError` is a compile refusal: an error a client
    can act on needs a status."""
    stripped = strip_qualifiers(returns) if returns else None
    if not stripped or stripped == "Unit":
        return {"kind": "plain", "type": "Unit"}
    if stripped == "Response":
        return {"kind": "response"}
    head, args = _schema_parse_type(stripped)
    if head == "Result" and len(args) == 2:
        ok_type, err_type = args
        if err_type != "ApiError":
            refuse(f"{where} returns `Result[{ok_type}, {err_type}]`, but an "
                   "error a client can act on needs a status",
                   hint="return `Result[T, ApiError]` (whose `Err` carries the "
                        "status/code/message) or a `Response` you build yourself")
        return {"kind": "result", "ok": ok_type}
    return {"kind": "plain", "type": stripped}


def _lower_externs(program: Program, filename: str, types: dict,
                   fns: list | None = None) -> list:
    externs: list[dict] = []
    # name -> first declaring file, so a cross-module duplicate names BOTH files
    # (roadmap 394), same as `_lower_fns`. Externs carry provenance in
    # `program.decl_files` (they have no `.source` field of their own).
    seen: dict[str, str] = {}
    # classification of every extern by name, so a declared inverse can be held
    # to the "non-emission AND non-witnessed" rule (docs/design/243 rule 3): an
    # inverse that itself emits crosses a one-way boundary in teardown (G5), and
    # a witnessed inverse is infinite regress. Built before the loop so an
    # inverse may name an extern declared later in the file.
    extern_class = {d.name: d.classification for d in program.externs}
    # G5 transitive teardown guard: a witnessed inverse that calls a plain `fn`
    # which itself reaches an emission is as much a teardown emission as a direct
    # one (the 330->329-transitive shape on the teardown path). Reuse the
    # emission-reach fixed point over the lowered fn bodies (emission_analysis.py),
    # seeded from the extern classifications, so `_check_witnessed_inverse` can
    # follow fn calls transitively instead of inspecting extern names only.
    # Computed once, lazily, and only when a witnessed extern actually declares an
    # inverse, so every other program stays byte-identical and pays nothing.
    _inverse_reach: dict = {}

    def _witnessed_inverse_reach():
        if not _inverse_reach:
            witness: dict[str, str] = {}
            extern_seed = [
                {"name": d.name, "class": d.classification,
                 "capabilities": list(d.capabilities or [])}
                for d in program.externs]
            reach = set(_emitting_capabilities(fns or [], extern_seed, witness))
            _inverse_reach["fns"] = reach
            _inverse_reach["witness"] = witness
        return _inverse_reach["fns"], _inverse_reach["witness"]
    # item 245: a deferred emission may not appear in any extern's teardown slot
    # (a whole-program check, so an `undo`/`compensate` naming a deferred extern
    # declared later in the file is still caught).
    _check_deferred_not_in_teardown(program, filename)
    for decl in program.externs:
        decl_file = program.decl_files.get(id(decl), filename)
        if decl.name in seen:
            first_file = seen[decl.name]
            if os.path.abspath(first_file) == os.path.abspath(decl_file):
                # a same-file re-declaration: keep the terse single-file message
                raise RevlError(decl_file, decl.line,
                                f"duplicate extern `{decl.name}`")
            raise RevlError(
                decl_file, decl.line,
                _duplicate_symbol_message("extern", decl.name,
                                          first_file, decl_file))
        seen[decl.name] = decl_file
        if decl.classification == "acquire" and decl.undo is None:
            raise RevlError(
                filename, decl.line,
                f"acquire extern `{decl.name}` must declare `undo` (G4)",
                hint="an `acquire` crosses into an observable effect and needs a teardown inverse",
            )
        # R0 (item 308): an `acquire` return must be a NOMINAL OPAQUE HANDLE
        # type. A primitive (`Int`) or a structural carrier (`Result[..]`,
        # `Opt[..]`, `List[..]`, a function type, a record literal) is refused
        # at the declaration. The acquire returns are the resource-taint base
        # (`resources.resource_base`); promoting that base into the frontend
        # ownership checks means the base must carry identity, and a primitive
        # cannot — `-> Int` would make every integer a borrowed handle and the
        # language unwritable (design doc 308, R0).
        if (decl.classification == "acquire" and decl.returns is not None
                and decl.returns not in NO_HANDLE_RETURNS
                and not acquire_return_is_nominal_handle(decl.returns)):
            from . import navigate as _nav  # noqa: PLC0415 — lazy, additive
            raise RevlError(
                filename, decl.line,
                f"acquire extern `{decl.name}` returns `{decl.returns}`, which is "
                f"not a nominal opaque handle type (item 308, R0)",
                hint="an `acquire` return is an owned resource handle whose "
                     "identity the ownership checks track; declare an opaque "
                     "handle type (a bare nominal like `LogHandle`) and return "
                     "that, not a primitive or a structural carrier "
                     "(`Result[..]`, `Opt[..]`, `List[..]`, a function type)",
                # R0 is unreachable under the untrusted-author profile (no_extern
                # refuses any extern declaration before lowering), so the trusted
                # view (profile=None) is the only one that can arise here.
                navigate=_nav.ownership_navigate(
                    kind="r0", returns=decl.returns,
                    handle_name=decl.name[:1].upper() + decl.name[1:],
                    profile=None),
            )
        if decl.classification == "pure" and (decl.undo is not None or decl.compensate is not None):
            raise RevlError(
                filename, decl.line,
                f"pure extern `{decl.name}` cannot declare `undo` or `compensate`",
                hint="`pure` means no observable effect, so there is nothing to invert or compensate",
            )
        if decl.classification == "emission" and decl.undo is not None:
            raise RevlError(
                filename, decl.line,
                f"emission extern `{decl.name}` cannot declare `undo`",
                hint="emissions are one-way boundary crossings; use `compensate` for a best-effort cleanup",
            )
        # item 440: `undo pure <inverse>(result)` — the READ tier of 309's
        # re-dispatch register. Two rules, checked here next to the sibling
        # teardown-slot rules:
        #   (1) `undo idempotent pure` is refused. They are DIFFERENT claims
        #       about one inverse ("running it twice leaves the world where once
        #       left it" vs "running it changes nothing at all"), and recovery
        #       must know which one it is trusting; silently preferring one would
        #       make the residue proof lie about its evidence.
        #   (2) the named inverse must itself be a `pure`-CLASSIFIED extern. This
        #       is what anchors the read claim to the classification revl already
        #       has, WITHOUT deriving the tier from it: `pure` is checked for
        #       shape only ("no observable effect" is the declaration's wording,
        #       never a proof), and shipped examples classify a mutating host
        #       body `pure` (`extern pure fn close_ledger(h)`, docs/guide-ai-
        #       agents.md), so a derived read tier would be unsound in the UNSAFE
        #       direction. Requiring both the classification and the explicit
        #       word keeps the claim reviewable in the diff.
        if decl.undo_read and decl.undo_idempotent:
            raise RevlError(
                filename, decl.line,
                f"extern `{decl.name}` declares both `undo idempotent` and "
                f"`undo pure` — pick one",
                hint="`undo idempotent` claims a SECOND run leaves the world "
                     "where the first left it; `undo pure` claims the inverse "
                     "changes nothing at all (the read tier). Recovery reports "
                     "which claim it replayed under, so it must be one claim "
                     "(item 440, docs/design/309-idempotent-inverse.md §3d)",
                code="G4", category="idempotent")
        if decl.undo_read:
            callee = _undo_callee_name(decl.undo)
            callee_class = extern_class.get(callee) if callee else None
            if callee_class != "pure":
                what = (f"`{callee}`, which is "
                        + (f"classified `{callee_class}`" if callee_class
                           else "not a declared `pure` extern")
                        if callee else "an expression that is not a plain call")
                raise RevlError(
                    filename, decl.line,
                    f"extern `{decl.name}` declares `undo pure`, but the inverse "
                    f"is {what}",
                    hint="the read tier says the inverse OBSERVES and does not "
                         "mutate, so recovery may re-dispatch it with no key, no "
                         "fence and no operator. The claim is anchored to the "
                         "`pure` classification: declare the inverse as `extern "
                         "pure fn ...`, or drop `pure` from the undo slot and "
                         "take the fenced tier (item 440)",
                    code="G4", category="idempotent")
        # item 246: `requires approval` gates a boundary CROSSING, and only an
        # `emission` extern crosses irreversibly. A witnessed extern is already
        # reversible (class a, auto-approved), a pure/acquire one crosses nothing,
        # so the clause is meaningless there — reject the claim, don't drop it.
        if decl.requires_approval and decl.classification != "emission":
            raise RevlError(
                filename, decl.line,
                f"`{decl.classification}` extern `{decl.name}` cannot declare "
                f"`requires approval`",
                hint="only an `emission` extern crosses irreversibly; a witnessed "
                     "extern is already revertible and a pure/acquire one crosses "
                     "no boundary, so there is nothing to gate (item 246)",
            )
        # item 373: the reach clause `emission(confined: <param>)` names what an
        # irreversible crossing is BOUNDED to, so `revl audit` can show the one
        # property a reviewer needs (the confinement) and `audit --diff` can flag
        # a weakening. Two rules, enforced here next to the sibling classification
        # checks:
        #   (1) reach is emission-only — a witnessed extern is already reversible,
        #       a pure/acquire one crosses no boundary, so "confined to" is
        #       meaningless there; reject the claim rather than drop it.
        #   (2) the confinement TARGET must name a real PARAMETER, not a literal
        #       the host body picks. This is the partial check that makes the
        #       otherwise trust-me reach honest-by-review: a host body that
        #       ignores the parameter and confines to a baked-in fallback is now a
        #       reviewable lie, and a reach naming a non-parameter fails to compile.
        if decl.reach is not None:
            reach_kind, reach_target = decl.reach
            if decl.classification != "emission":
                raise RevlError(
                    filename, decl.line,
                    f"`{decl.classification}` extern `{decl.name}` cannot declare a "
                    f"`({reach_kind}: ...)` reach clause",
                    hint="only an `emission` crosses irreversibly, so only an emission "
                         "is worth bounding; a witnessed extern is already revertible and "
                         "a pure/acquire one crosses no boundary (item 373)",
                )
            param_names = {p.name for p in decl.params}
            if reach_target not in param_names:
                params_list = ", ".join(sorted(param_names)) or "(none)"
                raise RevlError(
                    filename, decl.line,
                    f"emission `{decl.name}` is `confined: {reach_target}`, but "
                    f"`{reach_target}` is not one of its parameters ({params_list})",
                    hint="the confinement target must name a PARAMETER — the region an "
                         "emission is bounded to has to be caller-supplied data the host "
                         "body cannot swap for a literal, or the reach claim is "
                         "unreviewable (item 373)",
                )
        # item 309: the `idempotent` emission modifier and its `idempotent(key: p)`
        # keyed form. Two rules, enforced here next to the sibling reach checks:
        #   (1) `idempotent`/`idempotent(key:)` is EMISSION-ONLY. It is item-44's
        #       delivery claim (the remote treats re-delivery as delivery), and
        #       only an emission crosses to a remote. Placed on a witnessed/acquire
        #       extern it would read as a keyed INVERSE, which 243 rule 3 forbids
        #       (inverses are non-emission); reject the claim rather than drop it.
        #   (2) the key TARGET must name a real PARAMETER and be scalar-
        #       serializable (`Str`/`Int`), so a fresh process can read the same
        #       key VALUE off the WAL descriptor on every re-issue (§1b, §1c).
        if decl.idempotent and decl.classification != "emission":
            raise RevlError(
                filename, decl.line,
                f"`{decl.classification}` extern `{decl.name}` cannot be declared "
                f"`idempotent`",
                hint="`idempotent` is a delivery claim about a boundary crossing, "
                     "so it is emission-only; a witnessed/acquire reversal is a "
                     "non-emission INVERSE (243 rule 3), and its at-most-once claim "
                     "is spelled `undo idempotent <inverse>(result)` instead "
                     "(docs/design/309-idempotent-inverse.md, §1b)",
                code="G4", category="idempotent")
        if decl.idempotency_key is not None:
            param_by_name = {p.name: p for p in decl.params}
            if decl.idempotency_key not in param_by_name:
                params_list = ", ".join(sorted(param_by_name)) or "(none)"
                raise RevlError(
                    filename, decl.line,
                    f"emission `{decl.name}` declares `idempotent(key: "
                    f"{decl.idempotency_key})`, but `{decl.idempotency_key}` is not "
                    f"one of its parameters ({params_list})",
                    hint="the idempotency key names the PARAMETER whose per-call "
                         "value the remote dedups on; it must resolve against the "
                         "signature (item 309, §1b)",
                    code="G4", category="idempotent")
            key_type = param_by_name[decl.idempotency_key].type
            if key_type not in ("Str", "Int"):
                raise RevlError(
                    filename, decl.line,
                    f"emission `{decl.name}` idempotency key "
                    f"`{decl.idempotency_key}` has type `{key_type}`, which is not "
                    f"scalar-serializable",
                    hint="an idempotency key rides the WAL descriptor as durable "
                         "data every re-issue reads back, so it must be a "
                         "serializable scalar (`Str` or `Int`), not a host handle "
                         "or a compound type (item 309, §1b)",
                    code="G4", category="idempotent")
        # item 257: a `validated` emission extern. Check emission-only + non-Unit
        # and derive the boundary schema on the qualifier-stripped return type
        # (already stripped in place by extract_and_normalize; re-stripped for
        # order-robustness). Refuses an unexpressible return type at compile time.
        validated_schema: dict | None = None
        if decl.validated:
            validated_schema = _validated_response_schema(
                decl.name, decl.returns, decl.classification == "emission",
                types, filename, decl.line, "extern")
        # item 257 (Slice 2): the `retry N` budget, legal only alongside
        # `validated` (refused otherwise), byte-identical when absent.
        validated_retry_ir = _validated_retry_ir(
            decl.name, decl.validated, getattr(decl, "retry", 0),
            filename, decl.line, "extern")
        # witnessed-inverse externs (docs/design/243-witnessed-externs.md). A
        # witnessed mutation is a transaction, not a bracket: its declared `undo`
        # is auto-registered by the accumulator and replays on abort only. The
        # correctness envelope is checked here, before the descriptor reaches the
        # IR — the Slice-2 runtime seam trusts these invariants.
        witness_type: str | None = None
        if decl.classification == "witnessed":
            if decl.compensate is not None:
                raise RevlError(
                    filename, decl.line,
                    f"witnessed extern `{decl.name}` cannot declare `compensate`",
                    hint="a witnessed mutation carries a proof-grade `undo`; "
                         "`compensate` is the best-effort form for one-way emissions",
                    code="G5", category="witnessed",
                )
            if decl.undo is None:
                raise RevlError(
                    filename, decl.line,
                    f"witnessed extern `{decl.name}` must declare `undo` (G4)",
                    hint="a witnessed mutation is reversible only because it names the "
                         "inverse the accumulator auto-registers; declare "
                         "`undo <inverse>(result)`",
                    code="G4", category="witnessed",
                )
            # The witness is the return value, and it must be a `Result[W, E]` so
            # the inverse registers on `Ok` only (a failed mutation touched
            # nothing): rule "registered only on Ok" (docs/design/243).
            head, args = parse_type(decl.returns)
            if head != "Result" or len(args) != 2:
                raise RevlError(
                    filename, decl.line,
                    f"witnessed extern `{decl.name}` must return "
                    f"`Result[Witness, Error]` — the fallible witness the inverse "
                    f"binds (G4)",
                    hint="every host mutation can fail (ENOENT/EPERM/disk-full); the "
                         "inverse is auto-registered on the `Ok` branch only, so the "
                         "return must be a `Result`",
                    code="G4", category="witnessed",
                )
            witness_type = args[0]
            # The witness must be WAL-serializable DATA, not a host handle: a
            # crash leaves only the write-ahead log, and an inverse closing over
            # an in-process object is residue, not recovery (recovery.py). A host
            # object type (Map/Pool/Job) cannot be reconstructed from the WAL.
            wt_head, _ = parse_type(witness_type)
            if wt_head in _HOST_CALLABLES:
                raise RevlError(
                    filename, decl.line,
                    f"witnessed extern `{decl.name}` witness `{witness_type}` is a "
                    f"host object — the witness must be WAL-serializable data (G8)",
                    hint="a host handle dies with the process; after a crash only the "
                         "write-ahead log survives, so the witness must be durable data "
                         "(paths, refs, a record) the inverse can be rebuilt from",
                    code="G8", category="witnessed",
                )
        # `async` validity (docs/design/async-extern.md §1): the modifier is
        # legal only on `emission` externs, and an async extern may not declare
        # `compensate` in v1 (the compensation seam is synchronous on every
        # tier). These sit next to the classification rules above and refuse
        # with honest messages before the flag reaches the IR.
        if decl.async_:
            if decl.classification == "pure":
                raise RevlError(
                    filename, decl.line,
                    f"`pure` extern `{decl.name}` cannot be `async` — a suspension is "
                    f"observable; classify it `emission`",
                    hint="pure externs are callable from every pure position (tests, "
                         "match guards, undo slots), which have no async story",
                )
            if decl.classification == "acquire":
                raise RevlError(
                    filename, decl.line,
                    f"`acquire` extern `{decl.name}` cannot be `async` yet — an "
                    f"acquire's `undo` runs on the synchronous teardown/unwind path",
                    hint="classify it `emission`, or file the need if an awaited "
                         "teardown ever becomes real",
                )
            if decl.classification == "witnessed":
                raise RevlError(
                    filename, decl.line,
                    f"`witnessed` extern `{decl.name}` cannot be `async` yet — its "
                    f"declared inverse replays on the synchronous abort/teardown path",
                    hint="classify it `emission`, or file the need if an awaited "
                         "rollback ever becomes real",
                )
            if decl.compensate is not None:
                raise RevlError(
                    filename, decl.line,
                    "an `async` extern cannot declare `compensate` yet — the "
                    "compensation seam is synchronous on every tier",
                )
        # `deferred` validity (docs/design/245-session-commit.md, Decision 2).
        # The class of an action is a total function of its checked
        # classification: nothing at runtime or in the harness can move an
        # action between classes, so the rules that keep class (b) honest are
        # enforced here, before the flag reaches the IR.
        if decl.deferred:
            _check_deferred_extern(decl, filename)
        # item 388: the caller-decided colour marker `fn|async`. A poly extern
        # fixes no colour; lowering splits it into concrete sync/async clones per
        # call-site colour (below, in the component-lowering post-pass). Its
        # validity envelope mirrors the `async` one directly above, because a poly
        # extern IS an emission that may be emitted async: emission-only, not
        # `deferred`, not ALSO a fixed `async` (the two spellings are mutually
        # exclusive — a fixed `async` already picks the colour), and no
        # `compensate` (the compensation seam is synchronous, exactly as for a
        # fixed `async` extern). Plus the cheap per-backend `await`-keyword lint:
        # a colour-agnostic body cannot suspend, so an `await` in a `fn|async`
        # host body is refused. This is a LINT, not a proof — colour-agnosticism
        # is unprovable inside opaque host text (G8, item 24) — but it catches the
        # common authoring mistake at compile time.
        # item 396 option B: a `HostRef` body has no author-written TEXT, so the
        # colour-poly await-lint (which scans body text) and 388's clone
        # synthesis (which deep-copies `bodies`, not `refs`) do not cover it.
        # Rather than risk a silently-dropped ref clone, refuse the poly+ref
        # combination outright with a clear redirect (the decision recorded for
        # item 388 composition). Fixed-colour refs compose freely.
        from .parser import HostRef as _HostRef  # noqa: PLC0415
        if decl.colour_poly and any(isinstance(b, _HostRef) for b in decl.bodies):
            offender = next(b for b in decl.bodies if isinstance(b, _HostRef))
            raise RevlError(
                filename, offender.line,
                f"a `fn|async` (caller-decided-colour) extern cannot use a "
                f"host-module ref; `{decl.name}` declares both",
                hint="a poly extern is cloned per call-site colour, and one host "
                     "symbol cannot be both a coroutine and a plain callable, so "
                     "a ref cannot serve both clones. Fix the colour "
                     "(`async fn`/`fn`) and ref a matching sync-or-async symbol, "
                     "or use an inline body (item 396 option B / 388)")
        if decl.colour_poly:
            _check_poly_extern(decl, filename)
        # item 379 / option (b) of docs/design/378-sync-extern-service-reach.md:
        # validate the typed `config` schema the same way a component's config is
        # validated (lower.py:4681 default-type compatibility). Config is STATIC
        # data resolved once at plug, so there is no service reach and no async
        # op: A1 and the capability gate are untouched (design "(b)"). Duplicate
        # field names are refused, and a non-`null` default must fit its declared
        # field type. The schema reaches the IR below only when non-empty, so an
        # extern with no `config` block is byte-identical.
        seen_cfg: set[str] = set()
        for cfg in decl.config:
            if cfg.name in seen_cfg:
                raise RevlError(filename, cfg.line,
                                f"duplicate config field `{cfg.name}` in extern `{decl.name}`")
            seen_cfg.add(cfg.name)
            if cfg.default is None:
                continue
            lit_type = _config_default_type(cfg.default)
            if lit_type is not None and not compatible(cfg.type, lit_type):
                raise mismatch(filename, cfg.line,
                               f"config field `{cfg.name}` default of extern `{decl.name}`",
                               cfg.type, lit_type)
        # item 395 / Stage-5 TIER GATE (Fable review, before ts/go/rust/java
        # config injection): option (b)'s config coeffect binds `_revl_config` in
        # the extern body ONLY on a tier whose emitter has the injection seam
        # (`_CONFIG_INJECTION_TIERS`, py-only today). A config extern that carries
        # a host body for a seam-less tier would emit that body with `_revl_config`
        # UNBOUND — a late, mis-attributed failure (runtime ReferenceError on ts;
        # a compile error of the emitted artifact on go/rust/java). Refuse the
        # whole hazard class HERE, at compile, naming the offending tier and
        # redirecting to option (c). Gated on `decl.config`, so a non-config
        # extern with any host body is untouched (byte-identical). Ordered by the
        # author's @-body spelling for a deterministic first offender.
        from .parser import HostBodyFile, HostRef  # noqa: PLC0415
        if decl.config:
            for body in decl.bodies:
                # item 396 option B: a `config` extern binds `_revl_config` as
                # the first line of the emitted BODY for that text to read; a ref
                # has no author-written body, so binding it inside the thunk would
                # bind a name the referenced host symbol cannot see. Refuse
                # config+ref with a redirect to an inline body that forwards it.
                if isinstance(body, HostRef):
                    raise RevlError(
                        decl_file, body.line,
                        f"a config extern cannot use a host-module ref; "
                        f"`{decl.name}` declares both",
                        hint="`config` binds `_revl_config` inside the emitted "
                             "body for the body text to read, but a ref has no "
                             "body text — the referenced host symbol never sees "
                             "the name. Use an inline `= @backend { ... }` body "
                             "that reads `_revl_config` and forwards it to the "
                             "host call (item 396 option B).")
                if body.backend not in _CONFIG_INJECTION_TIERS:
                    raise RevlError(
                        decl_file, body.line,
                        f"extern config is not yet supported on the @{body.backend} "
                        f"tier (config extern `{decl.name}`)",
                        hint=(
                            f"only the @py emitter binds `_revl_config` from the "
                            f"plug-time config map today; a @{body.backend} body "
                            f"would emit with `_revl_config` unbound. Use option "
                            f"(c): give the mechanism a home component that "
                            f"`requires` the service "
                            f"(docs/design/378-sync-extern-service-reach.md)."),
                    )
        bodies: dict[str, str] = {}
        # item 396: provenance for a body SPLICED from an external file. Absent
        # unless the file form is used, so every existing extern's IR is
        # byte-identical. Records the written path and the sha256 of the raw
        # file bytes so two compiles are byte-comparable and `revl verify` can
        # re-hash the file.
        body_files: dict[str, dict] = {}
        # item 396 option B: a per-tier host-MODULE ref (symbol + root-relative
        # path + pinned content hash). Additive next to `bodies`; a backend key
        # may appear in `bodies` OR `refs` but never both (the duplicate-body
        # refusal, extended). Absent unless a ref is used, so every existing IR
        # is byte-identical.
        refs: dict[str, dict] = {}
        for body in decl.bodies:
            if isinstance(body, HostBodyFile):
                # The compiler's body-file resolver replaces every HostBodyFile
                # with a resolved HostBody before lowering; reaching here means
                # the resolution seam was skipped (an internal error, not an
                # author error).
                raise RevlError(
                    filename, body.line,
                    f"internal: unresolved @{body.backend} host-body file for "
                    f"extern `{decl.name}` reached lowering (item 396)")
            if isinstance(body, HostRef):
                # tier gate (mirrors the config-injection gate): "import a symbol
                # from a checked file" is native on py and ts only; go/rust/java
                # lack a file-addressable module primitive and wasm cannot import
                # a file. Refuse the others at compile, naming the tier — never a
                # broken artifact. A tier joins EXTERN_REF_TIERS only behind its
                # own design note, not by analogy.
                if body.backend not in _EXTERN_REF_TIERS:
                    raise RevlError(
                        filename, body.line,
                        f"a host-module ref (`= @{body.backend} ref ...`) is not "
                        f"supported on the @{body.backend} tier (extern "
                        f"`{decl.name}`)",
                        hint="`ref` imports a symbol from a file-addressable host "
                             "module, which is native on @py and @ts only. go/"
                             "rust/java have no file-addressable import primitive "
                             "and wasm cannot import a file — each needs its own "
                             "design. Use an inline `= @backend { ... }` body or "
                             "a `= @backend file` splice on this tier "
                             "(item 396 option B).")
                if body.rel_path is None:
                    raise RevlError(
                        filename, body.line,
                        f"internal: unresolved @{body.backend} host-module ref "
                        f"for extern `{decl.name}` reached lowering (item 396)")
                if body.backend in bodies or body.backend in refs:
                    raise RevlError(filename, body.line,
                                    f"duplicate @{body.backend} body for extern `{decl.name}`")
                refs[body.backend] = {
                    "symbol": body.symbol,
                    "path": body.rel_path,
                    "sha256": body.sha256,
                    # item 410: the root KIND, ADDITIVE. Present only for an
                    # install-origin (stdlib / REVL_IMPORT_PATH) ref, so a
                    # user-origin ref IR is byte-identical to 396(B) (the
                    # 342/388 additivity discipline: absent, never `"user"`).
                    # Selects the runner's install root vs the user root at
                    # deploy.
                    **({"root": body.root_kind}
                       if getattr(body, "root_kind", None) else {}),
                }
                continue
            if body.backend in bodies or body.backend in refs:
                raise RevlError(filename, body.line,
                                f"duplicate @{body.backend} body for extern `{decl.name}`")
            bodies[body.backend] = body.text
            if body.source_path is not None:
                body_files[body.backend] = {"path": body.source_path,
                                            "sha256": body.sha256}
        entry: dict = {
            "name": decl.name,
            "class": decl.classification,
            "params": _ir_params(
                ((p.name, p.type) for p in decl.params),
                getattr(decl, "secret_params", ())),
            "returns": decl.returns,
            "bodies": bodies,
            # item 396 option A: file-splice provenance, present only when a
            # `= @backend file` body was used (additive: every existing IR is
            # byte-identical without it).
            **({"body_files": body_files} if body_files else {}),
            # item 396 option B: host-module refs (symbol + root-relative path +
            # pinned content hash), present only when a `= @backend ref` body was
            # used. The py/ts emitters generate a lazy import thunk from it and
            # the py driver hash-checks the file at plug (additive).
            **({"refs": refs} if refs else {}),
            # additive async flag (docs/design/async-extern.md §4), mirroring
            # the service-method spelling at lower.py:2583. Absent means sync;
            # `ir_version` stays 3 (confirmed human decision, §4).
            #
            # item 388: a poly extern (`fn|async`) is PRE-SEEDED here as the async
            # form (`async: True`) so awaited call sites resolve during the
            # coloring fixpoint and component lowering (the ordering wrinkle,
            # design §"honest hard part" #3). `colour_poly: True` marks the entry
            # for `_finalize_poly_externs`, the post-pass that — after every
            # component has recorded which colours its call sites requested —
            # keeps this entry only if an async call site exists, splits off a
            # `_revl_sync` clone only if a sync call site exists, and PRUNES the
            # unused colour. The marker is stripped there, so the final IR carries
            # only concrete clones and a poly extern nobody calls emits nothing
            # (additive, the item-342 property extended to externs).
            **({"async": True, "colour_poly": True} if decl.colour_poly
               else {"async": True} if decl.async_ else {}),
            # additive deferred flag (docs/design/245-session-commit.md,
            # Decision 2): class (b), the deferrable emission. Absent means the
            # emission fires at the call (class c). Only an `emission` extern may
            # carry it (checked above), so no non-emission extern's IR changes.
            **({"deferred": True} if decl.deferred else {}),
            # item 246: the declaration-owned `requires approval` floor. Absent
            # unless the author wrote it, so every existing extern's IR is
            # byte-identical. A crossing reaching this extern needs a covering
            # `with e` edge or lowering refuses (Decision 3).
            **({"requires_approval": True} if decl.requires_approval else {}),
            # item 373: the reach clause, recorded as `{"kind", "target"}`. Absent
            # unless the author wrote it, so every existing extern's IR is
            # byte-identical (a bare emission is "unconfined" = no key). `revl
            # audit` prints it and `audit --diff` reads it to flag a weakening.
            **({"reach": {"kind": decl.reach[0], "target": decl.reach[1]}}
               if decl.reach is not None else {}),
            # item 309: the idempotency register, ADDITIVE. Absent unless the
            # author declared one of the three surfaces, so every existing
            # extern's IR is byte-identical. `undo_idempotent` marks an
            # at-most-once INVERSE (undo slot); `idempotent`/`idempotency_key`
            # mark a re-deliverable emission (bare = trust-me, keyed = by
            # construction). `register` is the per-declaration honesty tier the
            # audit prints and the 290/309 policy floors read (order:
            # declared < keyed < read)
            # (docs/design/309-idempotent-inverse.md, §2, §"question 4").
            # item 421 F6: this extern's DECLARED return carried `Secret[T]`, so
            # its result is where a confidential value ENTERS the value world
            # (item 256 §7a). `taint.py` strips the qualifier before lowering, so
            # `returns` above no longer mentions it and this flag is the only
            # surviving record, the counterpart of `params[i]["secret"]` for the
            # return position. A backend reads it to register the value the
            # instant it is produced, which is what lets the host trace scrub it
            # (`runtime._record`). Absent unless the author wrote `Secret[...]`,
            # so every existing extern's IR is byte-identical.
            **({"secret_return": True} if getattr(decl, "secret_return", False)
               else {}),
            # ...and the narrower witness-position flag. A witnessed extern's
            # durable discharge-descriptor records the Ok witness as the
            # inverse's referent argument, so a tier WAL writer reads THIS — not
            # `secret_return`, which is also set when only the error arm is
            # confidential — to decide whether that referent may be written out
            # verbatim. Absent unless the author put `Secret[...]` in the Ok arm.
            **({"secret_witness": True} if getattr(decl, "secret_witness", False)
               else {}),
            **({"undo_idempotent": True} if decl.undo_idempotent else {}),
            # item 440: `undo pure` — the READ tier of the re-dispatch register.
            # Absent unless the author wrote it, so every existing extern's IR is
            # byte-identical.
            **({"undo_read": True} if decl.undo_read else {}),
            **({"idempotent": True} if decl.idempotent else {}),
            **({"idempotency_key": decl.idempotency_key}
               if decl.idempotency_key is not None else {}),
            **({"register": _idempotent_register(decl)}
               if (decl.idempotent or decl.undo_idempotent or decl.undo_read)
               else {}),
            # item 379: the typed config schema, in the SAME shape a component
            # carries it (lower.py:4956 `[{"name","type","default"}]`), so the
            # emitter and driver reuse the component config path verbatim. Absent
            # unless the author wrote a `config` block, so every existing extern's
            # IR is byte-identical.
            **({"config": [_ir_config_field(f) for f in decl.config]}
               if decl.config else {}),
            # item 257: the `validated` flag and the derived response schema, a
            # compile-time-constant dict the emit-side validate seam checks the
            # completion against. ADDITIVE: absent unless the author wrote
            # `validated`, so every existing extern's IR is byte-identical.
            **({"validated": True, "response_schema": validated_schema}
               if decl.validated else {}),
            # item 257 (Slice 2): the retry budget (§5.2), a static crossing
            # attribute. Absent unless `retry N` was written, so byte-identical.
            **validated_retry_ir,
        }
        if decl.classification == "witnessed":
            # The witnessed descriptor the Slice-2 runtime teardown loop reads
            # (docs/design/243-witnessed-externs.md). `entry_kind: "transactional"`
            # is the SECOND accumulator entry kind — distinct from an acquire's
            # bracket: it replays on abort ONLY and is discharged (+ its witness
            # GC'd) on commit, where a bracket also replays on clean unload.
            # `ok_conditional` records that the inverse auto-registers on the
            # Result's `Ok` branch only; `witness` is the WAL-serializable data
            # type the inverse is reconstructed from.
            entry["entry_kind"] = "transactional"
            entry["revertible"] = True
            entry["ok_conditional"] = True
            entry["witness"] = witness_type
            if decl.capabilities:
                entry["capabilities"] = list(decl.capabilities)
        if decl.classification == "emission" and decl.capabilities:
            # item 343: a capability-scoped `emission[gateway.send]` records its
            # declared TOKEN in the IR, exactly as a witnessed extern does. The
            # 246 class->approval classifier and 344 standing grants read this to
            # key the crossing on the token instead of the extern name. Absent
            # (a bare `emission`) means no key is written, so every existing
            # emission extern's IR stays byte-identical (name-as-capability).
            entry["capabilities"] = list(decl.capabilities)
        if decl.undo is not None:
            # An acquire binds its declared return as `result`; a witnessed
            # extern binds the `Ok` witness (the Result's success payload), which
            # is exactly what the auto-registered inverse receives on abort.
            undo_result_type = (witness_type if decl.classification == "witnessed"
                                else decl.returns)
            # Classification of the inverse before its arg types: a witnessed or
            # emission inverse is refused on principle, whatever it is applied to.
            if decl.classification == "witnessed":
                reach, reach_witness = _witnessed_inverse_reach()
                _check_witnessed_inverse(decl, extern_class, reach,
                                         reach_witness, filename)
            _check_extern_undo(decl.undo, decl.name, "undo", types, filename,
                               result_type=undo_result_type)
            entry["undo"] = _lower_extern_expr(decl.undo, filename)
        if decl.compensate is not None:
            _check_extern_undo(decl.compensate, decl.name, "compensate",
                               types, filename)
            entry["compensate"] = _lower_extern_expr(decl.compensate, filename)
        externs.append(entry)
    return externs


def _extern_emission_caps(entry: dict) -> tuple:
    """The declared emission capability tokens of a lowered extern IR entry
    (item 256): its scoped `capabilities`, or its NAME when the emission is bare
    (the name-as-capability rule, docs/capabilities.md). Empty for a non-emission
    extern, which can never carry a bound secret."""
    if entry.get("class") != "emission":
        return ()
    return tuple(entry.get("capabilities") or (entry["name"],))


def _lower_secrets(program: Program, externs: list, filename: str) -> list:
    """Cross-index `program.secrets` against the lowered extern emission
    capabilities (item 256, Slice 1). For each `secret NAME for CAP`:

      * find every emission extern whose declared capability includes CAP - the
        bound bodies the runtime injects the key into, and nowhere else (§3);
      * refuse a secret bound to a capability whose bound body's ONLY tier is a
        non-injection tier (wasm has no plug-time secrets dict - §3 Cross-tier),
        exactly as a config extern on wasm is refused;
      * refuse a secret whose NAME collides with a bound extern's parameter name
        (the injected `NAME = _revl_secret(...)` first local would shadow it);
      * refuse a secret that binds NO emission extern at all - the key would be
        injected nowhere, an inert binding is a footgun (fail-loud, §1b);
      * annotate each bound extern entry with `entry["secrets"]` (the names it
        receives) so the emitter binds them as the first body locals.

    Returns the manifest-visible `[{"name","capability"}]` rows (name and
    capability only - the value is NEVER in the IR, §1b). Empty and fully inert
    for a program that binds no secret, so every existing IR is byte-identical."""
    secrets = getattr(program, "secrets", None) or []
    if not secrets:
        return []
    by_name = {e["name"]: e for e in externs}
    # bound bodies per extern name, accumulated so the emitter injects once even
    # when several secrets share a capability an extern serves.
    bound_names: dict[str, list[str]] = {}
    rows: list = []
    seen: set[str] = set()
    for sec in secrets:
        if sec.name in seen:
            raise RevlError(filename, sec.line,
                            f"duplicate secret `{sec.name}`")
        seen.add(sec.name)
        bound = [e for e in externs if sec.capability in _extern_emission_caps(e)]
        if not bound:
            raise RevlError(
                filename, sec.line,
                f"secret `{sec.name}` is bound to capability `{sec.capability}`, "
                f"but no emission extern serves it - the key would be injected "
                f"nowhere",
                hint="a secret injects only into the extern bodies of an "
                     "`emission[<cap>]` whose token matches (a component/service "
                     "method body never receives it). Declare a matching emission "
                     "extern, or fix the capability token "
                     "(docs/design/256-capability-bound-secrets.md §3).")
        for e in bound:
            # name / parameter collision: the injected first local would shadow a
            # declared parameter (a bug the author would never diagnose at run
            # time - the body would read the key instead of its argument).
            for p in e.get("params") or []:
                if p.get("name") == sec.name:
                    raise RevlError(
                        filename, sec.line,
                        f"secret `{sec.name}` collides with a parameter of extern "
                        f"`{e['name']}` - the injected secret local would shadow "
                        f"the parameter",
                        hint="rename the secret (or the parameter); the secret is "
                             "bound as the first local of every extern body it "
                             "reaches (item 256).")
            # tier gate: the key is bound as a plug-time local, which only the
            # injection-tier emitters (py/ts/go/java/rs) can do. A wasm-only bound
            # body has no plug-time secrets dict, exactly as a wasm config extern
            # has none - refuse at compile, naming the tier.
            body_tiers = set(e.get("bodies") or {}) | set(e.get("refs") or {})
            if body_tiers and not (body_tiers & _CONFIG_INJECTION_TIERS):
                offending = ", ".join(sorted(body_tiers))
                raise RevlError(
                    filename, sec.line,
                    f"secret `{sec.name}` is bound to a capability whose only "
                    f"extern body is on the @{offending} tier, which has no "
                    f"plug-time secret injection (emission extern `{e['name']}`)",
                    hint="only the py/ts/go/java/rs emitters bind a secret as a "
                         "body-scope local from the plug-time secrets map; wasm's "
                         "raw body has no such dict, so a wasm-only bound "
                         "capability cannot carry a secret (item 256, §3 "
                         "Cross-tier).")
            bound_names.setdefault(e["name"], []).append(sec.name)
        rows.append({"name": sec.name, "capability": sec.capability})
    # carry the resolved bound-body set into the IR: each bound extern lists the
    # secret names it receives, so the emitter binds them as its first locals.
    for ename, names in bound_names.items():
        by_name[ename]["secrets"] = names
    return rows


# item 310: capability-aware caching (docs/design/310-capability-aware-caching.md).
# The source class words map to the roadmap IR vocabulary; `cache` lowers to
# metadata the emission fixed point NEVER reads (so every 414 static fold sees a
# cached crossing identically hit and miss).
_CACHE_IR_CLASS = {"pure": "pure_fn",
                   "capability": "capability_result",
                   "external": "external_effect"}


def _cache_ir(cache) -> dict:
    """The IR descriptor for a `CacheClause`. Additive: absent unless a
    declaration carries `cache`, so every existing IR is byte-identical."""
    entry = {"class": _CACHE_IR_CLASS[cache.cls]}
    if cache.invalidated_by:
        entry["invalidated_by"] = list(cache.invalidated_by)
    if cache.ttl_ms is not None:
        entry["ttl_ms"] = cache.ttl_ms
    return entry


def _crossable_cache_tokens(program: Program) -> set[str]:
    """Every capability TOKEN a crossing in this composition can fire, for the
    item-310 `invalidated_by` resolution check. An emission extern contributes
    its declared scope tokens (or its name when unscoped); a scoped emission
    service method contributes its declared tokens. A misspelled `invalidated_by`
    token that matches none of these is a freshness claim that can never come
    true, so it is refused rather than failing open into an effectively-ttl-less
    cache (design §`invalidated_by`)."""
    tokens: set[str] = set()
    for ext in program.externs:
        if ext.classification == "emission":
            for cap in (ext.capabilities or (ext.name,)):
                tokens.add(cap)
    for svc in program.services:
        for m in svc.methods.values():
            if m.emission and m.capabilities:
                for cap in m.capabilities:
                    tokens.add(cap)
    return tokens


def _cache_token_resolves(token: str, crossable: set[str]) -> bool:
    """Whether an `invalidated_by` token names a crossing the composition can
    fire — exact match or covered in the item-294 capability partial order (a
    wider declared token covers a narrower subscription)."""
    if token in crossable:
        return True
    from . import cap_order  # noqa: PLC0415
    for declared in crossable:
        try:
            if cap_order.covers(cap_order.parse_cap(declared),
                                cap_order.parse_cap(token)):
                return True
        except cap_order.CapError:
            continue
    return False


def _check_cache_freshness(cache, filename: str, line: int, what: str,
                           untrusted: bool = False) -> None:
    """The per-class freshness rules (design §"The freshness clauses"), class-
    local (no reach needed). Shared by fn/method/extern so one word means one
    thing on every surface."""
    from . import navigate as _nav  # noqa: PLC0415 — lazy, additive
    _prof = _UntrustedMark if untrusted else None
    has_inval = bool(cache.invalidated_by)
    has_ttl = cache.ttl_ms is not None
    if cache.cls == "pure" and (has_inval or has_ttl):
        raise RevlError(
            filename, line,
            f"`cache pure` on {what} cannot declare a freshness bound",
            hint="a pure result cannot go stale, so `ttl`/`invalidated_by` is a "
                 "category error (and probably a misclassified external read) — "
                 "drop the clause, or declare `cache external` "
                 "(docs/design/310-capability-aware-caching.md)",
            code="G4", category="cache",
            navigate=_nav.cache_navigate(kind="drop", what=what,
                                         clause="freshness", profile=_prof))
    if cache.cls == "capability" and has_inval:
        raise RevlError(
            filename, line,
            f"`cache capability` on {what} cannot declare `invalidated_by`",
            hint="`invalidated_by` names the staleness event of an EXTERNAL read; "
                 "a capability result's freshness bound IS its authorizing scope "
                 "(the grant + generation liveness), narrowable only by `ttl`. "
                 "Drop `invalidated_by`, or declare `cache external` (item 310)",
            code="G4", category="cache",
            navigate=_nav.cache_navigate(kind="drop", what=what,
                                         clause="invalidated_by", profile=_prof))
    if cache.cls == "external" and not (has_inval or has_ttl):
        raise RevlError(
            filename, line,
            "cache external requires a freshness bound: declare "
            "`invalidated_by <token>` and/or `ttl <duration>`: an external "
            "result changes without notice, so an unbounded cache serves the "
            "past as the present",
            code="G4", category="cache",
            navigate=_nav.cache_navigate(kind="add", what=what, profile=_prof))


def _check_cache_resource(cache, filename: str, line: int, what: str,
                          param_types, return_type, resources: set[str],
                          untrusted: bool = False) -> None:
    """The structural resource-in-entry refusal (design, laundering point 8, the
    E x 7 shape). An entry copies a result (and digests args) into a store that
    outlives the call; a resource handle stored in an entry would be stored
    authority, re-deliverable to a later access. The walk is STRUCTURAL over the
    resource-taint closure (nested records, variants, generic instantiations),
    never a type-name match, so a resource renamed or wrapped two levels deep
    refuses identically."""
    for role, tstr in (("result", return_type),
                       *(("parameter", t) for t in param_types)):
        hit = resource_in(tstr, resources)
        if hit is not None:
            from . import navigate as _nav  # noqa: PLC0415 — lazy, additive
            raise RevlError(
                filename, line,
                f"cache on {what} would store a resource handle `{hit}` "
                f"(in the {role} type `{tstr}`)",
                hint="a cache entry outlives the call and re-delivers its stored "
                     "value; a resource handle crosses a seam by proxy, never by "
                     "copy, so a cached one is stored authority re-deliverable to "
                     "a later access (item 310, surface E). Return/accept a value "
                     "type, not a resource handle",
                code="G4", category="cache",
                navigate=_nav.cache_navigate(
                    kind="blocked", what=what,
                    category=f"it stores the resource handle `{hit}`",
                    profile=(_UntrustedMark if untrusted else None)))


def _check_cache_declarations(program: Program, externs: list, types: dict,
                              emitting_caps: dict, filename: str,
                              untrusted: bool = False) -> None:
    """The item-310 admission checks, run once the emission fixed point and the
    type/extern tables are known. Refuses in every case the seam-method slice
    cannot soundly cache; the surviving declarations flow their `cache` metadata
    into the IR (service-method and — grammar-forward — extern sites).

    Layered exactly as the design scopes the slice:
      * externs: the interior-crossing crossing is NOT the seam method's direct
        body, so the whole extern surface is admission-refused — an escrow-shaped
        reach (witnessed/acquire/deferred/compensate) with its specific G7 reason,
        every other extern with the "later slice" reason (design §enforcement).
      * plain `fn`: only `cache pure` is legal, and only when the fn crosses
        nothing; a crossing reach or a capability/external class is refused.
      * service methods: the class must match the method's declared reach shape
        (`emission fn` <-> capability/external, plain `fn` <-> pure); freshness
        and the structural resource walk apply. The full worst-over-reach
        applicability fold over the provider closure (surface H) and the
        distributed-placement refusal run at load, where the class map exists."""
    from . import navigate as _nav  # noqa: PLC0415 — lazy, additive
    _prof = _UntrustedMark if untrusted else None
    resources = resource_taint(externs, types)
    crossable = None  # computed lazily, only when an `invalidated_by` appears

    def check_invalidated_by(cache, line, what):
        nonlocal crossable
        if not cache.invalidated_by:
            return
        if crossable is None:
            crossable = _crossable_cache_tokens(program)
        for token in cache.invalidated_by:
            if not _cache_token_resolves(token, crossable):
                raise RevlError(
                    filename, line,
                    f"`invalidated_by {token}` on {what} names a token no "
                    f"crossing in this composition can fire",
                    hint="a subscription nothing can fire is a freshness claim "
                         "that can never come true; a misspelled token must not "
                         "fail open into an effectively-ttl-less cache. Name an "
                         "emission token some extern or service method crosses "
                         "(item 310, §invalidated_by)",
                    code="G4", category="cache")

    # -- externs: the interior-crossing surface, admission-refused in this slice
    for decl in program.externs:
        cache = getattr(decl, "cache", None)
        if cache is None:
            continue
        cls = decl.classification
        # escrow-shaped reach: a hit would skip an escrow registration (G7).
        if cls in ("witnessed", "acquire"):
            noun = ("witnessed mutation" if cls == "witnessed"
                    else "acquired resource")
            raise RevlError(
                filename, decl.line,
                f"cache on a `{cls}` extern `{decl.name}` is refused",
                hint=f"a {noun} is not a read — caching it would skip the escrow "
                     "registration its teardown depends on, so an abort would "
                     "replay an incomplete history (G7). `cache` reads, it does "
                     "not mutate (item 310, §witnessed teardown)",
                code="G7", category="cache",
                navigate=_nav.cache_navigate(
                    kind="blocked", what=f"a `{cls}` extern `{decl.name}`",
                    category=f"a {noun}, not a read", profile=_prof))
        if cls == "emission" and getattr(decl, "deferred", False):
            raise RevlError(
                filename, decl.line,
                f"cache on a `deferred` emission extern `{decl.name}` is refused",
                hint="a deferred emission is a QUEUED write; a hit that skips the "
                     "firing skips the enqueue, so the commit would flush an "
                     "incomplete history (G7). `cache` is read-shaped (item 310)",
                code="G7", category="cache",
                navigate=_nav.cache_navigate(
                    kind="blocked",
                    what=f"a `deferred` emission extern `{decl.name}`",
                    category="a queued write, not a read", profile=_prof))
        if cls == "emission" and decl.compensate is not None:
            raise RevlError(
                filename, decl.line,
                f"cache on a `compensate`-declaring emission extern "
                f"`{decl.name}` is refused",
                hint="a compensated emission registers a compensation escrow entry "
                     "at fire time; a hit that skips the firing skips the "
                     "registration, so an abort after a hit replays an incomplete "
                     "offset history (G7). `cache` reads, it does not write "
                     "(item 310, §witnessed teardown)",
                code="G7", category="cache",
                navigate=_nav.cache_navigate(
                    kind="blocked",
                    what=f"a `compensate`-declaring emission extern `{decl.name}`",
                    category="a compensated write, not a read", profile=_prof))
        # every other extern: grammar-forward, enforcement-honest.
        raise RevlError(
            filename, decl.line,
            f"cache on an interior crossing (extern `{decl.name}`) is not yet "
            f"enforceable; declare it on the seam method",
            hint="the seam consent gate decides the hit/miss transaction at the "
                 "call, before execution, so `cache` is enforceable this slice "
                 "only on a SEAM SERVICE METHOD where the call is the crossing. "
                 "An interior extern crossing needs a crossing-level ledger "
                 "transaction that is a later slice (item 310, §enforcement)",
            code="G4", category="cache",
            navigate=_nav.cache_navigate(
                kind="blocked", what=f"an interior extern crossing `{decl.name}`",
                category="an interior crossing, not a seam method", profile=_prof))

    # -- plain fns: `cache pure` only, crossing-free only
    for fn in program.fn_decls:
        cache = getattr(fn, "cache", None)
        if cache is None:
            continue
        what = f"fn `{fn.name}`"
        _check_cache_freshness(cache, fn.source or filename, fn.line, what,
                               untrusted)
        crosses = fn.name in emitting_caps
        if cache.cls in ("capability", "external"):
            named = sorted(c for c in (emitting_caps.get(fn.name) or ()) if c != "*")
            raise RevlError(
                fn.source or filename, fn.line,
                f"`cache {cache.cls}` on {what} is not allowed on a plain `fn`",
                hint="freshness belongs on the boundary, not on a caller of it "
                     "(two callers could declare contradictory staleness for one "
                     "crossing). Declare `cache pure` to memoize a pure fn, or "
                     "move the clause to the `emission` service method or extern "
                     "that reads the boundary"
                     + (f" ({', '.join(named)})" if named else "")
                     + " (item 310)",
                code="G4", category="cache")
        if crosses:  # cache pure on a crossing reach
            named = sorted(c for c in (emitting_caps.get(fn.name) or ()) if c != "*") \
                or ["a boundary"]
            raise RevlError(
                fn.source or filename, fn.line,
                f"the reach of {what} crosses {named[0]}: a crossing result is "
                f"not pure",
                hint="`cache pure` memoizes a function whose reach crosses "
                     "nothing; move the clause to the emission that reads the "
                     "boundary, as `cache capability` or `cache external` "
                     "(item 310)",
                code="G4", category="cache")
        check_invalidated_by(cache, fn.line, what)

    # -- service methods: class must match the declared reach shape
    for svc in program.services:
        for m in svc.methods.values():
            cache = getattr(m, "cache", None)
            if cache is None:
                continue
            what = f"`{svc.name}.{m.name}`"
            _check_cache_freshness(cache, filename, m.line, what, untrusted)
            if cache.cls == "pure" and m.emission:
                raise RevlError(
                    filename, m.line,
                    f"the reach of {what} crosses a boundary (it is an "
                    f"`emission` method): a crossing result is not pure",
                    hint="declare `cache capability` (a capability-backed "
                         "deterministic read) or `cache external` (an external "
                         "read, which requires a freshness bound); `cache pure` "
                         "is only for a method that crosses nothing (item 310)",
                    code="G4", category="cache")
            if cache.cls in ("capability", "external") and not m.emission:
                raise RevlError(
                    filename, m.line,
                    f"the reach of {what} crosses nothing (a plain `fn` method): "
                    f"declare `cache pure`",
                    hint="`cache capability`/`external` name a boundary read; a "
                         "non-emission method reads no boundary, so its only sound "
                         "cache is pure memoization (item 310)",
                    code="G4", category="cache")
            param_types = [t for _, t in m.params]
            _check_cache_resource(cache, filename, m.line, what,
                                  param_types, m.returns, resources, untrusted)
            check_invalidated_by(cache, m.line, what)


def _lower_tests(program: Program, filename: str, types: dict,
                 services: dict | None = None) -> list:
    """Lower `test` and `lifecycle test` blocks to IR v3 test units (§7/§7.1).

    `types` (the case/signature table) is threaded through so a `test` body is
    the same expression scope a `fn` body is: nullary user-ADT constructors
    resolve as values (`let s = FirstTime`) and statements are type-checked.
    """
    if not program.tests:
        return []
    # A `test` body is the same callable scope a `fn` body is (mirrors
    # `_lower_fns`' `default_callables` and `_lower_prop_tests`): module `fn`s
    # AND `extern`s, plus the host callables/constructors already in fn scope.
    # Without the externs an in-module `extern pure fn` visible to fn bodies was
    # invisible inside a `test`, forcing every extern-backed helper to be
    # wrapped in a `fn` just to be unit-tested in-file (roadmap item 182).
    callables = (_HOST_CALLABLES | _BUILTIN_CONSTRUCTORS | _DECLASSIFY_BUILTINS
                 | {fn.name for fn in program.fn_decls}
                 | {ext.name for ext in program.externs})
    tests: list[dict] = []
    seen: set[str] = set()
    for decl in program.tests:
        if decl.name in seen:
            raise RevlError(filename, decl.line, f"duplicate test `{decl.name}`")
        seen.add(decl.name)
        if decl.lifecycle:
            tests.append({
                "name": decl.name,
                "lifecycle": True,
                "body": _lower_lifecycle_body(decl, program, services or {}, filename,
                                              callables, types),
            })
            continue
        scope: dict[str, bool] = {}
        type_env: dict[str, str] = {}
        check_list_index_bounds(decl.body, filename)
        body: list[dict] = []
        for stmt in decl.body:
            _lower_pure_stmt(stmt, scope, callables, {}, body, filename, type_env, types)
        tests.append({"name": decl.name, "body": body})
    return tests


# ---------------------------------------------------------------- prop tests
#
# `prop test "name" (params) { assert … }` (roadmap item 37): the parameters
# are *generated inputs*, and the body is a pure property that must hold for
# every generated value.  Lowering does two things a plain `test` does not:
#
#   * it validates that every parameter type is one the generator can DERIVE a
#     value from (a primitive, an `Opt`/`List`/`Result` of one, or a declared
#     record/ADT), so an ungeneratable parameter is a compile error rather than
#     a runtime surprise; and
#   * it records the parameters (with their resolved types) alongside the
#     lowered body in a `prop_tests` IR section, from which the py runner
#     (src/revl/fault.py) derives the generators and the shrinker.
#
# The body itself lowers exactly as a `fn`/`test` body does, with the
# parameters in scope — so `assert` reads identically to everywhere else.
_GENERATABLE_PRIMITIVES = {"Int", "Int32", "Bool", "Str", "Float", "F64", "Num"}


def _check_generatable(filename: str, line: int, type_name: str, types: dict,
                       propname: str, record_stack: tuple = (),
                       variant_seen: frozenset = frozenset()) -> None:
    """Reject a prop-test parameter (or nested) type the generator cannot make.

    Generatable: a primitive; `Opt[T]`/`List[T]` of a generatable argument; a
    declared record whose fields are generatable; a declared ADT whose case
    payloads are generatable.  A record that (transitively) contains
    itself is genuinely non-constructible and is named as such; recursive ADTs
    are fine (they have a base case, and the runner bounds generation depth).
    """
    head, args = parse_type(type_name)
    if head in _GENERATABLE_PRIMITIVES and not args:
        return
    if head == "Opt" and len(args) == 1:
        _check_generatable(filename, line, args[0], types, propname,
                           record_stack, variant_seen)
        return
    if head == "List" and len(args) == 1:
        _check_generatable(filename, line, args[0], types, propname,
                           record_stack, variant_seen)
        return
    spec = types.get(head) if head and not args else None
    if spec and spec.get("kind") == "record":
        if head in record_stack:
            cycle = " -> ".join(record_stack + (head,))
            raise RevlError(
                filename, line,
                f"prop test `{propname}`: record type `{head}` contains itself "
                f"({cycle}) and cannot be generated",
                hint="a record always holds all its fields, so a self-containing record "
                     "has no finite value; break the cycle with an `Opt[...]` or `List[...]`")
        for ftype in spec.get("fields", {}).values():
            _check_generatable(filename, line, ftype, types, propname,
                               record_stack + (head,), variant_seen)
        return
    if spec and spec.get("kind") == "variant":
        if head in variant_seen:
            # already validated on this path — a recursive ADT is fine (it has a
            # base case; the depth-bounded generator handles it). Stop rather
            # than descend forever.
            return
        for case in spec.get("cases") or []:
            if case.get("payload") is not None:
                # a case payload may reference the ADT recursively — the record
                # cycle stack is not carried across the ADT boundary (that split
                # is a valid base/recursive one), but the variant set is, to
                # terminate on a self-referential ADT
                _check_generatable(filename, line, case["payload"], types, propname,
                                   (), variant_seen | {head})
        return
    raise RevlError(
        filename, line,
        f"prop test `{propname}`: parameter type `{type_name}` cannot be generated",
        hint="a prop-test parameter must be a type the checker can derive inputs from: "
             "`Int`/`Int32`/`Bool`/`Str`/`Float`, an `Opt[...]`/`List[...]` of one, or a "
             "declared record/ADT (docs/prop-test.md)")


def _lower_prop_tests(program: Program, filename: str, types: dict,
                      services: dict | None = None) -> list:
    """Lower `prop test` blocks to IR prop units (docs/prop-test.md)."""
    if not program.prop_tests:
        return []
    callables = (_HOST_CALLABLES | _BUILTIN_CONSTRUCTORS | _DECLASSIFY_BUILTINS
                 | {fn.name for fn in program.fn_decls}
                 | {ext.name for ext in program.externs})
    units: list[dict] = []
    seen: set[str] = set()
    for decl in program.prop_tests:
        if decl.name in seen:
            raise RevlError(filename, decl.line, f"duplicate prop test `{decl.name}`")
        seen.add(decl.name)
        scope: dict[str, bool] = {}
        type_env: dict[str, str] = {}
        for param in decl.params:
            check_type_wellformed(filename, param.line, param.type)
            _check_generatable(filename, param.line, param.type, types, decl.name)
            scope[param.name] = False
            type_env[param.name] = param.type
        body: list[dict] = []
        check_list_index_bounds(decl.body, filename)
        for stmt in decl.body:
            _lower_pure_stmt(stmt, scope, callables, {}, body, filename, type_env, types)
        units.append({
            "name": decl.name,
            "params": [{"name": _predeclared_mangle(p.name), "type": p.type}
                       for p in decl.params],
            "body": body,
        })
    return units


# `fail at effect X` is sugar: it resolves to the index of the body step that
# binds X, so every backend and the runner see exactly one addressing scheme
# (a step index).  Index is the primitive because it is total — *every* body
# step has one, including `emit`, `provide`, `await` and unbound `effect`
# blocks — while a name only exists for `let effect NAME = …`.  The name form
# is the refactor-stable one to write, so both spellings are kept and the
# diagnostics always report the pair.
_FAULT_ASSERTS = (
    "failed", "no-residue", "inverses-lifo", "no-emissions", "siblings-unaffected",
)


def _fault_effect_index(body: list, name: str) -> int | None:
    """1-based index of the top-level `let-effect` step binding *name*."""
    for index, step in enumerate(body, 1):
        if step.get("step") == "let-effect" and step.get("bind") == name:
            return index
    return None


def _lower_fault_tests(program: Program, components: list, filename: str) -> list:
    """Lower `fault test` blocks to IR fault units (docs/fault-tests.md).

    Runs after component lowering: the injection point is validated against
    the *lowered* body, so `fail at step 4` is a compile error when the
    component only has three steps rather than a confusing runtime miss.
    """
    if not program.fault_tests:
        return []
    by_name = {component["name"]: component for component in components}
    units: list[dict] = []
    seen: set[str] = set()
    for decl in program.fault_tests:
        if decl.name in seen:
            raise RevlError(filename, decl.line, f"duplicate fault test `{decl.name}`")
        seen.add(decl.name)
        component = by_name.get(decl.component)
        if component is None:
            known = ", ".join(sorted(by_name)) or "(none in this composition)"
            raise RevlError(filename, decl.line,
                            f"fault test `{decl.name}` names unknown component `{decl.component}`",
                            hint=f"components in this composition: {known}")
        body = component.get("body") or []
        if not body:
            raise RevlError(filename, decl.line,
                            f"component `{decl.component}` has an empty activation body — "
                            f"there is no point at which it can fail")
        if decl.at_effect is not None:
            step = _fault_effect_index(body, decl.at_effect)
            if step is None:
                bindings = [s.get("bind") for s in body if s.get("step") == "let-effect"]
                known = ", ".join(f"`{b}`" for b in bindings) or "(none)"
                raise RevlError(
                    filename, decl.line,
                    f"fault test `{decl.name}`: component `{decl.component}` has no "
                    f"`let … effect` step bound to `{decl.at_effect}`",
                    hint=f"effect bindings in `{decl.component}`: {known}")
        else:
            step = decl.at_step
            if step > len(body):
                raise RevlError(
                    filename, decl.line,
                    f"fault test `{decl.name}`: `fail at step {step}` is past the end of "
                    f"`{decl.component}` (its activation body has {len(body)} step(s))")
        known_config = {field.get("name") for field in component.get("config") or []}
        for key in decl.config:
            if key not in known_config:
                fields = ", ".join(sorted(known_config)) or "(none)"
                raise RevlError(
                    filename, decl.line,
                    f"fault test `{decl.name}`: `{decl.component}` has no config field `{key}`",
                    hint=f"config fields of `{decl.component}`: {fields}")
        asserts: list[str] = []
        for kind, line in decl.asserts:
            if kind not in _FAULT_ASSERTS:  # pragma: no cover — parser gates the spelling
                raise RevlError(filename, line, f"unknown fault-test assertion `{kind}`")
            if kind not in asserts:
                asserts.append(kind)
        unit = {
            "name": decl.name,
            "component": decl.component,
            "at": {"step": step},
            "assert": asserts,
        }
        if decl.at_effect is not None:
            unit["at"]["effect"] = decl.at_effect
        if decl.config:
            unit["config"] = dict(decl.config)
        units.append(unit)
    return units

def _lower_lifecycle_body(decl: TestDecl, program: Program, services: dict, filename: str,
                          callables: set, types: dict) -> list:
    """Lower a `lifecycle test` body (syntax-2.0 §7.1).

    The body is a *linear script* over a live composition, so the checker can
    track exactly what is loaded and what keys are provided at every point —
    every diagnostic below is a compile error, not a runtime surprise.

    G2 (provision disjointness) is what makes this tractable and is also the
    reason there is no `swap C -> C2` statement: two components may not
    provide the same key in one document, so a replacement *provider* is not
    expressible; a replacement *instance* is `unload C` then `load C with
    { ... }`, which this statement set already spells.
    """
    components = {comp.name: comp for comp in program.components}
    loaded: dict[str, ComponentDecl] = {}    # component name -> decl
    provided: dict[str, str] = {}            # provision key -> component name
    scope: dict[str, bool] = {}
    type_env: dict[str, str] = {}
    body: list[dict] = []

    def _known() -> str:
        return ", ".join(f"`{name}`" for name in sorted(components)) or "<none>"

    for stmt in decl.body:
        if isinstance(stmt, LoadStmt):
            comp = components.get(stmt.component)
            if comp is None:
                raise RevlError(filename, stmt.line,
                                f"unknown component `{stmt.component}`",
                                hint=f"a lifecycle test loads components declared in this "
                                     f"document: {_known()}")
            if stmt.component in loaded:
                raise RevlError(
                    filename, stmt.line,
                    f"`{stmt.component}` is already loaded",
                    hint="one instance per component at a time — `unload` it first; two live "
                         "providers of one key is exactly what G2 forbids (§7.1)",
                )
            config = _lower_lifecycle_config(stmt, comp, filename, scope, callables,
                                             type_env, types)
            for key, _svc, _line in comp.provides:
                provided[key] = comp.name
            loaded[comp.name] = comp
            body.append({"step": "load", "component": comp.name, "config": config})
        elif isinstance(stmt, UnloadStmt):
            if stmt.component not in loaded:
                if stmt.component not in components:
                    raise RevlError(filename, stmt.line,
                                    f"unknown component `{stmt.component}`",
                                    hint=f"declared components: {_known()}")
                raise RevlError(filename, stmt.line,
                                f"`{stmt.component}` is not loaded at this point")
            comp = loaded.pop(stmt.component)
            for key, _svc, _line in comp.provides:
                provided.pop(key, None)
            body.append({"step": "unload", "component": comp.name})
        elif isinstance(stmt, CallStmt):
            body.append(_lower_lifecycle_call(stmt, provided, components, services, filename,
                                              scope, callables, type_env, types))
        elif isinstance(stmt, AdvanceStmt):
            # item 102: drive the clock coeffect (item 57) forward. Nothing else
            # in a lifecycle test moves the clock, so this is what makes a
            # timer's firing an assertable timeline step.
            body.append({"step": "advance", "ms": stmt.ms})
        elif isinstance(stmt, AbortStmt):
            # item 377 (F-H1.7): drive the enclosing session frame's 245 abort —
            # mark every live frame aborting, replay the witnessed inverses LIFO,
            # drop the deferral queue. Like `Session.abort`, it tears the live
            # composition down, so nothing is loaded afterwards. Refuse an abort
            # with nothing loaded: there is no session frame to abort, exactly as
            # `Session.abort` needs an owner (it would be a vacuous no-op).
            if not loaded:
                raise RevlError(
                    filename, stmt.line,
                    "`abort` has nothing to abort — no component is loaded at "
                    "this point",
                    hint="`abort` reverts the witnessed effects of the live "
                         "composition; `load` a component and drive it first "
                         "(item 377, docs/design/245-session-commit.md)")
            body.append({"step": "abort"})
            # the abort tears the composition down (session-abort semantics), so
            # the checker's model of what is live returns to empty — a later
            # `unload X` correctly reads as "not loaded", and a later `call`
            # against a since-torn-down key is refused at compile time.
            loaded.clear()
            provided.clear()
        elif isinstance(stmt, ResidueStmt):
            body.append({"step": "assert_no_residue"})
        elif isinstance(stmt, AssertStmt):
            expr = stmt.expr
            if isinstance(expr, ExprVar) and expr.name not in scope:
                raise RevlError(
                    filename, stmt.line,
                    f"unknown lifecycle assertion `{expr.name}`",
                    hint="the lifecycle assertion is `assert no_residue` (§7.1); anything else "
                         "after `assert` is a Bool expression over this test's `let` bindings",
                )
            _bool_cond(expr, type_env, types, filename, "assert")
            body.append({"step": "assert",
                         "expr": _lower_pure_expr(expr, scope, callables, {}, filename,
                                                  type_env, types)})
        else:  # pragma: no cover — the lifecycle grammar produces nothing else
            raise RevlError(filename, getattr(stmt, "line", decl.line),
                            "unexpected statement in a lifecycle test body")

    return body


def _lower_lifecycle_config(stmt: LoadStmt, comp: ComponentDecl, filename: str, scope: dict,
                            callables: set, type_env: dict, types: dict) -> dict:
    """Check and lower `load C with { field: expr, ... }` against C's `config`."""
    fields = {cfg.name: cfg for cfg in comp.config}
    given: dict[str, dict] = {}
    for name, value, line in stmt.config:
        cfg = fields.get(name)
        if cfg is None:
            known = ", ".join(f"`{f}`" for f in fields) or "<none>"
            raise RevlError(filename, line,
                            f"`{name}` is not a config field of {comp.name}",
                            hint=f"config fields of {comp.name}: {known}")
        if name in given:
            raise RevlError(filename, line, f"duplicate config field `{name}`")
        check_ast(value, cfg.type, type_env, types, filename,
                  f"config field `{name}` of {comp.name}")
        given[name] = _lower_pure_expr(value, scope, callables, {}, filename, type_env, types)
    missing = [cfg.name for cfg in comp.config if cfg.default is None and cfg.name not in given]
    if missing:
        listed = ", ".join(f"`{name}`" for name in missing)
        raise RevlError(filename, stmt.line,
                        f"`load {comp.name}` is missing required config {listed}",
                        hint=f"write `load {comp.name} with {{ {missing[0]}: ... }}`")
    return given


def _lower_lifecycle_call(stmt: CallStmt, provided: dict, components: dict, services: dict,
                          filename: str, scope: dict, callables: set,
                          type_env: dict, types: dict) -> dict:
    """Check and lower `call key.op(args)` / `let x = call key.op(args)`.

    A lifecycle test drives the composition from *outside* it — it is not a
    provider — so G4's `emit` marker does not apply here: the bound G4
    enforces is a service declaration bounding *its providers*, and a test has
    no declaration to exceed (§7.1).
    """
    owner = provided.get(stmt.key)
    if owner is None:
        keys = sorted({key for comp in components.values() for key, _s, _l in comp.provides})
        if stmt.key in keys:
            raise RevlError(
                filename, stmt.line,
                f"no provider for key `{stmt.key}` at this point",
                hint="load the component that provides it before calling through the key",
            )
        listed = ", ".join(f"`{key}`" for key in keys) or "<none>"
        raise RevlError(filename, stmt.line,
                        f"unknown provision key `{stmt.key}`",
                        hint=f"keys provided in this document: {listed}")
    comp = components[owner]
    service_name = next(svc for key, svc, _line in comp.provides if key == stmt.key)
    svc = services.get(service_name)
    if svc is None:  # pragma: no cover — checked when the component was lowered
        raise RevlError(filename, stmt.line, f"unknown service `{service_name}`")
    method = svc.methods.get(stmt.method)
    if method is None:
        listed = ", ".join(f"`{name}`" for name in svc.methods) or "<none>"
        raise RevlError(filename, stmt.line,
                        f"`{stmt.key}.{stmt.method}` is not an operation of service "
                        f"{service_name}",
                        hint=f"operations of {service_name}: {listed}")
    if len(stmt.args) != len(method.params):
        raise RevlError(filename, stmt.line,
                        f"`{stmt.key}.{stmt.method}` takes {len(method.params)} "
                        f"argument(s), {len(stmt.args)} given")
    args = []
    for arg, (pname, ptype) in zip(stmt.args, method.params):
        check_ast(arg, ptype, type_env, types, filename,
                  f"`{stmt.key}.{stmt.method}` argument `{pname}`")
        args.append(_lower_pure_expr(arg, scope, callables, {}, filename, type_env, types))
    node = {"step": "call", "key": stmt.key, "method": stmt.method, "args": args}
    if stmt.bind is not None:
        if stmt.bind in scope:
            raise RevlError(filename, stmt.line,
                            f"`{stmt.bind}` is already declared in this lifecycle test",
                            hint="bindings are test-scoped, not block-scoped — "
                                 "sibling branches share one namespace; rename "
                                 "or reuse the existing binding")
        scope[stmt.bind] = False
        if method.returns:
            type_env[stmt.bind] = method.returns
        node["bind"] = _predeclared_mangle(stmt.bind)
    return node


def _bool_cond(expr, type_env: dict, types: dict, filename: str, where: str) -> None:
    # a condition is a check position like any other: `if (hole "…")` is a
    # `Bool` obligation, not an untyped hole (docs/holes.md)
    if pin_hole(expr, "Bool", filename, f"`{where}` condition"):
        return
    t = infer_ast(expr, type_env, types, filename)
    if t is not None and t != "Bool":
        raise mismatch(filename, getattr(expr, "line", 0), f"`{where}` condition", "Bool", t)


# ------------------------------------- item 485: `List` index bounds (#938)
#
# `["a"][5]`, and `xs[0 - 1]` with `xs` a list literal in scope, are indexes
# the checker can see fall outside the only domain a `List` index has:
# `0 .. len - 1`. Every tier faults on them, and not even uniformly — py/go/
# rust/java raise, ts reads `undefined` and wasm reads `0`, which is the
# `xs[5]` drift `tests/test_cross_tier_execution.py` records as still needing
# "a static emitted-code guard per tier". The `Str` arm of `infer_ast` already
# refuses a literal index on a known receiver with a coded `T1` (issue #938
# row 4); this is that same refusal for `List`, where the length is known.
#
# An index that is not a foldable literal — `xs[i]`, `xs[f()]` — is
# deliberately untouched. Bounds are not a static property in general, and the
# runtime fault for that case stays pinned by `AGREED_549`. The pass runs over
# a fn/test/prop-test body *before* it is lowered, so a refused program never
# reaches an emitter (the issue's acceptance half is the frontend).

_FOLD_OPS = {
    "+": lambda a, b: a + b,
    "-": lambda a, b: a - b,
    "*": lambda a, b: a * b,
}


def _index_const(expr):
    """The `int` an index expression folds to, or `None` when the checker
    cannot trust a value for it.

    Only total operations over integer literals are folded (`5`, `0 - 1`,
    `2 * 3`). A division, a variable, or a call is not: a fold the runtime
    could disagree with would refuse a program that runs."""
    if isinstance(expr, ExprLit):
        value = expr.value
        return value if isinstance(value, int) and not isinstance(value, bool) else None
    if isinstance(expr, ExprUn) and expr.op in ("-", "+"):
        inner = _index_const(expr.operand)
        if inner is None:
            return None
        return -inner if expr.op == "-" else inner
    if isinstance(expr, ExprBin) and expr.op in _FOLD_OPS:
        left = _index_const(expr.left)
        right = _index_const(expr.right)
        if left is None or right is None:
            return None
        return _FOLD_OPS[expr.op](left, right)
    return None


def _indexed_len(target, lens: dict):
    """The known length of the list an index expression reads, or `None`.

    A list literal is its own length; a name is its length only if the binding
    in scope was a list literal and has not been reassigned since."""
    if isinstance(target, ExprList):
        return len(target.items)
    if isinstance(target, ExprVar):
        return lens.get(target.name)
    return None


def _refuse_index_bounds(filename: str, line: int, index: int, length: int) -> None:
    if length == 0:
        detail = "it is empty"
    elif index < 0:
        detail = ("a `List` index counts from the front — a negative index "
                  "faults on every tier (docs/contract-errata.md §549)")
    else:
        detail = f"the only valid indexes are 0 .. {length - 1}"
    raise RevlError(
        filename, line,
        f"index {index} is out of range for a {length}-element `List` — {detail}",
        hint="a `List` index is bounded by the list's length; read a shorter "
             "index, or guard the read with `xs.length()` first "
             "(docs/stdlib-2.0.md § The surface)",
        code="T1", category="type-mismatch",
    )


def _scan_index_bounds(expr, lens: dict, filename: str) -> None:
    """Walk one expression, refusing a `List` index that is provably outside
    `0 .. len - 1`. `lens` maps a name in scope to the length of the list
    literal it was bound to.

    Unrecognized node types are skipped rather than guessed at: a shape this
    walk does not know is an unchecked index (a gap), never a wrong refusal."""
    if isinstance(expr, ExprIndex):
        index = _index_const(expr.index)
        if index is not None:
            length = _indexed_len(expr.target, lens)
            if length is not None and not 0 <= index < length:
                _refuse_index_bounds(filename, expr.line, index, length)
        _scan_index_bounds(expr.target, lens, filename)
        _scan_index_bounds(expr.index, lens, filename)
    elif isinstance(expr, ExprBin):
        _scan_index_bounds(expr.left, lens, filename)
        _scan_index_bounds(expr.right, lens, filename)
    elif isinstance(expr, ExprUn):
        _scan_index_bounds(expr.operand, lens, filename)
    elif isinstance(expr, ExprCall):
        _scan_index_bounds(expr.callee, lens, filename)
        for arg in expr.args:
            _scan_index_bounds(arg, lens, filename)
    elif isinstance(expr, (ExprField, ExprOptField)):
        _scan_index_bounds(expr.target, lens, filename)
    elif isinstance(expr, ExprOptCall):
        _scan_index_bounds(expr.target, lens, filename)
        for arg in expr.args:
            _scan_index_bounds(arg, lens, filename)
    elif isinstance(expr, ExprIf):
        _scan_index_bounds(expr.cond, lens, filename)
        _scan_index_bounds(expr.then, lens, filename)
        _scan_index_bounds(expr.otherwise, lens, filename)
    elif isinstance(expr, ExprList):
        for item in expr.items:
            _scan_index_bounds(item, lens, filename)
    elif isinstance(expr, ExprRecord):
        for _, value in expr.fields:
            _scan_index_bounds(value, lens, filename)
    elif isinstance(expr, ExprRecordUpdate):
        _scan_index_bounds(expr.base, lens, filename)
        for _, value in expr.updates:
            _scan_index_bounds(value, lens, filename)
    elif isinstance(expr, ExprEndorse):
        _scan_index_bounds(expr.expr, lens, filename)
    elif isinstance(expr, Interp):
        for kind, part in expr.parts:
            if kind == "expr":
                _scan_index_bounds(part, lens, filename)
    elif isinstance(expr, ExprArrow):
        # an arrow body is either an expression or a statement block; a block
        # is checked by `_scan_index_bounds_body`, which owns the scoping
        _scan_index_bounds_body_of(expr.body, lens, filename)
    elif isinstance(expr, ExprMatch):
        _scan_index_bounds(expr.scrutinee, lens, filename)
        for _, _, arm_body in expr.arms:
            _scan_index_bounds_body_of(arm_body, lens, filename)
    elif isinstance(expr, ExprBlockArm):
        _scan_index_bounds_body_of(expr, lens, filename)


def _scan_index_bounds_body_of(node, lens: dict, filename: str) -> None:
    """Dispatch a body position that is either an expression or a statement
    block. A block gets a child scope: its own `let`s must not leak out."""
    if isinstance(node, ExprBlockArm):
        inner = dict(lens)
        _scan_index_bounds_body(node.stmts, inner, filename)
        _scan_index_bounds(node.tail, inner, filename)
    elif isinstance(node, list):
        inner = dict(lens)
        _scan_index_bounds_body(node, inner, filename)
    elif node is not None:
        _scan_index_bounds(node, lens, filename)


def _scan_index_bounds_body(stmts: list, lens: dict, filename: str) -> None:
    """Walk a statement list in order, tracking which names are bound to a list
    literal of a known length. A binding is forgotten the moment it is
    reassigned or shadowed, so a stale length can never refuse a live program.

    Statement kinds this walk does not know are skipped (a gap, not a wrong
    refusal); the acquisition-shaped kinds never appear in the fn/test/prop-test
    bodies this pass is run over."""
    for stmt in stmts:
        if isinstance(stmt, LetStmt):
            _scan_index_bounds(stmt.value, lens, filename)
            # Only an IMMUTABLE binding is tracked. `var` is excluded because a
            # nested block can reassign it (`var xs = []` … `xs = xs.push(v)`
            # inside a `while`), and this walk gives each nested block its own
            # scope copy — so the enclosing scope would keep a stale length and
            # refuse a live program. A `let` binds once and cannot be reassigned,
            # so its literal length is true for the whole scope.
            if isinstance(stmt.value, ExprList) and not stmt.mutable:
                lens[stmt.name] = len(stmt.value.items)
            else:
                lens.pop(stmt.name, None)
        elif isinstance(stmt, LetPatternStmt):
            _scan_index_bounds(stmt.value, lens, filename)
            # a destructured binding has parts whose lengths are not tracked
            for name in _pattern_bound_names(stmt.pattern):
                lens.pop(name, None)
        elif isinstance(stmt, AssignStmt):
            _scan_index_bounds(stmt.value, lens, filename)
            # only a `var` is assignable, and `var` is never tracked, so an
            # assignment can only ever forget a name
            lens.pop(stmt.name, None)
        elif isinstance(stmt, (ExprStmt, AssertStmt, AwaitStmt)):
            _scan_index_bounds(stmt.expr, lens, filename)
        elif isinstance(stmt, FailStmt):
            _scan_index_bounds(stmt.message, lens, filename)
        elif isinstance(stmt, ReturnStmt):
            if stmt.expr is not None:
                _scan_index_bounds(stmt.expr, lens, filename)
        elif isinstance(stmt, IfStmt):
            _scan_index_bounds(stmt.cond, lens, filename)
            # each arm is its own block, exactly as `_lower_pure_stmt` scopes it
            _scan_index_bounds_body(stmt.then, dict(lens), filename)
            if stmt.otherwise:
                _scan_index_bounds_body(stmt.otherwise, dict(lens), filename)
        elif isinstance(stmt, WhileStmt):
            _scan_index_bounds(stmt.cond, lens, filename)
            _scan_index_bounds_body(stmt.body, dict(lens), filename)
        elif isinstance(stmt, ForStmt):
            _scan_index_bounds(stmt.iterable, lens, filename)
            inner = dict(lens)
            inner.pop(stmt.bind, None)
            _scan_index_bounds_body(stmt.body, inner, filename)
        elif isinstance(stmt, LetEffect):
            _scan_index_bounds(stmt.acquire, lens, filename)
            if isinstance(stmt.acquire, SpawnExpr):
                for value in stmt.acquire.config.values():
                    _scan_index_bounds(value, lens, filename)
            _scan_index_bounds(stmt.undo, lens, filename)
            for setup in stmt.setup:
                _scan_index_bounds_body([setup], dict(lens), filename)
        # ---- component activation bodies (the one place `let … = effect { … }`
        # and the rest of the action statements are legal). A component body is
        # an action list, so only the fields that can carry an index expression
        # are walked; `timer.interval_ms` is an int literal by construction, and
        # a `provide` method body is an ordinary statement list.
        elif isinstance(stmt, EffectStmt):
            _scan_index_bounds(stmt.acquire, lens, filename)
            if isinstance(stmt.acquire, SpawnExpr):
                for value in stmt.acquire.config.values():
                    _scan_index_bounds(value, lens, filename)
            _scan_index_bounds(stmt.undo, lens, filename)
            for setup in stmt.setup:
                _scan_index_bounds_body([setup], dict(lens), filename)
        elif isinstance(stmt, EmitStmt):
            _scan_index_bounds(stmt.expr, lens, filename)
            _scan_index_bounds(stmt.compensate, lens, filename)
            _scan_index_bounds(stmt.approval, lens, filename)
        elif isinstance(stmt, LetApprovalStmt):
            _scan_index_bounds(stmt.request, lens, filename)
        elif isinstance(stmt, TimerStmt):
            _scan_index_bounds_body(stmt.body, dict(lens), filename)
        elif isinstance(stmt, StreamIterStmt):
            _scan_index_bounds(stmt.subject, lens, filename)
            inner = dict(lens)
            inner.pop(stmt.bind, None)
            _scan_index_bounds_body(stmt.body, inner, filename)
        elif isinstance(stmt, ProvideStmt):
            for method in stmt.methods:
                inner = dict(lens)
                for param in method.params:
                    inner.pop(param, None)
                _scan_index_bounds_body(method.body, inner, filename)


def check_list_index_bounds(stmts: list, filename: str) -> None:
    """Refuse a `List` index that is statically outside `0 .. len - 1`
    (roadmap item 485, issue #938). Runs over a body before it is lowered."""
    _scan_index_bounds_body(stmts, {}, filename)


def _pattern_bound_names(pattern) -> list[str]:
    """Every name a `let` destructuring pattern binds. Both shapes are
    `list[str]`-valued, so no element of a destructured binding is ever a list
    literal whose length this pass could track."""
    if isinstance(pattern, RecordPattern):
        return list(pattern.fields)
    if isinstance(pattern, ListPattern):
        names = list(pattern.binds)
        if pattern.rest:
            names.append(pattern.rest)
        return names
    return []


def _lower_pure_stmt(stmt, scope: dict, callables: set, alias_fns: dict, body: list, filename: str,
                     type_env: dict | None = None, types: dict | None = None,
                     expected_return: str | None = None) -> None:
    type_env = type_env if type_env is not None else {}
    types = types if types is not None else {}
    if isinstance(stmt, LetStmt):
        if stmt.name in scope:
            raise RevlError(filename, stmt.line,
                            f"`{stmt.name}` is already declared in this function",
                            hint="a `let` binds a name once per scope — rename this "
                                 "binding, or use `=` to reassign an existing `var`. "
                                 "(Disjoint sibling blocks — the two arms of an "
                                 "if/else — may reuse a name, since only one is live.)")
        # host provenance: a let bound to a host constructor call carries
        # host-object methods, exempt from the stdlib method table
        if not stmt.mutable and _is_host_valued(stmt.value, scope):
            scope[stmt.name] = "host"
        else:
            scope[stmt.name] = stmt.mutable
        declared = getattr(stmt, "type", None)
        if declared is not None:
            # `let g: (Int) -> Int = v => v + 1` — the annotation is the
            # checking position for the right-hand side, which is what gives an
            # un-annotated arrow its parameter and return types.
            check_type_wellformed(filename, stmt.line, declared)
            check_ast(stmt.value, declared, type_env, types, filename,
                      f"`let {stmt.name}: {render_type(declared)}`")
            type_env[stmt.name] = declared
            actual_declared = infer_ast(stmt.value, type_env, types, None)
        else:
            inferred = infer_ast(stmt.value, type_env, types, filename)
            if inferred is not None:
                type_env[stmt.name] = inferred
            actual_declared = None
        lowered_value = _lower_pure_expr(stmt.value, scope, callables, alias_fns, filename, type_env, types)
        # an annotated `let x: Float = 3` is a coercion site too (docs/arithmetic.md)
        _mark_widen(declared, actual_declared, lowered_value)
        _pin_empty_literal(declared, lowered_value)
        body.append({"step": "let", "name": _predeclared_mangle(stmt.name),
                     "value": lowered_value,
                     "mutable": stmt.mutable})
    elif isinstance(stmt, LetPatternStmt):
        _lower_let_pattern_stmt(stmt, scope, callables, alias_fns, body, filename, type_env, types)
    elif isinstance(stmt, AssignStmt):
        if stmt.name not in scope:
            _reject_foreign_name(stmt.name, filename, stmt.line)  # item 384
            raise RevlError(filename, stmt.line, f"`{stmt.name}` is not declared in this function",
                            hint="declare it with `let` (single-assignment) or `var` (mutable)")
        if not scope[stmt.name]:
            raise RevlError(filename, stmt.line,
                            f"cannot reassign `{stmt.name}` — it is `let` (single-assignment)",
                            hint="declare it with `var` to make it mutable (syntax-2.0 §3.5)")
        if stmt.op == "=":
            value = stmt.value
        else:
            # `x += e` desugars to `x = x + e`; the parser only composes the
            # operator, so lowering never has to remember it beyond this point.
            value = ExprBin(stmt.op[:-1], ExprVar(stmt.name, stmt.line), stmt.value, stmt.line)
        declared = type_env.get(stmt.name)
        if isinstance(value, ExprArrow) and declared:
            # reassigning a `var` of function type: the arrow needs the
            # declaration as its *checking* position, exactly as at the `let`.
            # Inference alone returns nothing for an un-annotated arrow, so the
            # comparison below would pass anything (docs/function-types.md).
            check_ast(value, declared, type_env, types, filename,
                      f"assignment to `{stmt.name}` (a `{render_type(declared)}` variable)")
        inferred = infer_ast(value, type_env, types, filename)
        if declared and inferred and not compatible(declared, inferred, types):
            # `var m = Map.empty()` / `var xs = []` type the binding at the
            # checker's inferred BOTTOM. The accumulator idiom names the
            # element type at the first reassignment, so a value that only
            # FILLS those bottoms widens the binding instead of being refused
            # (`m = m.set(k, 1)` makes `m` a `Map[Str, Int]` from here on, and
            # `return m` is then judged against the real element type).
            widened = widen_bottom(declared, inferred, types)
            if widened is None:
                raise mismatch(filename, stmt.line,
                               f"assignment to `{stmt.name}` (a `{render_type(declared)}` variable)",
                               declared, inferred)
            type_env[stmt.name] = widened
            declared = widened
        if inferred is not None and declared is None:
            type_env[stmt.name] = inferred
        lowered_value = _lower_pure_expr(value, scope, callables, alias_fns, filename, type_env, types)
        # assigning into a `Float`-declared variable is a coercion site too
        _mark_widen(declared, inferred, lowered_value)
        body.append({"step": "assign", "name": _predeclared_mangle(stmt.name),
                     "value": lowered_value})
    elif isinstance(stmt, ReturnStmt):
        if stmt.expr is not None:
            check_ast(stmt.expr, expected_return, type_env, types, filename, "this function's return")
        elif expected_return:
            raise RevlError(filename, stmt.line,
                            f"bare `return` in a function declared to return `{expected_return}`")
        lowered = (None if stmt.expr is None else
                   _lower_pure_expr(stmt.expr, scope, callables, alias_fns,
                                    filename, type_env, types))
        if lowered is not None and expected_return:
            actual_ret = infer_ast(stmt.expr, type_env, types, filename)
            # `return 3` in a `-> Float` fn is a coercion site (docs/arithmetic.md)
            _mark_widen(expected_return, actual_ret, lowered)
            lowered = _inject_opt(expected_return,
                                  actual_ret,
                                  lowered)
        body.append({"step": "return", "expr": lowered})
    elif isinstance(stmt, IfStmt):
        then: list[dict] = []
        _bool_cond(stmt.cond, type_env, types, filename, "if")
        # Each arm is its own block: it snapshots the enclosing scope/type_env
        # (as `while`/`for`/`match` arms already do) rather than sharing one flat
        # dict. This block-scopes the arm's `let`s — they do not leak past the
        # `if`, and the two arms cannot collide with each other, so disjoint
        # sibling branches may reuse a name. A redeclaration *within* one arm, or
        # in one straight-line scope, still hits the guard: the snapshot is
        # mutated in sequence, so the second `let` sees the first.
        then_scope = dict(scope)
        then_type_env = dict(type_env)
        for s in stmt.then:
            _lower_pure_stmt(s, then_scope, callables, alias_fns, then, filename, then_type_env, types, expected_return)
        otherwise = None
        if stmt.otherwise is not None:
            otherwise = []
            else_scope = dict(scope)
            else_type_env = dict(type_env)
            for s in stmt.otherwise:
                _lower_pure_stmt(s, else_scope, callables, alias_fns, otherwise, filename, else_type_env, types, expected_return)
        body.append({"step": "if", "cond": _lower_pure_expr(stmt.cond, scope, callables, alias_fns, filename, type_env, types),
                     "then": then, "else": otherwise})
    elif isinstance(stmt, WhileStmt):
        _bool_cond(stmt.cond, type_env, types, filename, "while")
        cond = _lower_pure_expr(stmt.cond, scope, callables, alias_fns, filename, type_env, types)
        inner_scope = dict(scope)
        inner_type_env = dict(type_env)
        inner_body: list[dict] = []
        for s in stmt.body:
            _lower_pure_stmt(s, inner_scope, callables, alias_fns, inner_body, filename, inner_type_env, types, expected_return)
        body.append({"step": "while", "cond": cond, "body": inner_body})
    elif isinstance(stmt, ForStmt):
        if stmt.bind in scope:
            raise RevlError(filename, stmt.line,
                            f"`{stmt.bind}` is already declared in this function",
                            hint="a loop binding shadows nothing already in scope — "
                                 "rename it. (Disjoint sibling blocks may reuse a "
                                 "name, since only one is live.)")
        iter_diag = infer_ast(stmt.iterable, type_env, types, filename)
        if iter_diag is not None and parse_type(iter_diag)[0] != "List":
            raise RevlError(filename, stmt.line,
                            f"`for ... of` iterates a `List[...]`, got `{render_type(iter_diag)}`")
        iterable = _lower_pure_expr(stmt.iterable, scope, callables, alias_fns, filename, type_env, types)
        inner_scope = dict(scope)
        inner_type_env = dict(type_env)
        inner_scope[stmt.bind] = False
        iter_type = _expr_static_type(stmt.iterable, type_env, types)
        element_type = _type_arg(iter_type, "List")
        if element_type is not None:
            inner_type_env[stmt.bind] = element_type
        inner_body = []
        for s in stmt.body:
            _lower_pure_stmt(s, inner_scope, callables, alias_fns, inner_body, filename, inner_type_env, types, expected_return)
        body.append({"step": "for", "bind": _predeclared_mangle(stmt.bind),
                     "iterable": iterable, "body": inner_body})
    elif isinstance(stmt, ExprStmt):
        infer_ast(stmt.expr, type_env, types, filename)
        body.append({"step": "expr", "expr": _lower_pure_expr(stmt.expr, scope, callables, alias_fns, filename, type_env, types)})
    elif isinstance(stmt, AssertStmt):
        _bool_cond(stmt.expr, type_env, types, filename, "assert")
        body.append({"step": "assert", "expr": _lower_pure_expr(stmt.expr, scope, callables, alias_fns, filename, type_env, types)})
    elif isinstance(stmt, BreakStmt):
        # item 379: additive step kind, no payload. The parser already refused a
        # `break` outside a loop, so lowering only records it; teardown is
        # untouched (break/continue are frame-neutral — no revl teardown
        # boundary coincides with a loop boundary, docs/design/379-break-
        # continue.md Decision 1).
        body.append({"step": "break", "line": stmt.line})
    elif isinstance(stmt, ContinueStmt):
        body.append({"step": "continue", "line": stmt.line})
    else:  # pragma: no cover — grammar prevents it
        raise RevlError(filename, getattr(stmt, "line", 1), "unexpected statement in fn body")


def _lower_let_pattern_stmt(stmt: LetPatternStmt, scope: dict, callables: set, alias_fns: dict,
                            body: list, filename: str, type_env: dict, types: dict) -> None:
    """Lower a `let`/`var` destructuring to one ``let_pattern`` step."""
    pattern = stmt.pattern
    if isinstance(pattern, RecordPattern):
        names = list(pattern.fields)
        if not names:
            raise RevlError(filename, pattern.line, "record destructuring needs at least one field")
        if len(set(names)) != len(names):
            raise RevlError(filename, pattern.line, "duplicate name in record destructuring")
        for name in names:
            if name in scope:
                raise RevlError(filename, stmt.line,
                                f"`{name}` is already declared in this function",
                                hint="a `let` binds a name once per scope — rename this "
                                     "binding, or use `=` to reassign an existing `var`. "
                                     "(Disjoint sibling blocks may reuse a name, since "
                                     "only one is live.)")
        value_type = _expr_static_type(stmt.value, type_env, types)
        spec = types.get(value_type or "")
        if spec is not None:
            if spec.get("kind") != "record":
                raise RevlError(
                    filename, stmt.line,
                    f"record destructuring requires a record, but `{render_type(value_type)}` is not a record",
                )
            fields = spec.get("fields", {})
            for name in names:
                if name not in fields:
                    raise RevlError(filename, pattern.line,
                                    f"`{name}` is not a field of record `{render_type(value_type)}`")
        elif value_type is not None and parse_type(value_type)[0] in _BUILTIN_NONRECORD:
            raise RevlError(
                filename, stmt.line,
                f"record destructuring requires a record, but `{render_type(value_type)}` is not a record",
            )
        value_ir = _lower_pure_expr(stmt.value, scope, callables, alias_fns, filename, type_env, types)
        for name in names:
            scope[name] = stmt.mutable
            if spec is not None:
                type_env[name] = spec.get("fields", {})[name]
        body.append({
            "step": "let_pattern",
            "pattern": "record",
            "names": names,
            "value": value_ir,
            "mutable": stmt.mutable,
        })
        return

    if isinstance(pattern, ListPattern):
        if not pattern.binds:
            raise RevlError(filename, pattern.line,
                            "list destructuring needs at least one binding before `...rest`")
        names = list(pattern.binds)
        if pattern.rest is not None:
            names.append(pattern.rest)
        if len(set(names)) != len(names):
            raise RevlError(filename, pattern.line, "duplicate name in list destructuring")
        for name in names:
            if name in scope:
                raise RevlError(filename, stmt.line,
                                f"`{name}` is already declared in this function",
                                hint="a `let` binds a name once per scope — rename this "
                                     "binding, or use `=` to reassign an existing `var`. "
                                     "(Disjoint sibling blocks may reuse a name, since "
                                     "only one is live.)")
        value_type = _expr_static_type(stmt.value, type_env, types)
        if value_type is not None and parse_type(value_type)[0] != "List" and (
            types.get(value_type) is not None
            or parse_type(value_type)[0] in _BUILTIN_NONRECORD
        ):
            raise RevlError(
                filename, stmt.line,
                f"list destructuring requires a `List[...]`, but `{render_type(value_type)}` is not a list",
            )
        value_ir = _lower_pure_expr(stmt.value, scope, callables, alias_fns, filename, type_env, types)
        element_type = _type_arg(value_type, "List")
        for name in pattern.binds:
            scope[name] = stmt.mutable
            if element_type is not None:
                type_env[name] = element_type
        if pattern.rest is not None:
            scope[pattern.rest] = stmt.mutable
            if value_type is not None:
                type_env[pattern.rest] = value_type
        body.append({
            "step": "let_pattern",
            "pattern": "list",
            "names": pattern.binds,
            "rest": pattern.rest,
            "value": value_ir,
            "mutable": stmt.mutable,
        })
        return

    raise RevlError(filename, stmt.line, "unexpected destructuring pattern")


def _tagged_case(name: str, types: dict) -> dict | None:
    """If `name` is a *tagged* ADT constructor — the built-in `Result`
    (`Ok`/`Err`) or any user variant case — return its case-table entry.
    `Opt` (`Some`/`None`) is not tagged: it stays host-null/value, so it is
    excluded here and handled as identity/null."""
    if name in ("Some", "None"):
        return None
    return (types.get(CASES_KEY) or {}).get(name)


def _lower_hole(expr: ExprHole, filename: str) -> dict:
    """`hole` -> the IR's one non-executable node (docs/holes.md).

    A hole must know its type by now: the checker pins it from context in
    check position, and `hole[T]` states it outright. Anywhere else the
    honest answer is a rejection — guessing would hand the author a type the
    compiler invented, which is exactly the drowning-in-noise failure holes
    exist to fix.
    """
    type_name = expr.known_type
    if type_name is None:
        raise RevlError(
            filename, expr.line,
            "this `hole` has no expected type — nothing in its context says "
            "what it must eventually be",
            hint="annotate it (`hole[Str] \"why\"`), or put it somewhere with a "
                 "declared type: a `fn`'s `-> T`, a service method's return, or "
                 "an argument of a declared function (docs/holes.md)",
            code="T3", category="hole",
        )
    check_type_wellformed(filename, expr.line, type_name)
    node = {"kind": "hole", "type": type_name, "file": filename, "line": expr.line}
    if expr.message is not None:
        node["message"] = expr.message
    return node


def _retarget_holes(node, source: str) -> None:
    """Point holes at the file they were written in.

    Lowering runs over one merged program, so its `filename` is the first
    root path; a declaration carries its own provenance and an obligation an
    agent must go and fill is worthless with the wrong path on it.
    """
    if isinstance(node, dict):
        if node.get("kind") == "hole":
            node["file"] = source
        for value in node.values():
            _retarget_holes(value, source)
    elif isinstance(node, list):
        for value in node:
            _retarget_holes(value, source)


# Operators whose meaning depends on whether the operands are Int or Float.
# `/` and `%` because integer and float division differ; `+`, `-` and `*`
# because Int is a *bounded* 64-bit type whose overflow traps, and a tier
# cannot check a bound it does not know applies. Booleans gain nothing from
# the annotation, so they do not carry it.
_TYPED_ARITH_OPS = ("/", "%", "+", "-", "*")

# Relational comparison needs the operand type for ONE family: `Str`. The
# order revl promises is lexicographic by CODE POINT (docs/strings.md — the
# same unit `length`/`charAt`/`slice` count in), and three tiers get that free
# from their host (python compares code points; go and rust compare UTF-8
# bytes, which is the same order). Two do not:
#   - TypeScript's `<` on a string compares UTF-16 CODE UNITS, so
#     `"￿" < "\u{10000}"` is `false` there and `true` everywhere else — a
#     silent wrong answer at the BMP/supplementary boundary.
#   - Java has no relational operator on `String` at all, so `a < b` reached
#     `javac` as "bad operand types for binary operator '<'": the document
#     compiled on five tiers and would not build on the sixth.
# Neither tier can tell a `Str` comparison from an `Int` one at the `bin` node
# (relational nodes carried no type), which is the same missing-information
# shape `_TYPED_ARITH_OPS` exists for — so the annotation is spelled the same
# way, on the same key, and is additive (no ir_version bump), exactly as
# `widen` and `key_type` were. wasm refuses the form by name and keeps doing
# so; a refusal is honest where a wrong answer is not.
_RELATIONAL_OPS = ("<", ">", "<=", ">=")


def _str_literal_value(value):
    """Canonical IR form for a `Str` literal: a sequence of Unicode scalar
    values (code points), never UTF-16 surrogate pairs (docs/strings.md,
    roadmap item 51 — the string wave).

    The lexer stores raw source characters and a Python `str` is already a
    code-point sequence, so for a well-formed program this is the identity.
    It is stated explicitly here because it is the invariant every backend's
    literal escaper depends on: each emitter reads this value and must escape
    *from code points* (`\\u{1F600}` on rust, `\\U0001F600` on go, the raw
    scalar in wasm's UTF-8 pool), never re-encode it as UTF-16. A lone
    surrogate reaching this point would mean an upstream path re-introduced
    UTF-16 — the exact defect that made astral literals uncompilable on go and
    rust — so it is rejected here rather than emitted as invalid source.
    """
    if isinstance(value, str):
        for ch in value:
            if 0xD800 <= ord(ch) <= 0xDFFF:
                raise ValueError(
                    "string literal carries a lone surrogate; a Str literal is "
                    "a sequence of Unicode code points (docs/strings.md)")
    return value


def _literal_value(value, filename: str | None, line: int):
    """The IR form of a literal, carrying the refusals a literal value itself
    can earn. Every `lit` node the frontend builds goes through here, so the
    IR handed to a backend can never carry a value no tier can spell.

    Two of them today: a lone surrogate in a `Str` (above, an upstream-defect
    invariant) and a non-finite `Float`. The Float bound is also enforced in
    the checker, where it produces the diagnostic a reader sees; this is the
    choke point that makes it exhaustive, because a literal in a position the
    checker never infers still lands here (issue #312).
    """
    if isinstance(value, float):
        _reject_float_literal_range(filename, line, value)
    return _str_literal_value(value)


def _mark_widen(expected: str | None, actual: str | None, node: dict | None) -> dict | None:
    """Mark an implicit `Int` -> `Float` coercion site in the IR.

    `compatible` lets an `Int` stand where a `Float` is declared, but until
    now the widening was invisible: a `call` argument, a `let` value or a
    `return` expression reached every backend as a bare `lit`/`var`, and the
    tiers that keep `Int` and `Float` apart split three ways on `ident(3)`
    (docs/arithmetic.md) — rust refused with E0308, TypeScript computed the
    wrong answer (`3n === 3` is false), and python/go/java absorbed it behind
    a host rule. This is the same shape of gap `operands` closed for `/`, and
    it closes the same way: the frontend — the single IR producer, and the
    only stage that knows both types — annotates the coercion site, and every
    backend can emit the conversion.

    The marker is additive (`"widen": "Float"` on the coerced node), so no
    `ir_version` changes and v1/v2/v3 reference documents stay
    byte-identical: a coercion site requires a declared `Float` position,
    which only full-language (v3) sources can express.
    """
    if node is None:
        return node
    ehead = parse_type(expected)[0]
    ahead = parse_type(actual)[0]
    if ehead == "Float" and ahead in ("Int", "Int32"):
        node["widen"] = "Float"
    elif ehead == "Int" and ahead == "Int32":
        # Int32 -> Int is a lossless *widening* the tiers that keep the two
        # widths apart (rust i32/i64, wasm, go, java, ts number/bigint) must
        # emit explicitly, exactly as Int -> Float is marked. `"widen": "Int"`
        # names the target width; python absorbs it (one int type).
        node["widen"] = "Int"
    return node


def _pin_empty_literal(declared: str | None, node: dict | None) -> None:
    """An annotated `let`/`var` pins an empty-collection literal (roadmap 76b, 107).

    `var m: Map[Str, Int] = Map.empty()` lowers to a `maplit` node that knows
    nothing about the author's annotation — the checker accepts the empty map
    (it types `Map[Str, Never]`, bottom, and flows into any `Map[K, V]`) but
    the go tier refuses an unpinned empty Map because Go infers composite
    literals positionally, not from later use. The annotation the author
    already wrote is the pin, so the frontend — the single IR producer, and
    the only stage that knows the declared type — attaches it to the literal:
    ``"expected": "Map[Str, Int]"`` on the `maplit` node. The marker is
    additive and appears only where an annotation exists, so v1/v2/v3
    reference documents without one stay byte-identical.
    """
    if declared is None or not isinstance(node, dict):
        return
    kind = node.get("kind")
    if kind == "maplit":
        node["expected"] = declared
    elif (
        kind == "list"
        and not (node.get("items") or [])
        and declared.startswith("List[")
    ):
        # `var out: List[Int] = []` (roadmap 107): the checker accepts the empty
        # list (it types `List[Never]`, bottom, and flows into any `List[T]`) but
        # a positional emitter — the wasm tier — has no element to infer from and
        # refuses. The author's annotation is the pin, threaded onto the literal
        # exactly as the empty-Map case above, so the emitter can type it.
        node["expected"] = declared


def _lower_pure_expr(expr, scope: dict, callables: set, alias_fns: dict, filename: str,
                     type_env: dict | None = None, types: dict | None = None) -> dict:
    type_env = type_env if type_env is not None else {}
    types = types if types is not None else {}
    if isinstance(expr, ExprHole):
        return _lower_hole(expr, filename)
    if isinstance(expr, ExprEndorse):
        inner = _lower_pure_expr(expr.expr, scope, callables, alias_fns, filename,
                                 type_env, types)
        if expr.approval is not None:
            # approvals are acquired in a component activation body (item 246),
            # not in a top-level `fn`; a `with` here has nothing to bind.
            raise RevlError(
                filename, expr.line,
                "`endorse ... with <approval>` is only available in a component "
                "or provide-method body — a top-level `fn` cannot acquire an "
                "`Approval[C]`",
                hint="move the approval-gated endorse into the provide method, or "
                     "drop the `with` clause (item 246/249)")
        return _endorse_node(inner, expr, None)
    # ADT construction (Result / user variants) lowers to a tagged `adt` node
    # (Opt's Some/None are not tagged — handled as identity/null downstream).
    _cases = types.get(CASES_KEY) or {}
    # A bound local shadows a constructor of the same spelling (issue #320): a
    # parameter `Ok`/`Some`/… is the value, not the variant, so it is resolved
    # as an in-scope `var` below (and renamed by `_predeclared_mangle`), never
    # lowered to an `adt` node here.
    if isinstance(expr, ExprCall) and isinstance(expr.callee, ExprVar) \
            and expr.callee.name not in scope \
            and _tagged_case(expr.callee.name, types) is not None:
        info = _cases[expr.callee.name]
        return {"kind": "adt", "type": info["adt"], "case": expr.callee.name,
                "args": [_lower_pure_expr(a, scope, callables, alias_fns, filename, type_env, types)
                         for a in expr.args]}
    if isinstance(expr, ExprVar) and expr.name not in scope:
        info = _tagged_case(expr.name, types)
        if info is not None and info.get("payload") is None \
                and not str(info.get("adt", "")).startswith(("Result", "Opt")):
            return {"kind": "adt", "type": info["adt"], "case": expr.name, "args": []}
    # Module-namespace call: `alias.fn(args)` desugars to the imported public
    # function by its original name (IR functions are top-level, not nested
    # in namespace objects).
    if (
        isinstance(expr, ExprCall)
        and isinstance(expr.callee, ExprField)
        and isinstance(expr.callee.target, ExprVar)
    ):
        alias = expr.callee.target.name
        if alias in alias_fns:
            name = expr.callee.name
            if name not in alias_fns[alias]:
                raise RevlError(
                    filename,
                    expr.callee.line,
                    f"`{alias}.{name}` is not a public function in module `{alias}`",
                    hint=f"`use ... as {alias}` imports only `pub` declarations (G1)",
                )
            return {
                "kind": "call",
                "callee": {"kind": "var", "name": name},
                "args": [_lower_pure_expr(a, scope, callables, alias_fns, filename, type_env, types) for a in expr.args],
            }
    if isinstance(expr, ExprLit):
        if expr.value is None:
            raise null_error(filename, expr.line)
        return {"kind": "lit", "value": _literal_value(expr.value, filename, expr.line)}
    if isinstance(expr, ExprVar):
        if expr.name not in scope and expr.name not in callables:
            _reject_foreign_name(expr.name, filename, expr.line)  # item 384
            raise RevlError(filename, expr.line, f"`{expr.name}` is not declared in this function",
                            hint="declare it with `let`/`var` or add it as a parameter (G1)")
        # issue #320: an in-scope value binding that spells a host predeclared
        # name is renamed to match its (mangled) declaration; a callable
        # reference (module fn / extern / host) is left verbatim.
        if expr.name in scope:
            return {"kind": "var", "name": _predeclared_mangle(expr.name)}
        return {"kind": "var", "name": expr.name}
    if isinstance(expr, ExprBin):
        node = {"kind": "bin", "op": expr.op,
                "left": _lower_pure_expr(expr.left, scope, callables, alias_fns, filename, type_env, types),
                "right": _lower_pure_expr(expr.right, scope, callables, alias_fns, filename, type_env, types)}
        # `/` and `%` mean different things on Int and Float, and a backend
        # cannot tell them apart from the node alone: python and TypeScript
        # both render `7 / 2` as 3.5 while rust renders 3, and neither is
        # wrong given what it was told. Carrying the *operand* type (not the
        # result) is what makes the arithmetic specifiable at all — see
        # docs/arithmetic.md. Inference runs without a filename so an
        # undetermined operand is an absent annotation, never an error.
        if expr.op in _TYPED_ARITH_OPS:
            left_type = infer_ast(expr.left, type_env, types, None)
            right_type = infer_ast(expr.right, type_env, types, None)
            if left_type == "Int32" and right_type == "Int32":
                # Int32 arithmetic traps at the i32 edge, the same discipline
                # `Int` has at i64 (docs/arithmetic.md). `/` still yields Float
                # and `%` is width-agnostic; only `+ - *` need the i32 helper.
                node["operands"] = "Int32"
            elif left_type == "Int" and right_type == "Int":
                node["operands"] = "Int"
            elif "Float" in (left_type, right_type):
                node["operands"] = "Float"
        elif expr.op in _RELATIONAL_OPS:
            # `Str` ordering is by code point on every tier that lowers it;
            # ts and java need to be told the operands are strings to get
            # there (see _RELATIONAL_OPS). Only `Str` is marked: every other
            # relational operand is a scalar its host already orders the same
            # way revl does.
            if (infer_ast(expr.left, type_env, types, None) == "Str"
                    and infer_ast(expr.right, type_env, types, None) == "Str"):
                node["operands"] = "Str"
        return node
    if isinstance(expr, ExprUn):
        node = {"kind": "un", "op": expr.op,
                "operand": _lower_pure_expr(expr.operand, scope, callables, alias_fns, filename, type_env, types)}
        # Unary minus is arithmetic too: negating Int.MIN overflows, and a
        # backend cannot tell an Int negation from a Float one without the
        # operand type — the same information `bin` carries for the same
        # reason. Only `Int` is annotated: it is the type whose bound a
        # backend must re-impose (docs/arithmetic.md), and no tier needs to
        # treat Float negation specially.
        if expr.op == "-":
            operand_type = infer_ast(expr.operand, type_env, types, None)
            if operand_type in ("Int", "Int32"):
                # `-x` is `0 - x`; on Int32, `0 - Int32.MIN` overflows the i32
                # range just as `0 - Int.MIN` overflows i64, so the bound is
                # re-imposed at the tier (docs/arithmetic.md).
                node["operands"] = operand_type
        return node
    if isinstance(expr, ExprCall):
        _callee = expr.callee
        # the Map VALUE constructor (docs/stdlib-2.0.md §Map): intercepted
        # before the host-receiver test, because `Map` is a host root — but
        # `empty` is a value-namespace name, disjoint from the host verbs.
        if (isinstance(_callee, ExprField)
                and isinstance(_callee.target, ExprVar)
                and _callee.target.name == "Map"
                and _callee.target.name not in scope
                and _callee.name == "empty"):
            if expr.args:
                raise RevlError(
                    filename, expr.line,
                    f"`Map.empty()` takes no arguments, {len(expr.args)} given",
                    hint="build up an empty map with `set`: `Map.empty().set(\"k\", v)`",
                )
            return {"kind": "maplit", "entries": []}
        _host_receiver = isinstance(_callee, ExprField) and (
            _is_host_valued(_callee.target, scope)
            # the constructor root itself (Map.new(), Pool.open(...)):
            or (isinstance(_callee.target, ExprVar)
                and _callee.target.name in _HOST_CALLABLES
                and _callee.target.name not in scope)
        )
        if isinstance(expr.callee, ExprField) and not _host_receiver:
            method = expr.callee.name
            # item 383: receiver-first list transforms (`xs.map(f)` etc.) are
            # SUGAR for their generic free function; desugar to the plain call
            # here (the checker already typed the desugared form) so the
            # existing generic-call path lowers it. Pure syntactic redirect —
            # no builtin-method row, so no new per-backend branch.
            if method in LIST_TRANSFORMS:
                return _lower_pure_expr(desugar_list_transform(expr), scope,
                                        callables, alias_fns, filename,
                                        type_env, types)
            arity = _BUILTIN_METHODS.get(method)
            if arity is None:
                raise RevlError(
                    filename, expr.line,
                    f"no builtin method `{method}` on values — the stdlib surface is "
                    f"{', '.join(sorted(_BUILTIN_METHODS))} (docs/stdlib-2.0.md)",
                    hint="records carry data, not methods; call functions as `f(x)`, "
                         "and call arrows through a `let` binding",
                )
            # The stdlib-named-method sliver (roadmap 75(b)): only a receiver
            # the checker can *prove* is a stdlib value (Str/List/Int/Int32/
            # Bytes/Map) may take the builtin table. A receiver whose
            # provenance no constructor pins — an extern's return, a
            # host-object result, a type parameter — used to lower a
            # stdlib-named method as that builtin and misdispatch at runtime.
            # Refuse it like any other host-boundary method (HOST-METHOD); the
            # fence then closes to exactly "host-object results are on the
            # audit surface" (G8).
            recv_t = _expr_static_type(expr.callee.target, type_env, types)
            if _is_wildcard(recv_t):
                _refuse_unpinned_stdlib_method(method, recv_t, filename,
                                               expr.line)
            if len(expr.args) != arity:
                raise RevlError(filename, expr.line,
                                f"builtin `{method}` takes {arity} argument(s), "
                                f"{len(expr.args)} given")
            _refuse_zero_divisor(method, expr.args, filename, expr.line)
            # Value dot-accessors (roadmap item 189): a `Value` receiver's
            # `.field`/`.str`/`.list`/`.keys` is receiver-first SUGAR for the
            # `value_*` free function — it desugars here to the SAME call IR
            # `value_str(value_field(...))` lowers to, so the emitted code is
            # byte-identical on every tier and no backend needs a new branch.
            # Gated on a proven `Value` receiver: `.keys()` also names a Map
            # builtin, which keeps the generic path below (recv head != Value).
            # `.field`/`.str`/`.list` are Value-only, so the checker already
            # proved the receiver is `Value` by the time lowering runs.
            if method in _VALUE_ACCESSORS and parse_type(recv_t)[0] == "Value":
                return {
                    "kind": "call",
                    "callee": {"kind": "var", "name": _VALUE_ACCESSORS[method]},
                    "args": [_lower_pure_expr(expr.callee.target, scope, callables, alias_fns, filename, type_env, types)]
                    + [_lower_pure_expr(a, scope, callables, alias_fns, filename, type_env, types) for a in expr.args],
                }
            node: dict = {"kind": "builtin", "method": method,
                          "target": _lower_pure_expr(expr.callee.target, scope, callables, alias_fns, filename, type_env, types),
                          "args": [_lower_pure_expr(a, scope, callables, alias_fns, filename, type_env, types) for a in expr.args]}
            if method == "to_int":
                # `to_int` is spelled for two receiver families (Int32 widen,
                # Str parse) — the backends must dispatch on the receiver's
                # static type, which the IR node would otherwise not carry
                # (the same reason `un` annotates Int negation). Annotate it,
                # exactly as the checker selected the row.
                node["recv"] = infer_ast(expr.callee.target, type_env, types, None)
            elif method == "to_str":
                # `to_str` only needs the annotation to tell a Float receiver
                # (which renders through the canonical `ftoa`, byte-identical to
                # a `${aFloat}` interpolation) from an Int one — and only the
                # py/java/rust tiers read it, exclusively as `recv == "Float"`.
                # Every other receiver renders the same with or without the tag,
                # so it is attached ONLY for a Float receiver. This keeps the
                # common Int case tag-less, matching the item-199 self-host
                # frontend, which does not carry receiver types on this surface.
                recv_ty = infer_ast(expr.callee.target, type_env, types, None)
                if recv_ty == "Float":
                    node["recv"] = recv_ty
            return node
        # A call argument that widens Int -> Float is marked on the argument
        # node (`_mark_widen`) so every backend emits the conversion — the
        # `ident(3)` gap in docs/arithmetic.md. Generic signatures are
        # instantiated first, exactly as the checker does, so a `T` bound to
        # `Float` by this call marks too. Inference runs without a filename:
        # the checking pass has already diagnosed real mismatches, so this is
        # annotation only.
        if isinstance(expr.callee, ExprVar):
            sig = (types.get(FNS_KEY) or {}).get(expr.callee.name)
            if sig is not None and sig.get("params"):
                params = list(sig["params"])
                if sig.get("tparams"):
                    subst: dict = {}
                    arg_types = [infer_ast(a, type_env, types, None) for a in expr.args]
                    for p, a in zip(params, arg_types):
                        unify(p, a, subst)
                    params = [substitute(p, subst) for p in params]
                lowered_args = [_lower_pure_expr(a, scope, callables, alias_fns, filename, type_env, types)
                                for a in expr.args]
                for p, a, node in zip(params,
                                      [infer_ast(a, type_env, types, None) for a in expr.args],
                                      lowered_args):
                    _mark_widen(p, a, node)
                # item 187: fill omitted trailing arguments with each defaulted
                # parameter's default expression. Lower each default here and
                # mark the Int->Float widening on it exactly as a written
                # argument would get, so a `Float = 0` default emits correctly.
                sig = types.get(FNS_KEY, {}).get(expr.callee.name) or {}
                defaults = sig.get("defaults") or []
                for i in range(len(lowered_args), len(params)):
                    dexpr = defaults[i]
                    dnode = _lower_pure_expr(dexpr, scope, callables, alias_fns,
                                             filename, type_env, types)
                    _mark_widen(params[i], infer_ast(dexpr, type_env, types, None),
                                dnode)
                    lowered_args.append(dnode)
                return {"kind": "call", "callee": _lower_pure_expr(expr.callee, scope, callables, alias_fns, filename, type_env, types),
                        "args": lowered_args}
        return {"kind": "call", "callee": _lower_pure_expr(expr.callee, scope, callables, alias_fns, filename, type_env, types),
                "args": [_lower_pure_expr(a, scope, callables, alias_fns, filename, type_env, types) for a in expr.args]}
    if isinstance(expr, ExprField):
        target_type = _expr_static_type(expr.target, type_env, types)
        if expr.name == "length" and _is_sized_type(target_type):
            return {"kind": "len",
                    "target": _lower_pure_expr(expr.target, scope, callables, alias_fns, filename, type_env, types)}
        node = {"kind": "field",
                "target": _lower_pure_expr(expr.target, scope, callables, alias_fns, filename, type_env, types),
                "name": expr.name}
        # item 380: a field whose declared type is `Opt[T]` reads TOTAL — absent
        # yields the empty Opt, never a raise (py) or a `??`-outliving `undefined`
        # (ts) — so `e.kind ?? default` means the same on every tier.
        if _field_is_opt(target_type, expr.name, types):
            node["opt"] = True
        return node
    if isinstance(expr, ExprIndex):
        node = {"kind": "index", "target": _lower_pure_expr(expr.target, scope, callables, alias_fns, filename, type_env, types),
                "index": _lower_pure_expr(expr.index, scope, callables, alias_fns, filename, type_env, types)}
        # issue #957: a subscript is lowered by the CONTAINER's declared key
        # type, not by the shape of the index expression. Every backend read the
        # index node as a positional `List` read, so `m[k]` on a `Map[Str, V]`
        # emitted an integer cast of the key: `revlIndex(m, Number(k))` on ts
        # (`NaN`, silently wrong), `(m)[(k) as usize]` on rust and
        # `m.get((int)(k))` on java (neither compiles), and `_revl_index(m, k)`
        # on python, whose helper is the List guard and compares the key with 0.
        # `key_type` is the declared key of a `Map` target and nothing else, so
        # a `List` read and a host/`Any` property read are untouched.
        key_type, value_type = _map_key_value_types(expr.target, type_env, types)
        if key_type is not None:
            node["key_type"] = key_type
            # The declared VALUE type travels with it: the tiers infer a
            # subscript's type from the container, and a map read that answered
            # "unknown" was then treated as a `List` element read downstream —
            # `let s: Str = m[k]  s.length()` picked go's LIST length helper and
            # did not build. One annotation, read by every backend's inference.
            if value_type is not None:
                node["value_type"] = value_type
        return node
    if isinstance(expr, ExprIf):
        return {"kind": "if", "cond": _lower_pure_expr(expr.cond, scope, callables, alias_fns, filename, type_env, types),
                "then": _lower_pure_expr(expr.then, scope, callables, alias_fns, filename, type_env, types),
                "else": _lower_pure_expr(expr.otherwise, scope, callables, alias_fns, filename, type_env, types)}
    if isinstance(expr, ExprRecord):
        # item 459 F1: an `asset "..."` IS a record, but only once the resolver
        # has filled it. Lowering an unresolved one would emit the empty record
        # its parser default carries — a handle with no path and no digest.
        if isinstance(expr, ExprAsset):
            _require_resolved_asset(expr, filename)
        # A record is a value type (syntax-2.0 §3.5): a field is initialised by
        # *copying* the initialiser's value into the record. Reading a `var`'s
        # field into a record (`{ x: v.field }`) has always been allowed for
        # exactly this reason, and a bare `var` read (`{ x: v }`) is the same
        # copy — the value is taken, the mutable cell is not captured, so the
        # `var` still never escapes its function. Both forms lower identically.
        return {"kind": "record",
                "fields": [[name, _lower_pure_expr(e, scope, callables, alias_fns, filename, type_env, types)]
                           for name, e in expr.fields]}
    if isinstance(expr, ExprRecordUpdate):
        return {"kind": "record_update",
                "base": _lower_pure_expr(expr.base, scope, callables, alias_fns, filename, type_env, types),
                "updates": [[name, _lower_pure_expr(e, scope, callables, alias_fns, filename, type_env, types)]
                            for name, e in expr.updates]}
    if isinstance(expr, ExprBlockArm):
        return _lift_block_arm(expr, scope, callables, alias_fns, filename,
                               type_env, types)
    if isinstance(expr, ExprList):
        return {"kind": "list",
                "items": [_lower_pure_expr(e, scope, callables, alias_fns, filename, type_env, types) for e in expr.items]}
    if isinstance(expr, ExprArrow):
        inner = dict(scope)
        inner_type_env = dict(type_env)
        param_types = _arrow_param_types(expr)
        for param, ptype in zip(expr.params, param_types):
            inner[param] = False
            if ptype:
                inner_type_env[param] = ptype
            else:
                inner_type_env.pop(param, None)
        captures = sorted(_mutable_free_vars(expr.body, scope, set(expr.params)))
        _b1_capture_check(expr, type_env, types, filename, expr.line)
        node = {"kind": "arrow",
                "params": [_predeclared_mangle(p) for p in expr.params],
                "captures": [_predeclared_mangle(c) for c in captures],
                "body": _lower_pure_expr(expr.body, inner, callables, alias_fns, filename, inner_type_env, types)}
        # IR v3: an arrow whose signature the checker knows *completely* carries
        # it, so a backend can declare it instead of guessing
        # (docs/function-types.md). Both keys are absent together otherwise —
        # including for a partially annotated arrow (item 75(a) §4, R3).
        if _arrow_signature_known(expr):
            node["param_types"] = param_types
            node["returns"] = expr.returns or "Any"
        # item 92: an arrow the checker typed against `(…) -> Async[T]` carries
        # the async color into the IR, so every emitter reads one shape
        # (`.get("async")`) instead of parsing the `returns` string.
        #
        # item 75(a) rule C2: the colour comes from `expr.returns`, which only
        # the checker writes and only from a checking position — never from the
        # author's `written_returns`. The flag is a certificate that a
        # declaration promised to await this arrow (`_refuse_leaky_pure_arrow`
        # skips a flagged arrow; `_calls_in(stop_async_arrows=True)` stops
        # descending at one), so a self-declared colour would forge it. Rule C1
        # refuses the annotation in the checker; this is the invariant restated
        # where the flag is actually set, so the two cannot drift apart.
        _assert_colour_is_positional(expr, filename)
        if expr.returns and parse_type(expr.returns)[0] == "Async":
            node["async"] = True
        return node
    if isinstance(expr, ExprMatch):
        scrutinee_type = _expr_static_type(expr.scrutinee, type_env, types)
        _check_match_exhaustiveness(expr, type_env, types, filename)
        scrutinee = _lower_pure_expr(expr.scrutinee, scope, callables, alias_fns, filename, type_env, types)
        arms = []
        for pattern, bind, body in expr.arms:
            inner_scope = dict(scope)
            inner_type_env = dict(type_env)
            payload_type = _arm_payload_type(scrutinee_type, pattern, types)
            if bind is not None:
                inner_scope[bind] = False
                inner_type_env.pop(bind, None)
                if payload_type is not None:
                    inner_type_env[bind] = payload_type
            arm = {
                "pattern": pattern,
                "bind": _predeclared_mangle(bind) if bind is not None else None,
                "body": _lower_pure_expr(body, inner_scope, callables, alias_fns, filename, inner_type_env, types),
            }
            # payload type helps backends that must cast (e.g. Java's tagged
            # Result); other emitters ignore it
            if payload_type is not None:
                arm["payload_type"] = payload_type
            arms.append(arm)
        return {"kind": "match", "scrutinee": scrutinee, "arms": arms}
    if isinstance(expr, ExprOptField):
        return {
            "kind": "optfield",
            "target": _lower_pure_expr(expr.target, scope, callables, alias_fns, filename, type_env, types),
            "name": expr.name,
        }
    if isinstance(expr, ExprOptCall):
        return {
            "kind": "optcall",
            "target": _lower_pure_expr(expr.target, scope, callables, alias_fns, filename, type_env, types),
            "method": expr.method,
            "args": [_lower_pure_expr(a, scope, callables, alias_fns, filename, type_env, types) for a in expr.args],
        }
    if isinstance(expr, Interp):
        # each `${...}` segment is a full expression, lowered (and G1/type-
        # checked) like any other; text segments pass through
        parts: list = []
        for kind, value in expr.parts:
            if kind == "text":
                parts.append(["text", value])
            else:
                parts.append(["expr", _lower_pure_expr(
                    value, scope, callables, alias_fns, filename, type_env, types)])
        return {"kind": "interp", "parts": parts}
    raise RevlError(filename, getattr(expr, "line", 1), "unexpected expression in fn body")


def _inject_opt(expected: str | None, actual: str | None, node: dict) -> dict:
    """Materialize the `T` -> `Opt[T]` injection the checker accepts.

    `compatible` lets a `T` stand where an `Opt[T]` is declared (typecheck.py,
    "Opt discipline"), but accepting the *type* is only half of it: the value
    still has to become an optional. Nothing did that, so a method declared
    `-> Opt[Int]` returning `1` emitted `Option<i64> { 1 }` on rust and
    `Optional<Long> { return 1L; }` on java — both rejected by their
    compilers. python and TypeScript never noticed, which is why it survived:
    the injection is invisible on an untyped tier.

    Done here rather than in each backend because the frontend is the single
    IR producer, and because deciding it in a backend needs the very type
    information the emitters do not carry.
    """
    if actual is None:
        return node
    ehead, eargs = parse_type(expected)
    if ehead != "Opt" or not eargs:
        return node
    if parse_type(actual)[0] == "Opt":
        return node          # already an optional; injecting would double-wrap
    return {"kind": "call", "callee": {"kind": "var", "name": "Some"}, "args": [node]}


def _default_expr_callees(expr, out: set) -> None:
    """Collect the names of every function/constructor *called* inside a
    default-value expression (item 187 purity check). Only var-headed call
    callees matter — an effectful operation is always a named extern/fn."""
    if isinstance(expr, ExprCall):
        if isinstance(expr.callee, ExprVar):
            out.add(expr.callee.name)
        _default_expr_callees(expr.callee, out)
        for a in expr.args:
            _default_expr_callees(a, out)
    elif isinstance(expr, ExprBin):
        _default_expr_callees(expr.left, out)
        _default_expr_callees(expr.right, out)
    elif isinstance(expr, ExprUn):
        _default_expr_callees(expr.operand, out)
    elif isinstance(expr, (ExprField, ExprOptField)):
        _default_expr_callees(expr.target, out)
    elif isinstance(expr, ExprOptCall):
        _default_expr_callees(expr.target, out)
        for a in expr.args:
            _default_expr_callees(a, out)
    elif isinstance(expr, ExprIndex):
        _default_expr_callees(expr.target, out)
        _default_expr_callees(expr.index, out)
    elif isinstance(expr, ExprIf):
        _default_expr_callees(expr.cond, out)
        _default_expr_callees(expr.then, out)
        _default_expr_callees(expr.otherwise, out)
    elif isinstance(expr, ExprRecord):
        for _, value in expr.fields:
            _default_expr_callees(value, out)
    elif isinstance(expr, ExprRecordUpdate):
        _default_expr_callees(expr.base, out)
        for _, value in expr.updates:
            _default_expr_callees(value, out)
    elif isinstance(expr, ExprList):
        for item in expr.items:
            _default_expr_callees(item, out)
    elif isinstance(expr, Interp):
        for kind, part in expr.parts:
            if kind == "expr":
                _default_expr_callees(part, out)


def _validate_default_params(program: Program, types: dict,
                             emitting_fns: set) -> None:
    """Decl-site checks for default parameters (item 187): a default is a pure
    expression that type-checks against its parameter. The ordering invariant
    (defaults are trailing) is enforced in the parser; here we (a) refuse an
    effectful default — one that reaches an emission/acquire/witnessed extern
    or an emitting fn, which would smuggle an effect into an otherwise pure
    call-site expansion — and (b) type-check the default against the declared
    parameter type, once, at the declaration rather than at every call."""
    effectful = {ext.name for ext in program.externs
                 if ext.classification != "pure"} | set(emitting_fns or ())
    for decl in program.fn_decls:
        for p in decl.params:
            default = getattr(p, "default", None)
            if default is None:
                continue
            reached: set = set()
            _default_expr_callees(default, reached)
            bad = sorted(reached & effectful)
            if bad:
                raise RevlError(
                    program.filename, p.line,
                    f"default for parameter `{p.name}` calls `{bad[0]}`, which "
                    "is effectful",
                    hint="a default value must be a pure expression — it is "
                         "evaluated at the call site whenever the argument is "
                         "omitted, and an effect there would be invisible in the "
                         "source",
                    code="G6", category="purity",
                )
            dt = infer_ast(default, {}, types, program.filename)
            if dt is not None and not compatible(p.type, dt, types):
                raise mismatch(program.filename, p.line,
                               f"default for parameter `{p.name}`", p.type, dt)


def _component_header_stub(comp: ComponentDecl, filename: str) -> dict:
    """A header-only placeholder for a component whose BODY lowering aborted
    (item 386, Stage 1, Change 1 — the soundness fix).

    Body lowering raised, so no lowered body exists — but DROPPING the component
    corrupts `_link`: the multi-realm route check would fabricate "no component
    provides key in realm" for a consumer routing to this component's key, and
    G2 (provision conflict) / G3 (dependency cycle) would silently MISS a real
    conflict or cycle on a key this component's HEADER declares. So we keep the
    topology complete from the parts available BEFORE body lowering — the
    `requires`/`provides` clauses on the `component` declaration — and mark it
    `poisoned` so the body-walking post-passes (taint, spawn bounds/attenuation,
    holes) skip it. `isolate`/`routes` are body statements, so a stub carries
    none: its provisions sit in the shared realm, which is exactly enough to
    stop the route-check fabrication and keep G2/G3 sound over its keys."""
    return {
        "name": comp.name,
        "source": comp.source or filename,
        "requires": {local for local, _svc, _line in comp.requires},
        "provides": {key for key, _svc, _line in comp.provides},
        "body": [],
        "poisoned": True,
    }


def _raise_collected(errors: list[RevlError], program: Program) -> None:
    """Dedup, order, and raise the collected refusals as a `RevlErrors` carrier
    (item 386, Stage 1, Change 4).

    Dedup key is `(code, filename, line, message)` — two recovery paths reaching
    the same refusal collapse to one. Ordering is by COMPILE ORDER, not
    alphabetical: `program.filename` (paths[0]) first, then each component's
    `source` in declaration order (== the multi-file argument order, roadmap
    312), then line. Python's sort is stable, so ties keep the pipeline
    (append) order. This makes `diagnostics[0]` equal to what today's
    single-error compile reports for the same input, keeping every existing
    single-error test and consumer stable."""
    file_rank: dict[str, int] = {}

    def _rank(name: str) -> int:
        if name not in file_rank:
            file_rank[name] = len(file_rank)
        return file_rank[name]

    _rank(program.filename)
    for comp in program.components:
        _rank(comp.source or program.filename)

    seen: set = set()
    unique: list[RevlError] = []
    for err in errors:
        key = (err.code, err.filename, err.line, err.message)
        if key in seen:
            continue
        seen.add(key)
        unique.append(err)

    unique.sort(key=lambda e: (file_rank.get(e.filename, len(file_rank)), e.line))
    raise RevlErrors(unique)


# --- item 379 / Decision 2 (docs/design/379-break-continue.md) --------------
# The frame-neutrality of `break`/`continue` rests on a grammar accident: loops
# live only in the fn statement grammar, and every teardown-registering form
# lives only in the activation/method grammar, so the two never meet and no
# emitter wraps a loop in teardown scaffolding. This pass makes that accident an
# enforced whole-IR invariant, run once over the lowered IR: no registering step
# may sit inside a `while`/`for` body, and — the same invariant read the other
# way — no `while`/`for` step may sit in a component activation, provide-method,
# or setup body. Either leak would let a future item register teardown at a loop
# boundary; the java setup emitter (`_emit_setup_stmt`) would even compile the
# loop-in-activation form silently, so a parse-time counter or a single
# lowering-local assert would not catch it on every tier.

_REGISTERING_STEP_KINDS = frozenset({
    "effect", "let-effect", "emit", "timer", "approval", "spawn",
})
_LOOP_STEP_KINDS = frozenset({"while", "for"})


def _iter_all_fn_steps(steps):
    """Every step in a fn-grammar body, descending `if` arms and loop bodies."""
    for step in steps or []:
        yield step
        kind = step.get("step")
        if kind in _LOOP_STEP_KINDS:
            yield from _iter_all_fn_steps(step.get("body") or [])
        elif kind == "if":
            yield from _iter_all_fn_steps(step.get("then") or [])
            yield from _iter_all_fn_steps(step.get("else") or [])


def _iter_loop_scoped_steps(steps):
    """Every step lexically inside a `while`/`for` body within a fn-grammar step
    list (descending `if` arms, and nested loops via `_iter_all_fn_steps`)."""
    for step in steps or []:
        kind = step.get("step")
        if kind in _LOOP_STEP_KINDS:
            yield from _iter_all_fn_steps(step.get("body") or [])
        elif kind == "if":
            yield from _iter_loop_scoped_steps(step.get("then") or [])
            yield from _iter_loop_scoped_steps(step.get("else") or [])


def _find_loop_step(node):
    """Deep-search an activation/method/setup IR subtree for a `while`/`for`
    step. Expression nodes key on `kind`, never `step`, and component IR never
    embeds a module `fn` body, so this never false-positives on a real loop."""
    if isinstance(node, dict):
        if node.get("step") in _LOOP_STEP_KINDS:
            return node
        for value in node.values():
            found = _find_loop_step(value)
            if found is not None:
                return found
    elif isinstance(node, list):
        for item in node:
            found = _find_loop_step(item)
            if found is not None:
                return found
    return None


def _find_all_loop_steps(node):
    """Every `while`/`for` step in a subtree (issue #548 relaxed the old
    single-hit `_find_loop_step`: a component may now legitimately carry loops,
    in its provide-method bodies, so the invariant checks each one rather than
    refusing the first)."""
    if isinstance(node, dict):
        if node.get("step") in _LOOP_STEP_KINDS:
            yield node
        for value in node.values():
            yield from _find_all_loop_steps(value)
    elif isinstance(node, list):
        for item in node:
            yield from _find_all_loop_steps(item)


def _iter_component_activation_loops(steps):
    """Every `while`/`for` step in a component's ACTIVATION/setup position —
    i.e. anywhere in the component body EXCEPT a provide-method body, where
    issue #548 now admits loops. The parser refuses activation-body loops, so
    this is the whole-IR safety net for that invariant (the pre-#548 guard used
    `_find_loop_step`, which refused the first loop anywhere in the component;
    #548's rewrite dropped the activation-body refusal entirely by only
    descending into loop bodies looking for registering steps)."""
    for step in steps or []:
        kind = step.get("step")
        if kind in _LOOP_STEP_KINDS:
            yield step
            yield from _iter_component_activation_loops(step.get("body") or [])
        elif kind == "if":
            yield from _iter_component_activation_loops(step.get("then") or [])
            yield from _iter_component_activation_loops(step.get("else") or [])
        elif kind == "provide":
            # A provide-method body is not activation position — loops there are
            # legal (#548) and are checked below for registering steps instead.
            continue


def _validate_no_loop_scoped_registration(ir: dict, filename: str) -> None:
    doc = "docs/design/379-break-continue.md"
    fn_bodies: list[list] = [fn.get("body") or [] for fn in ir.get("functions") or []]
    for key in ("tests", "fault_tests", "prop_tests"):
        for unit in ir.get(key) or []:
            body = unit.get("body")
            if isinstance(body, list):
                fn_bodies.append(body)
    for body in fn_bodies:
        for step in _iter_loop_scoped_steps(body):
            kind = step.get("step")
            if kind in _REGISTERING_STEP_KINDS:
                raise RevlError(
                    filename, step.get("line", 0),
                    f"a `{kind}` step registers teardown and may not appear "
                    f"inside a `while`/`for` body",
                    hint="`break`/`continue` are frame-neutral only because loops "
                         "and registration never meet; an item that wants them to "
                         f"must first amend the teardown contract ({doc})",
                )
    # issue #548: a `while`/`for` loop is now valid in a provide-METHOD body
    # (the parser still admits none in an activation/setup body). The
    # frame-neutrality invariant is unchanged in substance — a teardown-
    # registering step still may not sit inside a loop body — so it is enforced
    # here the SAME way as over fn bodies, rather than by refusing loops
    # outright. `_lower_control_stmt` already refuses registration inside method
    # control flow at lowering; this is the whole-IR safety net that makes the
    # invariant true on every tier.
    for component in ir.get("components") or []:
        # A loop in the component's own activation/setup body (any position
        # except a provide-method body) is still refused outright — #548
        # admitted loops only in provide-method bodies. The parser already
        # refuses them at parse time; this is the whole-IR safety net that keeps
        # the invariant true even for IR built directly.
        for loop in _iter_component_activation_loops(component.get("body") or []):
            raise RevlError(
                filename, loop.get("line", 0),
                "a `while`/`for` loop may not appear in a component activation "
                "body",
                hint="iteration lives in the fn statement grammar or a provide "
                     f"method; lift the loop into a module `fn` and call it ({doc})",
            )
        for loop in _find_all_loop_steps(component):
            for step in _iter_all_fn_steps(loop.get("body") or []):
                kind = step.get("step")
                if kind in _REGISTERING_STEP_KINDS:
                    raise RevlError(
                        filename, step.get("line", 0),
                        f"a `{kind}` step registers teardown and may not appear "
                        f"inside a `while`/`for` body",
                        hint="`break`/`continue` are frame-neutral only because "
                             "loops and registration never meet; keep the effect/"
                             "emit at the provide method's top level "
                             f"(issue #548, {doc})",
                    )


# ---------------------------------------------------------------------------
# call-position name resolution (item 445 follow-up)
#
# A call whose callee is a bare name lowers to the SAME node either way — a
# `var` callee — whether the name is a local binding or a module `fn`. Nothing
# downstream can then tell the two apart, and the consumers do not agree about
# which one they picked:
#
#   * the python backend's template inliner resolves the name to the MODULE FN
#     (`let helper = g` over a `fn helper` emitted the body of `fn helper`,
#     silently dropping `g`);
#   * a TypeScript `const`, a Rust `let` and a Go `:=` all shadow the function
#     in the emitted code, so those three resolve to the LOCAL;
#   * Java keeps methods and variables in separate namespaces, so `helper(...)`
#     next to a `final var helper` binds the STATIC METHOD;
#   * and the name-keyed frontend analyses (cardinality's recursion set,
#     emission_analysis' reach, ownership.py's retention summary, taint's
#     callee map) all read the module fn's facts for a call that may never
#     reach it.
#
# revl already refuses shadowing INSIDE a function — a `let` binds a name once
# per scope — so the question is only reachable because a module callable was
# left out of that rule. Putting it back is the whole fix: with no binder able
# to take a called callable's name, a call-position name has one referent
# again, and every consumer above is right without carrying a marker each would
# have to honour separately.
#
# Two scoping facts keep this precise rather than merely strict:
#
#   * the visible set is the one the CHECKER resolves against, not the whole
#     merged program. `fn_scopes` keeps a module-private declaration out of
#     another module's namespace, and two modules that never `use` each other
#     may reuse a name — selfhost/lexer.rvl declares `fn step` while
#     selfhost/emit_py.rvl binds a local `step`, and both are correct. That
#     residue (one flat EMITTED namespace over module-scoped resolution) is the
#     emitters' to respect, and is handled where it bites, in
#     backends/python/emit.py's `_inline_bound_names`.
#   * only a name this body also CALLS is ambiguous. A binding that merely
#     coincides with a callable's name reads fine and is common — see
#     backends/wasm/golden/functions.revl, where `fn make_row(id: Int, name:
#     Str)` sits beside `fn name(row: Row)` and never calls it.
# ---------------------------------------------------------------------------

def _binder_names(node, out: list) -> None:
    """Append every `(name, line)` this subtree BINDS.

    A parameter, a `let`/`var`, a destructure, a `for` bind, an arrow
    parameter, a match-arm payload, and the component-body binders (an effect
    `let`, an approval `let`, a lifecycle `call ... as`). Traversal is generic
    over the AST dataclasses so a binder form added to the grammar is covered
    without a second edit here; only the RECOGNITION is enumerated.
    """
    if isinstance(node, (list, tuple)):
        for item in node:
            _binder_names(item, out)
        return
    if not dataclasses.is_dataclass(node) or isinstance(node, type):
        return
    if isinstance(node, (FnParam, LetStmt)):
        out.append((node.name, node.line))
    elif isinstance(node, LetPatternStmt):
        pattern = node.pattern
        if isinstance(pattern, RecordPattern):
            out.extend((name, pattern.line) for name in pattern.fields)
        elif isinstance(pattern, ListPattern):
            out.extend((name, pattern.line) for name in pattern.binds)
            if pattern.rest:
                out.append((pattern.rest, pattern.line))
    elif isinstance(node, (ForStmt, LetEffect, LetApprovalStmt, CallStmt)):
        if isinstance(node.bind, str):
            out.append((node.bind, node.line))
    elif isinstance(node, ExprArrow):
        out.extend((name, node.line) for name in node.params or [])
    elif isinstance(node, ExprMatch):
        for arm in node.arms:
            if len(arm) > 1 and isinstance(arm[1], str):
                out.append((arm[1], node.line))
    for field in dataclasses.fields(node):
        _binder_names(getattr(node, field.name, None), out)


def _called_names(node, out: set) -> None:
    """Every name used in CALL position — the callee of `f(...)` where `f` is a
    bare name. A method call (`x.m()`), a module-alias call (`m.f()`) and an
    immediately applied arrow all name something other than a bare identifier,
    so none of them can be ambiguous.
    """
    if isinstance(node, (list, tuple)):
        for item in node:
            _called_names(item, out)
        return
    if not dataclasses.is_dataclass(node) or isinstance(node, type):
        return
    if isinstance(node, ExprCall) and isinstance(node.callee, ExprVar):
        out.add(node.callee.name)
    for field in dataclasses.fields(node):
        _called_names(getattr(node, field.name, None), out)


def _refuse_callable_shadowing(program: Program, filename: str) -> None:
    """Refuse a body that both BINDS a name and CALLS it, where that name is
    also a module callable visible to the body.

    Precision matters here: a binding that merely coincides with a callable's
    name is unambiguous and common (`fn name(row: Row)` alongside `fn
    make_row(id: Int, name: Str)` — the parameter is a `Str` and is never
    called), so the refusal is scoped to the position where the two readings
    actually differ. Whole-body granularity, not per-block: the emitters and
    the name-keyed analyses all work a function at a time, and a `let` in one
    arm with the call in another reads no better than the same-block form.
    """
    declared = ({fn.name for fn in program.fn_decls}
                | {ext.name for ext in program.externs})
    if not declared:
        return
    externs = {ext.name for ext in program.externs}

    def check(decl, visible: set, decl_file: str) -> None:
        if not visible:
            return
        called: set = set()
        _called_names(decl, called)
        ambiguous = visible & called
        if not ambiguous:
            return
        binders: list = []
        _binder_names(decl, binders)
        for name, line in binders:
            if name not in ambiguous:
                continue
            kind = "extern" if name in externs else "function"
            raise RevlError(
                decl_file, line,
                f"`{name}` is bound here and called in this body, and a "
                f"module {kind} of that name is in scope",
                hint=f"a call to `{name}` would name both, and the tiers do "
                     "not agree which wins (a Java local does not shadow a "
                     "static method, while a TypeScript, Rust or Go local "
                     "does) — rename the binding. Module `fn`s and `extern`s "
                     "share one namespace with local bindings, the same way a "
                     "`let` binds a name once per scope.",
            )

    for decl in program.fn_decls:
        # exactly the namespace `_lower_fns` resolves this body's bare names in
        visible = set(program.fn_scopes.get(id(decl), declared)) | externs
        check(decl, visible & declared, decl.source or filename)
    # components and `test`/prop-test blocks resolve against the whole merged
    # program (`component_callables` in `check_and_lower`), so their visible
    # set is that same one.
    for decl in (list(program.components) + list(program.tests)
                 + list(program.prop_tests)):
        check(decl, declared, getattr(decl, "source", "") or filename)


def check_and_lower(program: Program, ambient: dict | None = None,
                    taint_strict: bool = False, untrusted: bool = False) -> dict:
    """Check and lower a program, optionally against an *ambient* composition
    (a running manifest, DESIGN §4's runtime-admission gate): ambient services
    are in scope without redeclaration, and G2/G3 are checked over the union
    of ambient and newly compiled components.

    `ambient`: {"services": <v1 services table>, "components": [<manifest
    component entries>]} — see compile_files for how it is derived.

    `taint_strict` (item 249, Slice D) turns on derived taint sinks and sources —
    off by default and byte-identical when off, on under the untrusted-author
    profile or `revl compile --taint-strict`.

    `untrusted` (item 274) marks the untrusted-author profile so a G9 sink
    refusal carries the collapsed navigable verdict (no author-side declassify
    path exists under `no_declassify`). Purely additive: it changes only the
    optional `navigate` field of the refusal, never the verdict or the IR.

    Issue #310: the checkers and lowerers here walk the tree recursively, so
    they need the same stack the parser gave itself to accept it, and the same
    promise on the way out — a `RecursionError` is an unhandled fault in a
    library, and every caller of this one (`revl compile`, the LSP,
    `revl.gate`) is entitled to a diagnostic instead.
    """
    with recursion_headroom():
        try:
            return _check_and_lower(program, ambient, taint_strict, untrusted)
        except RecursionError:
            raise RevlError(
                program.filename, 0,
                "this program nests deeper than the compiler can check",
                hint=f"expressions are bounded at {NESTING_LIMIT} levels "
                     "(parser.NESTING_LIMIT) and the other nestings by the "
                     "interpreter's stack; this is an implementation bound, not "
                     "a language one — name the inner constructs with `let` "
                     "bindings or helper functions",
            ) from None


def _check_and_lower(program: Program, ambient: dict | None = None,
                     taint_strict: bool = False, untrusted: bool = False) -> dict:
    ambient = ambient or {}

    # Taint/provenance (roadmap item 249, Slice A). Read the `Untrusted[T]` /
    # `Trusted[T]` qualifier surface off every declaration and STRIP it from the
    # declared types in place, so base typing, method lookup and the emitted IR
    # are byte-identical for any program that uses no qualifier. The flow verdict
    # (`check_taint`, below) runs once every component body is lowered.
    taint_model = extract_and_normalize(program, taint_strict=taint_strict)

    ambient_services = {
        name: _service_from_ir(name, spec)
        for name, spec in (ambient.get("services") or {}).items()
    }

    # Fold the AMBIENT composition's service operations into the taint model so a
    # crossing's derived sink/source class survives the manifest/composition
    # boundary. A per-turn source admitted against a running manifest reaches the
    # composition only through its ambient services, whose provider bodies are not
    # in the turn's program; without this the flow walk sees no sink and no source
    # and `emit sh.exec(emit fs.read(p))` launders untrusted data into a shell sink
    # even under `taint_strict`. No-op with `taint_strict` off, so a trusted
    # load/swap against a running manifest is byte-identical.
    fold_ambient_composition(taint_model, ambient_services,
                             taint_strict=taint_strict)

    services: dict[str, ServiceDecl] = {}
    for svc in program.services:
        if svc.name in services:
            raise RevlError(program.filename, svc.line, f"duplicate service `{svc.name}`")
        prior = ambient_services.get(svc.name)
        if prior is not None:
            _admit_service_replacement(program, svc, prior, ambient)
        # issue #319: refuse dunder / prototype service-method names (protocol
        # hijacking) before they reach a backend.
        for method in (svc.methods or {}).values():
            _reject_dunder_name(method.name, "method", f"service `{svc.name}`",
                                program.filename, getattr(method, "line", svc.line))
        services[svc.name] = svc
    for name, svc in ambient_services.items():
        services.setdefault(name, svc)

    component_callables = (
        _HOST_CALLABLES
        | _BUILTIN_CONSTRUCTORS
        | _DECLASSIFY_BUILTINS
        | {fn.name for fn in program.fn_decls}
        | {ext.name for ext in program.externs}
    )

    # types and signatures are built first so component lowering can
    # type-check service/fn call sites (the sound-typing milestone)
    _resolve_type_aliases(program, program.filename)
    _validate_declared_types(program, program.filename)
    _check_principal_producers(program, program.filename)
    types = _lower_type_decls(program, program.filename)
    types[FNS_KEY] = _signature_table(program, types)
    types[CASES_KEY] = _case_table(types)
    # item 130 Slice 5: the typed-event contracts. Built after the record table
    # (an event IS a record, §6) and stashed under a `__`-prefixed key, so a
    # program with no event declaration reaches every downstream section — and
    # the emitted IR — byte-identically.
    events = _lower_event_decls(program, types, program.filename)
    if events:
        types[EVENTS_KEY] = events
    _refuse_callable_shadowing(program, program.filename)
    fns = _lower_fns(program, program.filename, types)
    externs = _lower_externs(program, program.filename, types, fns)
    # item 256 Slice 1: cross-index the bound secrets against the extern emission
    # capabilities - refuse a wasm-only or nowhere-bound secret and a name/param
    # collision, annotate each bound extern with the secret names it receives, and
    # produce the manifest-visible (name, capability) rows. Empty and inert for a
    # program that binds no secret, so every existing IR is byte-identical.
    secrets_ir = _lower_secrets(program, externs, program.filename)
    # item 388: the poly externs (`fn|async`), pre-seeded above as async IR
    # entries. `extern_colour_instances` is the shared registry each provide
    # method fills with the colour its call sites of a poly extern requested (the
    # analog of `sync_monomorphs`); `_finalize_poly_externs` reads it after the
    # component loop to split/prune each poly entry into its concrete clones.
    # Empty unless the program declares a poly extern, so every downstream section
    # is byte-identical without one.
    poly_extern_names: set = {
        d.name for d in program.externs if getattr(d, "colour_poly", False)}
    extern_colour_instances: dict = {}
    # item 246: the declaration-owned approval facts, stashed on the type table so
    # `_lower_emit_step`'s per-crossing obligation can read them with no signature
    # change. Empty `required` set unless an extern declared `requires approval`,
    # so a program with none is byte-identical.
    types[APPROVAL_KEY] = _approval_index(externs)
    # Externs whose effect machinery exists only in effect position are refused
    # in a plain fn/test body, in one walk (P-9, #543): a witnessed extern
    # (item 243 rule 1) whose auto-registered inverse would be dropped; an
    # `acquire` with an `undo` (399) whose teardown would be dropped; a
    # `deferred` emission (400) that would fire immediately, bypassing the
    # commit queue. Reported witnessed-before-teardown, as when these were three
    # sequential passes.
    _refuse_effect_position_bound_externs_in_fn_body(program, program.filename)
    _refuse_host_acquire_in_component_reachable_fn(program, program.filename)
    # Slice 2: the set every component's effect-position lowering consults to
    # tell a witnessed acquisition from an ordinary one (docs/design/243-
    # witnessed-externs.md). Computed once — every component shares the same
    # extern table.
    witnessed_externs = _witnessed_extern_names(program)
    # One fixed point, two consumers: `emitting_caps` is what it computes
    # (docs/capabilities.md), `witness` is why (why.py). Evidence never
    # decides a rejection, it only explains one.
    emission_evidence = _EmissionEvidence(program)
    emitting_caps = _emitting_capabilities(fns, externs, emission_evidence.witness)
    emitting_fns = set(emitting_caps)

    # item 310: the capability-aware caching admission checks, run here once the
    # emission fixed point and the type/extern tables are known (a `cache pure`
    # crossing-reach refusal reads `emitting_caps`; the structural resource walk
    # reads the extern/type tables). Refuses every declaration the seam-method
    # slice cannot soundly cache; survivors flow their `cache` IR below. Inert for
    # any program declaring no `cache` clause, so byte-identity holds.
    _check_cache_declarations(program, externs, types, emitting_caps,
                              program.filename, untrusted=untrusted)

    # item 187: default-parameter values must be pure and well-typed. Checked
    # here, once the emission fixed point is known, so an effectful default is
    # refused before any call site expands it.
    _validate_default_params(program, types, emitting_fns)

    # phase-2 async coloring (docs/design/async-extern.md §3): the async twin
    # of the emission fixed point above. Seed = async externs; a module `fn`
    # that reaches a colored callee — directly or transitively — is itself
    # colored. `async_witness` records the shortest derivation for diagnostics.
    async_witness: dict[str, str] = {}
    async_colored = _async_callables(fns, externs, async_witness)

    # sync/async arrow polymorphism (roadmap item 342, the dual of item 92).
    # A fn colored async *solely* because it calls its own async-typed callback
    # parameter — and reaching no other suspension — is "colour-polymorphic":
    # its async-ness is contingent on the arrow actually passed. When a sync
    # caller hands it a genuinely-sync arrow (a value that trivially lifts into
    # a completed async, item 92 §2), that call site does not suspend, so the
    # fn is monomorphized to a SYNC clone there — one source loop serves an
    # async evolve path and a sync tool-call path with no duplicated twin.
    colour_polymorphic: set = _colour_polymorphic_fns(fns, async_colored)
    # Filled by the sync call sites (provide methods, module fns, and — below —
    # `test` bodies): monomorph-name -> origin fn name. Synthesized into `fns`
    # once every call site has registered.
    sync_monomorphs: dict[str, str] = {}

    # item 387 (finishing item 342 phase 2): 342 hooked its monomorphization
    # into `_lower_provide` alone, so a module `fn` reaching a colour-polymorphic
    # loop only through genuinely-sync arrows was auto-colored async here instead
    # of kept sync — and a sync context calling it then diverged (py ran to a
    # bare coroutine, ts refused at emit, H29). Redirect those free-fn call
    # sites to the sync monomorph and recolor, so a free fn whose only async
    # reach was such a call is sync on BOTH tiers. No-op (and `async_colored`
    # byte-identical) when no such call exists.
    if colour_polymorphic:
        async_colored = _monomorphize_free_fn_calls(
            fns, externs, colour_polymorphic, async_colored, types,
            sync_monomorphs, component_callables, async_witness)
        colour_polymorphic = _colour_polymorphic_fns(fns, async_colored)

    # Stamp `"async": True` on every colored fn entry (the emitters read it
    # with `.get("async")`, needing no reachability analysis of their own),
    # mirroring the extern spelling in `_lower_externs`. And refuse first-class
    # *value* use of an async callable: an arrow type carries no color, so
    # passing an async extern or a colored fn as a value would smuggle a
    # suspension past the checker — the async fixed point never widened for it,
    # so it is a compile error, not a coloring (async-extern.md §3, "First-class
    # values are refused, not widened").
    _fn_decls_by_name = {d.name: d for d in program.fn_decls}
    for entry in fns:
        name = entry["name"]
        called_vals: set = set()
        _calls_in(entry.get("body") or [], set(), values=called_vals)
        passed = sorted(called_vals & async_colored)
        if passed:
            decl = _fn_decls_by_name.get(name)
            raise RevlError(
                (decl.source if decl is not None else None) or program.filename,
                decl.line if decl is not None else 0,
                f"function `{name}` uses async callable `{passed[0]}` as a "
                f"function value, but an async callable has no arrow type",
                hint="call it directly from an async context — an arrow type "
                     "carries no async color, so a suspension cannot be awaited "
                     "through it (A1)",
                code="A1", category="async-propagation",
            )
        # item 92: a sync-typed arrow in a module fn that reaches an async
        # callable (an async extern or a colored fn) is the finding-#21 leak —
        # a compile error now. An arrow the checker typed against `(…) ->
        # Async[T]` carries the async flag and is admitted; a plain one that
        # reaches a suspension is refused. Pure fns have no req keys, so only
        # the named-callable reach applies here (rule 3 is component-only).
        _refuse_leaky_pure_arrow(entry.get("body") or [], async_colored,
                                 _fn_decls_by_name.get(name), program.filename)
        if name in async_colored:
            entry["async"] = True

    # instance-parametric components: one registry shared across the lowering
    # of every component, so `spawn C` can resolve C's config/provisions and
    # the linker can learn which components are runtime templates and what the
    # spawn (instance) graph is (docs/design-v2-instances.md).
    spawn_reg: dict = {
        "by_name": {c.name: c for c in program.components},
        "edges": [],        # (spawner, target) — the instance graph
        "templates": set(),  # components that are spawn targets (excluded from static composition)
        "sites": [],        # G4 spawn-boundary obligations, checked after lowering
        "names": {},        # spawner component -> set of named-instance addresses (item 10)
        "named_instances": [],  # ordered records of every `as "<name>"` spawn (item 10)
    }

    # item 386, Stage 1: collect ALL refusals in one pass instead of aborting
    # on the first. `errors` accumulates every recoverable refusal; the
    # carrier is raised once at the end (below). The component loop is the
    # cleanest recovery unit — by this point the type and signature tables
    # already exist, so one component's failure does not poison another's
    # lowering.
    errors: list[RevlError] = []

    def _collect(fn, *args, **kwargs):
        """Run a whole-composition post-pass, collecting a `RevlError` instead
        of aborting so its sibling passes still run (item 386, Change 2). An
        UNEXPECTED (non-`RevlError`) crash is dropped only when the compile is
        ALREADY failing: a post-pass tripping over poisoned/partial state must
        not replace N good diagnostics with a traceback. On an otherwise-clean
        compile it propagates as the bug it is."""
        try:
            return fn(*args, **kwargs)
        except RevlError as post_error:
            errors.append(post_error)
            return None
        except Exception:  # noqa: BLE001 — see docstring: guarded only when failing
            if errors:
                return None
            raise

    components = []
    seen = set()
    for comp in program.components:
        if comp.name in seen:
            # A duplicate component is already represented in the topology by
            # its first declaration, so record the refusal but append NO stub
            # (a second same-named entry would fabricate a `_link` G2 conflict).
            errors.append(RevlError(comp.source or program.filename, comp.line,
                                    f"duplicate component `{comp.name}`"))
            continue
        seen.add(comp.name)
        try:
            # A multi-file composition merges declarations from several sources
            # into one Program whose `filename` is only the first argument
            # (paths[0]). Body diagnostics render through `env.filename`, so a
            # component from a LATER file must lower under its own `source`.
            # Otherwise its rejection names the first source with this file's
            # line number (roadmap 312).
            lowered_comp = _lower_component(comp, services,
                                            comp.source or program.filename,
                                            component_callables, types, emitting_fns,
                                            emitting_caps, emission_evidence, spawn_reg,
                                            async_colored, witnessed_externs,
                                            colour_polymorphic, sync_monomorphs,
                                            poly_extern_names, extern_colour_instances,
                                            extern_class={e["name"]: e.get("class")
                                                          for e in externs},
                                            extern_undo={
                                                e["name"]: _callee_name(e.get("undo"))
                                                for e in externs
                                                if _callee_name(e.get("undo"))},
                                            errors=errors, untrusted=untrusted)
            if comp.source:
                _retarget_holes(lowered_comp, comp.source)
            # async coloring (docs/design/async-extern.md §3, "Component
            # bodies"): a setup/activation body (an `emit` step, an `effect`, an
            # `await` step) may not reach an async callable — an async extern
            # *or* a phase-2 colored fn — because divert/inertia semantics are
            # out of scope for v1. Provide-method bodies are checked at their
            # own site above, so they are pruned here. A component that recovered
            # past a refused statement (item 386, Stage 2) has a partial body and
            # is already failing, so skip the reach sweep — walking its poisoned
            # body could fabricate or crash, and its diagnostics are collected.
            if async_colored and not lowered_comp.get("poisoned"):
                _reached: set = set()
                _async_reached_outside_provide(lowered_comp, async_colored, _reached)
                if _reached:
                    _culprit = sorted(_reached)[0]
                    _kind = "extern" if _culprit in {
                        e.name for e in program.externs if e.async_} else "function"
                    raise RevlError(
                        comp.source or program.filename, comp.line,
                        f"component `{comp.name}` reaches async {_kind} "
                        f"`{_culprit}` in a setup/activation body, which "
                        f"cannot suspend a fiber (A1)",
                        hint="wrap the suspending call in an `async fn` service "
                             "operation and drive it from a provide method — v1 does "
                             "not lower an awaited `emit` step",
                        code="A1", category="async-propagation",
                    )
            components.append(lowered_comp)
        except RevlError as comp_error:
            # This component's BODY lowering aborted. DROPPING it would corrupt
            # `_link` (the route check fabricates "no provider", G2/G3 silently
            # miss real conflicts/cycles on its keys), so append a HEADER-ONLY
            # stub — provides/requires from the `comp` declaration, marked
            # `poisoned` — to keep the topology complete, and continue.
            errors.append(comp_error)
            components.append(_component_header_stub(comp, program.filename))
            continue

    # item 386: the body-walking post-passes run over the SUCCESSFULLY lowered
    # components only. A poisoned header stub has no lowered body, so feeding it
    # to taint / spawn / hole walks would crash or fabricate; `_link` alone sees
    # the full list (stubs included) because it needs the complete topology.
    live_components = [c for c in components if not c.get("poisoned")]

    # sync/async arrow polymorphism (item 342): materialize the sync clones the
    # sync call sites above requested. Additive — a program with no lifted call
    # site registers none, so `fns` (and every downstream section) is
    # byte-identical to before.
    _collect(_synthesize_sync_monomorphs, fns, sync_monomorphs)

    # Taint/provenance verdict (item 249, Slice A): refuse any untrusted-origin
    # value that reaches a `Trusted[T]` sink without a declassifier on its path
    # (G9). No-op and byte-identical when the program declared no qualifier.
    _collect(check_taint, program, fns, live_components, taint_model,
             program.filename, untrusted=untrusted)

    # state hand-off admission (roadmap item 53): a candidate provider that
    # *accepts* a `handoff` on a key some running provider *exports* must accept
    # a §5-compatible shape — else the swap would drop the predecessor's state.
    # No-op unless the ambient carries running hand-offs (a swap against a
    # stateful running provider), so a fresh compile is unaffected.
    _collect(_admit_handoff_replacement, program, live_components, ambient)

    # withdrawn-provision admission (roadmap item 186 / issue #86): a
    # replacement that drops a provision a RETAINED running component still
    # requires is refused, rather than admitted into a composition where that
    # consumer deactivates into PENDING with no diagnostic. Runs over the FULL
    # component list (stubs included) for the same reason `_link` does: a
    # poisoned component's declared `provides` still counts as re-providing the
    # key, so a body defect does not fabricate a second, spurious refusal about
    # a provision that is in fact kept. No-op unless the ambient carries a
    # withdrawal, so a cold compile and a pure addition are unaffected.
    _collect(_admit_provision_withdrawal, program, components, ambient,
             templates=spawn_reg["templates"])

    # G4/G6 across the spawn boundary: a spawner's declared emission upper
    # bound must cover what its spawned instances emit (decision 8). Checked
    # here, after every component's emission surface is known.
    _collect(_check_spawn_emission_bounds, live_components, services, spawn_reg,
             program.filename)

    # Capability attenuation across the spawn boundary (item 66): a child's
    # capability set must be a checked subset of its spawner's held authority,
    # so lineage narrows monotonically and a supervisor cannot amplify. Returns
    # the per-instance attenuation chain for the G8 audit surface.
    attenuation_chain = _collect(_check_spawn_attenuation,
                                 live_components, services, spawn_reg,
                                 program.filename, untrusted=untrusted)

    # Emission budgets, static check (item 260 §3.2): a declared `budget.requests`
    # / `calls` ceiling that the proved cardinality max exceeds is a red compile,
    # and a finite ceiling over an `unbounded`/symbolic body is unprovable. Gated
    # on a declared ceiling, so a budget-free composition is byte-identical.
    _collect(_check_declared_ceilings, live_components, services, fns, externs,
             program.filename)

    fault_tests = _collect(_lower_fault_tests, program, live_components,
                           program.filename)

    # `_link` collects its own G2/G3 refusals into the shared `errors` sink
    # (item 386, Change 2): it must see the FULL component list, stubs included,
    # so its topology is complete — a real conflict/cycle on a refused
    # component's declared key is still reported, and a consumer routing to it
    # gets no fabricated "no provider" error.
    manifest = _collect(_link, program, components, ambient.get("components") or [],
                        templates=spawn_reg["templates"], errors=errors)
    if manifest and attenuation_chain:
        # additive, spawn-only: a non-spawning composition has no `instances`
        # key, so its manifest is byte-identical to before (docs/capability-
        # attenuation.md).
        manifest["instances"] = attenuation_chain
    if manifest and spawn_reg["named_instances"]:
        # item 10 placement horizon, next slice: enumerate the named instances
        # (`spawn C … as "<name>"`) at the composition layer, so a later
        # placement slice can key on an instance ADDRESS instead of only a
        # template component. Sorted by (spawner, name) for a deterministic
        # manifest; each name is unique within its spawner (checked in
        # `_lower_spawn`) while a name may recur across spawners, so (spawner,
        # name) is the stable address. Additive and named-only: a composition
        # with no named spawn carries no `named_instances` key and is
        # byte-identical to before (docs/design-v2-instances.md).
        manifest["named_instances"] = sorted(
            spawn_reg["named_instances"],
            key=lambda r: (r["spawner"], r["name"]))

    # lifecycle tests are lowered last: they check against the component
    # declarations, so a broken component must report itself first
    tests = _collect(_lower_tests, program, program.filename, types, services)
    prop_tests = _collect(_lower_prop_tests, program, program.filename, types, services)

    # item 387: a plain `test`/`prop test` body is a pure SYNC context. Finish
    # item 342 there — monomorphize each colour-polymorphic call handed only
    # genuinely-sync arrows to its sync clone, and refuse (A1) any residual reach
    # of an async callable — so a test never emits a bare, un-awaited call to an
    # async callable (py) that the ts emitter would refuse (the H29 divergence).
    # Then re-run the sync-clone synthesis to materialize any clone a test body
    # was the sole caller of. Both are no-ops (IR byte-identical) when no async
    # callable and no colour-polymorphic fn exist.
    if async_colored or colour_polymorphic:
        _collect(_admit_sync_test_bodies, tests, prop_tests, async_colored,
                 colour_polymorphic, types, sync_monomorphs, component_callables,
                 program.filename)
        _synthesize_sync_monomorphs(fns, sync_monomorphs)

    # item 388: caller-decided extern colour — split and prune, run LAST so every
    # section that can name an extern (fns, components, tests, prop tests) has
    # been lowered. Each provide method has recorded which colours its poly-extern
    # call sites requested (`extern_colour_instances`); the sync PROVIDE-method
    # calls have already been rewritten to the `_revl_sync` clone. Materialize the
    # concrete clones and PRUNE the colour no call site used (the eager-expand-
    # and-prune resolution of the ordering wrinkle). The async clone additionally
    # survives whenever the ORIGINAL name is still referenced anywhere — an async
    # method, a module `fn`, or a `test` — so no such call dangles. Additive: no
    # poly extern means `poly_extern_names` is empty and `externs` is unchanged.
    if poly_extern_names:
        poly_referenced: set = set()
        for _section in (fns, live_components, tests, prop_tests):
            _calls_in(_section or [], poly_referenced)
        _collect(_finalize_poly_externs, externs, poly_extern_names,
                 extern_colour_instances, poly_referenced)

    # item 386: every recoverable refusal is now collected. Raise them together
    # as a `RevlErrors` carrier BEFORE building the IR — the result dict reads
    # `manifest`/`components`/etc. which may be partial or poisoned on the error
    # path, so short-circuiting here keeps a failing compile from crashing while
    # assembling an IR nobody will read. A clean compile has `errors == []` and
    # falls straight through, byte-identical to before.
    if errors:
        _raise_collected(errors, program)

    uses_components_2 = any(
        isinstance(stmt, (FailStmt, IfStmt))
        or (isinstance(stmt, (LetEffect, EffectStmt)) and stmt.setup)
        for comp in program.components
        for stmt in comp.body
    )
    # a timer (`every`/`after`, item 57) is additive v3: a consumer predating
    # the construct refuses the whole document rather than silently dropping a
    # `timer` body step it cannot schedule (docs/time-coeffect.md). ir_version
    # stays 3 — no bump beyond it.
    uses_timers = any(
        isinstance(stmt, (TimerStmt, StreamIterStmt))
        for comp in program.components
        for stmt in comp.body
    )
    uses_v2 = any(
        comp.get("isolate") or comp.get("intercept") or comp.get("routes")
        for comp in components)
    uses_v3 = any(not name.startswith("__") for name in types) or bool(fns) or bool(externs) or bool(tests)
    uses_v3 = uses_v3 or any(
        svc.commutative or any(m.async_ or m.commutative or m.idempotent
                               for m in svc.methods.values())
        for svc in services.values()
    )
    uses_v3 = uses_v3 or uses_components_2
    uses_v3 = uses_v3 or uses_timers
    # a `fault_tests` section is an additive v3 feature; the version bump is
    # itself a guard, so a consumer that predates the section refuses the
    # whole document instead of silently dropping the fault tests
    uses_v3 = uses_v3 or bool(fault_tests)
    # a `prop_tests` section is likewise additive v3 (roadmap item 37)
    uses_v3 = uses_v3 or bool(prop_tests)

    def _has_builtin(node) -> bool:
        if isinstance(node, dict):
            # a tagged ADT construction is a v3 feature too (`adt` node)
            if node.get("kind") in ("builtin", "adt"):
                return True
            return any(_has_builtin(v) for v in node.values())
        if isinstance(node, list):
            return any(_has_builtin(v) for v in node)
        return False

    uses_v3 = uses_v3 or any(_has_builtin(comp.get("body")) for comp in components)
    # instance-parametric components are a v3 feature: a `spawn` node in any
    # body bumps the version so a consumer predating the feature refuses the
    # document rather than mis-composing a runtime template as a static entry
    # (docs/design-v2-instances.md)
    uses_v3 = uses_v3 or bool(spawn_reg["templates"])

    result = {
        "ir_version": IR_VERSION_V3 if uses_v3 else (IR_VERSION_V2 if uses_v2 else IR_VERSION),
        "services": {
            name: {
                **({"commutative": True} if svc.commutative else {}),
                "methods": {
                    m.name: {
                        "params": _ir_params(
                            m.params, getattr(m, "secret_params", ())),
                        "returns": m.returns,
                        # roadmap item 441 / issue #120 (L5,
                        # docs/design/458-termination-language-surface.md §3, §6):
                        # which operations are termination criteria/guards is a
                        # HEADER fact, readable without lowering a body — the
                        # freeze and `revl goal audit` read this key. Present only
                        # when the operation's return was a `Criterion`/`Guard`
                        # marker (erased to the `Opt[Bool]` in `returns` above),
                        # so every existing service's IR is byte-identical (L6).
                        **({"termination": m.termination}
                           if getattr(m, "termination", None) else {}),
                        "emission": m.emission,
                        # only a *scoped* emission carries the key: bare
                        # `emission` means "any capability", and its absence
                        # is exactly that (so no pre-capability IR changes)
                        **({"capabilities": list(m.capabilities)}
                           if m.capabilities is not None else {}),
                        **({"async": True} if m.async_ else {}),
                        **({"commutative": True} if m.commutative else {}),
                        # delivery semantics (roadmap item 44): the checked
                        # right for the runtime to auto-retry this emission
                        **({"idempotent": True} if m.idempotent else {}),
                        # item 310: the capability-aware cache descriptor, the
                        # interface contract every provider inherits. Metadata the
                        # emission fixed point never reads (so every 414 static
                        # fold sees a cached crossing identically on both paths);
                        # the seam gate reads it at the call. Absent unless the
                        # method declares `cache`, so every existing method's IR
                        # is byte-identical.
                        **({"cache": _cache_ir(m.cache)} if m.cache else {}),
                        # item 257: `validated` + the derived `response_schema`,
                        # additive (byte-identical when absent). The gate refuses
                        # an unexpressible return type at compile time.
                        **_method_validated_ir(m, types, program.filename),
                        # item 457: the `route` clause resolved to a bind table +
                        # return classification, additive (byte-identical when the
                        # operation heads no `route`). The gate refuses an
                        # ill-bound path/query/body or a non-`ApiError` error type.
                        **_method_route_ir(m, types, program.filename, name),
                    }
                    for m in svc.methods.values()
                },
            }
            for name, svc in services.items()
        },
        "components": components,
        "manifest": manifest,
    }
    user_types = {name: spec for name, spec in types.items() if not name.startswith("__")}
    if user_types:
        result["types"] = user_types
    if fns:
        result["functions"] = fns
    if externs:
        result["externs"] = externs
    # item 256 Slice 1: the manifest-visible secret bindings (name + capability
    # only, never a value). Present only when the program binds a secret, so every
    # existing IR is byte-identical. The driver (run.py) resolves each name to a
    # value at plug and installs it into `_REVL_SECRETS`; the value lives nowhere
    # in the IR.
    if secrets_ir:
        result["secrets"] = secrets_ir
    if tests:
        result["tests"] = tests
    # the obligation ledger (docs/holes.md). Present only when the draft has
    # holes, so an IR document for finished code is byte-identical to before.
    obligations = holes.collect(result)
    if obligations:
        result["holes"] = obligations

    if fault_tests:
        result["fault_tests"] = fault_tests
    if prop_tests:
        result["prop_tests"] = prop_tests
    # item 249: the taint verdict has run, so `endorse(v)` — identity on the base
    # type — is spliced out of the IR here; no emitter or golden sees it. A
    # program with no `endorse` is rebuilt identically (byte-identity).
    if taint_model.active:
        result = splice_declassifiers(result)
    # item 379 Decision 2: the frame-neutrality invariant, enforced over the
    # fully-assembled IR (after every body is lowered and any declassifier
    # splice has run).
    _validate_no_loop_scoped_registration(result, program.filename)
    # item 445: the unique-ownership fact behind in-place accumulation, proved
    # ONCE here and stamped on the IR (`unique` on a self-rebinding `assign`,
    # `unique_birth` on the `let` that would need the defensive copy) instead of
    # re-derived per emitter — the go and python tiers had written the same
    # aliasing rule twice, and ts/rust/java/wasm would have written it four more
    # times. Runs last, over the fully-assembled IR, so the declassifier splice
    # above cannot invalidate an answer. Additive and absent on every node that
    # does not qualify, so an IR document for a program with no in-place
    # accumulation is byte-identical to before. See src/revl/ownership.py.
    ownership.annotate_ir(result)
    return result


# Admission gate and service-compatibility relation (DESIGN.md §5/§6.6) live
# in `admission.py` (roadmap item 17). Re-exported here so `revl.lower` keeps
# its public import surface: the check-and-lower spine, `plan.py`, and the
# service-compat tests all import these names from `revl.lower`.
from .admission import (  # noqa: E402,F401
    _Drift,
    _Touchers,
    _admit_handoff_replacement,
    _admit_provision_withdrawal,
    _admit_service_replacement,
    _caps_str,
    _caps_widen,
    _drift_error,
    _handoff_compatible,
    _handoff_error,
    _service_compatible,
    _service_equal,
    _service_from_ir,
    _service_touchers,
)


# ---------------------------------------------------------------- components

def _component_scope(env: Env) -> dict[str, str]:
    scope = {name: safe for name, safe in env.locals.items()}
    scope.update(env.params)
    return scope


def _component_req_call(env: Env, root: str, method: str, args: list, line: int) -> dict:
    if root not in env.requires:
        raise RevlError(env.filename, line,
                        f"`{root}` is not a declared requirement of {env.component.name}")
    # item 130: a required `Stream[T]` is a requirement but not a service, so a
    # method call on it is refused by name before the service table is indexed.
    if root in env.stream_requires:
        _refuse_stream_requirement_as_service(env, root, method, line)
    svc = env.services[env.requires[root]]
    decl = svc.methods.get(method)
    if decl is None:
        raise RevlError(env.filename, line,
                        f"`{root}.{method}` is not a method of service {svc.name}")
    if len(args) != len(decl.params):
        raise RevlError(env.filename, line,
                        f"`{root}.{method}` takes {len(decl.params)} "
                        f"argument(s), {len(args)} given")
    if decl.emission and getattr(env, "_expr_mode", "setup") == "setup":
        raise RevlError(
            env.filename, line,
            f"call to emission `{root}.{method}` must be marked `emit` (G4)",
            hint="an emission crosses the system boundary and cannot be reverted; "
                 "`emit` makes that visible at the call site",
        )
    for arg, (pname, ptype) in zip(args, decl.params):
        actual = infer_ir(arg, env.type_env, env.types, env.services)
        if ptype and actual and not compatible(ptype, actual, env.types):
            raise mismatch(env.filename, line,
                           f"`{root}.{method}` argument `{pname}`", ptype, actual)
    return {"kind": "call", "target": {"kind": "req", "name": root},
            "method": method, "args": args}


def _refuse_block_arm_stmt(stmt, filename: str):
    """A provide-method match block arm lowers only `let` bindings + a final
    expression (roadmap item 361): that is the shape BOTH tiers emit as an
    expression (an awaited walrus sequence on the expression-only python tier,
    an IIFE on ts). A loop / reassignment / destructuring is refused with a
    clear message rather than mis-compiled — the sound residual, narrower than
    the former blanket "not lowerable here" refusal."""
    desc = {
        AssignStmt: "a reassignment",
        WhileStmt: "a `while` loop",
        ForStmt: "a `for` loop",
        IfStmt: "a statement `if`",
        LetPatternStmt: "a destructuring `let`",
    }.get(type(stmt), "this statement")
    raise RevlError(
        filename, getattr(stmt, "line", 0),
        f"{desc} is not lowered inside a provide-method match block arm",
        hint="a block arm here supports `let` bindings and a final expression "
             "(the shape both tiers emit as an expression); lift a loop or "
             "reassignment into a module `fn`, or rewrite it with `let` / an "
             "`if`-expression (docs/records.md §6)",
        code="G6", category="block-arm",
    )


def _lower_component_block_arm(expr, env: Env, scope: dict[str, str],
                               callables: set, pure_only: bool = False) -> dict:
    """Lower a statement-block match arm (`=> { let x = …; expr }`) inside a
    component / provide-method body (roadmap item 361).

    A module-fn block arm is lambda-lifted into a synthetic helper `fn`
    (`_lift_block_arm`), but a provide-method block arm may read component
    `config` or a required service, which a module `fn` cannot hold — so it is
    lowered *inline* as a `do` expression (a `let`-sequence + a final value).
    The emitters render it as an IIFE (ts) / an awaited walrus sequence (py),
    so an async extern reached in the block is awaited within the method's
    in-flight window. The async-coloring fixed point and the A1 refusals are
    left untouched: they walk the lowered body (`_calls_in`), see the async
    callable inside the `do` node, and still refuse a *sync* method reaching
    it — only an `async` method admits and awaits it."""
    filename = env.filename
    inner = dict(scope)
    taken = set(inner.values())
    saved_tenv = dict(env.type_env)
    stmts: list[dict] = []
    try:
        for st in expr.stmts:
            if not isinstance(st, LetStmt):
                _refuse_block_arm_stmt(st, filename)
            value = _lower_component_pure_expr(st.value, env, inner, callables, pure_only)
            safe = _safe_name(st.name, taken)
            taken.add(safe)
            inner[st.name] = safe
            if st.type is not None:
                check_type_wellformed(filename, st.line, st.type)
                env.type_env[safe] = st.type
            else:
                inferred = infer_ir(value, env.type_env, env.types, env.services)
                if inferred is not None:
                    env.type_env[safe] = inferred
            stmts.append({"step": "let", "name": safe, "value": value,
                          "mutable": bool(st.mutable)})
        tail = _lower_component_pure_expr(expr.tail, env, inner, callables, pure_only)
    finally:
        env.type_env = saved_tenv
    return {"kind": "do", "stmts": stmts, "tail": tail}


def _check_component_call(node: dict, env: Env, filename: str, line: int) -> None:
    """Item 423: a component-body call to a declared `fn` or extern is held to
    the callee's declared arity and argument types.

    The judgment is not new and nothing here re-implements it. `infer_ir`'s
    `fn` arm already renders both refusals off the one signature table
    (`FNS_KEY`), the one arity rule and the one `unify`, and a `fn` body has
    always got them. What the component stratum was missing was the FILENAME:
    `infer_ir` is documented to raise on a definite mismatch only when handed
    one, and every component caller ran it in its non-raising oracle mode. So
    `let s = effect secret_put(42)` against `secret_put(v: Str)` compiled, and
    so did `secret_put("v", "w")`.

    Item 404 handed the filename over for a provide-method `let`, and item 420
    for the site `undo` slot. This is the general case, and it sits at the one
    place a component-stratum `fn` node is ever built, so no position can be
    forgotten: `_lower_expr` funnels every component expression here (setup and
    undo alike), which makes acquire expressions, site `undo`/`compensate`
    slots, `emit` and `await` expressions, `fail` messages, guard conditions,
    effect-block setup and provide-method bodies one covered surface rather
    than a list of slots to keep patching.

    Checking at construction also reaches what a root sweep cannot: an
    `infer_ir` walk from a step's root does not descend into an opaque `call`
    or `host` node's arguments, so `undo db.rollback(release(h))` hides its
    inner call from a root-only check. Here every call is judged as it is
    built, bottom-up, at its own line.

    Leniency is unchanged and load-bearing: an argument of unknown or
    host-frontier provenance infers to `None`, `unify` accepts it, and the
    call stays admitted. Only a DEFINITE mismatch raises.

    Item 420's slot-specific refusal composes here rather than beside here.
    The general judgment is the only one that runs, so it is the one that has
    to carry the position: `_lower_site_inverse` names the inverse slot on
    `env` for the duration of that slot's lowering, and a mismatch raised
    while it is set is re-rendered with the slot named and the two legal
    spellings listed. The MESSAGE is the stratum checker's verbatim either
    way, so the T1 shape consumers classify on never depends on position;
    only the HINT does, because at a site `undo` the generic hint offers
    advice the author cannot take (item 274)."""
    try:
        infer_ir(node, env.type_env, env.types, env.services, filename, line)
    except RevlError as err:
        slot = getattr(env, "_inverse_slot", None)
        if slot is None:
            raise
        raise _site_inverse_refusal(err, slot) from None


def _lower_component_pure_expr(expr, env: Env, scope: dict[str, str], callables: set,
                               pure_only: bool = False) -> dict:
    filename = env.filename
    line = getattr(expr, "line", 0)

    if isinstance(expr, ExprHole):
        return _lower_hole(expr, filename)

    if isinstance(expr, ExprEndorse):
        inner = _lower_component_pure_expr(expr.expr, env, scope, callables, pure_only)
        approval = _lower_endorse_approval(expr, env, scope, callables, pure_only)
        return _endorse_node(inner, expr, approval)

    # ADT construction (Result / user variants) — same tagged `adt` node as
    # the pure-fn path; Opt's Some/None stay untagged.
    cases = env.types.get(CASES_KEY) or {}
    if isinstance(expr, ExprCall) and isinstance(expr.callee, ExprVar) \
            and _tagged_case(expr.callee.name, env.types) is not None:
        info = cases[expr.callee.name]
        return {"kind": "adt", "type": info["adt"], "case": expr.callee.name,
                "args": [_lower_component_pure_expr(a, env, scope, callables, pure_only)
                         for a in expr.args]}
    if isinstance(expr, ExprVar):
        info = _tagged_case(expr.name, env.types)
        if info is not None and info.get("payload") is None \
                and not str(info.get("adt", "")).startswith(("Result", "Opt")):
            return {"kind": "adt", "type": info["adt"], "case": expr.name, "args": []}

    if isinstance(expr, EmitExpr):
        # the value of an irreversible call; the marker stays at the call site
        saved_mode = getattr(env, "_expr_mode", "setup")
        env._expr_mode = "emit"
        try:
            node = _lower_component_pure_expr(expr.expr, env, scope, callables, pure_only)
        finally:
            env._expr_mode = saved_mode
        if not _is_emission_call(node, env):
            raise RevlError(
                filename, expr.line,
                f"`emit` on {_node_desc(node)}, which is not declared `emission`",
                hint="only calls to `emission` service operations cross the boundary; "
                     "drop the `emit` marker (G4)",
                code="G4", category="emission",
            )
        return node
    if isinstance(expr, ExprMatch):
        # the ADT eliminator, available in component and method bodies too:
        # a component consuming a Result should not have to call out to a fn
        scrutinee = _lower_component_pure_expr(expr.scrutinee, env, scope,
                                               callables, pure_only)
        scrutinee_type = _expr_static_type(expr.scrutinee, env.type_env, env.types)
        _check_match_exhaustiveness(expr, env.type_env, env.types, filename)
        arms = []
        for pattern, bind, body in expr.arms:
            inner = dict(scope)
            payload_type = _arm_payload_type(scrutinee_type, pattern, env.types)
            if bind is not None:
                safe = _safe_name(bind, set(scope.values()))
                inner[bind] = safe
            arm = {
                "pattern": pattern,
                "bind": inner.get(bind) if bind is not None else None,
                "body": _lower_component_pure_expr(body, env, inner, callables, pure_only),
            }
            # the payload type a match arm binds, when the scrutinee's static
            # type is recoverable — the same key the pure-fn lowering
            # (`_lower_pure_expr`) writes, so a backend that must cast (java's
            # tagged Result) can do so in component/method bodies too
            if payload_type is not None:
                arm["payload_type"] = payload_type
            arms.append(arm)
        return {"kind": "match", "scrutinee": scrutinee, "arms": arms}
    if isinstance(expr, ExprLit):
        if expr.value is None:
            raise null_error(filename, line)
        return {"kind": "lit", "value": _literal_value(expr.value, filename, line)}
    if isinstance(expr, Interp):
        # A `${...}` template in a component/method body. Each interpolated
        # expression must lower in the CURRENT lexical `scope`, not through the
        # env-only `_lower_expr` — otherwise a name bound locally here (a
        # match-arm payload, `Word(w) => `word:${w}``) is invisible to the
        # template and misresolves as a component requirement (`w` is not a
        # declared requirement). This is the component-path twin of the fn-body
        # template-scope fix (#570, review item 8): the fn-body lowerer already
        # walks template parts in scope (`_lower_pure_expr`); the component path
        # deferred to `_lower_expr(env)` and lost the arm binding. Build the
        # same `format` node `_lower_expr` builds, but lower the expr parts in
        # `scope`.
        template: list[str] = []
        fmt_args: list = []
        for part_kind, value in expr.parts:
            if part_kind == "text":
                template.append(value.replace("$", "$$"))  # A4: literal dollars
            else:
                template.append(f"${len(fmt_args)}")
                fmt_args.append(_lower_component_pure_expr(
                    value, env, scope, callables, pure_only))
        return {"kind": "format", "template": "".join(template), "args": fmt_args}
    if isinstance(expr, ExprVar):
        name = expr.name
        if name in scope:
            return _resolve_provision_alias({"kind": "name", "id": scope[name]}, env)
        info = _tagged_case(name, env.types)
        if info is not None and info.get("payload") is None \
                and not str(info.get("adt", "")).startswith(("Result", "Opt")):
            return {"kind": "adt", "type": info["adt"], "case": name, "args": []}
        if name in callables:
            return {"kind": "var", "name": name}
        if name in getattr(env, "stream_requires", {}):
            # item 130: the key IS declared — it is a required stream, and a
            # stream is read only in a `subscribe` head.
            _refuse_stream_requirement_read(env, name, filename, line)
        if getattr(env, "_plain_body", False):
            declared = ", ".join(f"`{r}`" for r in env.requires) or "<nothing>"
            raise RevlError(
                filename, line,
                f"`{name}` is not a declared requirement of {env.component.name}",
                hint=f"component {env.component.name} requires {declared} — "
                     f"add `requires {name}: <Service>`?",
            )
        _reject_foreign_name(name, filename, line)  # item 384
        raise RevlError(filename, line,
                        f"`{name}` is not declared in this component effect block",
                        hint="declare it with `let` in the effect block, or use a "
                             "requirement/config field (G1)")
    if isinstance(expr, ExprField):
        if isinstance(expr.target, ExprVar) and expr.target.name == "config":
            if expr.name not in env.config_fields:
                raise RevlError(filename, line,
                                f"`{expr.name}` is not a config field of {env.component.name}")
            return {"kind": "config", "field": expr.name}
        lowered_target = _lower_component_pure_expr(expr.target, env, scope, callables,
                                                    pure_only)
        # `s.<key>` on a spawn handle is a provision read, not a record field
        # (docs/design-v2-instances.md). Only a name this component bound to a
        # handle carries `Instance[C]`, so it stays on the supervision tree.
        inst = _instance_handle_component(lowered_target, env)
        if inst is not None:
            return _lower_instance_get(lowered_target, expr.name, line, inst, env)
        target_type = infer_ir(lowered_target, env.type_env, env.types, env.services)
        # item 392: the provide-method / component-body twin of the item 380(2)
        # refusal in `infer_ast`. A field read off a value whose static type is
        # `Any`/`Value` (the erased-dynamic types — a `json_parse` result) is the
        # 279/299 silent-divergence class: py raises `KeyError` on an absent key,
        # ts yields `undefined`, and neither is a defensible total answer for a
        # field the author declared present. `infer_ast` (stratum 1 — fn/test/
        # module-fn bodies) already refuses it, and the component-setup sweep
        # reaches the same refusal in `infer_ir`; but a `provide` method body and
        # a component pure-expression position lower through here WITHOUT a
        # filename-carrying sweep, so the same expression compiled clean — the
        # same context-scoping gap as the `.length`-in-provide-method case marked
        # just below. Refuse it here with the identical diagnostic so the
        # divergence is a compile error on every tier, wherever the read sits.
        _thead, _ = parse_type(target_type)
        if filename and _thead in ("Any", "Value"):
            raise RevlError(
                filename, line,
                f"field read `.{expr.name}` on a value of type "
                f"`{render_type(target_type)}` — an erased value has no known fields",
                hint=("bind it to a record type first "
                      f"(`let e: SomeRecord = …; e.{expr.name}` — an `Opt[T]` "
                      "field then reads back the empty Opt on absence), or walk "
                      "it with stdlib/value.rvl (`value_is_object(v)`, "
                      f"`value_opt(v, \"{expr.name}\")`, `value_field_or`)"),
                code="T1", category="type-mismatch")
        node = {"kind": "field", "target": lowered_target, "name": expr.name}
        # item 104 (cross-tier): the property form `.length` in a COMPONENT
        # position stays a `field` node (the fn-body form is a `len` node — that
        # split is deliberate). But `.length` on a sized value (Str/Bytes/List)
        # is the code-point/element count, not a record slot: each tier's field
        # emitter reads a record field by `getattr`/member, which raises on a
        # `Str`. The component emitters carry no static type at the field site
        # (unlike the typed wasm/rust emitters), so the frontend marks the node
        # here — with the SAME `_is_sized_type` check — and the field handlers
        # honour the mark, rendering the code-point path. Gated on a sized type,
        # so a record whose field is literally named `length` still reads its
        # slot.
        if expr.name == "length" and _is_sized_type(target_type):
            node["sized_length"] = True
        # item 380: an `Opt[T]`-declared field reads TOTAL on every tier.
        elif _field_is_opt(target_type, expr.name, env.types):
            node["opt"] = True
        return node
    if isinstance(expr, ExprCall):
        args = [_lower_component_pure_expr(a, env, scope, callables, pure_only)
                for a in expr.args]
        # A spawn-handle provision flowing in as an ARGUMENT to a local arrow
        # whose parameter carries the service type is the same boundary crossing
        # as calling the provision directly; follow it across the parameter
        # binding so the arrow body's `emit`-marker discipline matches the direct
        # spelling (GHSA-wg4v-r47x-52p2 residual — the sibling of #331's alias).
        if isinstance(expr.callee, ExprVar) \
                and expr.callee.name in (getattr(env, "local_arrows", None) or {}):
            _check_arrow_param_crossings(
                env.local_arrows[expr.callee.name], args, env, scope,
                callables, pure_only)
        # A method call whose receiver is a NAME takes the var-root fast paths
        # below (host family, required service, stdlib builtin, opaque local) —
        # except when that name is a spawn-handle provision alias. Those must
        # take the generic fall-through, where the receiver lowers back to its
        # `instance-get` and the call is judged as the direct `w.<key>.<method>`
        # spelling is: `emit`-marked (G4), folded into the audit surface (G8),
        # counted by cardinality. Skipping the fast paths IS the fix — nothing
        # below needed to learn about aliases.
        if isinstance(expr.callee, ExprField) and isinstance(expr.callee.target, ExprVar) \
                and scope.get(expr.callee.target.name) not in \
                (getattr(env, "provision_locals", None) or {}):
            root = expr.callee.target.name
            method = expr.callee.name
            if root in _HOST_CALLABLES:
                # the Map VALUE constructor (docs/stdlib-2.0.md §Map) — a
                # pure value, not an effect; intercepted before the host
                # builtin check (`empty` is not a host verb).
                if root == "Map" and method == "empty":
                    if args:
                        raise RevlError(
                            filename, line,
                            f"`Map.empty()` takes no arguments, {len(args)} given",
                            hint="build up an empty map with `set`: "
                                 "`Map.empty().set(\"k\", v)`",
                        )
                    return {"kind": "maplit", "entries": []}
                if pure_only:
                    raise RevlError(
                        filename, line,
                        f"host builtin `{root}.{method}` is an effect and cannot appear "
                        "in pure setup",
                        hint="move the acquisition to the final expression of the effect block (G6)",
                    )
                # G4: a host ACQUIRE verb only in an acquisition bracket.
                if f"{root}.{method}" in _HOST_ACQUIRE_VERBS \
                        and expr is not getattr(env, "_host_acquire_root", None):
                    mode = getattr(env, "_expr_mode", "setup")
                    where = ("a teardown slot" if mode == "undo"
                             else "an `emit` expression" if mode == "emit"
                             else "this position")
                    _refuse_unbracketed_host_acquire(root, method, where,
                                                     filename, line)
                host_check(f"{root}.{method}",
                           [infer_ir(a, env.type_env, env.types, env.services)
                            for a in args],
                           filename, line)
                return {"kind": "host", "fn": f"{root}.{method}", "args": args}
            # host provenance (docs/stdlib-2.0.md §Map): a local bound to a
            # host acquisition keeps its stub verb surface verbatim — checked
            # BEFORE the builtin table so the sanctioned `remove` overlap
            # dispatches by receiver kind, never by name alone. The verb is
            # checked against the acquisition's family surface (item 401): an
            # unknown verb (`store.frobnicate(k)`) is refused here (HOST-METHOD)
            # instead of compiling as a pass-through that only crashes at the
            # host runtime, the item-84 shape.
            if scope.get(root) in env.host_locals:
                _check_host_verb(
                    env.host_locals[scope[root]], method, len(args),
                    filename, line)
                return {"kind": "call",
                        "target": {"kind": "name", "id": scope[root]},
                        "method": method, "args": args}
            if root in env.requires:
                if pure_only:
                    raise RevlError(
                        filename, line,
                        f"call to required service `{root}.{method}` is an effect and cannot "
                        "appear in pure setup",
                        hint="service calls must be acquired with `effect ... undo ...` or "
                             "marked `emit` (G4/G6)",
                    )
                return _component_req_call(env, root, method, args, line)
            if method in _BUILTIN_METHODS:
                # The stdlib-named-method sliver (roadmap 75(b)), same rule as
                # a `fn` body: only a receiver the checker can *prove* is a
                # stdlib value may take the builtin table. A local of unknown
                # type (a host-object result such as `let v = store.get(k)`)
                # used to lower a stdlib-named method as that builtin and
                # misdispatch at runtime; refuse it (HOST-METHOD). Undeclared
                # roots fall through and are caught by G1 name resolution.
                if root in scope:
                    recv_t = infer_ir({"kind": "name", "id": scope[root]},
                                      env.type_env, env.types, env.services)
                    if _is_wildcard(recv_t):
                        _refuse_unpinned_stdlib_method(method, recv_t,
                                                       filename, line)
                if len(args) != _BUILTIN_METHODS[method]:
                    raise RevlError(filename, line,
                                    f"builtin `{method}` takes {_BUILTIN_METHODS[method]} "
                                    f"argument(s), {len(args)} given")
                node: dict = {"kind": "builtin", "method": method,
                              "target": _lower_component_pure_expr(expr.callee.target, env, scope,
                                                                   callables, pure_only),
                              "args": args}
                if method == "to_int":
                    # receiver-family dispatch (`recv`), as in a fn body — the
                    # tiers read it to tell a Str/Int32 `to_int` apart.
                    node["recv"] = infer_ir({"kind": "name", "id": scope[root]},
                                            env.type_env, env.types, env.services)
                elif method == "to_str":
                    # only a Float `to_str` needs the tag (canonical `ftoa`); it
                    # is attached solely for a Float receiver so the common Int
                    # case stays tag-less, matching the self-host frontend.
                    recv_ty = infer_ir({"kind": "name", "id": scope[root]},
                                       env.type_env, env.types, env.services)
                    if recv_ty == "Float":
                        node["recv"] = recv_ty
                return node
            if root in scope:
                # A method on a local that is a *known* stdlib-bearing value
                # (Str/List/Bytes) must be a builtin — builtins were already
                # handled above, so a non-builtin here is a typo/misuse, not a
                # host method. Receivers of unknown/host type infer to None and
                # stay lenient (host provenance is exempt — docs/stdlib-2.0.md).
                recv_t = infer_ir({"kind": "name", "id": scope[root]},
                                  env.type_env, env.types, env.services)
                if parse_type(recv_t)[0] in _SIZED_HEADS:
                    raise RevlError(
                        filename, line,
                        f"no builtin method `{method}` on `{recv_t}` — the stdlib surface is "
                        f"{', '.join(sorted(_BUILTIN_METHODS))} (docs/stdlib-2.0.md)",
                        hint="records carry data, not methods; call functions as `f(x)` (G6)",
                    )
                return {"kind": "call",
                        "target": {"kind": "name", "id": scope[root]},
                        "method": method, "args": args}
        if isinstance(expr.callee, ExprVar):
            name = expr.callee.name
            # ADT/Opt construction lowers exactly as it does in a `fn` body:
            # tagged variants to an `adt` node, Some/None to identity/null.
            # Emitting a plain call here would name a constructor the host
            # runtimes do not define (they are not functions).
            if _tagged_case(name, env.types) is not None:
                info = (env.types.get(CASES_KEY) or {})[name]
                return {"kind": "adt", "type": info["adt"], "case": name, "args": args}
            if name in _BUILTIN_CONSTRUCTORS:
                return {"kind": "call", "callee": {"kind": "var", "name": name},
                        "args": args}
            if name in callables:
                # item 187: fill omitted trailing arguments with their default
                # expressions before async coercion, so the module-fn call the
                # emitters see is fully supplied (no per-tier default handling).
                filled = _with_default_args(
                    name, args, env.types,
                    lambda d: _lower_component_pure_expr(d, env, scope,
                                                         callables, pure_only))
                node = {"kind": "fn", "name": name,
                        "args": _coerce_async_args(name, filled, env, line)}
                _check_component_call(node, env, filename, line)
                return node
        if isinstance(expr.callee, ExprField) and expr.callee.name in _BUILTIN_METHODS:
            method = expr.callee.name
            # the same sliver guard as the var-root path above: a non-var
            # receiver of unknown type (e.g. `open_pool("pg://").remove(k)`)
            # must not lower as the builtin either
            target = _lower_component_pure_expr(expr.callee.target, env, scope,
                                                callables, pure_only)
            recv_t = infer_ir(target, env.type_env, env.types, env.services)
            if _is_wildcard(recv_t):
                _refuse_unpinned_stdlib_method(method, recv_t, filename, line)
            if len(args) != _BUILTIN_METHODS[method]:
                raise RevlError(filename, line,
                                f"builtin `{method}` takes {_BUILTIN_METHODS[method]} "
                                f"argument(s), {len(args)} given")
            node: dict = {"kind": "builtin", "method": method, "target": target,
                          "args": args}
            if method == "to_int":
                # receiver-family dispatch (`recv`), as in a fn body
                node["recv"] = infer_ast(expr.callee.target, env.type_env,
                                         env.types, None)
            elif method == "to_str":
                # only a Float `to_str` needs the tag; attach it solely for a
                # Float receiver so the common Int case matches the self-host.
                recv_ty = infer_ast(expr.callee.target, env.type_env,
                                    env.types, None)
                if recv_ty == "Float":
                    node["recv"] = recv_ty
            return node
        callee_node = _lower_component_pure_expr(expr.callee, env, scope, callables,
                                                 pure_only)
        # a provision method call off a spawn handle (`s.<key>.<method>(...)`)
        # crosses the boundary exactly as a `req` emission does, so the same
        # `emit`-marker discipline applies — an unmarked emission is refused
        # (G4), not silently lowered. The `req` path enforces this inline
        # (`_component_req_call`); the handle path reaches the generic
        # fall-through, so the check lives here.
        inst = _instance_get_call({"kind": "call", "callee": callee_node,
                                   "args": args}, env)
        if inst is not None:
            recv, decl = inst
            if decl.emission and getattr(env, "_expr_mode", "setup") == "setup":
                handle = recv.get("target") if isinstance(recv.get("target"), dict) else {}
                spelled = ".".join(p for p in (handle.get("id"), recv.get("key"),
                                               callee_node.get("name")) if p)
                raise RevlError(
                    filename, line,
                    f"call to emission `{spelled}` must be marked `emit` (G4)",
                    hint="an emission crosses the system boundary and cannot be reverted; "
                         "`emit` makes that visible at the call site",
                    code="G4", category="emission",
                )
        return {"kind": "call", "callee": callee_node, "args": args}
    if isinstance(expr, ExprBin):
        node = {"kind": "bin", "op": expr.op,
                "left": _lower_component_pure_expr(expr.left, env, scope, callables,
                                                   pure_only),
                "right": _lower_component_pure_expr(expr.right, env, scope, callables,
                                                    pure_only)}
        # A provide-method body is a second renderer on every tier, so a
        # comparison written there must mean what the same comparison means in
        # a module `fn` — the lesson item 458's `&&`/`||` fix already paid for.
        # `env.type_env` carries the method's parameter types (the service
        # signature is their source of truth, A6); an operand it cannot type
        # is simply left unannotated, never guessed.
        if expr.op in _RELATIONAL_OPS:
            tenv = getattr(env, "type_env", None) or {}
            if (infer_ast(expr.left, tenv, env.types, None) == "Str"
                    and infer_ast(expr.right, tenv, env.types, None) == "Str"):
                node["operands"] = "Str"
        return node
    if isinstance(expr, ExprUn):
        return {"kind": "un", "op": expr.op,
                "operand": _lower_component_pure_expr(expr.operand, env, scope, callables,
                                                      pure_only)}
    if isinstance(expr, ExprIndex):
        return {"kind": "index",
                "target": _lower_component_pure_expr(expr.target, env, scope, callables,
                                                     pure_only),
                "index": _lower_component_pure_expr(expr.index, env, scope, callables,
                                                    pure_only)}
    if isinstance(expr, ExprIf):
        return {"kind": "if",
                "cond": _lower_component_pure_expr(expr.cond, env, scope, callables,
                                                   pure_only),
                "then": _lower_component_pure_expr(expr.then, env, scope, callables,
                                                   pure_only),
                "else": _lower_component_pure_expr(expr.otherwise, env, scope, callables,
                                                   pure_only)}
    if isinstance(expr, ExprRecord):
        if isinstance(expr, ExprAsset):  # item 459 F1
            _require_resolved_asset(expr, env.filename)
        return {"kind": "record",
                "fields": [[name, _lower_component_pure_expr(e, env, scope, callables,
                                                             pure_only)]
                           for name, e in expr.fields]}
    if isinstance(expr, ExprRecordUpdate):
        return {"kind": "record_update",
                "base": _lower_component_pure_expr(expr.base, env, scope, callables,
                                                   pure_only),
                "updates": [[name, _lower_component_pure_expr(e, env, scope, callables,
                                                              pure_only)]
                            for name, e in expr.updates]}
    if isinstance(expr, ExprBlockArm):
        return _lower_component_block_arm(expr, env, scope, callables, pure_only)
    if isinstance(expr, ExprList):
        return {"kind": "list",
                "items": [_lower_component_pure_expr(e, env, scope, callables, pure_only)
                          for e in expr.items]}
    if isinstance(expr, ExprArrow):
        # Arrow parameters bind in the arrow's body scope — including inside
        # provide-method bodies (roadmap 77a / FR-1): the pure-helper +
        # callback-arrow escape depends on `msgs2 => emit model.complete(msgs2)`
        # resolving `msgs2` to the arrow parameter, not misreading it as a
        # missing component requirement. Same shape as the pure-fn path below:
        # params shadow the enclosing scope; free vars captured from it are
        # snapshotted by value (unchanged).
        inner = dict(scope)
        param_types = _arrow_param_types(expr)
        # A stratum-3 arrow (a provide-method / component-body arrow) is not
        # checked yet, so `param_types` is None even when the author annotated
        # every parameter; the annotations survive on `written_param_types`.
        # For a parameter the author declared as a SERVICE type, carry that type
        # into `type_env` so a boundary crossing through the parameter is judged
        # as the emission it is (GHSA-wg4v-r47x-52p2 residual). Scoped to service
        # types so no other inference (stdlib-method pinning, field reads) sees a
        # type it did not see before — the IR node keys stay gated on the full
        # checked signature (`_arrow_signature_known`), so the IR is unmoved.
        declared = _arrow_declared_param_types(expr)
        for param, ptype, dtype in zip(expr.params, param_types, declared):
            # the component path resolves names through `id` (unlike the
            # pure-fn path's raw `var`), so the arrow parameter maps to its
            # own name — the emitted lambda binds params positionally, and a
            # `name` node for the parameter must render to exactly that.
            inner[param] = param
            svc_head, _ = parse_type(dtype or "")
            if ptype:
                env.type_env[param] = ptype
            elif dtype and svc_head in env.services:
                env.type_env[param] = dtype
            else:
                env.type_env.pop(param, None)
        captures = sorted(_mutable_free_vars(expr.body, scope, set(expr.params)))
        _b1_capture_check(expr, env.type_env, env.types, filename, expr.line)
        node = {"kind": "arrow", "params": expr.params, "captures": captures,
                "body": _lower_component_pure_expr(expr.body, env, inner, callables,
                                                   pure_only)}
        # item 75(a) §4/§5.3: the same complete-signature condition as the
        # pure-fn path. Stratum 3 does not *check* an arrow yet (slice 3), but
        # the grammar and the R3 fix land everywhere at once — there is one
        # parser and one lowering contract.
        _assert_colour_is_positional(expr, filename)
        if _arrow_signature_known(expr):
            node["param_types"] = param_types
            node["returns"] = expr.returns or "Any"
        # G8 audit provenance (GHSA-wg4v-r47x-52p2 residual): which parameters
        # are boundary handles (service-typed), so `_boundary` can enumerate a
        # crossing routed through the parameter when the arrow is applied to a
        # provision — the audit-surface twin of the G4 marker demand above.
        # Present only when a parameter carries a service type (the new case),
        # so no existing arrow node moves; ignored by every emitter (they read
        # params/body/captures/param_types/returns).
        svc_params = {p: d for p, d in zip(expr.params, declared)
                      if d and parse_type(d)[0] in env.services}
        if svc_params:
            node["service_params"] = svc_params
        return node
    if isinstance(expr, ExprOptField):
        return {
            "kind": "optfield",
            "target": _lower_component_pure_expr(expr.target, env, scope, callables, pure_only),
            "name": expr.name,
        }
    if isinstance(expr, ExprOptCall):
        return {
            "kind": "optcall",
            "target": _lower_component_pure_expr(expr.target, env, scope, callables, pure_only),
            "method": expr.method,
            "args": [_lower_component_pure_expr(a, env, scope, callables, pure_only) for a in expr.args],
        }
    raise RevlError(filename, line, "unsupported expression in component effect block",
                    hint="block-effect setup is stratum-1 pure code (G6)")


def _lower_component_setup_stmt(stmt, env: Env, scope: dict[str, str], callables: set,
                                mutables: set[str], out: list) -> None:
    filename = env.filename

    def _sweep(node, line):
        # Run the raising type oracle over a lowered setup node (HOLE 3(c) /
        # HOLE 2): definite operator/builtin misuse in stratum-1 setup code now
        # raises, exactly as it does in a `fn` body. Unknown/host operands infer
        # to None and are left alone. Returns the inferred type (or None).
        return infer_ir(node, env.type_env, env.types, env.services, filename, line)

    if isinstance(stmt, LetStmt):
        safe = env.bind_local(stmt.name, stmt.line)
        scope[stmt.name] = safe
        if stmt.mutable:
            mutables.add(stmt.name)
        value = _lower_component_pure_expr(stmt.value, env, scope, callables,
                                           pure_only=True)
        inferred = _sweep(value, stmt.line)
        if inferred is not None:
            env.type_env[safe] = inferred
        _note_provision_alias(safe, value, env)
        env.provision_values[stmt.name] = stmt.value
        if isinstance(stmt.value, ExprArrow):
            env.local_arrows[stmt.name] = stmt.value
        out.append({"step": "let", "name": safe, "value": value})
    elif isinstance(stmt, AssignStmt):
        if stmt.name not in scope:
            _reject_foreign_name(stmt.name, filename, stmt.line)  # item 384
            raise RevlError(filename, stmt.line,
                            f"`{stmt.name}` is not declared in this effect block",
                            hint="declare it with `let`/`var` first (G1)")
        if stmt.name not in mutables:
            raise RevlError(filename, stmt.line,
                            f"cannot reassign `{stmt.name}` — it is `let` (single-assignment)",
                            hint="declare it with `var` to make it mutable (syntax-2.0 §3.5)")
        value = _lower_component_pure_expr(stmt.value, env, scope, callables,
                                           pure_only=True)
        _sweep(value, stmt.line)
        out.append({"step": "assign", "name": scope[stmt.name], "value": value})
    elif isinstance(stmt, ExprStmt):
        expr = _lower_component_pure_expr(stmt.expr, env, scope, callables,
                                          pure_only=True)
        _sweep(expr, stmt.line)
        out.append({"step": "expr", "expr": expr})
    elif isinstance(stmt, IfStmt):
        cond = _lower_component_pure_expr(stmt.cond, env, scope, callables,
                                          pure_only=True)
        cond_t = _sweep(cond, stmt.line)
        if cond_t is not None and cond_t != "Bool":
            raise mismatch(filename, stmt.line, "`if` condition", "Bool", cond_t)
        then: list[dict] = []
        for s in stmt.then:
            _lower_component_setup_stmt(s, env, scope, callables, mutables, then)
        otherwise = None
        if stmt.otherwise is not None:
            otherwise = []
            for s in stmt.otherwise:
                _lower_component_setup_stmt(s, env, scope, callables, mutables, otherwise)
        out.append({"step": "if", "cond": cond, "then": then})
        if otherwise is not None:
            out[-1]["else"] = otherwise
    elif isinstance(stmt, AssertStmt):
        expr = _lower_component_pure_expr(stmt.expr, env, scope, callables,
                                          pure_only=True)
        assert_t = _sweep(expr, stmt.line)
        if assert_t is not None and assert_t != "Bool":
            raise mismatch(filename, stmt.line, "`assert`", "Bool", assert_t)
        out.append({"step": "assert", "expr": expr})
    else:
        raise RevlError(filename, getattr(stmt, "line", 0),
                        "unsupported statement in effect block setup",
                        hint="effect block setup is stratum-1 pure code: "
                             "`let`/`var`/`if`/pure calls are allowed (G6)")


def _lower_component_guard_stmts(stmts: list, env: Env, callables: set) -> list[dict]:
    out: list[dict] = []
    for stmt in stmts:
        if isinstance(stmt, FailStmt):
            out.append({
                "step": "fail",
                "message": _lower_component_pure_expr(
                    stmt.message, env, _component_scope(env), callables,
                    pure_only=True,
                ),
            })
        elif isinstance(stmt, IfStmt):
            out.append(_lower_component_if(stmt, env, callables))
        else:
            raise RevlError(env.filename, getattr(stmt, "line", 0),
                            "only `fail` (and nested `if` guards) may appear in a component guard",
                            hint="component `if` is for deliberate L-Raise decisions, not general "
                                 "control flow (G6)")
    return out


def _lower_component_if(stmt: IfStmt, env: Env, callables: set) -> dict:
    scope = _component_scope(env)
    # a guard condition is a `Bool` position, so a hole there is a `Bool`
    # obligation rather than an untyped one (docs/holes.md)
    pin_hole(stmt.cond, "Bool", env.filename, "`if` guard condition")
    step = {
        "step": "if",
        "cond": _lower_component_pure_expr(stmt.cond, env, scope, callables,
                                           pure_only=True),
        "then": _lower_component_guard_stmts(stmt.then, env, callables),
    }
    if stmt.otherwise is not None:
        step["else"] = _lower_component_guard_stmts(stmt.otherwise, env, callables)
    return step


def _config_default_type(value) -> str | None:
    """Surface type of a config-default literal (bool before int: bool is an
    int subclass)."""
    if isinstance(value, bool):
        return "Bool"
    if isinstance(value, int):
        return "Int"
    if isinstance(value, float):
        return "Float"
    if isinstance(value, str):
        return "Str"
    return None


# Emission reachability, capability sets, and the G4 evidence trail live in
# `emission_analysis.py` (roadmap item 17). Re-exported here so `revl.lower`
# keeps its public import surface: the spine, `query.py`, `__main__.py`, and
# the capability tests all import these names from `revl.lower`.
from .emission_analysis import (  # noqa: E402,F401
    _EmissionEvidence,
    _HOST_CONFINED_CAP_ROOTS,
    _async_callables,
    _cap_realm_root,
    _is_async_fn_type,
    _calls_in,
    _capability_hint,
    _emission_chain,
    _emitting_capabilities,
    _emitting_fns,
    _method_emissions,
    _witness_depth,
    cap_scope_enumerated_not_run,
)


def _async_reached_outside_provide(node, async_names: set, acc: set) -> None:
    """Async extern names a lowered component body reaches, *excluding* the
    positions that carry their own in-flight window or admission gate. Mirrors
    `_calls_in`'s call/value detection but prunes provide steps, timer steps,
    and — since item 131 — the `effect`/`let-effect`/`emit`/`await` steps.

    A `timer` body (item 57) reaching an async op is no longer refused here: a
    timer is a spawned in-flight handle (item 106's `Async[T]` window), so it is
    coloured async in `_lower_timer_step` and its firing is awaited/cancelled by
    the runtime, exactly like a provide method's own async reach is admitted at
    its site above (docs/time-coeffect.md §async).

    Item 131: the `await` step is pruned (its suspension is admitted, widened to
    async externs/colored fns), and an AWAIT-MARKED effect/emit step is pruned
    (an awaited async acquisition/emission is admitted). A NON-await effect/emit
    step is still walked, so an async-callable reached without `await` keeps this
    legacy "reaches async … in a setup/activation body" refusal — the message
    the self-hosted admission gate mirrors. The req-op family that gate is blind
    to is caught instead by `_admit_effect_async`/`_admit_emit_async` (rule 1),
    which run during lowering and set the `async` flag this prune reads."""
    if isinstance(node, dict):
        step = node.get("step")
        if step in ("provide", "timer", "await"):
            return
        if step in ("effect", "let-effect", "emit") and node.get("async"):
            return
        kind = node.get("kind")
        if kind == "fn" and node.get("name") in async_names:
            acc.add(node["name"])
        callee = node.get("callee")
        if kind == "call" and isinstance(callee, dict) \
                and callee.get("kind") == "var" and callee.get("name") in async_names:
            acc.add(callee["name"])
        if kind == "var" and node.get("name") in async_names:
            acc.add(node["name"])
        for value in node.values():
            _async_reached_outside_provide(value, async_names, acc)
    elif isinstance(node, list):
        for value in node:
            _async_reached_outside_provide(value, async_names, acc)


def _activation_can_hang(body) -> bool:
    """Whether this activation body has anything that can go silently hung —
    the admission signal item 477's declared-ceiling G-rule reads.

    A hung provider is one stuck mid-activation on a call that neither returns
    nor faults. The activation-time surface for that (docs/design/async-extern.md
    §"Component bodies" already fixes the vocabulary, and A1 forbids an *async*
    reach here) is:

      * an `emit` step — an emission crossing to a host boundary; and
      * an `effect`/`let-effect` step — a host acquisition (`kind: "host"`) or a
        cross to a required service (`kind: "call"` on a `req` receiver), either
        of which can block.

    A `provide` step is PRUNED: its method bodies run per call, not during the
    activation transition, so a ceiling on the activation does not measure them
    (mirrors `_async_reached_outside_provide`'s prune). A body with none of the
    above — only pure `let`s and its `provide` registrations — completes without
    any crossing that can stall, so it has nothing to be silent about, and a
    declared ceiling on it is a category error the G-rule refuses."""
    if isinstance(body, dict):
        step = body.get("step")
        if step == "provide":
            return False
        if step in ("emit", "effect", "let-effect"):
            return True
        return any(_activation_can_hang(value) for value in body.values())
    if isinstance(body, list):
        return any(_activation_can_hang(item) for item in body)
    return False


def _async_service_op(node, env):
    """The async service operation a lowered call/emit node reaches directly, as
    `(display_name, method, op_decl)` — else `None`.

    Two receiver shapes reach one, and both are suspension sources the name-based
    `_calls_in` is blind to (rule 3 of the item-92 async-reach):

      * a REQUIRED KEY — `emit model.complete(x)`, whose `req` receiver sits in
        the node's `target` slot;
      * a SPAWN HANDLE's provision — `emit w1.wtask.run(x)` (roadmap item 98,
        harness finding #27). The pure stratum lowers `w1.wtask` to an
        `instance-get` carrying the service its key yields, and the trailing
        `.run(...)` wraps it in a `field` callee, so the receiver arrives through
        `callee`, not `target` (`_instance_get_call`, the same detour
        `_is_emission_call` already takes for the G4 emission marker).

    Reading only the `req` shape left the handle shape uncoloured: an arrow
    delegating to a spawned async worker was neither refused for carrying no
    async colour nor coloured, and the py tier handed its caller an unawaited
    coroutine. A spawned instance's async op suspends exactly as a required
    service's does, so both answer here.

    `display_name` is what a diagnostic names as the culprit's receiver:
    `model` for a required key, `w1.wtask` for a handle provision."""
    if not isinstance(node, dict):
        return None
    target = node.get("target")
    method = node.get("method")
    if isinstance(target, dict) and target.get("kind") == "req" and method:
        svc = env.services.get(env.requires.get(target.get("name")) or "")
        decl = svc.methods.get(method) if svc is not None else None
        if decl is not None and getattr(decl, "async_", False):
            return (target.get("name"), method, decl)
        return None
    inst = _instance_get_call(node, env)
    if inst is not None and getattr(inst[1], "async_", False):
        recv, decl = inst
        handle = recv.get("target") or {}
        holder = handle.get("id") if isinstance(handle, dict) else None
        key = recv.get("key")
        name = ".".join(part for part in (holder, key) if part)
        return (name, node["callee"]["name"], decl)
    return None


def _req_op_is_async(node, env) -> bool:
    """A lowered call/emit node that reaches an async service operation — through
    a required key or a spawn handle's provision (`_async_service_op`)."""
    return _async_service_op(node, env) is not None


def _reached_async_req_ops(node, env, acc: list) -> None:
    """Collect the async service ops (`req.method`, or a spawn handle's
    `h.<key>.<op>`, whose op is `async fn`) a lowered method body reaches
    DIRECTLY — in statement OR expression position (a ternary arm, a nested
    expression), the blind spot item 117 closes. The name-based `_calls_in` the
    A1 provide-method check runs sees async *callables* (externs, colored fns)
    but never an async *service operation* reached through a required key or a
    spawned instance (rule 3 of the item-92 async-reach), so a sync method whose
    ternary returns `emit m.op(x)` slipped through as admitted (finding #40).

    Any nested arrow is pruned: an arrow value's async-reach is the concern of
    `_refuse_leaky_arrow`/`_refuse_leaky_pure_arrow` (finding #21), which raise
    the arrow-color diagnostic instead — this walk owns only the ops the method
    body reaches without an intervening arrow. Each hit is
    `(receiver_name, method, op_decl)`."""
    if isinstance(node, dict):
        if node.get("kind") == "arrow":
            return
        hit = _async_service_op(node, env)
        if hit is not None:
            acc.append(hit)
        for value in node.values():
            _reached_async_req_ops(value, env, acc)
    elif isinstance(node, list):
        for value in node:
            _reached_async_req_ops(value, env, acc)


def _reaches_stream_next(node, env) -> str | None:
    """The first `<sub>.next()` on a live subscription a lowered expression
    reaches, named for a diagnostic, or None (item 130).

    `next` is a suspension source (it awaits the next item raced against the
    subscription's cancel token, §4.6), so it is admitted only where a suspension
    is legal — never in a teardown slot (`undo`/`compensate`), where the two-phase
    abort loop is synchronous and a park could hang or silently no-op (rule 3.4:
    `close`, the inverse, must not itself `next`). A subscription is a host-local
    of the reserved `Subscription` family (set at the `subscribe` bracket)."""
    host_locals = getattr(env, "host_locals", None) or {}
    if isinstance(node, dict):
        target = node.get("target")
        if node.get("kind") == "call" and node.get("method") == "next" \
                and isinstance(target, dict) and target.get("kind") == "name" \
                and host_locals.get(target.get("id")) == "Subscription":
            return "next"
        for value in node.values():
            hit = _reaches_stream_next(value, env)
            if hit is not None:
                return hit
    elif isinstance(node, list):
        for value in node:
            hit = _reaches_stream_next(value, env)
            if hit is not None:
                return hit
    return None


def _first_suspension(node, env) -> str | None:
    """The first suspension source a lowered ACTIVATION-body expression reaches,
    named for a diagnostic, or None (item 131). A suspension source is either a
    req-target `async fn` service operation (rule 3 of the item-92 async-reach,
    the blind spot the name-based walk misses) or an async-colored callable — an
    `async` extern or a phase-2 colored fn (rule 1). Nested arrows are pruned:
    an arrow value's color is its own concern, refused by `_refuse_leaky_arrow`.

    This is the shared predicate behind the four admission rules of item 131 §3.
    It looks past the name-based `_async_reached_outside_provide` walk precisely
    where that walk is blind — a req-target async op — closing the two silent
    `effect`/`emit` leaks and the two silent teardown leaks the probe table
    named.

    Item 130 folds a stream `<sub>.next()` in here as a fourth suspension source,
    so the same teardown gate that refuses an awaited `undo` also refuses a
    `next` in a teardown slot (rule 3.4)."""
    reached: list = []
    _reached_async_req_ops(node, env, reached)
    if reached:
        req_name, method, _op = reached[0]
        return f"{req_name}.{method}"
    stream_next = _reaches_stream_next(node, env)
    if stream_next is not None:
        return stream_next
    called: set = set()
    _calls_in(node, called, stop_async_arrows=True)
    hit = sorted(called & (getattr(env, "async_callables", None) or set()))
    if hit:
        return hit[0]
    return None


def _first_reqop_suspension(node, env) -> str | None:
    """The first REQ-TARGET async service op a lowered expression reaches (rule
    3 of the item-92 async-reach), or None. This is the family the name-based
    `_async_reached_outside_provide` fence is blind to — the two silent leaks of
    item 131's probe table. An async-colored callable (an async extern or a
    phase-2 colored fn) is deliberately NOT reported here: that family is still
    refused by the name-based fence with its legacy "reaches async … in a
    setup/activation body" diagnostic (which the self-hosted gate mirrors), so
    the effect-composition rule-1 refusal owns only the req-op family it is the
    first to name."""
    reached: list = []
    _reached_async_req_ops(node, env, reached)
    if reached:
        req_name, method, _op = reached[0]
        return f"{req_name}.{method}"
    return None


def _admit_effect_async(stmt, step: dict, env: "Env", filename: str) -> None:
    """Enforce the exact `await`/async pairing on an `effect`/`let-effect`
    acquisition and refuse a suspending teardown (item 131 §3, rules 1-3).

    The acquisition (and any pure `setup`) is a FORWARD-path position: it may
    reach a suspension iff the surface spelled `effect await`. The `undo` is a
    TEARDOWN position: it may never reach one, because the two-phase abort loop
    is synchronous on every tier (docs/design/teardown-contract.md). Sets the
    additive IR `async` flag on the step whose surface carried `await`; a sync
    acquisition carries no key and lowers byte-identically to before."""
    is_async = getattr(stmt, "is_async", False)
    # Rule 1 (async without `await`) fires here only for the REQ-OP family — the
    # silent leak. The async-callable family (extern / colored fn) in a non-await
    # acquisition is still refused by the name-based `_async_reached_outside_
    # provide` fence with its legacy message, which the self-hosted gate mirrors.
    reqop = _first_reqop_suspension(step.get("acquire"), env)
    if reqop is None and step.get("setup"):
        reqop = _first_reqop_suspension(step["setup"], env)
    # Rule 2 (await without async) reads the FULL suspension surface (either
    # family): an `await` marker must name a real divert window of any kind.
    reach = _first_suspension(step.get("acquire"), env)
    if reach is None and step.get("setup"):
        reach = _first_suspension(step["setup"], env)
    if reqop is not None and not is_async:
        # Rule 1: async without `await`.
        raise RevlError(
            filename, stmt.line,
            f"component `{env.component.name}` acquires through async operation "
            f"`{reqop}` but the effect is not awaited; the binding would hold "
            f"the in-flight value, not the result (A1)",
            hint=f"write `effect await {reqop.split('.')[-1]}(...) undo ...`; the "
                 "await is a divert boundary (paper §4.3.2), so it is spelled, "
                 "never inserted",
            code="A1", category="async-propagation")
    if is_async and reach is None:
        # Rule 2: `await` without async — the marker must name a real divert
        # window, never decoration (exact pairing, both directions).
        raise RevlError(
            filename, stmt.line,
            "`effect await` on an acquisition that reaches nothing async — an "
            "`await` in an activation body is a real divert window (A1)",
            hint="nothing here suspends; drop `await` and write `effect <expr> "
                 "undo ...`",
            code="A1", category="async-propagation")
    if is_async:
        step["async"] = True
    undo_reach = _first_suspension(step.get("undo"), env)
    if undo_reach is not None:
        # Rule 3: teardown never suspends.
        raise RevlError(
            filename, stmt.line,
            f"`undo` reaches async operation `{undo_reach}`, but teardown is "
            "synchronous on every tier — a suspension there would be a teardown "
            "that can hang or silently no-op (A1)",
            hint="the two-phase abort loop does not await "
                 "(docs/design/teardown-contract.md, the bound rule); keep the "
                 "inverse a synchronous call",
            code="A1", category="async-propagation")


def _admit_emit_async(stmt, step: dict, env: "Env", filename: str) -> None:
    """Enforce the `await`/async pairing on an `emit` step and refuse a
    suspending `compensate` (item 131 §3, rules 1-3). The emission expression is
    forward-path (awaited iff the surface spelled `await emit`); the
    `compensate` slot is teardown-position and may never suspend."""
    is_async = getattr(stmt, "is_async", False)
    # Rule 1 fires here only for the REQ-OP family (the silent leak); an
    # async-callable emission in a non-await step stays with the legacy fence.
    reqop = _first_reqop_suspension(step.get("expr"), env)
    reach = _first_suspension(step.get("expr"), env)
    if reqop is not None and not is_async:
        # Rule 1: async without `await`.
        raise RevlError(
            filename, stmt.line,
            f"`emit` step reaches async operation `{reqop}` but the emission is "
            "not awaited; py would build a coroutine it never awaits (the "
            "emission never fires) and ts a floating unordered Promise (A1)",
            hint=f"write `await emit {reqop.split('.')[-1]}(...)`; the await is a "
                 "divert boundary (paper §4.3.2), so it is spelled, never inserted",
            code="A1", category="async-propagation")
    if is_async and reach is None:
        # Rule 2: `await` without async.
        raise RevlError(
            filename, stmt.line,
            "`await emit` on an emission that reaches nothing async — an `await` "
            "in an activation body is a real divert window (A1)",
            hint="nothing here suspends; drop `await` and write `emit <expr>`",
            code="A1", category="async-propagation")
    if is_async:
        step["async"] = True
    comp_reach = _first_suspension(step.get("compensate"), env)
    if comp_reach is not None:
        # Rule 3: teardown never suspends.
        raise RevlError(
            filename, stmt.line,
            f"`compensate` reaches async operation `{comp_reach}`, but teardown "
            "is synchronous on every tier — a suspension there would be a "
            "compensation that can hang or silently no-op (A1)",
            hint="the two-phase abort loop does not await "
                 "(docs/design/teardown-contract.md, the bound rule); keep the "
                 "compensation a synchronous call",
            code="A1", category="async-propagation")


def _arrow_reaches_async(body, env) -> bool:
    """True if a lowered arrow body reaches a suspension (item 92 §3): a
    req-target async service op (rule 3), or a call of an async-colored callable
    — an async extern or a phase-2 colored fn (rules 1). A nested async-flagged
    arrow is a *value* whose suspension is its own, so it is pruned."""
    hit = False

    def walk(n):
        nonlocal hit
        if hit:
            return
        if isinstance(n, dict):
            if n.get("kind") == "arrow" and n.get("async"):
                return
            if _req_op_is_async(n, env):
                hit = True
                return
            for value in n.values():
                walk(value)
        elif isinstance(n, list):
            for value in n:
                walk(value)

    walk(body)
    if hit:
        return True
    called: set = set()
    _calls_in(body, called, stop_async_arrows=True)
    return bool(called & (env.async_callables or set()))


def _refuse_leaky_arrow(node, env, source: str, line: int = 0) -> None:
    """Walk a lowered body for a *sync-typed* arrow that reaches an async
    operation — the item-92 leak (finding #21), now a compile error instead of
    an unawaited coroutine at runtime. An async-flagged arrow is admitted; a
    plain one that reaches a suspension is refused with the A1 diagnostic."""
    if isinstance(node, dict):
        if node.get("kind") == "arrow":
            if not node.get("async") and _arrow_reaches_async(node.get("body"), env):
                raise RevlError(
                    source or env.filename, node.get("line") or line or 0,
                    "this arrow reaches an async operation, but its type carries "
                    "no async color — the caller would receive an unawaited "
                    "suspension (A1)",
                    hint="declare the receiving parameter `(…) -> Async[T]` so "
                         "every call through it is awaited, or move the "
                         "suspending call out of the arrow "
                         "(docs/design/async-function-values.md)",
                    code="A1", category="async-propagation",
                )
            # its own body still walked below (a sync inner arrow may leak)
        for value in node.values():
            _refuse_leaky_arrow(value, env, source)
    elif isinstance(node, list):
        for value in node:
            _refuse_leaky_arrow(value, env, source)


def _coerce_async_args(callee_name, args, env, line):
    """At a component-body call to a module `fn`, admit an arrow into each
    parameter declared `(…) -> Async[T]` (item 92) by stamping the async color
    into the IR. The component path never runs `_check_arrow`, so this is where
    the color is placed; the pure-fn path gets it from `_resolve_arrow` instead.

    v1 admits only an *arrow* in an async slot (the harness's shape — a sync
    arrow is the accepted sync->async coercion, an async-bodied one is colored).
    A non-arrow value (a bare callable name, a fn-typed local) is refused: it
    would need an `as_async` wrapper the blocking backends do not yet erase —
    a filed follow-up, refused here rather than leaked."""
    sig = (env.types.get(FNS_KEY) or {}).get(callee_name)
    if not sig:
        return args
    params = sig.get("params") or []
    out = list(args)
    for i, ptype in enumerate(params):
        if i >= len(out) or not _is_async_fn_type(ptype):
            continue
        arg = out[i]
        if isinstance(arg, dict) and arg.get("kind") == "arrow":
            arg["async"] = True
            if not arg.get("returns"):
                arg["returns"] = render_type(parse_type(ptype)[1][-1])
        else:
            raise RevlError(
                env.filename, line,
                f"argument {i + 1} of `{callee_name}(...)` is declared "
                f"`{render_type(ptype)}` (async), but only an arrow may be "
                "passed into an async parameter in v1",
                hint="wrap it in an arrow, e.g. `x => f(x)`, so the emitter can "
                     "place the async boundary "
                     "(docs/design/async-function-values.md)",
                code="A1", category="async-propagation",
            )
    return out


def _sync_monomorph_name(origin: str, env) -> str:
    """A collision-free identifier for `origin`'s sync clone (item 342). Every
    call site for the same origin computes the same name: it depends only on the
    stable `env.callables` and the shared, converging `env.sync_monomorphs`."""
    name = f"{origin}_revl_sync"
    while name in (env.callables or set()) or (
            name in env.sync_monomorphs and env.sync_monomorphs[name] != origin):
        name += "_"
    return name


def _monomorph_callee(node):
    """The colour-polymorphic callee name of a lowered call, and a setter that
    rewrites it, for BOTH lowered call shapes: a component body's `{kind: fn,
    name}` and a module-`fn`/`test` body's `{kind: call, callee: {kind: var,
    name}}` (item 387 — 342 originally saw only the former). Returns
    `(origin, set_name)` or `(None, None)`."""
    if node.get("kind") == "fn" and isinstance(node.get("name"), str):
        def _set(m, _n=node):
            _n["name"] = m
        return node["name"], _set
    if node.get("kind") == "call":
        callee = node.get("callee")
        if isinstance(callee, dict) and callee.get("kind") == "var" \
                and isinstance(callee.get("name"), str):
            def _set(m, _c=callee):
                _c["name"] = m
            return callee["name"], _set
    return None, None


def _monomorphize_sync_callback_calls(node, env) -> None:
    """Sync/async arrow polymorphism at a sync call site (item 342 + item 387).

    A sync context (a provide method — item 342; or a module `fn`/`test` body —
    item 387) that calls a colour-polymorphic fn (one async solely by its own
    callback parameter) with a genuinely-sync arrow does not suspend: the arrow
    trivially lifts into a completed async. Instead of forcing the context async
    (A1) or authoring a duplicate sync loop, the call is redirected to a SYNC
    monomorph of the fn — `async` dropped, the callback de-async'd — and the
    arrow is un-stamped back to a plain sync value. `env.sync_monomorphs` records
    the request; the clone is synthesized once, after every call site is seen.

    Only fires when EVERY async-typed-param argument is a genuinely-sync arrow.
    If any such arrow reaches a real suspension, the call is left untouched: the
    A1 admission then refuses it, because a sync context truly cannot await it."""
    if isinstance(node, dict):
        origin, set_name = _monomorph_callee(node)
        if origin is not None and origin in env.colour_polymorphic:
            sig = (env.types.get(FNS_KEY) or {}).get(origin) or {}
            params = sig.get("params") or []
            args = node.get("args") or []
            async_arrows: list = []
            liftable = True
            for i, ptype in enumerate(params):
                if not _is_async_fn_type(ptype):
                    continue
                arg = args[i] if i < len(args) else None
                if (isinstance(arg, dict) and arg.get("kind") == "arrow"
                        and not _arrow_reaches_async(arg.get("body"), env)):
                    async_arrows.append((arg, ptype))
                else:
                    # a genuinely-async arrow (or a non-arrow) — not liftable;
                    # leave the async loop in place for the A1 admission to judge
                    liftable = False
                    break
            if liftable and async_arrows:
                mono = _sync_monomorph_name(origin, env)
                env.sync_monomorphs[mono] = origin
                set_name(mono)
                for arg, ptype in async_arrows:
                    arg.pop("async", None)
                    inner = parse_type(ptype)[1][-1]          # Async[T]
                    unwrapped = parse_type(inner)[1]
                    arg["returns"] = render_type(unwrapped[0]) if unwrapped else None
        for value in node.values():
            _monomorphize_sync_callback_calls(value, env)
    elif isinstance(node, list):
        for value in node:
            _monomorphize_sync_callback_calls(value, env)


def _resolve_poly_extern_calls(node, env, is_async: bool) -> None:
    """Caller-decided extern colour at a call site (item 388, stage 3 — the
    EXTERN analog of `_monomorphize_sync_callback_calls`).

    A poly extern (`fn|async`) is pre-seeded as the async form (its IR entry
    carries `async: True`, named `engine_run`). Walk a provide-method body and,
    at each call of a poly extern, record the enclosing method's colour into the
    shared `env.extern_colour_instances` map so the post-pass knows which clones
    to keep:

    - An ASYNC method's call resolves to the async clone (the pre-seeded entry,
      original name), left in place: it is in `async_externs`/`_PY_ASYNC_EXTERNS`,
      so the existing name-keyed await machinery awaits it, which A1 permits
      inside an async method.
    - A SYNC method's call is rewritten to the `_revl_sync` clone name and the
      sync colour recorded. The rewrite runs BEFORE the A1 admission (exactly
      where item 342's monomorph hook runs), so the sync call site has already
      cleared async membership — the sync clone is a concrete `def` not in the
      async set, so A1 never fires and no `await` lands in the sync function.

    Reuses `_monomorph_callee` for both lowered call shapes (`{kind: fn, name}`
    and `{kind: call, callee: {kind: var, name}}`)."""
    if isinstance(node, dict):
        origin, set_name = _monomorph_callee(node)
        if origin is not None and origin in env.poly_externs:
            inst = env.extern_colour_instances.setdefault(
                origin, {"sync": False, "async": False, "sync_name": None})
            if is_async:
                inst["async"] = True
            else:
                sync_name = inst["sync_name"] or _sync_monomorph_name(origin, env)
                inst["sync"] = True
                inst["sync_name"] = sync_name
                set_name(sync_name)
        for value in node.values():
            _resolve_poly_extern_calls(value, env, is_async)
    elif isinstance(node, list):
        for value in node:
            _resolve_poly_extern_calls(value, env, is_async)


def _finalize_poly_externs(externs: list, poly_names: set,
                           instances: dict, referenced: set) -> None:
    """Materialize and prune the concrete clones of every poly extern (item 388,
    stage 4 — the EXTERN analog of `_synthesize_sync_monomorphs`, plus the
    eager-expand-and-PRUNE resolution of the ordering wrinkle).

    Each poly extern was pre-seeded as one async IR entry (`colour_poly: True`).
    After every component has recorded which colours its call sites requested
    (`instances[name]`), rewrite that single entry into the concrete clones that
    are actually used, IN PLACE so emission order is deterministic:

    - async requested -> keep the pre-seeded entry as the async clone (original
      name, `async: True`);
    - sync requested  -> a deep-copied clone with `async` dropped and the
      `_revl_sync` name the sync call sites were rewritten to;
    - a colour NObody requested is PRUNED. A poly extern called in only one
      colour emits exactly one clone (a sync-only program emits no async clone
      and vice-versa); a poly extern nobody calls emits nothing at all (additive:
      parser, IR, and every golden stay byte-identical without a poly extern).

    The `colour_poly` marker is stripped from every surviving clone, so the final
    IR carries only ordinary concrete extern entries the emitters already
    understand."""
    import copy

    for name in poly_names:
        idx = next((i for i, e in enumerate(externs)
                    if e.get("name") == name and e.get("colour_poly")), None)
        if idx is None:
            continue
        preseed = externs[idx]
        preseed.pop("colour_poly", None)
        inst = instances.get(name) or {}
        replacement: list = []
        # keep the async clone if an async provide method requested it OR the
        # original (async) name still appears anywhere in the final IR — a call
        # from an async method, a module `fn`, or a `test` that was never
        # monomorphized to the sync clone (only sync PROVIDE methods rewrite their
        # calls). Without this second condition such a residual reference would
        # dangle after the async clone was pruned.
        if inst.get("async") or name in referenced:
            replacement.append(preseed)          # keep as the async clone
        if inst.get("sync"):
            clone = copy.deepcopy(preseed)
            clone["name"] = inst.get("sync_name") or f"{name}_revl_sync"
            clone.pop("async", None)             # the sync clone is a blocking def
            replacement.append(clone)
        externs[idx:idx + 1] = replacement       # prune the unused colour


def _synthesize_sync_monomorphs(fns: list, sync_monomorphs: dict) -> None:
    """Materialize the sync clones requested by item-342 call sites, appending
    each to `fns`. A clone is the origin fn with `async` dropped and every
    async-typed callback parameter de-async'd (`(A) -> Async[T]` -> `(A) -> T`),
    so both emitters render it as a plain sync fn awaiting nothing — the body is
    byte-identical, only the header and the callback's colour differ."""
    import copy

    by_name = {f["name"]: f for f in fns}
    for mono, origin in sorted(sync_monomorphs.items()):
        if mono in by_name:            # already synthesized (shared clone)
            continue
        src = by_name.get(origin)
        if src is None:                # origin vanished — nothing to clone
            continue
        clone = copy.deepcopy(src)
        clone["name"] = mono
        clone.pop("async", None)
        for p in clone.get("params") or []:
            if _is_async_fn_type(p.get("type")):
                p["type"] = _strip_async_fn_return(p["type"])
        fns.append(clone)
        by_name[mono] = clone


def _strip_async_fn_return(fn_type: str) -> str:
    """`(A, B) -> Async[T]` -> `(A, B) -> T`: the sync reading of an async
    callback type (item 342). A non-async fn type is returned unchanged."""
    head, args = parse_type(fn_type)
    if head != FN_HEAD or not args:
        return fn_type
    ret_head, ret_args = parse_type(args[-1])
    if ret_head != "Async" or not ret_args:
        return fn_type
    parts = list(args[:-1]) + [ret_args[0]]
    return f"({', '.join(render_type(p) for p in parts[:-1])}) -> {render_type(parts[-1])}"


class _FreeFnMonoEnv:
    """A lightweight `env` shim exposing exactly the attributes the item-342
    monomorphization walk reads, so `_monomorphize_sync_callback_calls` and
    `_arrow_reaches_async` can run over a module `fn` body or a `test`/`prop
    test` body — none of which has a component `Env`. Such a body binds no
    required key, so `services`/`requires` are empty and `_req_op_is_async` is
    always False (rule 3 is component-only)."""

    def __init__(self, colour_polymorphic, types, sync_monomorphs, callables,
                 async_callables):
        self.colour_polymorphic = colour_polymorphic
        self.types = types
        self.sync_monomorphs = sync_monomorphs
        self.callables = callables
        self.async_callables = async_callables
        self.services: dict = {}
        self.requires: dict = {}
        self.stream_requires: dict = {}


def _colour_polymorphic_fns(fns: list, async_colored: set) -> set:
    """The item-342 colour-polymorphic set: a fn colored async SOLELY because it
    calls its own async-typed callback parameter — it has such a param, it is
    colored, and its body reaches no OTHER async name (`stop_async_arrows` prunes
    a nested async arrow, whose suspension is its own value). Its async-ness is
    contingent on the arrow actually passed: a genuinely-sync arrow lifts the fn
    to a sync clone (`_monomorphize_sync_callback_calls`)."""
    poly: set = set()
    for entry in fns:
        if entry["name"] not in async_colored:
            continue
        if not any(_is_async_fn_type(p.get("type"))
                   for p in entry.get("params") or []):
            continue
        reached: set = set()
        _calls_in(entry.get("body") or [], reached, stop_async_arrows=True)
        if not (reached & async_colored):
            poly.add(entry["name"])
    return poly


def _monomorphize_free_fn_calls(fns, externs, colour_polymorphic, preliminary,
                                types, sync_monomorphs, callables,
                                async_witness) -> set:
    """Complete item-342 at MODULE-`fn` call sites (item 387).

    342 hooked its sync monomorphization into `_lower_provide` alone, so a free
    `fn` that reaches a colour-polymorphic loop ONLY by handing it genuinely-sync
    arrows was auto-colored async by the phase-2 fixed point instead of being
    kept sync. A sync context then calling that fn (a `test` block, a sync
    provide method) diverged: py emitted a bare, un-awaited call yielding a
    coroutine while ts refused at emit, naming this very frontend hole (H29).
    Here such a fn is kept sync and its call redirected to the sync monomorph,
    exactly as a sync provide method's call is.

    An async caller is left untouched (item-92 coercion, the loop stays async):
    `genuinely_async` is the colour of the call graph once EVERY liftable
    polymorphic call is made sync, so a fn still colored there reaches a real
    suspension on its own account (a real async extern, or a genuinely-async
    arrow into the loop) and keeps its async loop. Returns the final
    `async_colored` after the rewrite (== `genuinely_async` by construction)."""
    import copy

    # 1) genuinely-async fns: recolor a throwaway copy in which every liftable
    #    polymorphic call is already synced. A fn still colored there is async on
    #    its own account, independent of the arrows a caller happens to pass.
    probe = copy.deepcopy(fns)
    probe_env = _FreeFnMonoEnv(colour_polymorphic, types, {}, callables, preliminary)
    for f in probe:
        _monomorphize_sync_callback_calls(f.get("body") or [], probe_env)
    genuinely_async = _async_callables(probe, externs)

    # 2) rewrite the REAL bodies of the fns that end up sync. A genuinely-async
    #    fn is skipped so its loop stays async — item 92's coercion, unchanged.
    real_env = _FreeFnMonoEnv(colour_polymorphic, types, sync_monomorphs,
                              callables, preliminary)
    for f in fns:
        if f["name"] in genuinely_async:
            continue
        _monomorphize_sync_callback_calls(f.get("body") or [], real_env)

    # 3) recolor for the final verdict over the rewritten bodies.
    async_witness.clear()
    return _async_callables(fns, externs, async_witness)


def _admit_sync_test_bodies(tests, prop_tests, async_colored, colour_polymorphic,
                            types, sync_monomorphs, callables, filename) -> None:
    """A plain `test`/`prop test` body is a pure SYNC context — it cannot await.
    Complete item-342 there too (item 387): monomorphize each colour-polymorphic
    call handed only genuinely-sync arrows to its sync clone, then refuse (A1)
    any residual reach of an async callable. Without this a test calling an async
    callable diverged — py emitted a bare, un-awaited call yielding a coroutine
    while ts refused at emit, naming this frontend hole (H29). A `lifecycle test`
    is untouched: it drives a live composition and awaits through the runtime."""
    env = _FreeFnMonoEnv(colour_polymorphic, types, sync_monomorphs, callables,
                         async_colored)
    for unit in list(tests or []) + list(prop_tests or []):
        if unit.get("lifecycle"):
            continue
        body = unit.get("body")
        if not body:
            continue
        if colour_polymorphic:
            _monomorphize_sync_callback_calls(body, env)
        # residual reach of an async callable — a genuinely-async callee a sync
        # test cannot await, or one passed as a value. Both tiers must refuse.
        called: set = set()
        values: set = set()
        _calls_in(body, called, values=values)
        hit = sorted((called | values) & (async_colored or set()))
        if hit:
            raise RevlError(
                filename, 0,
                f"test `{unit.get('name')}` reaches async callable `{hit[0]}`, "
                f"but a `test` body is a synchronous context with no in-flight "
                f"window to await it (A1)",
                hint="drive the async operation from a `lifecycle test` (which "
                     "runs a live composition and can await it through a provide "
                     "method), or reach it only from an `async fn` service "
                     "operation (docs/design/async-extern.md §3)",
                code="A1", category="async-propagation",
            )


def _refuse_leaky_pure_arrow(node, async_colored, decl, filename) -> None:
    """The module-fn twin of `_refuse_leaky_arrow`: a sync-typed arrow whose
    body reaches an async callable (a colored name — pure fns have no req keys)
    is the item-92 leak. Admitted (async-flagged) arrows are skipped."""
    if isinstance(node, dict):
        if node.get("kind") == "arrow" and not node.get("async"):
            called: set = set()
            _calls_in(node.get("body"), called, stop_async_arrows=True)
            hit = sorted(called & (async_colored or set()))
            if hit:
                raise RevlError(
                    (decl.source if decl is not None else None) or filename,
                    getattr(decl, "line", 0) or 0,
                    f"this arrow reaches async callable `{hit[0]}`, but its type "
                    "carries no async color — the caller would receive an "
                    "unawaited suspension (A1)",
                    hint="declare the receiving parameter `(…) -> Async[T]` so "
                         "every call through it is awaited, or move the "
                         "suspending call out of the arrow "
                         "(docs/design/async-function-values.md)",
                    code="A1", category="async-propagation",
                )
        for value in node.values():
            _refuse_leaky_pure_arrow(value, async_colored, decl, filename)
    elif isinstance(node, list):
        for value in node:
            _refuse_leaky_pure_arrow(value, async_colored, decl, filename)


# item 130 rule 3.5 — the IR kinds a `map`/`filter` transform may NOT contain.
# `f`/`p` type in PURE mode (G6): a combinator chain is a pure derivation whose
# only effects are the source's bracket and the consumer's body, so an effectful
# transform is refused with the hint to move the effect into the consumer body
# where it is capability- and lifecycle-checked (§4.7). `call` is the host-object
# method call (`sub.next()`, `pool.query(…)`); a value-method call lowers as
# `builtin` and stays admitted.
_IMPURE_STAGE_KINDS = frozenset({
    "host", "req", "call", "spawn", "subscribe", "lease-acquire", "lease-revoke",
})


def _first_impure_in_stage(node) -> str | None:
    """The first effectful IR node a stream combinator's transform reaches, named
    for a diagnostic, or None (item 130 rule 3.5)."""
    if isinstance(node, dict):
        kind = node.get("kind")
        if kind in _IMPURE_STAGE_KINDS:
            if kind == "call":
                target = node.get("target") or {}
                head = target.get("id") if isinstance(target, dict) else None
                return f"{head}.{node.get('method')}" if head else str(node.get("method"))
            if kind == "host":
                return str(node.get("fn"))
            if kind == "req":
                return f"{node.get('req')}.{node.get('method')}"
            return kind
        for value in node.values():
            hit = _first_impure_in_stage(value)
            if hit is not None:
                return hit
    elif isinstance(node, list):
        for value in node:
            hit = _first_impure_in_stage(value)
            if hit is not None:
                return hit
    return None


def _lower_stream_stages(sub_expr: "SubscribeExpr", env: "Env",
                         filename: str) -> list:
    """Lower the derived-stream combinator chain of a `subscribe` (item 130
    Slice 2, §1) and enforce rule 3.5 (the transforms are pure).

    Each stage is `{"stage": "map"|"filter"|"take", "fn"|"count": …}`. A stage is
    a DERIVED stream: its `close` closes its upstream link, so the whole chain
    rides the one bracket the `subscribe` registers and cancellation reaches the
    provider end to end."""
    stages: list = []
    for stage in sub_expr.stages or []:
        if stage.kind == "take":
            stages.append({"stage": "take", "count": stage.arg.value})
            continue
        fn_ir = _lower_expr(stage.arg, env, mode="setup")
        if fn_ir.get("kind") != "arrow":
            raise RevlError(
                filename, stage.line,
                f"`{stage.kind}` needs a pure transform written as an arrow "
                f"(rule 3.5)",
                hint=f"write `{stage.kind}(x => …)` — the combinators are a pure "
                     "derivation; effects belong in the consumer body, where they "
                     "are capability- and lifecycle-checked (item 130 §3.5, §4.7)",
                code="lifecycle", category="lifecycle")
        impure = _first_impure_in_stage(fn_ir.get("body"))
        if impure is None:
            impure = _first_suspension(fn_ir.get("body"), env)
        if impure is not None:
            raise RevlError(
                filename, stage.line,
                f"`{stage.kind}`'s transform reaches `{impure}`, but a stream "
                f"combinator is pure (rule 3.5)",
                hint="move the effect into the consumer body, where it is "
                     "capability-checked against the component's row and joins "
                     "the OWNER's teardown accumulator; a combinator chain stays "
                     "a pure derivation (item 130 §3.5, §4.7)",
                code="lifecycle", category="lifecycle")
        stages.append({"stage": stage.kind, "fn": fn_ir})
    return stages


def _lower_replay_decl(spec, acquire: dict, env: "Env", filename: str,
                       line: int) -> dict:
    """Lower a PROVIDER-side `replay(n)` / `replay(from: "<durable>")`
    declaration (item 130 §4.5).

    §4.5 gives replay one owner: the provider. The declaration says this source
    HOLDS a backlog — last-n in memory, or a durable cursor — and it is the only
    thing that makes a `replay(…)` at a `subscribe` anything but an undeclared
    argument. Two shapes, two strengths:

    * `replay(n)` — the last n items, held by the provider, gone with the
      process. Enough to give a late consumer a backlog; NOT a crash claim.
    * `replay(from: "<durable>")` — a durable cursor NAME. It is the stronger
      claim precisely because it is WAL-serializable: a name and a position
      survive the process, which is what lets a crashed subscription be
      reconstructible rather than residue (§4.9).

    A cursor must therefore be a STRING LITERAL. A computed cursor could not be
    written into the WAL as the descriptor recovery re-issues from, so admitting
    one would ship exactly the vacuous durability claim §4.5 refuses."""
    if acquire.get("kind") != "host" or acquire.get("fn") != "Stream.source":
        raise RevlError(
            filename, line,
            "`replay` is a stream provider's declaration and this acquisition "
            "is not a stream source",
            hint="only `effect Stream.source()` holds a backlog to replay; write "
                 "`let src = effect Stream.source() replay(<n>) undo "
                 "src.close()` (item 130 §4.5)",
            code="lifecycle", category="lifecycle")
    if spec.count is not None:
        return {"count": int(spec.count)}
    return {"cursor": _replay_cursor_name(spec, env, filename, line)}


def _lower_required_replay_decls(env: "Env", filename: str) -> None:
    """Lower each `requires <k>: Stream[T] replay(…)` declaration onto `env`
    (item 130 §4.5, §6c).

    The provider-side twin of `_lower_replay_decl`, and deliberately the same
    two shapes with the same cursor rule: once the source is a coeffect the
    provider sits on the other side of the injection, so the REQUIREMENT is
    where its durability claim is stated — it is the contract the wiring must
    satisfy. Validated EAGERLY, before the body is walked, so a malformed cursor
    on a requirement nothing subscribes to is still refused; a declaration the
    body never asks for is fine, exactly as a declaring local source that is
    subscribed without a `replay(…)` is."""
    specs = getattr(env.component, "require_replay", None) or {}
    for key, spec in specs.items():
        binding = _key_binding(key)
        if spec.count is not None:
            env.stream_replay[binding] = {"count": int(spec.count)}
            continue
        env.stream_replay[binding] = {
            "cursor": _replay_cursor_name(spec, env, filename, spec.line)}


def _replay_cursor_name(spec, env: "Env", filename: str, line: int) -> str:
    """The durable cursor name a `replay(from: …)` spells, refusing anything but
    a string literal (item 130 §4.5).

    Shared by the provider declaration and the consumer request so the two are
    read by one rule. The cursor IS the descriptor recovery re-issues the
    subscription from (§4.9), so it has to be writable into the WAL exactly as
    written; a computed one would be a durability claim with nothing durable in
    it."""
    cursor = _lower_expr(spec.cursor, env, mode="setup")
    name = cursor.get("value") if cursor.get("kind") == "lit" else None
    if not isinstance(name, str) or not name:
        raise RevlError(
            filename, line,
            "a durable replay cursor must be a literal name",
            hint="the cursor IS the descriptor a fresh process re-issues the "
                 "subscription from, so it has to be writable into the WAL as it "
                 "stands; write `replay(from: \"orders\")` (item 130 §4.5, §4.9)",
            code="lifecycle", category="lifecycle")
    return name


def _admit_replay(spec, stream_ir: dict, env: "Env", filename: str,
                  line: int) -> dict:
    """Admit a CONSUMER-side `replay(…)` at a `subscribe` against the provider's
    own declaration (item 130 §4.5).

    §4.5's last sentence: an undeclared `replay` argument at a `subscribe` is a
    compile error. That is this function — plus the three ways a declared one can
    still be a claim the provider does not back: asking a different SHAPE than
    the provider declared, asking for more items than it holds, and asking a
    fan-in (no provider declared the interleaving of two backlogs, so a merged
    replay would order items by nothing)."""
    if stream_ir.get("kind") == "stream-merge":
        raise RevlError(
            filename, line,
            "`replay` on a `merge(a, b)` fan-in has no declared order — the "
            "backlogs of two providers do not interleave",
            hint="a merged stream is derived, and neither source declared how "
                 "its backlog orders against the other's. Replay one source and "
                 "merge the live streams, or drop the `replay` (item 130 §4.5)",
            code="lifecycle", category="lifecycle")
    # item 130 §6c: the stream may be a locally acquired source or a required
    # `Stream[T]` coeffect, and §4.5's rule is the same either way — a request is
    # admitted only against a DECLARATION. Only where the declaration lives moves
    # with the stream: on the acquisition for a local source, on the requirement
    # for a coeffect one, because that is the side the provider contract is
    # stated on once the provider is across an injection. Resolved here, and
    # everything below compares request to declaration without knowing which.
    if stream_ir.get("kind") == "req":
        src_name = stream_ir.get("name")
        declared = env.stream_replay.get(src_name)
        undeclared_hint = (
            "replay is a provider-side durability claim — the provider must hold "
            "the backlog and, after a crash, reconstruct it (§4.9). A required "
            f"stream states it on the requirement: `requires {src_name}: "
            "Stream[T] replay(<n>)`, or a durable cursor `replay(from: "
            "\"<name>\")`; then a `subscribe` may ask for it (item 130 §6c).")
        label = f"required stream `{src_name}`"
    else:
        src_name = stream_ir.get("id") if stream_ir.get("kind") == "name" else None
        declared = env.replay_sources.get(src_name)
        undeclared_hint = (
            "replay is a provider-side durability claim — the provider must hold "
            "the backlog and, after a crash, reconstruct it (§4.9). Declare it on "
            "the source: `let src = effect Stream.source() replay(<n>) undo "
            "src.close()`, or a durable cursor `replay(from: \"<name>\")`; then a "
            "`subscribe` may ask for it.")
        label = f"stream source `{src_name}`"
    if declared is None:
        raise RevlError(
            filename, line,
            "`replay` at a `subscribe` requires a provider that declares it "
            "(item 130 §4.5)",
            hint=undeclared_hint,
            code="lifecycle", category="lifecycle")
    if spec.cursor is not None:
        want = {"cursor": _replay_cursor_name(spec, env, filename, line)}
        if "cursor" not in declared:
            raise RevlError(
                filename, line,
                f"{label} declares a last-n backlog, not a durable cursor",
                hint="a last-n backlog dies with the provider; only `replay(from: "
                     "\"<name>\")` on the SOURCE is the durable claim a cursor "
                     "subscription reads (item 130 §4.5, §4.9)",
                code="lifecycle", category="lifecycle")
        if want["cursor"] != declared["cursor"]:
            raise RevlError(
                filename, line,
                f"{label} declares the durable cursor "
                f"`{declared['cursor']}`, not `{want['cursor']}`",
                hint="a cursor names the provider's own durable position; a "
                     "consumer may only resume the one the provider declared "
                     "(item 130 §4.5)",
                code="lifecycle", category="lifecycle")
        return want
    if "count" not in declared:
        raise RevlError(
            filename, line,
            f"{label} declares a durable cursor, so a subscription resumes FROM it "
            f"rather than asking for a last-n backlog",
            hint=f"write `replay(from: \"{declared['cursor']}\")` — the cursor is "
                 "the position the provider holds, and the count of items behind "
                 "it is the provider's to decide (item 130 §4.5)",
            code="lifecycle", category="lifecycle")
    want = int(spec.count)
    if want > declared["count"]:
        raise RevlError(
            filename, line,
            f"`replay({want})` asks for more than {label} "
            f"declares — its backlog holds {declared['count']}",
            hint="the provider holds the buffer, so a consumer cannot ask past "
                 "it; raise the source's own `replay(<n>)` or lower the request "
                 "(item 130 §4.5)",
            code="lifecycle", category="lifecycle")
    return {"count": want}


def _refuse_stream_requirement_read(env: "Env", key: str, filename: str,
                                    line: int) -> None:
    """Refuse reading a required `Stream[T]` outside a `subscribe` head (item
    130, the coeffect wiring).

    A `Stream[T]` is a capability to ACQUIRE a subscription, not a value. The
    only thing a program does with one is subscribe, and a subscription is
    single-consumer — so a stream that could be bound, passed to a fn or stored
    in a record would be a second handle on a single-consumer resource with no
    bracket behind it. Refused by name, and named as the declared requirement it
    is rather than as an unknown name, which is what the ordinary
    not-a-requirement diagnostic would say about a key that IS declared."""
    elem = env.stream_requires[key]
    raise RevlError(
        filename, line,
        f"required stream `{key}` is read outside a `subscribe`",
        hint=f"`{key}` is a `Stream[{elem}]` — a capability to acquire a "
             f"subscription, not a value. Write `let sub = subscribe {key} undo "
             f"sub.close()` and use `sub`; a subscription is single-consumer, so "
             "the stream itself is never bound, passed or stored (item 130 §1)",
        code="lifecycle", category="lifecycle")


def _refuse_stream_requirement_as_service(env: "Env", key: str, method,
                                          line: int) -> None:
    """Refuse using a required `Stream[T]` as if it were a required SERVICE
    (item 130, the coeffect wiring).

    A coeffect is a declared requirement, and a required stream is declared the
    same way a required service is — so the one confusion the surface invites is
    calling a method on it. There is no service behind the key to resolve
    against, so the alternative to this refusal is a `KeyError` in the service
    table or, worse, a silently-empty method set. Refused BY NAME, naming the one
    operation a stream has."""
    if method is None:
        return
    elem = env.stream_requires[key]
    raise RevlError(
        env.filename, line,
        f"`{key}.{method}` — `{key}` is a required `Stream[{elem}]`, not a "
        f"service",
        hint=f"a stream has no methods; the only operation on it is `subscribe`: "
             f"`let sub = subscribe {key} undo sub.close()`, then `every x in "
             f"sub {{ … }}` pulls the items (item 130 §1)",
        code="lifecycle", category="lifecycle")


def _admit_stream_operand(node, env: "Env", filename: str, line: int,
                          *, form: str) -> str:
    """Admit ONE stream operand of a `subscribe` head and answer its safe name
    (item 130, docs/design/130-stream-reactive-types.md §3).

    Three checks, applied to a plain `subscribe src` and pointwise to every
    source of a `subscribe merge(a, b)` — a fan-in is only as sound as its
    weakest source, so a single silent or already-consumed operand poisons the
    whole thing:

    * the operand must name a stream (host-local family `Stream`);
    * rule 3.6 — it must be TERMINAL-DELIVERING (`effect Stream.source() undo
      s.close()`), so a provider that could vanish while a `next` is outstanding
      without delivering a terminal is refused (§9 Part B);
    * rule 3.1 — it must not already be consumed by another subscription or
      merge (single-consumer)."""
    # item 130: a required `Stream[T]` coeffect operand. The stream is supplied
    # by the WIRING, not acquired in this body, so the two admission rules split:
    #
    # * rule 3.6 (no-silent-vanish) is discharged at the coeffect boundary
    #   instead of at a local `undo`. There is no acquisition here to read an
    #   inverse off — the provider is on the other side of the injection — so the
    #   obligation is the one §4.3 already assigns to that layer: a provider that
    #   goes away resolves the consumer's outstanding `next` to a terminal
    #   (`Closed`/`Faulted`), never to silence. The reference runtime enforces the
    #   shape at the injection point (`Stream.subscribe` refuses a value that is
    #   not a stream), so the requirement cannot be satisfied by something with no
    #   terminal to deliver;
    # * rule 3.1 (single-consumer) is UNCHANGED and applies to the requirement
    #   key, so two subscriptions to one required stream are refused exactly as
    #   two subscriptions to one local source are. The key is namespaced away from
    #   the host-local safe names the local rule uses, so a requirement and a
    #   local source can never collide in this set.
    if isinstance(node, dict) and node.get("kind") == "req" \
            and node.get("name") in getattr(env, "stream_requires", {}):
        key = "req::" + node["name"]
        if key in env.subscribed_sources:
            raise RevlError(
                filename, line,
                f"required stream `{node['name']}` is already subscribed — a "
                "subscription is single-consumer (rule 3.1)",
                hint="multicast is a later item; compose fan-out from an explicit "
                     "bridge, one bracket per consumer (item 130 §4.1)",
                code="lifecycle", category="lifecycle")
        return key
    src_name = node.get("id") if isinstance(node, dict) \
        and node.get("kind") == "name" else None
    if src_name is None or env.host_locals.get(src_name) != "Stream":
        raise RevlError(
            filename, line,
            f"`{form}` needs a stream source — the operand does not name one",
            hint="acquire a source first: `let src = effect Stream.source() undo "
                 "src.close()`, then `let sub = subscribe src undo sub.close()` "
                 "(item 130). A required `Stream[T]` capability is a later slice.",
            code="lifecycle", category="lifecycle")
    if src_name not in env.terminal_stream_sources:
        # rule 3.6 — the §9 Part B refusal, the one the core guarantee rests on.
        raise RevlError(
            filename, line,
            f"`{form}` refuses a provider that can vanish without delivering a "
            f"terminal — stream source `{src_name}`'s inverse does not `close` it",
            hint="a subscription's outstanding `next` must be terminated by "
                 "exactly one of owner-teardown or a provider terminal, never a "
                 "silent third state; give the source `undo <src>.close()` so its "
                 "teardown delivers `Closed`/`Faulted` to the consumer "
                 "(item 130 §3.6, §9 Part B)",
            code="lifecycle", category="lifecycle")
    if src_name in env.subscribed_sources:
        # rule 3.1 — single-consumer: a stream is consumed at most once, by one
        # subscription or one merge.
        raise RevlError(
            filename, line,
            f"stream source `{src_name}` is already subscribed — a subscription "
            "is single-consumer (rule 3.1)",
            hint="multicast is a later item; compose fan-out from an explicit "
                 "bridge, one bracket per consumer (item 130 §4.1)",
            code="lifecycle", category="lifecycle")
    return src_name


def _lower_stream_head(head, env: "Env", filename: str, line: int,
                       consumed: list) -> dict:
    """Lower the stream a `subscribe` acquires — a plain source, or a
    `merge(a, b)` fan-in — and collect every source it CONSUMES (item 130
    Slice 3).

    Recursive, because a merged stream is itself a stream: `merge(merge(a, b),
    c)` is the three-source fan-in with no extra machinery. Each nested merge is
    a derived stream owned by the one above it, and the outermost is owned by the
    subscription — so the whole chain still tears down on the ONE bracket the
    `subscribe` registers, and every plain source stays on its own bracket."""
    if not isinstance(head, StreamMergeExpr):
        node = _lower_expr(head, env, mode="setup")
        consumed.append(_admit_stream_operand(node, env, filename, line,
                                              form="subscribe"))
        return node
    sources = []
    before = len(consumed)
    for src in head.sources:
        if isinstance(src, StreamMergeExpr):
            sources.append(_lower_stream_head(src, env, filename, line, consumed))
            continue
        node = _lower_expr(src, env, mode="setup")
        consumed.append(_admit_stream_operand(node, env, filename, line,
                                              form="merge"))
        sources.append(node)
    reached = consumed[before:]
    if len(set(reached)) != len(reached):
        # a source merged with itself would be two consumers of one stream
        raise RevlError(
            filename, line,
            "`merge` refuses the same stream source twice — a stream is "
            "single-consumer (rule 3.1)",
            hint="a fan-in of one source is that source; merge two distinct "
                 "streams, or compose fan-out from an explicit bridge "
                 "(item 130 §4.1)",
            code="lifecycle", category="lifecycle")
    return {"kind": "stream-merge", "sources": sources}


def _lower_subscribe_step(stmt: "LetEffect", env: "Env", filename: str,
                          *, bind_safe: str | None = None) -> dict:
    """Build the `let-effect` IR step for a `subscribe <stream> undo sub.close()`
    bracket (item 130, docs/design/130-stream-reactive-types.md §5).

    The step is an ordinary `let-effect` bracket carrying `subscribe: true` and
    the backpressure `policy`, so the emitters render `sub = <acquire>` then
    `yield lambda: <undo>` verbatim (the bracket whose handle is a live listener,
    §0) and wasm refuses the whole shape. Admission enforces:

    * rule 3.6 — every subscribed stream must be a terminal-delivering source
      (`effect Stream.source() undo s.close()`), so a provider that could vanish
      while a `next` is outstanding, without delivering a terminal, is refused
      (the no-silent-vanish rule the core guarantee rests on, §9 Part B);
    * rule 3.1 — a source is consumed at most once, by one subscription or one
      merge (single-consumer);
    * rule 3.4 — the `undo` (`close`) must not itself suspend (`close` is the
      synchronous, non-suspending bracket inverse; a `next` in it is refused);
    * rule 3.5 — a `map`/`filter` transform is pure (Slice 2, §3.5).

    Slice 3's `subscribe merge(a, b)` lowers the head to a `stream-merge` node
    over both sources (rules 3.6 and 3.1 applied POINTWISE, see
    `_admit_stream_operand`). The merged stream is DERIVED — owned by the
    subscription, not a bracket of its own, exactly like a Slice 2 stage — so the
    one bracket the subscribe registers still tears the whole fan-in down:
    `close` closes the merge, which detaches it from both sources, and each
    source is left to its own bracket. Multi-source teardown is therefore the
    same single LIFO stack Slice 1 proved, with no path where a source keeps
    feeding — or holding a reference to — a fan-in whose owner is gone."""
    sub_expr: SubscribeExpr = stmt.acquire
    consumed: list[str] = []
    # item 130: a required `Stream[T]` is a CAPABILITY, not a value — a bare
    # read of one is admitted in a `subscribe` head (including each operand of a
    # `merge` fan-in) and nowhere else, so the flag scopes exactly that head and
    # `_lower_postfix` refuses the read anywhere outside it.
    saved_head = getattr(env, "_stream_head_position", False)
    env._stream_head_position = True
    try:
        stream_ir = _lower_stream_head(sub_expr.stream, env, filename, stmt.line,
                                       consumed)
    finally:
        env._stream_head_position = saved_head
    # `bind_safe` is the ANONYMOUS bracket an `on <Event> as <x>` with no `in`
    # clause desugars to (item 130 §6b): the subscription has no surface name, so
    # it is not entered in `env.locals` and cannot be spelled, iterated twice or
    # closed by hand. Every other judgment below runs on it unchanged, which is
    # the point — the implicit handler rides the SAME bracket the explicit form
    # does rather than a second lowering that could drift.
    safe = bind_safe if bind_safe is not None \
        else env.bind_local(stmt.bind, stmt.line)
    # the subscription is a host-local of the reserved `Subscription` family, so
    # `sub.next()` / `sub.close()` are checked against that verb surface (item
    # 401) and `next` is recognised as a suspension in a teardown slot (§3.4).
    env.host_locals[safe] = "Subscription"
    # G5, same bound as every other bracket inverse: the subscription's teardown
    # slot may not cross a boundary (docs/design/teardown-contract.md). Walked on
    # the AST, before the undo is lowered, so an emitting inverse is named for
    # what it is rather than only for the `close` it is missing (the shape check
    # further down).
    if stmt.undo is None:
        # the desugared bracket's inverse, built as the IR the explicit form's
        # `undo <sub>.close()` lowers to — the shape check below is what pins the
        # two to the same thing.
        undo_ir = {"kind": "call", "target": {"kind": "name", "id": safe},
                   "method": "close", "args": []}
    else:
        _check_site_inverse_emission(stmt.undo, env, filename, stmt.line)
    # ... and lowered through the site-inverse entry, so the same expression also
    # gets item 423's construction-time argument judgment with the `undo` slot
    # named on `env` (item 420). The three judgments are disjoint and all three
    # are needed here: G5 reads the callee's CLASSIFICATION, 423 reads its
    # SIGNATURE, and the shape check below reads the IR the lowering produced.
    undo = undo_ir if stmt.undo is None \
        else _lower_site_inverse(stmt.undo, env, slot="undo")
    acquire = {"kind": "subscribe", "stream": stream_ir, "policy": sub_expr.policy}
    step = {
        "step": "let-effect",
        "subscribe": True,
        "policy": sub_expr.policy,
        "acquire": acquire,
        "undo": undo,
        "bind": safe,
    }
    # Slice 2, all ADDITIVE and all omitted at their defaults, so a Slice 1
    # program still lowers byte-identically (§5: the step carries the
    # `policy`/`buffer`/`replay` triple; `replay` is §4.5, a later slice).
    stages = _lower_stream_stages(sub_expr, env, filename)
    if stages:
        acquire["stages"] = stages
    if sub_expr.buffer is not None:
        acquire["buffer"] = sub_expr.buffer
        step["buffer"] = sub_expr.buffer
    if sub_expr.drain_ms is not None:
        # §8: the `block`-policy drain window is the one time-windowed piece of
        # stream behavior, and it fires on the deterministic test clock's
        # `advance` — never wall-clock.
        acquire["drain"] = sub_expr.drain_ms
        step["drain"] = sub_expr.drain_ms
    if getattr(sub_expr, "replay", None) is not None:
        # §4.5: the backlog this consumer asks for, admitted only against the
        # provider's own declaration. A durable cursor is additionally the §4.9
        # reconstructibility gate, so it is threaded onto the STEP too — the
        # bracket is what a crash leaves behind, and the cursor is the descriptor
        # a fresh process re-issues it from.
        want = _admit_replay(sub_expr.replay, stream_ir, env, filename, stmt.line)
        if "cursor" in want:
            # A cursor is a position in the PROVIDER's log. A derived stream
            # drops and rewrites items, and a lossy policy discards them, so
            # neither has a position in that log to resume from — a cursor over
            # one would name nothing, and resuming it would silently skip. Both
            # are refused rather than lowered into a claim nothing backs (§4.5).
            if acquire.get("stages"):
                raise RevlError(
                    filename, stmt.line,
                    "a durable replay cursor and a combinator chain do not "
                    "compose — a derived stream has no position in the "
                    "provider's log",
                    hint="subscribe the source with `replay(from: …)` and apply "
                         "`map`/`filter`/`take` to what the body does with each "
                         "item, or drop the cursor (item 130 §4.5)",
                    code="lifecycle", category="lifecycle")
            if sub_expr.policy in ("drop_newest", "drop_oldest"):
                raise RevlError(
                    filename, stmt.line,
                    f"a durable replay cursor and the lossy `{sub_expr.policy}` "
                    f"policy do not compose — a discarded item would advance the "
                    f"cursor past an item no consumer saw",
                    hint="a cursor is a resumable position, so it needs a policy "
                         "that never silently loses: `error` (the default) or "
                         "`block` (item 130 §4.4, §4.5)",
                    code="lifecycle", category="lifecycle")
        acquire["replay"] = want
        step["replay"] = want
    undo_reach = _first_suspension(step["undo"], env)
    if undo_reach is not None:
        raise RevlError(
            filename, stmt.line,
            f"`undo` reaches suspension `{undo_reach}`, but `close` is the "
            "synchronous, non-suspending bracket inverse (rule 3.4)",
            hint="teardown never suspends (docs/design/teardown-contract.md, the "
                 "bound rule) — the inverse of a subscription is `sub.close()`, "
                 "which trips the cancel token and returns; it must not `next`",
            code="lifecycle", category="lifecycle")
    # rule 3.6, the subscription half: the inverse must CLOSE THIS subscription.
    # The source's inverse is already shape-checked this way (a `Stream.source()`
    # whose undo does not `close` it is not recorded as terminal-delivering, so
    # `subscribe` refuses it); the bracket on the other end of the same wire had
    # no such check, so `undo nop("x")`, `undo src.close()` and a copy-pasted
    # sibling `undo a.close()` all passed while leaving THIS subscription open
    # and still attached to its source after the owner is DISPOSED. That is item
    # 130's core guarantee inverted: unloading the owner must CLOSE the stream
    # before the owner disappears (G7, R4).
    #
    # The required shape is literal and syntactic on purpose. A transitive close
    # through a helper fn is REFUSED, not admitted: proving a helper closes THIS
    # subscription needs alias tracking through fn bodies that the frontend does
    # not have, and admitting the call on faith would restore the same hole one
    # indirection later (the shape `_check_witnessed_inverse` had to close on the
    # emission side). The language already forbids the workaround anyway — a
    # `Subscription` is a host-local with no nominal type, so it cannot be passed
    # to a fn at all — so the rule refuses nothing an author can write today.
    #
    # Slice 3's `subscribe merge(a, b)` needs no separate clause and gets the
    # rule for free. The fan-in is DERIVED and owned by this one bracket, so
    # `sub.close()` is still the whole teardown; closing any single operand of
    # the merge instead is the same escape as closing the source of a plain
    # subscribe, and the required shape refuses it the same way.
    u = step["undo"]
    ut = u.get("target") if isinstance(u, dict) else None
    if not (isinstance(u, dict) and u.get("kind") == "call"
            and u.get("method") == "close" and not u.get("args")
            and isinstance(ut, dict) and ut.get("kind") == "name"
            and ut.get("id") == safe):
        raise RevlError(
            filename, stmt.line,
            f"the `undo` of a subscription must close THAT subscription — this "
            f"inverse does not `close` `{stmt.bind}`",
            hint=f"write `let {stmt.bind} = subscribe <stream> undo "
                 f"{stmt.bind}.close()` exactly (item 130 §3.6). Closing the "
                 "SOURCE, closing a sibling subscription, or doing nothing all "
                 "leave this listener attached after its owner is disposed, and "
                 "unloading the owner must CLOSE the stream before the owner "
                 "disappears (the core guarantee, G7/R4); a helper fn cannot "
                 "stand in, since nothing proves it closes THIS subscription",
            code="lifecycle", category="lifecycle")
    env.subscribed_sources.update(consumed)
    return step


def _bare_callee_name(raw_acquire) -> str | None:
    """The extern name an acquisition AST names by bare spelling, or None.

    A bare-name call (`open_h()`) and a bare name (`open_h`) are the two
    spellings the parser defers to the lowering, and both name the same
    declaration. Anything else (a dotted path, a literal, an operator) cannot
    be an extern by construction: externs are declared with an unqualified
    name and are imported under it."""
    if isinstance(raw_acquire, ExprCall):
        raw_acquire = raw_acquire.callee
    return raw_acquire.name if isinstance(raw_acquire, ExprVar) else None


def _lower_effect_step(acquire: dict, undo_expr, env: "Env", filename: str, line: int,
                       *, bind: str | None, raw_acquire=None) -> dict:
    """Build the `effect`/`let-effect` IR step for one activation-body
    acquisition (item 243 Slice 2, docs/design/243-witnessed-externs.md).

    A witnessed acquisition auto-registers its extern's DECLARED inverse as a
    transactional accumulator entry — there is no site-spelled undo, so the
    step carries no `"undo"` key at all (the parser already refuses a site
    `undo` token there; this is the defensive twin, and the checked source of
    the shape). `backends/python/emit.py._witnessed_extern` recognises this
    shape by matching the acquisition's callee name against the externs
    table, not by an IR step field, reads the DECLARED inverse from there,
    and emits the Ok-conditional transactional registration (Slice 2a). Every
    other acquisition keeps its ordinary site-spelled undo, lowered exactly
    as before — this helper changes no IR for a non-witnessed program.

    Deferred parser gate (item 315): a bare-name call missing its `undo` is
    admitted by the parser even when the callee's classification is not yet
    known — `use` imports resolve one file at a time, after parsing, so the
    parser cannot tell a same-file witnessed call from an IMPORTED one (or
    from a plain extern that is simply missing its `undo`) at parse time.
    `env.witnessed_externs` is built from `_witnessed_extern_names` over the
    MERGED, post-import program (`check_and_lower`), so by the time this runs
    an imported witnessed extern is indistinguishable from a same-file one —
    this is where the parser's deferred call is finally decided. If the
    callee turns out not to be witnessed after all, this raises the exact
    "effect has no `undo`" refusal (G4) the parser used to raise directly;
    `raw_acquire` (the original AST expression) is needed only to render that
    message the same way `_describe_expr` always has."""
    step_kind = "let-effect" if bind is not None else "effect"
    # item 397: the unbound statement form of a result-declared host verb (a
    # CAS like `insert_if_absent`) is refused. A CAS whose Bool nobody reads is
    # a plain `insert` with extra steps, and its site-spelled `undo` would be
    # registered unconditionally — removing the WINNER's entry on a `false`
    # CAS at teardown, exactly the corruption single-use exists to prevent
    # (docs/design/397-insert-if-absent.md §Classification, two sharp edges).
    if bind is None and _host_result_type(acquire, env) is not None:
        verb = str(acquire.get("method"))
        raise RevlError(
            filename, line,
            f"`{verb}` returns a value and must be bound: "
            f"`let ok = effect <map>.{verb}(k, v) undo <map>.remove(k)`",
            hint="a compare-and-set reports whether it inserted; discarding "
                 "that Bool makes its `undo` unsound (it would remove the "
                 "winning claimant's entry on a `false`). Bind the result, or "
                 "use `insert` for an unconditional overwrite",
            code="G4", category="host-boundary")
    wit_name = acquire.get("name") if acquire.get("kind") == "fn" else None
    if wit_name is not None and wit_name in env.witnessed_externs:
        if undo_expr is not None:
            raise RevlError(
                filename, line,
                f"witnessed extern `{wit_name}` cannot declare a site `undo`",
                hint="its declared inverse is auto-registered by the teardown "
                     "accumulator on the `Ok` branch; the accumulator owns "
                     "the inverse, not the call site "
                     "(docs/design/243-witnessed-externs.md)",
                code="G4", category="witnessed",
            )
        step = {"step": step_kind, "acquire": acquire}
    elif undo_expr is None:
        head = _describe_expr(raw_acquire) if raw_acquire is not None else "the expression"
        # item 420(d): the refusal stands, but its REASON depends on whether
        # the callee declares an inverse. If it does, this is the one position
        # that knows so (it runs on the merged, post-import program), and the
        # generic wording would deny the existence of a declaration the author
        # wrote and can point at. `_bare_callee_name` reads the AST rather than
        # the lowered node because the lowered `fn` shape covers only the
        # called spelling, and `effect open_h` names the same extern `effect
        # open_h()` does.
        callee = _bare_callee_name(raw_acquire)
        inverse = env.extern_undo.get(callee) if callee is not None else None
        declared = None
        if inverse is not None:
            declared = (env.extern_class.get(callee) or "acquire", inverse)
        message, hint = missing_undo_refusal(head, declared)
        raise RevlError(
            filename, line, message, hint=hint,
            code="G4", category="witnessed",
        )
    else:
        # G5 (docs/design/teardown-contract.md): a bracket inverse may NOT emit
        # in teardown. Checked before the undo is lowered so the refusal names
        # the callee the author wrote, and here rather than at each caller so
        # every site-spelled inverse (activation body and provide-method body
        # alike) is held to the same bound the DECLARED inverse of a witnessed
        # extern already obeys.
        _check_site_inverse_emission(undo_expr, env, filename, line)
        # the site slot's argument judgment (`_lower_site_inverse`): the code
        # that runs on abort, while the activation is already unwinding, is
        # held to the same declared signature the extern's own slot is, and
        # refuses with the slot named. Lowering through this one entry covers
        # the bound and unbound activation-body forms and both provide-method
        # acquire forms, since every one of them builds its step here. It is a
        # SIGNATURE judgment and the walk above is a CLASSIFICATION one, so
        # neither stands in for the other: `undo send_email(addr)` type-checks.
        undo = _lower_site_inverse(undo_expr, env, slot="undo")
        step = {"step": step_kind, "acquire": acquire, "undo": undo}
    if bind is not None:
        step["bind"] = bind
    return step


# ---------------------------------------------------------------------------
# item 308: effect ownership modes (owned + borrowed v1). The resource-taint
# base (R0: nominal opaque handles) lives in `resources.py`; these helpers are
# the frontend consumers of it — O1 (no hand-call of a declared inverse) and B1
# (a borrowed resource does not escape its scope). `owned` is the implicit mode
# of a handle bound by `let x = effect <acquire> …` at activation scope; every
# other resource-typed position is `borrowed` (positional, never dataflow — the
# safe direction, since every wrong answer is a false positive, not an unsound
# admission).
#
# Deferred, each with its landing place named in the design doc:
#   TODO(308-followup): `shared` mode (a 294 lease binding); `shared`/`transfer`
#     are reserved contextual keywords, not implemented in v1.
#   TODO(308-followup): explicit `transfer` (a source marker that moves the
#     bracket; the only honest future for a handoff of resource-carrying state).
#
# F10 (the retaining-extern audit) SHIPPED as `resources.retention_surface`,
# read by `revl audit` and its `--json` document: report-only, because the
# declaration does not say "retains" and no clause here can refuse what a host
# body keeps.
#
# F9 (method-scope early release) is DECIDED, and the decision is that revl
# already has the surface, spelled with the grammar it already had. See
# `_f9_instance_scope_scan` below and the design doc's "F9, decided".
# ---------------------------------------------------------------------------


def _resource_ctx(types: dict) -> tuple[set, set]:
    """`(taint, closers)` from a lowering `types` table (its `APPROVAL_KEY`
    carries the externs index). Cached on the table under a private key so a
    per-site call is O(1) after the first."""
    cache = types.get("__resource_ctx__")
    if cache is not None:
        return cache
    idx = (types.get(APPROVAL_KEY) or {}).get("externs") or {}
    externs = list(idx.values())
    # item 442 (issue #121): a delegated reference `Delegate[S]` is a borrow, so
    # the frontend borrow walk must confine it exactly as it confines an acquire
    # handle (design §3.3 D2, §4.3 C3/C4: no escape into activation state, a
    # carrier, a return, a spawn config, a handoff, or an inverse position).
    # `Delegate` is NOT an acquire return, so it is kept out of `resource_taint`
    # (whose base is `resource_base`, the acquire handles the seam/placement
    # analyses read); it is added HERE, to the frontend taint only, so B1/O1
    # visit it while the seam and audit surfaces stay defined by real handles.
    ctx = (resource_taint(externs, types) | {DELEGATE_HEAD},
           closing_ops(externs))
    try:
        types["__resource_ctx__"] = ctx
    except Exception:  # pragma: no cover - types is always a plain dict
        pass
    return ctx


def _owned_handles(env: "Env") -> set:
    """The activation-scope owned-handle safe-names of the component being
    lowered (bound by `let x = effect <acquire-class extern>`)."""
    owned = getattr(env, "_owned_handles", None)
    if owned is None:
        owned = set()
        env._owned_handles = owned
    return owned


def _node_local_name(node) -> str | None:
    """The bare local name a lowered leaf node references, or None. Covers the
    `{"kind": "name", "id": ..}` and `{"kind": "var", "name": ..}` shapes."""
    if not isinstance(node, dict):
        return None
    if node.get("kind") in ("name", "var"):
        return node.get("id") or node.get("name")
    return None


def _node_resource(node, env: "Env", taint: set) -> str | None:
    """The resource type a lowered expression node carries, or None."""
    if not isinstance(node, dict):
        return None
    t = infer_ir(node, env.type_env, env.types, env.services)
    return resource_in(t, taint)


def _walk_call_nodes(node):
    """Yield every lowered call node (`kind` fn/call) reachable in `node`."""
    stack = [node]
    while stack:
        cur = stack.pop()
        if isinstance(cur, dict):
            if cur.get("kind") in ("fn", "call"):
                yield cur
            stack.extend(cur.values())
        elif isinstance(cur, list):
            stack.extend(cur)


def _walk_value_nodes(node):
    """Yield every dict node reachable in a lowered expression tree."""
    stack = [node]
    while stack:
        cur = stack.pop()
        if isinstance(cur, dict):
            yield cur
            stack.extend(cur.values())
        elif isinstance(cur, list):
            stack.extend(cur)


# O1's hint, split by the position it fires in (item 274: a refusal names a
# fix the author can actually enact where they are standing). In an ACTIVATION
# body the own-undo exemption is reachable, so naming it is a real instruction.
# Inside a PROVIDE METHOD it is not: only `spawn` (and a result-declared host
# verb) may be acquired there, so the author cannot create an acquiring binding
# to hang an own-undo on, and `result` is not in scope in a site `undo` either.
# The spelling that DOES release exactly the acquired handle at a seam is
# `witnessed`: its declared inverse auto-registers on the enclosing activation's
# transactional accumulator, once per acquisition, with `result` bound to what
# the acquisition returned (docs/design/243-witnessed-externs.md, item 318).
_O1_HINT_ACTIVATION = (
    "let teardown run the inverse; if a resource must end early, that is an "
    "explicit-release surface revl does not have yet (only the acquiring "
    "binding's own `undo` may name its inverse)")
_O1_HINT_SEAM = (
    "let teardown run the inverse. The own-undo exemption is not reachable "
    "here: only `spawn` may be acquired inside a provide-method body, so there "
    "is no acquiring binding to hang an `undo` on, and `result` is not in "
    "scope in a site `undo`. To release exactly what a seam acquires, declare "
    "the extern `witnessed` and drop the site `undo`: its DECLARED `undo "
    "<inverse>(result)` auto-registers on the enclosing activation's "
    "transactional accumulator, once per acquisition "
    "(docs/design/243-witnessed-externs.md). Early release is an "
    "explicit-release surface revl does not have yet")


def _o1_check(node, env: "Env", filename: str, line: int, *,
              position: str, exempt_handle: str | None = None,
              seam: bool = False) -> None:
    """O1: refuse a hand-call of a declared inverse (a closing op) on a
    resource-typed argument anywhere in `node`. `position` names the syntactic
    slot for the diagnostic (`body` / `undo` / `compensate`). `exempt_handle`
    is the acquiring binding's own handle safe-name: in that binding's own
    `undo`, a closer call on that handle IS the bracket being created, not a
    double-close, and is admitted (the mandatory own-undo exemption).

    `seam` marks a provide-METHOD position, where the hint the activation body
    gets is unactionable (see `_O1_HINT_SEAM`)."""
    taint, closers = _resource_ctx(env.types)
    if not closers:
        return
    for call in _walk_call_nodes(node):
        name = call.get("name") if call.get("kind") == "fn" else \
            (call.get("callee") or {}).get("name")
        if name not in closers:
            continue
        for arg in call.get("args") or []:
            rt = _node_resource(arg, env, taint)
            if not rt:
                continue
            if (exempt_handle is not None
                    and _node_local_name(arg) == exempt_handle):
                continue
            owned = _node_local_name(arg) in _owned_handles(env)
            mode = "owned" if owned else "borrowed"
            from . import navigate as _nav  # noqa: PLC0415 — lazy, additive
            raise RevlError(
                filename, line,
                f"`{name}(...)` is a declared inverse (a close) of a resource; "
                f"the {mode} handle `{rt}` is closed exactly once by the "
                f"acquiring activation's teardown (G7), so hand-calling it here "
                f"(in {position} position) would double-close (item 308, O1)",
                hint=(_O1_HINT_SEAM if seam else _O1_HINT_ACTIVATION),
                code="G7", category="ownership",
                navigate=_nav.ownership_navigate(
                    kind="o1", resource=rt, mode=mode,
                    binding=_node_local_name(arg), seam=seam,
                    profile=(_UntrustedMark if env.untrusted else None)),
            )


def _b1_navigate(env: "Env", clause: str, mode: str, rt: str) -> dict:
    """The B1 borrow-escape family's navigable map (item 274, design §2.5): the
    author-side reshape that keeps the borrow in scope. All author-enacted,
    `candidate` (the compiler does not re-synthesize the rewrite to re-run the
    gate); collapses under the untrusted-author profile."""
    from . import navigate as _nav  # noqa: PLC0415 — lazy, additive
    return _nav.ownership_navigate(
        kind="b1", resource=rt, mode=mode, clause=clause,
        profile=(_UntrustedMark if env.untrusted else None))


def _b1_no_resource(node, env: "Env", filename: str, line: int, *,
                    clause: str, borrows_only: bool = True,
                    extra_owned: set | None = None) -> None:
    """B1: refuse a resource-typed value appearing anywhere in `node`. When
    `borrows_only` is True the owner's own handle is admitted (the owner-carve-
    out); when False (a `compensate` position, clause 5) an OWNED handle is
    refused too, because compensations run in teardown Phase 2 after Phase 1
    closed every bracket — a resource there is use-after-close by phase order.
    `extra_owned` adds method-scope owned-handle names (an acquire bound inside
    the current provide method) to the owner set for the own-undo exemption."""
    taint, _ = _resource_ctx(env.types)
    if not taint:
        return
    owned = _owned_handles(env) | (extra_owned or set())

    def _is_owned(n):
        return _node_local_name(n) in owned

    for sub in _walk_value_nodes(node):
        rt = _node_resource(sub, env, taint)
        if not rt:
            continue
        if borrows_only and _is_owned(sub):
            continue
        mode = "owned" if _is_owned(sub) else "borrowed"
        raise RevlError(filename, line, _b1_message(clause, mode, rt),
                        hint=_b1_hint(clause), code="G7", category="ownership",
                        navigate=_b1_navigate(env, clause, mode, rt))
    # a borrowed value with no local name (a bare call result / field read) is
    # still a resource by type; catch it when the whole node is the resource.
    rt = _node_resource(node, env, taint)
    if rt and not (borrows_only and _is_owned(node)):
        mode = "owned" if _is_owned(node) else "borrowed"
        raise RevlError(filename, line, _b1_message(clause, mode, rt),
                        hint=_b1_hint(clause), code="G7", category="ownership",
                        navigate=_b1_navigate(env, clause, mode, rt))


_B1_CLAUSE_TEXT = {
    "state": "stored into activation-level state",
    "capture": "captured by a closure",
    "return": "returned across a signature",
    "carrier": "placed in an escaping record/collection value",
    "undo": "placed in an `undo` expression",
    "witnessed": "passed to a witnessed effect's argument list",
    "compensate": "placed in a `compensate` expression",
    "spawn": "seated in a `spawn` config value",
    "handoff": "carried by a `handoff` type",
}


# container-mutating verbs whose target is an activation-level host local: a
# resource seated through one of these is stored into activation state (B1
# clause 1), unlike a plain fn/service call which is legitimate down-passing.
_MUTATING_VERBS = frozenset({
    "insert", "put", "set", "push", "add", "append", "store", "enqueue",
})


def _b1_flag_if_borrow(v, env: "Env", taint: set, owned: set, filename: str,
                       line: int, clause: str) -> None:
    rt = _node_resource(v, env, taint)
    if rt and _node_local_name(v) not in owned:
        raise RevlError(filename, line, _b1_message(clause, "borrowed", rt),
                        hint=_b1_hint(clause), code="G7", category="ownership",
                        navigate=_b1_navigate(env, clause, "borrowed", rt))


def _b1_body_scan(node, env: "Env", filename: str, line: int) -> None:
    """B1 clauses 1 (store into activation state) and 4 (escaping carrier):
    refuse a BORROWED resource value placed in a record/list/map literal, or
    inserted into an activation-level container (a mutating verb on an
    activation host local). Both orders are caught — the value is checked
    wherever it is seated, whether the carrier is then parked or was already
    parked. The owner's own handle is exempt (these clauses bind borrows only);
    passing a borrow DOWN a plain call chain stays admitted."""
    taint, _ = _resource_ctx(env.types)
    if not taint:
        return
    owned = _owned_handles(env)
    host_locals = getattr(env, "host_locals", {}) or {}
    for sub in _walk_value_nodes(node):
        kind = sub.get("kind")
        if kind == "record":
            for _, v in sub.get("fields") or []:
                _b1_flag_if_borrow(v, env, taint, owned, filename, line, "carrier")
        elif kind == "list":
            for v in sub.get("items") or []:
                _b1_flag_if_borrow(v, env, taint, owned, filename, line, "carrier")
        elif kind == "map":
            for entry in sub.get("entries") or []:
                v = entry[1] if isinstance(entry, (list, tuple)) and len(entry) == 2 \
                    else entry
                _b1_flag_if_borrow(v, env, taint, owned, filename, line, "carrier")
        elif kind == "call" and sub.get("method") in _MUTATING_VERBS:
            if _node_local_name(sub.get("target") or {}) in host_locals:
                for a in sub.get("args") or []:
                    _b1_flag_if_borrow(a, env, taint, owned, filename, line, "state")


def _is_service_crossing(call: dict, env: "Env") -> bool:
    """Whether a lowered call node is a SERVICE-METHOD crossing — a required-key
    call (`s.m(..)`, a `req` target) or a spawn-handle provision call
    (`w.key.m(..)`, an `instance-get` receiver). A plain fn/host call is not a
    crossing; neither is a method called ON a delegated reference itself, whose
    receiver is a borrowed local, not a `req`/provision (that is the delegate's
    admitted own use, C2)."""
    if not isinstance(call, dict) or call.get("kind") != "call":
        return False
    target = call.get("target")
    if isinstance(target, dict) and target.get("kind") == "req" and call.get("method"):
        return True
    return _instance_get_call(call, env) is not None


def _d4_delegate_no_recrossing(node, env: "Env", filename: str, line: int) -> None:
    """D4 (roadmap item 442 §6.2, issue #121): a received `Delegate[S]` value is
    a DEPTH-1 borrow. It may be used (its own `S` methods called) and passed
    DOWN a plain call, but it may NOT be handed as an argument across a SECOND
    service-method crossing. An unbounded delegation chain is a capability cone
    no header can enumerate, which breaks G8's enumerable-ceiling guarantee; v1
    bounds depth at one by refusing a delegated reference in the argument list
    of any service crossing (the existing crossing / non-crossing line, so no
    depth counter and no new concept — design §6.2 D4, C6)."""
    taint, _ = _resource_ctx(env.types)
    if DELEGATE_HEAD not in taint:
        return
    for call in _walk_call_nodes(node):
        if not _is_service_crossing(call, env):
            continue
        for arg in call.get("args") or []:
            if _node_resource(arg, env, {DELEGATE_HEAD}) != DELEGATE_HEAD:
                continue
            named = _node_local_name(arg)
            who = f"`{named}` " if named else ""
            raise RevlError(
                filename, line,
                f"a delegated reference {who}(`{DELEGATE_HEAD}[S]`) cannot be "
                "passed as an argument to a further service-method call — a "
                "delegation is bounded to depth one (item 442, issue #121)",
                hint="v1 admits a delegated reference for the duration of the "
                     "ONE call that received it: use it directly (call its own "
                     "`S` methods) or pass it down a plain `fn`, but it may not "
                     "cross a second service boundary. An unbounded delegation "
                     "chain is a capability cone no header can enumerate (G8); "
                     "if the far component needs the authority, delegate to it "
                     "directly from the holder (design §6.2 D4)",
                code="G8", category="delegation",
            )


def _ownership_check_expr(node, env: "Env", filename: str, line: int,
                          *, seam: bool = False) -> None:
    """Run the body-position ownership checks over one lowered expression: O1
    (no hand-call of a declared inverse, no own-undo exemption in a body
    position), B1 clauses 1/4 (no borrow stored into activation state or an
    escaping carrier), and D4 (no delegated reference re-crossed a second
    service boundary; item 442 §6.2). `seam` marks a provide-METHOD position so
    O1's hint names a fix reachable there (item 274)."""
    if node is None:
        return
    _o1_check(node, env, filename, line, position="body", seam=seam)
    _b1_body_scan(node, env, filename, line)
    _d4_delegate_no_recrossing(node, env, filename, line)


def _ownership_walk_method(steps, env: "Env", filename: str, line: int) -> None:
    """Apply the body-position O1/B1 checks over a lowered provide-METHOD body.
    A handle a service method parameter carries is a BORROW; an acquire bound
    inside the method is owned by the method (its own `undo` is exempt). Runs
    O1 (no hand-close) and B1 clauses 1/4/5 across the method's statements —
    clause 3 (return) and the emit `compensate` half are enforced inline where
    they are lowered."""
    method_owned: set = set()
    taint, _ = _resource_ctx(env.types)
    for st in steps or []:
        if not isinstance(st, dict):
            continue
        stp = st.get("step")
        if stp in ("let-effect", "effect"):
            acq = st.get("acquire")
            bind = st.get("bind")
            acq_res = _node_resource(acq, env, taint) if acq is not None else None
            undo = st.get("undo")
            if undo is not None:
                exempt = bind if (acq_res and bind) else None
                _o1_check(undo, env, filename, line, position="undo",
                          exempt_handle=exempt, seam=True)
                _b1_no_resource(undo, env, filename, line, clause="undo",
                                borrows_only=True, extra_owned=method_owned)
            _ownership_check_expr(acq, env, filename, line, seam=True)
            _b1_witnessed_check(acq, env, filename, line)
            if acq_res and bind:
                method_owned.add(bind)
        elif stp == "emit":
            _ownership_check_expr(st.get("expr"), env, filename, line, seam=True)
        elif stp in ("let", "assign"):
            _ownership_check_expr(st.get("value"), env, filename, line, seam=True)
        elif stp in ("return", "await"):
            _ownership_check_expr(st.get("expr"), env, filename, line, seam=True)
        elif stp in ("if", "while", "for"):
            # issue #548: control-flow arms hold pure value computation; descend
            # so a borrowed/owned handle used in a conditional or loop body is
            # judged exactly as at the method's top level. The arms register no
            # teardown (that is refused at lowering), so `method_owned` needs no
            # per-branch merge.
            if stp == "for":
                _ownership_check_expr(st.get("iterable"), env, filename, line,
                                      seam=True)
            else:
                _ownership_check_expr(st.get("cond"), env, filename, line,
                                      seam=True)
            _ownership_walk_method(st.get("then") or [], env, filename, line)
            _ownership_walk_method(st.get("else") or [], env, filename, line)
            _ownership_walk_method(st.get("body") or [], env, filename, line)
    _f9_instance_scope_scan(steps, env, filename, line)


def _b1_witnessed_check(acquire, env: "Env", filename: str, line: int) -> None:
    """B1 clause 5 (witnessed half): a witnessed effect's declared inverse is
    auto-registered on the same per-activation accumulator as an `undo`, so a
    resource-typed value in its argument list rides teardown and replays after
    the owner is gone. Refuse a resource argument to a witnessed acquisition."""
    if not isinstance(acquire, dict) or acquire.get("kind") != "fn":
        return
    if acquire.get("name") not in getattr(env, "witnessed_externs", set()):
        return
    taint, _ = _resource_ctx(env.types)
    if not taint:
        return
    owned = _owned_handles(env)
    for a in acquire.get("args") or []:
        rt = _node_resource(a, env, taint)
        if rt:
            mode = "owned" if _node_local_name(a) in owned else "borrowed"
            raise RevlError(filename, line, _b1_message("witnessed", mode, rt),
                            hint=_b1_hint("witnessed"), code="G7",
                            category="ownership",
                            navigate=_b1_navigate(env, "witnessed", mode, rt))


# ---------------------------------------------------------------------------
# F9: method-scope early release (item 308, design "F9, decided").
# ---------------------------------------------------------------------------
#
# THE DECISION. The design left this open behind a corpus count: if some
# program acquires at method scope, either an explicit-release surface lands or
# v1 refuses the form. The count came back ZERO general method-scope acquires,
# because the language already refuses them — `_lower_provide` admits exactly
# two acquisition forms in a provide-method body, `spawn` and a result-declared
# host verb (item 397), and the second binds a checked `Bool`, not a handle. So
# there is exactly ONE method-scope acquisition that yields a live resource, and
# it is the one that already has an early release: a `spawn` is a CHILD FIBER —
# its own nested teardown scope — and `w.dispose()` unloads it now, mid-method,
# with the grammar revl already had (`effect w.dispose() undo w.dispose()`).
# No new surface is added, and none is owed.
#
# WHY THAT DOES NOT DISTURB TEARDOWN, which is the whole reason a general
# release surface stayed deferred. Early release here RELEASES A SCOPE; it does
# not DISCHARGE AN ENTRY. The frame-adopted safety net (`Frame.acquire`'s
# `lambda w: w.dispose()`) stays registered on the enclosing activation's LIFO
# for its whole life, and `SpawnHandle.dispose` is idempotent, so:
#
#   * fault mid-scope BEFORE the release — the entry is registered and unrun;
#     the fault propagates out of the method (a method fault is NOT an
#     activation abort: `Frame._aborting` stays clear), and the entry runs at
#     activation teardown in LIFO position, guarded. Nothing is missed.
#   * fault mid-scope AFTER the release — the entry is registered and runs, and
#     the second dispose is a no-op on `_disposed`. Nothing runs twice.
#   * E-Stop mid-scope (item 443's `halted`) — the entry is STRANDED either
#     way: registered, not run, not dropped, kept for `revl recover`. Where the
#     release already happened the stranded record OVER-reports one entry whose
#     replay is a no-op. That is the R4-safe direction (residue is never
#     under-reported) and it is why early release must not discharge: a
#     discharge would drop the very descriptor the halt is required to keep, and
#     THAT would contradict `estop_strands_everything`.
#
# So G7 LIFO-completeness is untouched: the entry set is exactly what it was.
#
# WHAT THIS ADDS. The promise the nested scope makes — "a request-scoped
# instance is reclaimed when the request ends" — was unenforced: an
# `Instance[C]` handle is not an `extern acquire` return, so it is not in the
# resource-taint base and B1's clauses never bound it. A provide method could
# RETURN the handle, park it in activation state, or close over it, and the
# instance then outlived the request it was scoped to while its safety-net entry
# sat on the activation frame. This is B1's does-not-escape rule applied to the
# one handle B1 could not see, keyed on the BINDING (spawn is syntactically
# evident at the acquiring step) rather than on a type, since `Instance[C]` in
# the taint base would also bind the activation-scope owner pool that the
# owner carve-out deliberately admits.
#
# The admitted positions are a whitelist, not a blacklist: a handle is READ and
# not retained as the receiver of a host method call (`w.dispose()`) and as the
# base of a provision read (`w.task.run(..)`), which are the two things the
# instance surface is for. Every other occurrence is refused.

#: How an escaping instance handle got out, for the diagnostic.
_F9_ESCAPE = "may not leave the provide method that spawned it"

_F9_HINT = (
    "a spawned instance is a child fiber — its own nested teardown scope — so "
    "it is reclaimed when the request ends (`effect w.dispose() undo "
    "w.dispose()`), or by the activation frame's safety net at the latest. A "
    "holder outside the method would outlive that scope. Hand out a VALUE read "
    "off the instance instead, or spawn at ACTIVATION scope and lend the "
    "instance per call (the owner pool pattern, which the owner carve-out "
    "admits)")


def _f9_spawn_binds(steps) -> set:
    """The safe-names a provide-method body binds by `spawn` — the only
    method-scope acquisition that yields a live handle."""
    binds: set = set()
    for st in steps or []:
        if not isinstance(st, dict) or st.get("step") != "let-effect":
            continue
        acq = st.get("acquire")
        if isinstance(acq, dict) and acq.get("kind") == "spawn" and st.get("bind"):
            binds.add(st["bind"])
    return binds


def _f9_reads_not_retains(node) -> str | None:
    """The child slot in which `node` READS a handle without being able to keep
    it, or None. A host method call's receiver (`w.dispose()`) and a provision
    read's base (`w.task`) both consume the handle on the spot; every other slot
    may leave a second holder, so the default is "retains"."""
    kind = node.get("kind")
    if kind == "instance-get":
        return "target"
    if kind == "call" and node.get("method") and isinstance(node.get("target"), dict):
        return "target"
    return None


def _f9_walk(node, binds: set, env: "Env", filename: str, line: int,
             captured: bool = False) -> None:
    """Refuse any occurrence of a method-scope spawn handle outside the two
    slots that read it without retaining it.

    `captured` is set once the walk is INSIDE an arrow body, where the two
    read-only slots stop being read-only: an arrow's type (`() -> Int`) erases
    what it closes over, so a closure reading the instance carries it wherever
    the closure goes. That is B1 clause 2's reasoning, and clause 2's outright
    refusal is the shape adopted here for the same reason."""
    if isinstance(node, list):
        for item in node:
            _f9_walk(item, binds, env, filename, line, captured)
        return
    if not isinstance(node, dict):
        return
    if node.get("kind") == "arrow":
        captured = True
    name = _node_local_name(node)
    if name is not None and name in binds:
        from . import navigate as _nav  # noqa: PLC0415 — lazy, additive
        raise RevlError(
            filename, node.get("line") or line,
            f"the request-scoped instance handle `{name}` {_F9_ESCAPE}: it is "
            f"spawned into its own nested teardown scope and reclaimed when the "
            f"request ends, so a holder outside the method would outlive the "
            f"instance (item 308, F9)",
            hint=_F9_HINT, code="G7", category="ownership",
            navigate=_nav.ownership_navigate(
                kind="f9", mode="owned", binding=name,
                profile=(_UntrustedMark if env.untrusted else None)))
    skip = None if captured else _f9_reads_not_retains(node)
    for key, child in node.items():
        if key == skip:
            # the receiver/base itself is fine; anything NESTED under it (an
            # argument, an index) is not, so recurse past only the bare name
            if _node_local_name(child) in binds:
                continue
        _f9_walk(child, binds, env, filename, line, captured)


def _f9_instance_scope_scan(steps, env: "Env", filename: str, line: int) -> None:
    """F9: a `spawn` handle bound in a provide-method body does not escape it."""
    binds = _f9_spawn_binds(steps)
    if not binds:
        return
    for st in steps or []:
        if not isinstance(st, dict):
            continue
        for key, child in st.items():
            if key == "bind":
                continue  # the acquiring binding itself, a bare string
            _f9_walk(child, binds, env, filename, st.get("line") or line)


def _all_free_names(expr, bound: set[str]) -> set[str]:
    """Every `ExprVar` name referenced in `expr` and not shadowed by a lambda
    parameter or match binding (all free vars, unlike `_mutable_free_vars`
    which keeps only mutable ones)."""
    bound = set(bound or ())
    if isinstance(expr, ExprVar):
        return set() if expr.name in bound else {expr.name}
    if isinstance(expr, ExprArrow):
        return _all_free_names(expr.body, bound | set(expr.params))
    if isinstance(expr, ExprMatch):
        found = _all_free_names(expr.scrutinee, bound)
        for _, bind, body in expr.arms:
            arm_bound = set(bound) | ({bind} if bind is not None else set())
            found |= _all_free_names(body, arm_bound)
        return found
    found: set[str] = set()
    for attr in ("left", "right", "operand", "callee", "target", "index",
                 "cond", "then", "otherwise", "base"):
        child = getattr(expr, attr, None)
        if child is not None and not isinstance(child, (str, int, bool)):
            found |= _all_free_names(child, bound)
    for arg in getattr(expr, "args", None) or []:
        found |= _all_free_names(arg, bound)
    for _, value in getattr(expr, "fields", None) or []:
        found |= _all_free_names(value, bound)
    for _, value in getattr(expr, "updates", None) or []:
        found |= _all_free_names(value, bound)
    for item in getattr(expr, "items", None) or []:
        found |= _all_free_names(item, bound)
    return found


def _b1_capture_check(arrow, type_env: dict, types: dict, filename: str,
                      line: int) -> None:
    """item 308, B1 clause 2: refuse capturing ANY resource-typed value in a
    closure (owner included). A closure value's type (`() -> Int`) erases the
    capture, so a closure carrying a handle is invisible to the taint fixpoint
    and launders the handle across a signature (the recommended v1 rule is the
    outright refusal, strictly smaller than closure-value taint tracking)."""
    taint, _ = _resource_ctx(types)
    if not taint:
        return
    for name in _all_free_names(arrow.body, set(arrow.params)):
        t = type_env.get(name)
        rt = resource_in(t, taint) if t else None
        if rt:
            from . import navigate as _nav  # noqa: PLC0415 — lazy, additive
            raise RevlError(
                filename, line, _b1_message("capture", "borrowed", rt),
                hint=_b1_hint("capture"), code="G7", category="ownership",
                # this site has no `Env`; capture reveals only the author's own
                # closure (no operator topology), so the trusted map is sound.
                navigate=_nav.ownership_navigate(
                    kind="b1", resource=rt, mode="borrowed", clause="capture",
                    profile=None))


def _b1_return_admitted(node, env: "Env", taint: set) -> bool:
    """B1 clause 3: is this resource-typed return a borrow-CREATING move (so it
    is admitted) rather than a borrow-escape?

      * the owner returning its OWN activation handle (a bare name in the owned
        set), or
      * a FRESH MINT: a direct call whose result is the resource and NONE of
        whose arguments carry a resource — a constructor/factory handing the
        caller a newly-made handle (the transfer case). A call that threads a
        resource ARGUMENT into its result is a carrier/laundering and stays
        refused.
    """
    if _node_local_name(node) in _owned_handles(env):
        return True
    if isinstance(node, dict) and node.get("kind") in ("fn", "call"):
        for a in node.get("args") or []:
            if _node_resource(a, env, taint):
                return False
        return True
    return False


def _b1_message(clause: str, mode: str, rt: str) -> str:
    what = _B1_CLAUSE_TEXT.get(clause, clause)
    return (f"{mode} resource `{rt}` cannot be {what}; a borrow is confined to "
            f"the scope that received it and may not outlive its owner's "
            f"bracket (G7) (item 308, B1)")


def _b1_hint(clause: str) -> str:
    if clause in ("state", "carrier"):
        return ("restructure so the owner holds the handle and lends it per "
                "call; a borrow may be passed further down a call chain, but "
                "not parked in activation state or an escaping carrier")
    if clause == "capture":
        return ("v1 refuses capturing any resource handle in a closure (owner "
                "included): a closure value's type erases the capture, so it "
                "would launder the handle across a signature")
    if clause == "return":
        return ("only the owner may return its OWN handle from a provide "
                "method; a borrow (or a tainted carrier) may not be returned "
                "onward")
    if clause in ("undo", "witnessed", "compensate"):
        return ("teardown-position captures outlive or outrun the bracket; a "
                "compensate runs after every bracket closed, so no resource "
                "value (owned or borrowed) may appear there")
    if clause == "spawn":
        return ("spawn config seats the value in the child's activation for its "
                "whole lifetime; a child acquires its own handle or calls the "
                "owner's service per use")
    if clause == "handoff":
        return ("a handoff re-seats the predecessor's resource vector on the "
                "successor while the predecessor's teardown closes it; a real "
                "handle transfer is the deferred `transfer` marker, not handoff "
                "shape-compat")
    return "a borrow may not escape its scope"


def _poison_failed_binding(stmt, env: "Env") -> None:
    """Bind a recovered binding-statement's name to the poison sentinel so its
    later uses stay silent (item 386, Stage 2).

    When a `let`-binding component statement refuses (its initializer was a type
    error), the name may be UNBOUND — the refusal fired before `bind_local` ran —
    or bound with a now-stale type. Either way, rebinding it to `POISON` (an
    absorbing, silent wildcard) is what stops the downstream statements that read
    it from each fabricating a second diagnostic: without a binding at all, every
    later reference would raise an undefined-name cascade; with a concrete stale
    type, a type cascade. A non-binding action (an `effect`/`emit`/`fail` with no
    handle) introduces no reusable name, so there is nothing to poison and this
    is a no-op."""
    bind = getattr(stmt, "bind", None)
    if not bind:
        return
    safe = env.locals.get(bind)
    if safe is None:
        try:
            safe = env.bind_local(bind, getattr(stmt, "line", 0))
        except RevlError:
            return  # the name was already bound (e.g. a duplicate-name refusal)
    env.type_env[safe] = POISON


def _lower_component(comp: ComponentDecl, services: dict[str, ServiceDecl], filename: str,
                     callables: set | None = None, types: dict | None = None,
                     emitting_fns: set | None = None,
                     emitting_caps: dict | None = None,
                     emission_evidence: "_EmissionEvidence | None" = None,
                     spawn_reg: dict | None = None,
                     async_colored: set | None = None,
                     witnessed_externs: set | None = None,
                     colour_polymorphic: set | None = None,
                     sync_monomorphs: dict | None = None,
                     poly_externs: set | None = None,
                     extern_colour_instances: dict | None = None,
                     extern_class: dict | None = None,
                     extern_undo: dict | None = None,
                     errors: list | None = None,
                     untrusted: bool = False) -> dict:
    env = Env(comp, services, filename, types)
    env.untrusted = untrusted
    env.emitting_fns = emitting_fns or set()
    env.extern_class = extern_class or {}
    env.extern_undo = extern_undo or {}
    env.emitting_caps = emitting_caps or {}
    env.emission_evidence = emission_evidence
    env.witnessed_externs = witnessed_externs or set()
    env.async_externs = dict(emission_evidence.async_externs) if emission_evidence else {}
    # the phase-2 async-colored set (async externs + fns that transitively
    # reach one, docs/design/async-extern.md §3): the provide-method admission
    # tests membership here, not just direct extern calls, so a sync method
    # reaching a colored fn is refused too. Falls back to the extern names
    # alone when the fixed point was not supplied (older callers/tests).
    env.async_callables = set(async_colored) if async_colored is not None \
        else set(env.async_externs)
    # sync/async arrow polymorphism (item 342): the colour-polymorphic fns
    # (async solely by their own callback param) and the shared registry the
    # sync call sites fill with monomorph requests (monomorph-name -> origin).
    env.colour_polymorphic = set(colour_polymorphic) if colour_polymorphic else set()
    env.sync_monomorphs = sync_monomorphs if sync_monomorphs is not None else {}
    # item 388: the poly externs (`fn|async`) and the shared registry each
    # provide method fills with the call-site colour it requested. `_resolve_poly
    # _extern_calls` reads `poly_externs` to spot a poly-extern call and records
    # into `extern_colour_instances`; `_finalize_poly_externs` reads it after the
    # component loop. Empty unless the program declares a poly extern.
    env.poly_externs = set(poly_externs) if poly_externs else set()
    env.extern_colour_instances = (extern_colour_instances
                                   if extern_colour_instances is not None else {})
    env.callables = callables or set()  # module fns/externs/hosts for unified expressions
    # instance-parametric components: the registry of spawn targets, edges,
    # templates and G4 spawn-boundary sites (docs/design-v2-instances.md)
    env.spawn_reg = spawn_reg

    # a config default must fit its declared field type (config typing);
    # a `null` default is the documented optional exception and is allowed
    for cfg in comp.config:
        if cfg.default is None:
            continue
        lit_type = _config_default_type(cfg.default)
        if lit_type is not None and not compatible(cfg.type, lit_type):
            raise mismatch(filename, cfg.line,
                           f"config field `{cfg.name}` default", cfg.type, lit_type)

    provides = {}
    for key, svc, line in comp.provides:
        if svc not in services:
            raise RevlError(filename, line, f"unknown service `{svc}` in `provides` of {comp.name}")
        if key in provides:
            raise RevlError(filename, line, f"duplicate provision key `{key}` in {comp.name}")
        provides[key] = svc

    # item 130 §6c: the `requires <k>: Stream[T] replay(…)` declarations, lowered
    # before the body so a `subscribe <k> replay(…)` below has a declaration to be
    # admitted against and a malformed cursor is refused even where nothing asks.
    _lower_required_replay_decls(env, filename)

    body = []
    provided_keys: set[str] = set()
    provide_seen_line: int | None = None
    isolate: dict[str, str] = {}
    intercept: dict[str, dict] = {}
    routes: dict[str, dict] = {}
    handoff: dict | None = None
    action_seen = False
    # item 386, Stage 2: set when a statement's type-check refused and was
    # recovered past (statement-boundary synchronization). A component with any
    # recovered statement is marked `poisoned` below, exactly like a Stage-1
    # header-abort stub, so the body-walking post-passes skip its partial body.
    recovered = False

    def _dispatch_action(stmt, provide_seen_line):
        """Lower one *action* statement (effect/emit/fail/if/provide/…),
        appending its step(s) to `body`, and return the (possibly updated)
        `provide_seen_line`. Factored out of the body loop so the loop can wrap
        it in the Stage-2 statement-boundary recovery (item 386): a `RevlError`
        raised here is caught one frame out, recorded, and the walk resumes at
        the next statement. It closes over the component's lowering state
        (`env`, `body`, `provides`, `provided_keys`, `filename`, `callables`)."""
        if isinstance(stmt, StreamIterStmt) and provide_seen_line is not None:
            raise RevlError(
                filename, stmt.line,
                "`every … in` after `provide` — the iteration runs until the "
                "stream's terminal, so a provision below it would be reached "
                "only once the stream ended",
                hint="put the iteration above the `provide` block, or move the "
                     "provision above the loop (linker rule A2; item 130 §4.7)")
        if isinstance(stmt, (LetEffect, EffectStmt, TimerStmt)) and provide_seen_line is not None:
            raise RevlError(
                filename, stmt.line,
                "acquisition after `provide` — an effect acquired after a provision "
                "would be reverted while dependents can still call the service",
                hint="move acquisitions above the `provide` block (linker rule A2). "
                     "A timer is an acquisition too: its schedule is armed at "
                     "activation and cancelled on teardown (docs/time-coeffect.md)"
                     if isinstance(stmt, TimerStmt) else
                     "move acquisitions above the `provide` block (linker rule A2)",
            )
        if isinstance(stmt, EffectStmt) and isinstance(stmt.acquire, SpawnExpr):
            # a spawn's inverse is the instance's own teardown, which needs a
            # handle to name — so a spawn must be bound (decision 2)
            raise RevlError(
                filename, stmt.line,
                "`spawn` must be bound to a handle: "
                f"`let s = effect spawn {stmt.acquire.component} … undo s.dispose()`",
            )
        if isinstance(stmt, LetEffect) and isinstance(stmt.acquire, LeaseAcquire):
            # item 294 Slice 2: a capability lease. The acquire is not a host
            # call but a class-(c)-gated, ticket-mediated mint of a standing grant
            # over the capability's cone (session._enforce_lease_gate raises the
            # ticket before boot; an ungated run refuses). It lowers to a reserved
            # runtime acquisition returning a lease handle, and the site `undo
            # l.revoke()` retires that grant on the LIFO teardown. Duration/uses
            # reuse the grant's expiresAt/remainingUses; nothing here mints — the
            # grant is minted from the approved ticket, never self-minted.
            body.append(_lower_lease_step(stmt, env, filename))
        elif isinstance(stmt, LetEffect) and getattr(stmt, "subscribe", False):
            # item 130: `let sub = subscribe <stream> undo sub.close()`. A
            # subscription is a single-consumer acquisition bracket; unloading
            # the owner runs `close`, so the stream is CLOSED before the owner
            # disappears (the core guarantee, G7 applied to a bracket whose handle
            # is a live listener). Lowers to a `let-effect` step carrying
            # `subscribe: true` so the emitters render the bracket verbatim and
            # wasm can refuse the whole shape (design §5).
            body.append(_lower_subscribe_step(stmt, env, filename))
        elif isinstance(stmt, LetEffect):
            if stmt.setup:
                saved_locals = dict(env.locals)
                saved_taken = set(env._taken)
                saved_type_env = dict(env.type_env)
                setup_steps: list[dict] = []
                scope = _component_scope(env)
                mutables: set[str] = set()
                for setup_stmt in stmt.setup:
                    _lower_component_setup_stmt(setup_stmt, env, scope, callables or set(),
                                                mutables, setup_steps)
                with _acquire_position(env, stmt.acquire):
                    acquire = _lower_component_pure_expr(stmt.acquire, env, scope,
                                                         callables or set())
                env.locals = saved_locals
                env._taken = saved_taken
                # setup-let types are block-scoped; drop them so a recycled safe
                # name (env._taken is restored above) can't read a stale type
                env.type_env = saved_type_env
            else:
                setup_steps = []
                with _acquire_position(env, stmt.acquire):
                    acquire = _lower_expr(stmt.acquire, env, mode="setup")
            safe = env.bind_local(stmt.bind, stmt.line)
            # host provenance: an effect-acquired HOST object (`Map.new()`)
            # keeps its verb surface verbatim, exempt from the stdlib table —
            # see Env.host_locals. Record the acquisition's family (`Map` from
            # `Map.new`) so later method calls are checked against that family's
            # verb surface (item 401).
            if acquire.get("kind") == "host":
                env.host_locals[safe] = str(acquire["fn"]).partition(".")[0]
            acquired_type = infer_ir(acquire, env.type_env, env.types, env.services)
            # item 397: a result-declared host verb (a Bool CAS like
            # `insert_if_absent`) types its bind from the frontier's result
            # column. `infer_ir` cannot see host-local provenance (it takes no
            # `host_locals`), so the type is resolved here where it is known.
            if acquired_type is None:
                acquired_type = _host_result_type(acquire, env)
            if acquired_type is not None:
                env.type_env[safe] = acquired_type
            step = _lower_effect_step(acquire, stmt.undo, env, filename, stmt.line,
                                      bind=safe, raw_acquire=stmt.acquire)
            if setup_steps:
                step["setup"] = setup_steps
            if getattr(stmt, "verified", False):
                step["verified"] = True
            _admit_effect_async(stmt, step, env, filename)
            # item 308: a `let x = effect <acquire> …` whose acquisition yields a
            # resource makes `x` the OWNED handle of this activation. O1 admits
            # this binding's own `undo` naming its own inverse on `x` (the
            # own-undo exemption); B1 clause 5 still refuses a BORROW smuggled
            # into that undo.
            _taint308, _ = _resource_ctx(env.types)
            _is_resource_308 = bool(resource_in(acquired_type, _taint308))
            if _is_resource_308:
                _owned_handles(env).add(safe)
            # item 308 (issue #96), S1: `let h = effect shared <acquire> …` marks
            # an N-holder handle. The acquiring frame is holder #1 — an OWNER of
            # its own handle for its own frame, so the O1 own-undo exemption and
            # the B1 owner carve-out below apply exactly as for `owned` (a shared
            # handle stored in the acquirer's OWN activation state tears down with
            # its frame). What differs is the RUNTIME: the declared inverse is
            # bound to the count's zero crossing (SharedGrantBook / liveness_confirm
            # .py), not fired per-frame; and a crash re-fires it once via `revl
            # recover`'s `shared-reclaim-fence` (recovery.py). The mode is carried
            # on the step so the emitters and the recover/audit surfaces see it.
            # A `shared` marker on a NON-resource acquire is meaningless (nothing
            # to count), so it is refused rather than silently recorded.
            if getattr(stmt, "mode", "owned") == "shared":
                if not _is_resource_308:
                    raise RevlError(
                        filename, stmt.line,
                        f"`effect shared` requires a resource handle, but "
                        f"`{stmt.bind}` binds a non-handle value (its acquire "
                        f"returns no nominal opaque handle to count holders of)",
                        hint="a shared handle is torn down when its last holder "
                             "releases; a value with no resource identity has no "
                             "teardown to share. Drop `shared`, or return an "
                             "opaque handle type from the acquire (item 308, R0/S1)",
                        code="G7", category="ownership")
                step["mode"] = "shared"
            if step.get("undo") is not None:
                _o1_check(step["undo"], env, filename, stmt.line,
                          position="undo", exempt_handle=safe)
                _b1_no_resource(step["undo"], env, filename, stmt.line,
                                clause="undo", borrows_only=True)
            _ownership_check_expr(step.get("acquire"), env, filename, stmt.line)
            _b1_witnessed_check(step.get("acquire"), env, filename, stmt.line)
            # item 130 (rule 3.6): a stream source whose inverse CLOSES it is a
            # terminal-delivering provider — the only shape a subscription may be
            # admitted against. `Stream.source() undo s.close()` records `s`; a
            # source acquired with a non-closing inverse (or none) is NOT recorded,
            # so a later `subscribe s` is refused (§9 Part B, the no-silent-vanish
            # rule the core guarantee rests on).
            if acquire.get("kind") == "host" and acquire.get("fn") == "Stream.source":
                u = step.get("undo") or {}
                ut = u.get("target") if isinstance(u, dict) else None
                if isinstance(u, dict) and u.get("kind") == "call" \
                        and u.get("method") == "close" and isinstance(ut, dict) \
                        and ut.get("kind") == "name" and ut.get("id") == safe:
                    env.terminal_stream_sources.add(safe)
            # item 130 §4.5: the provider's own replay declaration. Threaded onto
            # the step only when DECLARED, so a replay-free program's IR is
            # byte-identical, and recorded on `env` so a `subscribe` on this
            # source can be admitted against it (`_admit_replay`).
            if getattr(stmt, "replay", None) is not None:
                decl = _lower_replay_decl(stmt.replay, acquire, env, filename,
                                          stmt.line)
                step["replay"] = decl
                acquire["replay"] = decl
                env.replay_sources[safe] = decl
            body.append(step)
        elif isinstance(stmt, EffectStmt):
            if stmt.setup:
                saved_locals = dict(env.locals)
                saved_taken = set(env._taken)
                saved_type_env = dict(env.type_env)
                setup_steps = []
                scope = _component_scope(env)
                mutables = set()
                for setup_stmt in stmt.setup:
                    _lower_component_setup_stmt(setup_stmt, env, scope, callables or set(),
                                                mutables, setup_steps)
                with _acquire_position(env, stmt.acquire):
                    acquire = _lower_component_pure_expr(stmt.acquire, env, scope,
                                                         callables or set())
                env.locals = saved_locals
                env._taken = saved_taken
                env.type_env = saved_type_env
            else:
                setup_steps = []
                with _acquire_position(env, stmt.acquire):
                    acquire = _lower_expr(stmt.acquire, env, mode="setup")
            step = _lower_effect_step(acquire, stmt.undo, env, filename, stmt.line,
                                      bind=None, raw_acquire=stmt.acquire)
            if setup_steps:
                step["setup"] = setup_steps
            if getattr(stmt, "verified", False):
                step["verified"] = True
            _admit_effect_async(stmt, step, env, filename)
            # item 308: an unbound effect creates no owned handle, so its `undo`
            # gets no own-undo exemption (O1) and may carry no resource (B1).
            if step.get("undo") is not None:
                _o1_check(step["undo"], env, filename, stmt.line, position="undo")
                _b1_no_resource(step["undo"], env, filename, stmt.line,
                                clause="undo", borrows_only=True)
            _ownership_check_expr(step.get("acquire"), env, filename, stmt.line)
            _b1_witnessed_check(step.get("acquire"), env, filename, stmt.line)
            body.append(step)
        elif isinstance(stmt, FailStmt):
            body.append({
                "step": "fail",
                "message": _lower_component_pure_expr(
                    stmt.message, env, _component_scope(env), callables or set(),
                    pure_only=True,
                ),
            })
        elif isinstance(stmt, IfStmt):
            body.append(_lower_component_if(stmt, env, callables or set()))
        elif isinstance(stmt, LetApprovalStmt):
            body.append(_lower_let_approval(stmt, env))
        elif isinstance(stmt, EmitStmt):
            emit_step = _lower_emit_step(stmt, env)
            _admit_emit_async(stmt, emit_step, env, filename)
            body.append(emit_step)
        elif isinstance(stmt, TimerStmt):
            body.append(_lower_timer_step(stmt, env))
        elif isinstance(stmt, StreamIterStmt):
            # item 130 Slice 4: `every <x> in <sub> { … }` — the async-iteration
            # form. Not an acquisition: the bracket it rides was registered by
            # the `subscribe` above it, and the loop only pulls that handle to
            # its terminal.
            if stmt.subject is None:
                # ... unless the `in <sub>` clause was dropped (§6b): an
                # `on <Event> as <x> { … }` handler resolves its source from the
                # component's `requires <k>: Stream[<Event>]` coeffect and
                # registers the bracket itself, so the pair of steps is exactly
                # what the explicit form spells by hand.
                body.extend(_lower_required_stream_handler(
                    stmt, env, filename, callables or set()))
            else:
                body.append(_lower_stream_iter_step(stmt, env, filename,
                                                    callables or set()))
        elif isinstance(stmt, AwaitStmt):
            body.append({"step": "await", "expr": _lower_expr(stmt.expr, env, mode="setup")})
        elif isinstance(stmt, ProvideStmt):
            if stmt.key in routes:
                # item 449: a `routes`-carrying component is realized as a
                # routing proxy at load (`run.py` `_install_router`), never
                # plugged as a fiber — the `_Router` proxy is the one provider
                # of the routed key downstream (G2). A hand-written `provide`
                # body for that SAME key used to compile, admit, and pass G4,
                # then be SILENTLY DISCARDED at load (`audit.seen() == 0`): the
                # author's body never ran and nothing said so. Refuse it by name
                # here rather than drop it at runtime — the header `provides
                # <key>: <Service>` clause is what the route needs, not a body.
                raise RevlError(
                    filename, stmt.line,
                    f"`provide {stmt.key}` in {comp.name} is silently discarded: "
                    f"the component routes `{stmt.key}` across `realms(...)`, so "
                    f"it is realized as a routing proxy and never plugged as a "
                    f"fiber — the provide body would never run (G2)",
                    hint=f"a `realms(...)` route already provides `{stmt.key}` "
                         f"downstream through the router proxy (item 162); the "
                         f"`provides {stmt.key}: <Service>` header clause is "
                         f"enough. Drop the `provide {stmt.key} {{ … }}` body, or "
                         f"route a distinct inner key and provide this one from a "
                         f"separate component (docs/router.md)",
                )
            provide_seen_line = stmt.line
            body.append(_lower_provide(stmt, provides, provided_keys, env))
        else:  # pragma: no cover — grammar prevents it
            raise RevlError(filename, stmt.line, "unexpected statement in component body")
        return provide_seen_line

    # an activation body is the one place `let x = effect { …setup…; acq }` is
    # legal, so it is the one place the `setup` statements can carry an index
    # this pass has to bound (item 485)
    check_list_index_bounds(comp.body, filename)
    for stmt in comp.body:
        if isinstance(stmt, HandoffStmt):
            # `handoff <key>: <Type>` (roadmap item 53): the verified state
            # hand-off of a stateful provider. A prelude declaration — it names
            # what this provider's live state *is*, before any effect creates
            # it — and targets a key this component provides (its own state
            # crosses to whoever re-provides that key). At most one per
            # component: a component's activation frame holds one resource
            # vector, so one declared shape describes it without ambiguity.
            if action_seen:
                raise RevlError(
                    filename, stmt.line,
                    "`handoff` must precede every effect, emit, await, and provide statement",
                    hint="a hand-off declares the provider's state shape before any "
                         "effect creates it (prelude rule, docs/state-handoff.md)",
                )
            if stmt.key not in provides:
                raise RevlError(
                    filename, stmt.line,
                    f"`{stmt.key}` is not a declared provision of {comp.name}",
                    hint="`handoff` targets a key this component provides — it is the "
                         "state a successor re-providing that key inherits (item 53)",
                )
            if handoff is not None:
                raise RevlError(
                    filename, stmt.line,
                    f"{comp.name} declares more than one `handoff` — a component has one "
                    f"activation frame, so it hands off one state shape",
                    hint="thread every piece of live state through the one hand-off type "
                         "(a record or Map), docs/state-handoff.md",
                )
            # item 246, invariant 5 (non-persistence): a hand-off crosses the
            # session boundary, so an `Approval[C]` may not be its shape. The
            # general type well-formedness rule refuses it (with `Async` etc.).
            check_type_wellformed(filename, stmt.line, stmt.state_type)
            # item 308, B1 clause 7: a resource-tainted handoff type re-seats the
            # predecessor's live handle vector on the successor while the
            # predecessor's teardown closes it — the successor starts warm with a
            # dead descriptor. Refuse it at admission from the shared taint set.
            _taint308, _ = _resource_ctx(env.types)
            _ho_res = resource_in(stmt.state_type, _taint308)
            if _ho_res:
                raise RevlError(
                    filename, stmt.line,
                    _b1_message("handoff", "owned", _ho_res),
                    hint=_b1_hint("handoff"), code="G7", category="ownership")
            handoff = {"key": stmt.key, "type": stmt.state_type}
            continue
        if isinstance(stmt, RouteStmt):
            # multi-realm bind (item 162): `isolate <key> in realms(...) [strategy(...)]`.
            # A prelude declaration, exactly like `isolate`/`intercept` — it derives
            # the resolution context (the router's realm set) before any dependency
            # access, so it must precede every action.
            if action_seen:
                raise RevlError(
                    filename, stmt.line,
                    "`isolate ... in realms(...)` must precede every effect, emit, await, "
                    "and provide statement",
                    hint="realm bindings derive the resolution context before any dependency "
                         "access (prelude rule, docs/design-v2-realms.md)",
                )
            required_keys = set(env.require_keys.values())
            # routing distributes a *consumer's* dependency across N backend
            # realms — it targets a REQUIRED key. A provision has one installed
            # instance in one realm (G2), so routing a provision is meaningless.
            if stmt.key not in required_keys:
                if stmt.key in provides:
                    raise RevlError(
                        filename, stmt.line,
                        f"`isolate ... in realms(...)` routes a *required* key — `{stmt.key}` "
                        f"is a provision of {comp.name}",
                        hint="a multi-realm bind distributes a consumer's dependency across "
                             "backend realms (item 162); a provision has one installed "
                             "instance in one realm (G2). Route the key you require, not the "
                             "one you provide",
                    )
                raise RevlError(
                    filename, stmt.line,
                    f"`{stmt.key}` is not a declared requirement of {comp.name}",
                    hint="`isolate ... in realms(...)` targets a key from the `requires` "
                         "clause (G1)",
                )
            # one binding per key: a key is pinned to one realm *or* routed across
            # a realm set, never both, and never two conflicting route sets.
            if stmt.key in isolate:
                raise RevlError(
                    filename, stmt.line,
                    f"key `{stmt.key}` is already isolated to a single realm in {comp.name} — "
                    f"it cannot also be routed across `realms(...)`",
                    hint="use either `isolate <key> in realm(<name>)` (pin) or "
                         "`isolate <key> in realms(...)` (route), not both",
                )
            if stmt.key in routes:
                raise RevlError(
                    filename, stmt.line,
                    f"key `{stmt.key}` is routed twice in {comp.name}",
                )
            if stmt.strategy is not None and stmt.strategy not in KNOWN_STRATEGIES:
                known = ", ".join(sorted(KNOWN_STRATEGIES))
                raise RevlError(
                    filename, stmt.line,
                    f"unknown routing strategy `{stmt.strategy}` for `{stmt.key}` in "
                    f"{comp.name}",
                    hint=f"a strategy is validated at compile time so a typo is not a silent "
                         f"runtime fallback; known strategies are: {known} (or omit "
                         f"`strategy(...)` for the router's default)",
                )
            routes[stmt.key] = {"realms": list(stmt.realms), "strategy": stmt.strategy}
            continue
        if isinstance(stmt, (IsolateStmt, InterceptStmt)):
            # prelude rule: realm/metadata declarations derive the resolution
            # context (Def. 27/29) and must precede every dependency access
            if action_seen:
                kw = "isolate" if isinstance(stmt, IsolateStmt) else "intercept"
                raise RevlError(
                    filename, stmt.line,
                    f"`{kw}` must precede every effect, emit, await, and provide statement",
                    hint="realm and metadata declarations derive the resolution context "
                         "before any dependency access (prelude rule, docs/design-v2-realms.md)",
                )
            # isolate/intercept name a key by its *qualified* wiring identity,
            # the same string G2 and the linker compare (docs/namespacing.md)
            required_keys = set(env.require_keys.values())
            if isinstance(stmt, IsolateStmt):
                if stmt.key not in required_keys and stmt.key not in provides:
                    raise RevlError(
                        filename, stmt.line,
                        f"`{stmt.key}` is not a declared requirement or provision of {comp.name}",
                        hint="`isolate` targets a key from the component header (G1)",
                    )
                if stmt.key in isolate:
                    raise RevlError(filename, stmt.line,
                                    f"key `{stmt.key}` is isolated twice in {comp.name}")
                isolate[stmt.key] = stmt.realm
            else:
                if stmt.key in provides and stmt.key not in required_keys:
                    raise RevlError(
                        filename, stmt.line,
                        f"`intercept` applies to required keys only — `{stmt.key}` is a provision",
                        hint="interception is the component-declared metadata d(k) of Def. 30, "
                             "whose domain is the dependency set; providers receive metadata "
                             "from their consumers' declarations",
                    )
                if stmt.key not in required_keys:
                    raise RevlError(
                        filename, stmt.line,
                        f"`{stmt.key}` is not a declared requirement of {comp.name}",
                        hint="`intercept` targets a key from the `requires` clause (G1)",
                    )
                if stmt.key in intercept:
                    raise RevlError(filename, stmt.line,
                                    f"key `{stmt.key}` is intercepted twice in {comp.name}")
                intercept[stmt.key] = stmt.metadata
            continue
        action_seen = True
        try:
            provide_seen_line = _dispatch_action(stmt, provide_seen_line)
        except RevlError as stmt_error:
            # item 386, Stage 2: statement-boundary synchronization. This
            # statement's type-check (or a per-statement structural rule) refused.
            # With a collect-all sink, record that ONE diagnostic and resume at
            # the NEXT statement, so several independent bad statements in one
            # component are all reported in a single pass. A binding form still
            # binds its name — to POISON — so the later statements that USE it read
            # a silent wildcard instead of fabricating a second mismatch at every
            # use (the sentinel is emitted where poison is BORN, here, never where
            # it propagates). With no sink (a direct/legacy caller, or a nested
            # lowering re-entering the spine) the refusal propagates to the
            # component boundary, byte-identical to Stage 1.
            if errors is None:
                raise
            errors.append(stmt_error)
            _poison_failed_binding(stmt, env)
            recovered = True
            continue

    lowered = {
        "name": comp.name,
        "source": comp.source or filename,
        "config": [_ir_config_field(f) for f in comp.config],
        # the IR carries the *qualified* wiring key (G2 / injection identity),
        # not the code-facing binding; for unqualified keys the two coincide,
        # so v1 documents stay byte-identical (docs/namespacing.md)
        "requires": {env.require_keys[binding]: svc for binding, svc in env.requires.items()},
        "provides": provides,
        "body": body,
    }
    # item 296 §6.3: the alias token carry-over binding, additive and
    # conditionally present — only a component with a `carrying(...)` require
    # carries a `carry` key, so every ordinary component's IR (and thus its
    # digest) is byte-identical to before. Keyed by the QUALIFIED require key to
    # match `requires`, so an IR-level fold that never saw the checker env (the
    # approval `ClassMap`) can resolve an `emit alias.method` crossing to the
    # consumer-facing tokens the checker's emission attribution already uses, and
    # so the adapter is not a fold-blind eleventh boundary.
    if env.require_carry:
        lowered["carry"] = {
            env.require_keys[binding]: list(tokens)
            for binding, tokens in env.require_carry.items()
        }
    # item 130 §4.5/§6c: the replay declarations the component's stream
    # REQUIREMENTS carry — the durability contract the wiring must satisfy for
    # each key. Additive and conditionally present, keyed by the QUALIFIED
    # require key to match `requires`, so a component with no declaring stream
    # requirement is byte-identical. It is the one place a consumer of the IR can
    # read what a required stream is obliged to hold without re-deriving it from
    # the `subscribe` steps, which state only what the body ASKED for.
    if env.stream_replay:
        lowered["stream_replay"] = {
            env.require_keys[binding]: decl
            for binding, decl in env.stream_replay.items()
        }
    # item 350: the boot marking, additive and conditionally present — an
    # ordinary component carries no `boot` key, so a composition that declares
    # no boot component is byte-identical through the IR and every emitter.
    if getattr(comp, "boot", False):
        lowered["boot"] = True
    # item 477 (follow-up 1): the DECLARED liveness ceiling, additive and
    # conditionally present. It is refused by an admission G-rule when declared on
    # an activation that CANNOT hang — one whose body reaches no emission and no
    # host-call, so it completes without any crossing that can stall and has
    # nothing to be silent about. A ceiling there is a category error (like a
    # `ttl` on `cache pure`), worth refusing rather than lowering to metadata no
    # runtime could ever act on. A clean, hangable activation lowers the ceiling
    # to `liveness_ceiling_ms`; a component that declares no ceiling carries no
    # key, so its IR and every emitted tier stay byte-identical
    # (docs/design/477-liveness-expiry.md, Follow-up 1).
    _liveness_ms = getattr(comp, "liveness_ms", None)
    if _liveness_ms is not None:
        if not _activation_can_hang(body):
            raise RevlError(
                comp.source or filename, comp.line,
                f"component `{comp.name}` declares a `liveness` ceiling but its "
                f"activation cannot hang — it reaches no emission and no "
                f"host-call, so it has nothing to be silent about",
                hint="a liveness ceiling bounds the silence of a provider stuck "
                     "mid-activation on a host-call or emission; an activation "
                     "that only registers `provide` blocks and binds pure values "
                     "never stalls, so a ceiling on it can never fire — drop the "
                     "`liveness` clause (docs/design/477-liveness-expiry.md)",
                category="liveness")
        lowered["liveness_ceiling_ms"] = _liveness_ms
    # v2 fields appear only when used, so v1 documents stay byte-identical
    if isolate:
        lowered["isolate"] = isolate
    if intercept:
        lowered["intercept"] = intercept
    # multi-realm bind (item 162), additive — a component with no `realms(...)`
    # route carries no `routes` key, so its IR is byte-identical to before.
    if routes:
        lowered["routes"] = routes
    # item 53: the state hand-off contract, additive — a stateless component
    # (the overwhelming majority) carries no `handoff` key, so its IR is
    # byte-identical to before. `ir_version` stays 3.
    if handoff is not None:
        lowered["handoff"] = handoff
    # item 386, Stage 2: a component that recovered past a refused statement has
    # a partial, untrustworthy body. Mark it `poisoned` — exactly like a Stage-1
    # header-abort stub — so the body-walking post-passes (taint, spawn
    # bounds/attenuation, holes) skip it while `_link` still sees its complete
    # header topology (provides/requires) and reports real G2/G3 on its keys.
    # The compile is already failing (its refusals are in `errors`), so this
    # partial IR is never emitted; the raise in `check_and_lower` precedes IR
    # assembly. A clean component never sets `recovered`, so its IR is
    # byte-identical to before.
    if recovered:
        lowered["poisoned"] = True
    return lowered


def _lower_provide(stmt: ProvideStmt, provides: dict[str, str], provided_keys: set[str], env: Env) -> dict:
    filename = env.filename
    comp = env.component
    if stmt.key not in provides:
        declared = ", ".join(f"`{k}`" for k in provides) or "none"
        raise RevlError(
            filename, stmt.line,
            f"`{stmt.key}` is not declared in the `provides` clause of {comp.name} (A9)",
            hint=f"rename the provide block to a declared key (declared: {declared}), "
                 f"or add `{stmt.key}: <Service>` to the `provides` clause of {comp.name}",
        )
    if stmt.key in provided_keys:
        raise RevlError(filename, stmt.line, f"provision `{stmt.key}` is installed twice in {comp.name}")
    provided_keys.add(stmt.key)

    svc = env.services[provides[stmt.key]]
    methods = []
    implemented = set()
    for method in stmt.methods:
        decl = svc.methods.get(method.name)
        if decl is None:
            raise RevlError(filename, method.line,
                            f"`{method.name}` is not a method of service {svc.name}")
        if len(method.params) != len(decl.params):
            raise RevlError(
                filename, method.line,
                f"method `{method.name}` of provision `{stmt.key}` takes {len(method.params)} "
                f"params but service {svc.name} declares {len(decl.params)}",
            )
        if method.async_ != decl.async_:
            raise RevlError(
                filename, method.line,
                f"method `{method.name}` of provision `{stmt.key}` is "
                f"{'async' if method.async_ else 'not async'} but service {svc.name} "
                f"declares it {'async' if decl.async_ else 'not async'}",
            )
        if method.name in implemented:
            raise RevlError(filename, method.line, f"duplicate method `{method.name}` in provision `{stmt.key}`")
        implemented.add(method.name)

        # optional param annotations (syntax-2.0: models write `fn query(sql:
        # Str)` on autopilot): well-formed and checked against the service's
        # declared type (A6 — the service is the source of truth).
        for surface, annotation, (_, svc_ptype) in zip(
            method.params, method.param_types or [None] * len(method.params), decl.params
        ):
            if annotation is None:
                continue
            # item 442: a provide method may re-spell a `Delegate[S]` parameter
            # (it mirrors the service signature, which `compatible` re-checks
            # below), so the delegate position is admitted here as well.
            check_type_wellformed(filename, method.line, annotation,
                                  allow_delegate_param=True)
            if svc_ptype and not (compatible(svc_ptype, annotation, env.types)
                                  and compatible(annotation, svc_ptype, env.types)):
                raise mismatch(
                    filename, method.line,
                    f"parameter `{surface}` of `{method.name}` (from service `{svc.name}`)",
                    svc_ptype, annotation)
        # optional `-> T` return annotation, checked against the service
        if method.returns is not None:
            check_type_wellformed(filename, method.line, method.returns)
            if decl.returns and not (compatible(decl.returns, method.returns, env.types)
                                     and compatible(method.returns, decl.returns, env.types)):
                raise mismatch(
                    filename, method.line,
                    f"return type of `{method.name}` (from service `{svc.name}`)",
                    decl.returns, method.returns)

        saved = env.params
        # item 470: the intent THIS operation declares, in scope for the whole
        # body and restored after it, so an `emit` reached while lowering the
        # body knows which declaration it must refine. Set only for an operation
        # that writes a `within { … }` clause (`None` for every operation in the
        # tree today), so the check below is inert unless a program opts in.
        saved_intent = env.declared_intent
        saved_stated = env.stated_crossings
        env.stated_crossings = []
        env.declared_intent = (
            (decl.within, svc.name, method.name)
            if getattr(decl, "within", None) is not None else None
        )
        # Per-method provenance: a method's own alias / arrow bindings must not
        # leak into the next method, whose safe names may recycle theirs.
        saved_provisions = dict(env.provision_locals)
        saved_arrows = dict(env.local_arrows)
        saved_values = dict(env.provision_values)
        env.params = env.bind_params(method.params, method.line)
        # method params carry the service's declared types (A6): surface
        # names bind the body, the service contributes the signature
        saved_tenv = dict(env.type_env)
        method_locals: dict[str, str] = {}
        for surface, (_, ptype) in zip(method.params, decl.params):
            env.type_env[env.params[surface]] = ptype

        # L1 (roadmap item 441 / issue #120,
        # docs/design/458-termination-language-surface.md §3): a termination
        # criterion/guard body may only READ the world. Walk the method's AST
        # body BEFORE it is lowered, so the criterion-naming refusal OWNS every
        # boundary-reaching shape the shared G5 walker resolves — including an
        # `emission` service operation off a required binding, which the forward
        # lowering's emit-marking rule would otherwise refuse first with a generic
        # message — and so a WITNESSED extern (which an ordinary provide body is
        # allowed to reach, item 318) is caught too. A first-class arrow bound in
        # the body is followed through a local pre-scan into `env.local_arrows`,
        # the same channel the forward lowering fills for the teardown walk; a
        # spawn-handle emission, needing provision provenance the forward pass
        # builds, is left to that pass (still refused, one message over). Set only
        # for a marked operation, so this is inert for every ordinary provide
        # method (L6).
        if getattr(decl, "termination", None):
            body_arrows = dict(env.local_arrows)
            for _ms in method.body:
                if isinstance(_ms, LetStmt) and isinstance(_ms.value, ExprArrow):
                    body_arrows[_ms.name] = _ms.value
            saved_body_arrows = env.local_arrows
            env.local_arrows = body_arrows
            try:
                _check_criterion_readonly(
                    method.body, decl.termination, method.name, svc.name,
                    env, comp.source or filename, method.line)
            finally:
                env.local_arrows = saved_body_arrows

        def _check_rebind(name: str, line: int) -> None:
            """A method-body binding may not collide with anything already in
            scope — params, earlier method locals, OR a component-scope name.

            The component-scope arm is the load-bearing one. `Env.bind_local`
            refuses a duplicate activation-body binding outright ("name `x` is
            already bound in C"), but this stratum consulted only `env.params`
            and `method_locals`, so a method-local `let` could reuse an
            activation-body name. That is not a scoping nicety: the method body
            lowers into a closure over the activation frame, and the safe-name
            allocator below draws from `env.params`/`method_locals` only, so the
            shadowing binding is emitted with the SAME host-safe name as the
            component local. Every tier then reads the wrong value — a Str where
            a host Map handle was expected, so the component local's declared
            inverse runs against the shadow (or, when the shadowing `let` sits
            after the use, the local is not bound at all) and the acquisition it
            was supposed to release leaks. Refusing the collision here gives the
            two strata one rule and the same diagnostic."""
            if name in env.params or name in method_locals or name in env.locals:
                raise RevlError(filename, line,
                                f"`{name}` is already bound in `{method.name}`")
        mbody = []
        returned = False

        def _sweep(node, line):
            # item 404: the provide-method twin of the activation-setup
            # `_sweep` (`_lower_component_setup_stmt`). A provide-method body is
            # stratum-3 lowered code that ran `infer_ir` only in its NON-raising
            # oracle mode, so a definite operator / index / builtin misuse that a
            # `fn`/`test` body (stratum 1, `infer_ast`) refuses compiled clean
            # inside a provide method — the same context-scoping gap item 392
            # closed for the Any-field-read. Run the SAME raising oracle over the
            # lowered pure value here so the whole refusal class fires uniformly.
            # Unknown / host operands infer to None and are left alone, exactly
            # as in the setup sweep. Returns the inferred type (or None).
            return infer_ir(node, env.type_env, env.types, env.services,
                            filename, line)

        # --- issue #548: control flow in a provide-method body --------------
        # `if`/`while`/`for` STATEMENTS whose arms compute VALUES (the review's
        # top two walls). The shape reuses the exact `if`/`while`/`for` IR the fn
        # grammar emits (`_lower_pure_stmt`), so every tier's fn-body renderer is
        # the reference for the method-body one. Two facts keep it bounded:
        #
        #   * the arms are PURE. A teardown-registering step (`effect`/`emit`/
        #     `let-effect`/`await`/timer/approval) inside a branch is refused
        #     (`_lower_control_stmt`), so the half-emitting-conditional and
        #     loop-teardown questions (design note §Group 3) stay out of scope —
        #     the activation frame still owns every inverse, registered at the
        #     method's top level exactly as before.
        #   * VISIBILITY is block-scoped (a branch's `let` does not leak past it,
        #     and disjoint sibling branches may reuse a source name) while the
        #     EMITTED safe name stays unique for the whole method (`used_safe`),
        #     so python's function-scope aliasing cannot make two branches share
        #     a slot.
        used_safe: set[str] = set()
        # item 458 / issue #721: how many `while`/`for` bodies enclose the
        # statement being lowered. A bare `emit` is admitted inside an `if`/
        # `else` arm (below) but not inside a loop, because item 379's
        # frame-neutrality invariant is enforced whole-IR
        # (`_validate_no_loop_scoped_registration`) and per-tier
        # (`_guard_frame_neutral_loop` in all six emitters) over the `emit` STEP
        # kind regardless of whether it carries a compensation. Refusing here
        # gives that case the accurate message instead of the whole-IR one.
        loop_depth = [0]

        def _alloc_safe(name: str) -> str:
            safe = _safe_name(
                name,
                set(env.params.values()) | set(method_locals.values())
                | set(env.locals.values()) | used_safe)
            used_safe.add(safe)
            return safe

        def _do_let(ms, out) -> None:
            _check_rebind(ms.name, ms.line)
            safe = _alloc_safe(ms.name)
            value = _lower_expr(ms.value, env, mode="setup")
            # item 470 stage 0: a binding that states its crossing with a
            # trailing `acting { … }` is checked here, at the crossing, exactly
            # as an `emit` step is. Inert for every binding that writes no
            # clause, which is every binding in the tree.
            _check_let_intent_refinement(ms, value, env)
            swept = _sweep(value, ms.line)
            method_locals[ms.name] = safe
            env.params[ms.name] = safe
            _note_provision_alias(safe, value, env)
            env.provision_values[ms.name] = ms.value
            if isinstance(ms.value, ExprArrow):
                env.local_arrows[ms.name] = ms.value
            if ms.type is not None:
                check_type_wellformed(filename, ms.line, ms.type)
                env.type_env[safe] = ms.type
                _pin_empty_literal(ms.type, value)
            elif swept is not None:
                env.type_env[safe] = swept
            out.append({"step": "let", "name": safe, "value": value,
                        "mutable": bool(ms.mutable)})

        def _do_assign(ms, out) -> None:
            if ms.name not in method_locals:
                _reject_foreign_name(ms.name, filename, ms.line)  # item 384
                raise RevlError(filename, ms.line,
                                f"`{ms.name}` is not declared in `{method.name}`",
                                hint="declare it with `let` (single-assignment) or "
                                     "`var` (mutable)")
            assigned = _lower_expr(ms.value, env, mode="setup")
            _sweep(assigned, ms.line)  # item 404
            out.append({"step": "assign", "name": method_locals[ms.name],
                        "value": assigned})

        def _do_return(ms, out) -> None:
            if ms.expr is None:
                if decl.returns:
                    raise RevlError(
                        filename, ms.line,
                        f"`{method.name}` returns `{decl.returns}` but this "
                        "`return` carries no value")
                out.append({"step": "return", "expr": None})
                return
            pin_hole(ms.expr, decl.returns, filename, f"`{method.name}` returns")
            lowered_return = _lower_expr(ms.expr, env, mode="setup")
            _taint308, _ = _resource_ctx(env.types)
            _ret_res = (resource_in(decl.returns, _taint308)
                        or _node_resource(lowered_return, env, _taint308))
            if _ret_res and not _b1_return_admitted(lowered_return, env, _taint308):
                raise RevlError(
                    filename, ms.line,
                    _b1_message("return", "borrowed", _ret_res),
                    hint=_b1_hint("return"), code="G7", category="ownership",
                    navigate=_b1_navigate(env, "return", "borrowed", _ret_res))
            actual = _sweep(lowered_return, ms.line)
            if decl.returns:
                check_ir(lowered_return, decl.returns, env.type_env,
                         env.types, env.services, filename, ms.line,
                         f"`{method.name}` returns")
                lowered_return = _inject_opt(decl.returns, actual, lowered_return)
            out.append({"step": "return", "expr": lowered_return})

        def _lower_scoped_block(stmts, out) -> None:
            """Lower a control-flow arm/body: bindings are visible only within
            it (visibility snapshot/restore), while `used_safe` keeps emitted
            names unique method-wide."""
            saved_params = env.params
            saved_tenv = env.type_env
            saved_locals = dict(method_locals)
            env.params = dict(saved_params)
            env.type_env = dict(saved_tenv)
            try:
                inner_returned = False
                for s in stmts:
                    if inner_returned:
                        raise RevlError(filename, s.line,
                                        "unreachable statement after `return`")
                    _lower_control_stmt(s, out)
                    if isinstance(s, ReturnStmt):
                        inner_returned = True
            finally:
                env.params = saved_params
                env.type_env = saved_tenv
                method_locals.clear()
                method_locals.update(saved_locals)

        def _lower_control_stmt(ms, out) -> None:
            if isinstance(ms, LetStmt):
                _do_let(ms, out)
            elif isinstance(ms, AssignStmt):
                _do_assign(ms, out)
            elif isinstance(ms, ReturnStmt):
                _do_return(ms, out)
            elif isinstance(ms, IfStmt):
                cond = _lower_expr(ms.cond, env, mode="setup")
                cond_t = _sweep(cond, ms.line)
                if cond_t is not None and cond_t != "Bool":
                    raise mismatch(filename, ms.line, "`if` condition", "Bool", cond_t)
                then_body: list = []
                _lower_scoped_block(ms.then, then_body)
                else_body = None
                if ms.otherwise is not None:
                    else_body = []
                    _lower_scoped_block(ms.otherwise, else_body)
                out.append({"step": "if", "cond": cond,
                            "then": then_body, "else": else_body})
            elif isinstance(ms, WhileStmt):
                cond = _lower_expr(ms.cond, env, mode="setup")
                cond_t = _sweep(cond, ms.line)
                if cond_t is not None and cond_t != "Bool":
                    raise mismatch(filename, ms.line, "`while` condition", "Bool", cond_t)
                loop_body: list = []
                loop_depth[0] += 1
                try:
                    _lower_scoped_block(ms.body, loop_body)
                finally:
                    loop_depth[0] -= 1
                out.append({"step": "while", "cond": cond, "body": loop_body})
            elif isinstance(ms, ForStmt):
                iter_node = _lower_expr(ms.iterable, env, mode="setup")
                iter_t = _sweep(iter_node, ms.line)
                if iter_t is not None and parse_type(iter_t)[0] != "List":
                    raise RevlError(
                        filename, ms.line,
                        f"`for ... of` iterates a `List[...]`, got "
                        f"`{render_type(iter_t)}`")
                _check_rebind(ms.bind, ms.line)
                saved_params = env.params
                saved_tenv = env.type_env
                saved_locals = dict(method_locals)
                env.params = dict(saved_params)
                env.type_env = dict(saved_tenv)
                loop_depth[0] += 1
                try:
                    safe = _alloc_safe(ms.bind)
                    method_locals[ms.bind] = safe
                    env.params[ms.bind] = safe
                    elem = _type_arg(iter_t, "List") if iter_t is not None else None
                    if elem is not None:
                        env.type_env[safe] = elem
                    loop_body = []
                    inner_returned = False
                    for s in ms.body:
                        if inner_returned:
                            raise RevlError(filename, s.line,
                                            "unreachable statement after `return`")
                        _lower_control_stmt(s, loop_body)
                        if isinstance(s, ReturnStmt):
                            inner_returned = True
                finally:
                    loop_depth[0] -= 1
                    env.params = saved_params
                    env.type_env = saved_tenv
                    method_locals.clear()
                    method_locals.update(saved_locals)
                out.append({"step": "for", "bind": safe,
                            "iterable": iter_node, "body": loop_body})
            elif isinstance(ms, BreakStmt):
                out.append({"step": "break", "line": ms.line})
            elif isinstance(ms, ContinueStmt):
                out.append({"step": "continue", "line": ms.line})
            elif isinstance(ms, EmitStmt):
                # item 458 / issue #721: a BARE `emit` (no `compensate`) is an
                # irreversible CROSSING, not a teardown registration — it fires
                # the emission and puts nothing on the activation frame's
                # teardown accumulator (`_lower_emit_step`: the accumulator entry
                # is the `compensate` slot, and only that slot). The same
                # crossing in VALUE position — `let v = emit …`, `x = emit …`,
                # `return emit …` — has always been admitted inside a
                # provide-method `if` arm and lowers on all six tiers, so
                # refusing only the STATEMENT spelling taxed authors who do not
                # want the value: they either bound a value they never read or
                # hoisted the crossing into a module `fn` taking an emitting
                # arrow (the harness's `maybe_run`/`maybe_ship` shape). Admit it
                # through the SAME `_lower_emit_step` the method's top level
                # uses, so one IR step reaches every tier's method renderer.
                #
                # Two cases stay refused, because both really do register:
                #   * `emit … compensate …` — the compensation is a first-class
                #     entry on the activation frame (item 247), so a conditional
                #     one is the deferred teardown-contract question;
                #   * any `emit` inside a `while`/`for` body — item 379's
                #     frame-neutrality invariant is enforced over the `emit` STEP
                #     kind whole-IR and in all six emitters, so admitting it here
                #     would only move the refusal.
                if loop_depth[0] > 0:
                    raise RevlError(
                        filename, ms.line,
                        "an `emit` step may not appear inside a provide-method "
                        "`while`/`for` body",
                        hint="`break`/`continue` are frame-neutral only because "
                             "loops and teardown registration never meet "
                             "(docs/design/379-break-continue.md); lift the "
                             "crossing out of the loop, or compute the value in "
                             "the loop and emit once after it")
                if ms.compensate is not None:
                    raise RevlError(
                        filename, ms.line,
                        "an `emit ... compensate ...` step is not allowed inside "
                        "a provide-method `if`/`while`/`for` body",
                        hint="a compensation is registered on the activation "
                             "frame and drained in teardown Phase 2 (item 247), "
                             "so a CONDITIONAL one needs the teardown contract "
                             "amended (docs/design/478-component-author-"
                             "ergonomics.md §Group 3). A bare `emit` — the "
                             "crossing alone — is allowed here")
                out.append(_lower_emit_step(ms, env))
            elif isinstance(ms, (LetEffect, EffectStmt, AwaitStmt,
                                 LetApprovalStmt, TimerStmt)):
                raise RevlError(
                    filename, ms.line,
                    "a teardown-registering step (`effect`/`let-effect`/"
                    "`await`) is not allowed inside a provide-method `if`/`while`/"
                    "`for` body",
                    hint="the activation frame owns every inverse and registers "
                         "it at the method's top level; a conditional or looped "
                         "acquisition would need the teardown contract amended "
                         "(issue #548, docs/design/478-component-author-"
                         "ergonomics.md §Group 3). Keep the effect at the "
                         "method's top level and let the control flow compute "
                         "values and bare `emit` crossings")
            else:  # pragma: no cover — the parser admits nothing else here
                raise RevlError(filename, getattr(ms, "line", method.line),
                                "unexpected statement in method control-flow body")

        for mstmt in method.body:
            if returned:
                raise RevlError(filename, mstmt.line, "unreachable statement after `return`")
            if getattr(mstmt, "verified", False):
                # `verified effect` is inverse round-trip tested by activating
                # the component and tearing it down (roadmap item 26); that
                # round-trip is only well-defined for an *activation-body*
                # effect, whose inverse the fiber's teardown runs. A
                # method-body effect runs per request, so it has no such
                # closed activate/teardown window — reject rather than accept
                # a marker the runner cannot honour.
                raise RevlError(
                    filename, mstmt.line,
                    "`verified effect` is only allowed in a component activation body",
                    hint="inverse round-trip testing activates the component and tears it "
                         "down; a provide-method effect runs per request and has no such "
                         "window (docs/verified-effect.md). Drop `verified`, or move the "
                         "effect to the activation body.")
            if isinstance(mstmt, LetEffect) and not isinstance(mstmt.acquire, SpawnExpr):
                # item 397: the NARROW lift of the phase-1 spawn-only rule. A
                # let-effect in a provide-method body is additionally admitted
                # when its acquire is a result-declared host verb (today:
                # exactly `insert_if_absent`) on an existing host local. The
                # bind names a checked VALUE (`Bool`), not a request-scoped
                # instance: there is no handle and no nested teardown scope, so
                # the effect-and-undo pair joins the activation frame's teardown
                # accumulator exactly as the unbound method-time `insert` does
                # today (demo/components/user_cache.rvl) — only the result gains
                # a (typed) name. The general method-body acquisition stays
                # deferred (docs/design/397-insert-if-absent.md §The one grammar
                # extension).
                with _acquire_position(env, mstmt.acquire):
                    acquire = _lower_expr(mstmt.acquire, env, mode="setup")
                result_type = _host_result_type(acquire, env)
                if result_type is None:
                    raise RevlError(
                        filename, mstmt.line,
                        "only `spawn` may be acquired inside a provide-method body",
                        hint="a request-scoped instance gets a nested teardown "
                             "scope; other acquisitions belong in the activation "
                             "body (docs/design-v2-instances.md). A result-declared "
                             "host verb (a Bool compare-and-set like "
                             "`insert_if_absent`) may be bound here")
                _check_rebind(mstmt.bind, mstmt.line)
                safe = _safe_name(mstmt.bind,
                                  set(env.params.values()) | set(method_locals.values())
                                  | set(env.locals.values()))
                method_locals[mstmt.bind] = safe
                env.params[mstmt.bind] = safe  # visible to later statements
                # a checked Bool value, NOT a host receiver: entered in the
                # type env so a pure `if`/ternary on it typechecks, and kept
                # OUT of host_locals (it has no verb surface).
                env.type_env[safe] = result_type
                mbody.append(_lower_effect_step(
                    acquire, mstmt.undo, env, filename, mstmt.line,
                    bind=safe, raw_acquire=mstmt.acquire))
            elif isinstance(mstmt, LetEffect):
                # item zero (docs/design-v2-instances.md): a spawn inside a
                # provide-method is a request-scoped instance. It gets its own
                # nested teardown scope (its child fiber), so `s.dispose()`
                # reclaims it when the instance dies, not when the component
                # tears down. Only `spawn` may be acquired here in phase 1 —
                # a general method-body acquisition is a separate feature.
                _check_rebind(mstmt.bind, mstmt.line)
                safe = _safe_name(mstmt.bind,
                                  set(env.params.values()) | set(method_locals.values())
                                  | set(env.locals.values()))
                with _acquire_position(env, mstmt.acquire):
                    acquire = _lower_expr(mstmt.acquire, env, mode="setup")
                method_locals[mstmt.bind] = safe
                env.params[mstmt.bind] = safe  # visible to later statements
                # record the handle's `Instance[C]` type so a later `s.<key>`
                # provision read (docs/design-v2-instances.md) resolves here too
                handle_type = infer_ir(acquire, env.type_env, env.types, env.services)
                if handle_type is not None:
                    env.type_env[safe] = handle_type
                undo = _lower_site_inverse(mstmt.undo, env, slot="undo")
                mbody.append({"step": "let-effect", "bind": safe,
                              "acquire": acquire, "undo": undo})
            elif isinstance(mstmt, EffectStmt):
                if isinstance(mstmt.acquire, SpawnExpr):
                    raise RevlError(
                        filename, mstmt.line,
                        "`spawn` must be bound to a handle: "
                        f"`let s = effect spawn {mstmt.acquire.component} … undo s.dispose()`",
                    )
                # item 318 (docs/design/243-witnessed-externs.md): a witnessed
                # effect is now valid in a provide-method body — THE dominant
                # H1 gate. An agent's fs mutation fires per tool call from a
                # provide-method, not the activation body; its declared inverse
                # auto-registers into the ENCLOSING COMPONENT'S activation frame
                # as a transactional entry (`Frame.transactional_method`), which
                # is component-long and whose commit/abort already discharges on
                # a clean unload / reverts on abort (Slice 2a). A witnessed call
                # carries no site `undo`; a plain effect still requires one.
                # `_lower_effect_step` makes exactly that distinction (the same
                # call the activation body uses): a witnessed acquisition lowers
                # to a `{"step": "effect", "acquire": ...}` with no `undo` key
                # (emit's `_method_witnessed_step` keys the transactional
                # registration off the acquisition's callee), and a plain
                # missing-undo effect raises the unchanged G4 refusal.
                with _acquire_position(env, mstmt.acquire):
                    acquire = _lower_expr(mstmt.acquire, env, mode="setup")
                mbody.append(_lower_effect_step(
                    acquire, mstmt.undo, env, filename, mstmt.line,
                    bind=None, raw_acquire=mstmt.acquire))
            elif isinstance(mstmt, EmitStmt):
                mbody.append(_lower_emit_step(mstmt, env))
            elif isinstance(mstmt, AwaitStmt):
                if not decl.async_:
                    raise RevlError(
                        filename, mstmt.line,
                        "`await` is only allowed in a component body",
                        hint="a provide method runs while the component is ACTIVE; iteration "
                             "boundaries (paper §4.3.2) exist only during activation (A1)",
                    )
                mbody.append({"step": "await", "expr": _lower_expr(mstmt.expr, env, mode="setup")})
            elif isinstance(mstmt, LetStmt):
                # a plain value binding: name an intermediate result instead
                # of nesting every call into a single expression. Shared with
                # the control-flow interior (issue #548) via `_do_let` — item
                # 404's misuse sweep, the `let x: T` pin (roadmap 76b) and the
                # inferred-type record (roadmap 75(b)) all live there.
                _do_let(mstmt, mbody)
            elif isinstance(mstmt, AssignStmt):
                _do_assign(mstmt, mbody)
            elif isinstance(mstmt, ReturnStmt):
                # item 308 B1 clause 3 (resource-return admission), the hole pin,
                # the F4 `check_ir` push and item 404's sweep all live in
                # `_do_return`; here it additionally marks the top-level body as
                # having returned so a later statement is unreachable and the
                # missing-return check below is satisfied.
                _do_return(mstmt, mbody)
                returned = True
            elif isinstance(mstmt, (IfStmt, WhileStmt, ForStmt)):
                # issue #548: control flow over the method's VALUE computation.
                # The arms are pure (registration is refused inside them); a
                # top-level `if`/`while`/`for` does not itself return, so the
                # method still needs a top-level `return` (or the missing-return
                # check below fires), exactly as a `fn` does.
                _lower_control_stmt(mstmt, mbody)
            else:  # pragma: no cover
                raise RevlError(filename, mstmt.line, "unexpected statement in method body")
        if decl.returns and not _definitely_returns(method.body):
            # same guarantee as a `fn` with a declared return, on the other
            # surface that has one: the emitted java method and rust trait impl
            # both fall off the end ("missing return statement" / E0308) while
            # python hands the caller a silent None.
            #
            # PARITY with the module-`fn` grammar (`_check_returns_on_every_path`,
            # via `_definitely_returns`): a method whose control flow returns on
            # EVERY path needs no trailing `return`. An `if`/`else` that returns
            # in both arms terminates the body exactly as it does in a `fn`, so a
            # dispatch written as plain control flow — the natural migration
            # target away from a ternary chain (item 458, issue #721) — is
            # accepted, not only the guard-then-trailing-return spelling. The two
            # messages mirror the fn checker: "never returns a value" when no
            # `return` appears at all, "control can reach the end" when one does
            # but not on every path (a bare `if` with no `else`, a `for`/`while`
            # that may run zero times).
            src = comp.source or filename
            if not _has_return(method.body):
                raise RevlError(
                    src, method.line,
                    f"`{method.name}` implements `{svc.name}.{method.name}`, which "
                    f"returns `{render_type(decl.returns)}`, but this body never "
                    f"returns a value",
                    hint=f"end the body with `return <{render_type(decl.returns)}>` — a "
                         f"provider must produce what its service promises, or "
                         f"consumers bound to `{svc.name}` receive nothing (rust E0308, "
                         'java "missing return statement")',
                    code="T1", category="type-mismatch",
                    expected=decl.returns, actual=None,
                )
            last_line = (getattr(method.body[-1], "line", method.line)
                         if method.body else method.line)
            raise RevlError(
                src, last_line,
                f"`{method.name}` implements `{svc.name}.{method.name}`, which "
                f"returns `{render_type(decl.returns)}`, but control can reach the "
                f"end of its body without a `return`",
                hint="every path must return: give the trailing `if` an `else` that "
                     "returns, or add a final `return` after it — a `for`/`while` may "
                     "run zero times and never counts (rust E0308, java \"missing "
                     "return statement\")",
                code="T1", category="type-mismatch",
                expected=decl.returns, actual=None,
            )
        # item 308: O1/B1 over the provide-method body — run BEFORE the param
        # types are restored out of `env.type_env`, so a parameter handle (a
        # borrow) is typed and detectable. An acquire bound in the method is
        # method-owned (its own `undo` is exempt).
        _ownership_walk_method(mbody, env, comp.source or filename, method.line)
        # item 470: the declaration bounds the OPERATION, not the `emit` steps
        # written in it. Run after the body is fully lowered, while the
        # declaration is still the one in scope.
        _check_intent_completeness(decl, mbody, env, svc.name, method.name,
                                   comp.source or filename, method.line)
        safe_params = [env.params[p] for p in method.params]
        env.params = saved
        env.declared_intent = saved_intent
        env.stated_crossings = saved_stated
        env.type_env = saved_tenv
        env.provision_locals = saved_provisions
        env.local_arrows = saved_arrows
        env.provision_values = saved_values

        # A service declaration is an *upper bound* on its providers' effects:
        # consumers bind to the service, not to this component, and a provider
        # may be purer than declared but never less. Without this, a plain
        # declaration hides an irreversible call from every consumer — and from
        # the G8 audit, which enumerates a caller's emissions by reading the
        # declarations of the methods it calls.
        if not decl.emission:
            caused_steps: dict[str, list] = {}
            caused, caps_used = _method_emissions(mbody, env, caused_steps)
            if caused:
                evidence = ", ".join(f"`{item}`" for item in caused)
                # the derivation for the *first* culprit: the message already
                # names them all, and one worked example is what the author
                # needs to see. The chain runs method -> ... -> emission.
                chain = caused_steps.get(caused[0]) or []
                why = None
                if chain:
                    head = TraceStep(method.name, "provide-method",
                                     comp.source or filename, method.line,
                                     f"provision `{stmt.key}`")
                    why = WhyTrace(kind="emission-propagation",
                                   subject=f"{svc.name}.{method.name}",
                                   steps=[head, *chain], shape=CHAIN)
                hint = (
                    f"a service declaration bounds what its providers may do — "
                    f"mark it `emission fn {method.name}(...)` in service "
                    f"`{svc.name}`, or move the irreversible call out of this "
                    f"method (G4)"
                )
                if "*" in caps_used:
                    # the capability set carries `*`: somewhere in the chain a
                    # call dispatches through a first-class function value
                    # (an arrow-typed parameter or binding), so the analysis
                    # cannot name what that call runs. Say so — the author is
                    # looking at a helper that looks pure and is not.
                    hint += (
                        ". This trace crosses a first-class dispatch: a call "
                        "invokes a function *value* (an arrow-typed parameter "
                        "or binding) rather than a named `fn`, so revl cannot "
                        "statically bound what it runs and must treat the "
                        "whole chain as possibly emitting"
                    )
                raise RevlError(
                    # the offending body lives in the component's own file,
                    # which is not the merged program filename
                    comp.source or filename, method.line,
                    f"`{svc.name}.{method.name}` is declared plain, but this "
                    f"implementation reaches {evidence}",
                    hint=hint,
                    code="G4", category="emission-propagation",
                    why=why,
                )
        elif decl.capabilities is not None:
            # the same upper bound, one refinement finer: `emission[db]` says
            # *where* a provider may cross, so the body's capability set must
            # be a subset. A provider using fewer capabilities is purer than
            # declared, which is the sound direction (docs/capabilities.md).
            caused, used = _method_emissions(mbody, env)
            extra = sorted(used - set(decl.capabilities))
            if extra:
                declared = ", ".join(decl.capabilities)
                offending = ", ".join(
                    "an unnameable host boundary" if cap == "*" else f"`{cap}`"
                    for cap in extra)
                evidence = ", ".join(f"`{item}`" for item in caused)
                raise RevlError(
                    comp.source or filename, method.line,
                    f"`{svc.name}.{method.name}` is declared "
                    f"`emission[{declared}]`, but this implementation emits "
                    f"through {offending}"
                    + (f" (reaching {evidence})" if evidence else ""),
                    hint=_capability_hint(svc.name, method.name,
                                          decl.capabilities, extra),
                    code="G4", category="emission-capability",
                )

        # sync/async arrow polymorphism (item 342): in a SYNC method, redirect
        # each call of a colour-polymorphic fn that receives only genuinely-sync
        # arrows to a sync monomorph, so the call no longer reaches an async
        # callable. Runs before the A1 admission below, whose `async_callables`
        # membership it thereby clears for the lifted case. An async method is
        # left untouched — item 92's coercion (loop stays async) is unchanged.
        if not decl.async_ and env.colour_polymorphic:
            _monomorphize_sync_callback_calls(mbody, env)

        # item 388: caller-decided extern colour. Record the colour each
        # poly-extern (`fn|async`) call site requests, and in a SYNC method
        # rewrite the call to the extern's `_revl_sync` clone. Runs in BOTH
        # colours, right beside the item-342 hook and BEFORE the A1 admission
        # below: the sync rewrite clears the poly extern's async membership so a
        # sync method calling it is not refused, while an async method's call
        # stays at the pre-seeded async name and is awaited (admitted here).
        if env.poly_externs:
            _resolve_poly_extern_calls(mbody, env, bool(decl.async_))

        # async coloring (docs/design/async-extern.md §3): an async call is
        # admitted only inside a provide method whose service operation is
        # declared `async fn`. The admission tests membership in the phase-2
        # *colored* set (async externs and any fn that transitively reaches
        # one), not just direct extern calls, so a sync method reaching a
        # colored helper fn is refused too — the twin of the emission-
        # propagation diagnostic above. The service declaration is the upper
        # bound on its providers, so asynchrony, like emission-ness, is a
        # declared property (A1).
        if env.async_callables:
            called: set = set()
            values: set = set()
            _calls_in(mbody, called, values=values)

            def _async_kind(name: str) -> str:
                return "extern" if name in env.async_externs else "function"

            def _async_locate(name: str):
                cdecl = (env.async_externs.get(name)
                         or (env.emission_evidence._decls.get(name)
                             if env.emission_evidence is not None else None))
                ev = env.emission_evidence
                return (ev.locate(cdecl) if ev is not None and cdecl is not None
                        else (None, getattr(cdecl, "line", None)))

            # a first-class reference to an async callable is refused in every
            # context, even an async method: an arrow type carries no color, so
            # the emitter cannot know to await it (async-extern.md §3, "refused,
            # not widened").
            passed_async = sorted(values & env.async_callables)
            if passed_async:
                culprit = passed_async[0]
                raise RevlError(
                    comp.source or filename, method.line,
                    f"`{svc.name}.{method.name}` uses async {_async_kind(culprit)} "
                    f"`{culprit}` as a function value, but an async callable has no "
                    f"arrow type",
                    hint="call it directly from an async context — an arrow type "
                         "carries no async color, so a suspension cannot be awaited "
                         "through it (A1)",
                    code="A1", category="async-propagation",
                )
            called_async = sorted(called & env.async_callables)
            if called_async and not decl.async_:
                culprit = called_async[0]
                cfile, cline = _async_locate(culprit)
                head = TraceStep(method.name, "provide-method",
                                 comp.source or filename, method.line,
                                 f"provision `{stmt.key}`")
                tail = TraceStep(culprit, f"async-{_async_kind(culprit)}",
                                 cfile, cline, f"async {_async_kind(culprit)}")
                why = WhyTrace(kind="async-propagation",
                               subject=f"{svc.name}.{method.name}",
                               steps=[head, tail], shape=CHAIN)
                evidence = ", ".join(f"`{name}`" for name in called_async)
                reached = (f"async extern {evidence}"
                           if culprit in env.async_externs
                           else f"async function {evidence}")
                raise RevlError(
                    comp.source or filename, method.line,
                    f"`{svc.name}.{method.name}` is declared sync, but this "
                    f"implementation reaches {reached} — a sync "
                    f"method has no in-flight window (A1)",
                    hint=f"declare the operation `async fn {method.name}(...)` in "
                         f"service `{svc.name}`, or move the suspending call out of "
                         f"this method",
                    code="A1", category="async-propagation",
                    why=why,
                )

        # item 117 (finding #40): the name-based reach above is blind to an
        # async *service operation* reached through a required key — the
        # complement of the async-callable case. A sync provide method that
        # reaches such an op in ANY position (a `let x = emit m.op(...)`
        # statement, or nested in a ternary arm / expression) has no in-flight
        # window to await it in, so it is refused — the expression-position
        # complement of item 141, which awaits the same emission inside an
        # *async* method (that path, `decl.async_`, is deliberately left
        # admitted here). Not guarded by `env.async_callables`: an async svc op
        # can be reached with no async externs/colored fns present at all.
        if not decl.async_:
            reached_ops: list = []
            _reached_async_req_ops(mbody, env, reached_ops)
            if reached_ops:
                req_name, op_method, op_decl = reached_ops[0]
                culprit = f"{req_name}.{op_method}"
                head = TraceStep(method.name, "provide-method",
                                 comp.source or filename, method.line,
                                 f"provision `{stmt.key}`")
                tail = TraceStep(culprit, "async-operation",
                                 getattr(op_decl, "source", None),
                                 getattr(op_decl, "line", None),
                                 "async service operation")
                why = WhyTrace(kind="async-propagation",
                               subject=f"{svc.name}.{method.name}",
                               steps=[head, tail], shape=CHAIN)
                raise RevlError(
                    comp.source or filename, method.line,
                    f"`{svc.name}.{method.name}` is declared sync, but this "
                    f"implementation reaches async operation `{culprit}` — a "
                    f"sync method has no in-flight window (A1)",
                    hint=f"declare the operation `async fn {method.name}(...)` "
                         f"in service `{svc.name}`, or move the suspending call "
                         f"out of this method",
                    code="A1", category="async-propagation",
                    why=why,
                )

        # item 92: a sync-typed arrow in this method that reaches an async
        # operation is the finding-#21 leak — a compile error now, not an
        # unawaited coroutine at runtime. Admitted (async-flagged) arrows are
        # skipped inside the walk.
        _refuse_leaky_arrow(mbody, env, comp.source or filename, method.line)

        # By-value capture for the derived inverses in this body: an `undo` /
        # `compensate` reading a `var` the body goes on to reassign must act on
        # the value its effect used, so name those locals for the emitters.
        _pin_inverse_captures(mbody)

        methods.append({"name": method.name, "params": safe_params, "body": mbody})

    missing = set(svc.methods) - implemented
    if missing:
        name = sorted(missing)[0]
        raise RevlError(filename, stmt.line,
                        f"provision `{stmt.key}` is missing method `{name}` declared by service {svc.name}")

    return {"step": "provide", "name": stmt.key, "service": svc.name, "methods": methods}


# ---------------------------------------------------------------- expressions

def _lower_let_approval(stmt: LetApprovalStmt, env: Env) -> dict:
    """`let a = await approval[C] { fields }` -> the `approval` body step (item
    246). Binds `a` at type `Approval[C]` and lowers the field expressions (the
    human's evidence). The suspension itself is the runtime's job; the checker's
    is to make `a` an unforgeable `Approval[C]` and to record C and the fields."""
    request = stmt.request
    fields = [[name, _lower_expr(fexpr, env, mode="pure")]
              for name, fexpr in request.fields]
    safe = env.bind_local(stmt.bind, stmt.line)
    env.type_env[safe] = f"Approval[{request.capability}]"
    return {"step": "approval", "bind": safe, "capability": request.capability,
            "fields": fields}


def _lower_emit_step(stmt: EmitStmt, env: Env) -> dict:
    node = _lower_expr(stmt.expr, env, mode="emit")
    if not _is_emission_call(node, env):
        desc = _node_desc(node)
        raise RevlError(env.filename, stmt.line,
                        f"`emit` on {desc}, which is not declared `emission`",
                        hint="only calls to `emission` service operations cross the boundary; "
                             "drop the `emit` marker (G4)")
    step = {"step": "emit", "expr": node}
    if stmt.compensate is not None:
        # compensation is teardown-position: emissions are permitted bare (A5)
        # the compensate twin of the site `undo` judgment: the extern's own
        # `compensate` slot is argument-checked (`_check_extern_undo`), and the
        # site slot runs in teardown Phase 2, so it gets the same judgment and
        # the same slot-naming refusal.
        comp = _lower_site_inverse(stmt.compensate, env, slot="compensate")
        step["compensate"] = comp
        # item 308, B1 clause 5 (compensate half): a compensation runs in
        # teardown Phase 2, AFTER Phase 1 closed every bracket, so ANY resource
        # value there (owned OR borrowed) is use-after-close by phase order.
        # O1 also refuses a declared inverse smuggled into a compensate.
        _o1_check(comp, env, env.filename, stmt.line, position="compensate")
        _b1_no_resource(comp, env, env.filename, stmt.line,
                        clause="compensate", borrows_only=False)
    _lower_emit_approval(stmt, node, step, env)
    _check_intent_refinement(stmt, node, env)
    return step


# ---------------------------------------------------------- item 470 ---------
#
# The checker-visible rule (docs/design/470-intent-refinement.md §4, stage 1).
#
# `src/revl/intent.py` already decides whether one action is a permitted
# refinement of one declared intent, and that kernel is deliberately unwired:
# what the tree had no surface for is the part the roadmap's exit criterion
# turns on — a DECLARATION held across time, and a crossing compared against it
# at the moment it fires, so the refusal can name the intent it violated rather
# than only the capability it reached.
#
# The two halves the parser adds are that surface. `within { … }` on a service
# operation is the declaration; `acting { … }` on an `emit` step is what one
# crossing does. They meet in a provide-method body, which is the only place a
# declared operation and a real crossing are both in hand: a service operation
# is an interface, its providers are the bodies, and the declaration is an
# upper bound every provider inherits exactly as `emission[...]` is.
#
# The object and the amount are NOT taken from the `acting` clause. They are
# read off the crossing's own capability spelling (`_emit_crossed_caps`, the
# same per-crossing resolution the approval obligation uses) through
# `intent.Action.from_cap`, which is `Intent.from_cap`'s typed twin: one
# spelling read as an intent and read as an action is the identity refinement,
# so the declaration and the crossing cannot drift by being written twice. The
# `acting` clause states only the three dimensions a capability spelling cannot
# carry — the verb, the tenant, and the set-valued scopes.
#
# Both demands below are keyed off `MethodDecl.within`, which is `None` for
# every operation in the tree, so no existing program reaches either one.


def _check_intent_refinement(stmt: EmitStmt, node: dict, env: Env) -> None:
    """Refuse a crossing that exceeds the intent its operation declared.

    The two OMISSIONS are refused in both directions, because each of them would
    otherwise be a silent hole:

      * an `acting` clause with no declaration to check it against would read as
        a check and perform none. Nothing here invents the missing intent —
        that is item 470's own scope note ("not inferring an intent the caller
        never stated") — so the clause is refused instead;
      * a crossing with NO `acting` clause inside a body whose operation does
        declare an intent is the dangerous direction: it would leave the
        declaration vacuous, since a body could declare `within` and then reach
        anything through an unannotated `emit`. Every crossing under a
        declaration must state what it does.

    `None`/`None` — the whole tree today — returns immediately, which is what
    makes the IR of an unannotated method and an unannotated emit unchanged.
    """
    declared = getattr(env, "declared_intent", None)
    acting = getattr(stmt, "acting", None)
    if declared is None and acting is None:
        return
    filename = env.filename
    if declared is None:
        _refuse_acting_without_declaration("`emit`", filename, stmt.line)
    clause, svc_name, method_name = declared
    where = f"`{svc_name}.{method_name}`"
    if acting is None:
        raise RevlError(
            filename, stmt.line,
            f"{where} declares an intent (`within` at line {clause.line}), so "
            f"this `emit` must state what it does with `acting {{ … }}`",
            hint="a crossing that states nothing cannot be shown to refine the "
                 "declaration, and one unannotated crossing would make the "
                 "declaration vacuous — write `acting { verb: <operation> }`, "
                 "adding `tenant:` and `scopes:` where the intent bounds them "
                 "(item 470)",
            code="G4", category="intent-refinement")
    crossed = _emit_crossed_caps(node, env)
    if not crossed or "*" in crossed:
        # The crossing names no capability this check can compare: a bare
        # `emission` operation, or a shape whose boundary set the per-crossing
        # resolution cannot pin down (a provision call off a spawn handle, a
        # service-typed local, an unclassified extern). Either way no declared
        # object can be SHOWN to cover it, and reading the unnameable as the
        # declared one is the direction the whole kernel was built to close.
        _refuse_unnameable_crossing(clause, where, filename, stmt.line, "`emit`")
    for token in crossed:
        _refine_one_crossing(token, clause, acting, where, filename, stmt.line,
                             "`emit`")


def _check_let_intent_refinement(stmt, value, env: Env) -> None:
    """Refuse a value-returning crossing that exceeds its operation's intent.

    Stage 0 of the design note's section 4, and the hole the completeness half
    opened. `_check_intent_refinement` demands that every crossing under a
    declaration state what it does, and the completeness check restates that
    over the whole body — but an `emit` STEP discards the value it produces, so
    an emission that RETURNS data (an LLM completion, an HTTP GET, a row count)
    is written `let r = emit svc.op(…)`, where the marker sits inside an
    expression and no clause can trail it. Under a declaration that spelling was
    refused with no rewrite available other than throwing the value away.

    The binding STATEMENT is the slot that can carry the clause, and once it
    does the check is exactly the per-crossing one the `emit` step already runs:
    the verb, the tenant and the scopes come off `acting`, while the object and
    the amount are read off the crossing's own capability spelling through
    `Action.from_cap`, so the two sides cannot drift by being written twice.

    Three refusals, and each is the same fail-closed direction as the step's:

      * an `acting` clause with no declaration to check it against
        (`_refuse_acting_without_declaration`, shared with the step);
      * an `acting` clause on a binding whose value performs no MARKED
        crossing. The `emit` marker is G4's point, and a clause on a value that
        does not carry it would state something about a crossing that is not
        there while leaving the real one (a bare call to an `emission` extern)
        unstated;
      * the crossing itself exceeding the declaration, or naming no boundary
        this check can compare.

    A binding that states NOTHING returns quietly and is left to
    `_check_intent_completeness`, which is where "a crossing that states
    nothing cannot be shown to refine the declaration" is already stated over
    the whole body. Registering the stated node with `env.stated_crossings` is
    what keeps that check from then refusing this one too.
    """
    acting = getattr(stmt, "acting", None)
    if acting is None:
        return
    filename = env.filename
    declared = getattr(env, "declared_intent", None)
    if declared is None:
        _refuse_acting_without_declaration("`let`", filename, stmt.line)
    clause, svc_name, method_name = declared
    where = f"`{svc_name}.{method_name}`"
    if not isinstance(stmt.value, EmitExpr):
        raise RevlError(
            filename, stmt.line,
            "this `let` states `acting { … }`, but its value carries no `emit` "
            "marker, so it performs no crossing this clause can be about",
            hint="a crossing is marked at its call site (G4), and the clause "
                 "states what THAT crossing does: write `let <name> = emit "
                 "<call> acting { verb: <operation> }`, or drop the clause — a "
                 "clause on an unmarked value would leave the real crossing "
                 "unstated (item 470)",
            code="G4", category="intent-refinement")
    crossed = _emit_crossed_caps(value, env)
    if not crossed or "*" in crossed:
        _refuse_unnameable_crossing(clause, where, filename, stmt.line, "`let`")
    for token in crossed:
        _refine_one_crossing(token, clause, acting, where, filename, stmt.line,
                             "`let`")
    env.stated_crossings.append(value)


def _refuse_acting_without_declaration(subject: str, filename: str,
                                       line: int) -> None:
    """An `acting` clause with no declaration to check it against.

    Shared by both stating slots (an `emit` step and a `let` binding), because
    the reason is the surface's, not the spelling's: an action is checked
    AGAINST a declaration, and item 470's own scope note forbids inventing the
    missing one. A clause that reads as a check and performs none is the hole.
    """
    raise RevlError(
        filename, line,
        f"this {subject} states `acting {{ … }}`, but the operation it runs in "
        "declares no `within { … }` intent for it to refine",
        hint="an action is checked AGAINST a declaration, and nothing infers "
             "an intent the caller never stated (item 470): declare it on the "
             "service operation — `... -> T within { object: <capability>, "
             "verbs: [<verb>] }` — or drop the `acting` clause",
        code="G4", category="intent-refinement")


def _declared_objects(clause) -> str:
    """Every capability the declaration names, as a refusal renders them."""
    return ", ".join(cap.to_str() for cap in clause.intent.objects())


def _refuse_unnameable_crossing(clause, where: str, filename: str,
                                line: int, subject: str = "`emit`") -> None:
    """A crossing whose boundary set cannot be named, under a declared intent."""
    declared = _declared_objects(clause)
    raise RevlError(
        filename, line,
        f"this {subject} crosses an unnameable boundary, and the intent {where} "
        f"declares authorizes `{declared}`",
        hint="an intent authorizes the boundaries it names, and a crossing that "
             "names none cannot be shown to be one of them (fail closed). Give "
             "the operation this crossing calls a capability scope — "
             "`emission[<capability>] fn …` — so the crossing can be compared "
             "against the declaration (item 470)",
        code="G4", category="intent-refinement",
        expected=declared, actual="an unnameable boundary")


def _refine_one_crossing(token: str, clause, acting, where: str,
                         filename: str, line: int,
                         subject: str = "`emit`") -> None:
    """One crossed capability token, against the declared intent.

    A crossing contributes one token per declared `emission[...]` scope, and
    EVERY one of them must refine the declaration: the intent bounds the
    operation, not a chosen capability of it, so admitting the crossing because
    one of its tokens fits would authorize the rest by association.
    """
    from . import cap_order as _cap_order  # noqa: PLC0415 - lazy, avoids a cycle
    from . import intent as _intent  # noqa: PLC0415 - lazy, avoids a cycle

    try:
        action = _intent.Action.from_cap(
            _cap_order.parse_cap(token),
            verb=acting.verb, tenant=acting.tenant, scopes=acting.scopes)
    except _cap_order.CapError as exc:  # pragma: no cover - parse validated
        raise RevlError(filename, line, str(exc),
                        hint=getattr(exc, "hint", None)) from exc
    except ValueError as exc:  # pragma: no cover - parse validated
        raise RevlError(filename, line, str(exc)) from exc
    refusal = _intent.refine(clause.intent, action)
    if refusal is None:
        return
    raise RevlError(
        filename, line,
        f"this {subject} exceeds the intent {where} declares: {refusal.message}",
        hint=f"{refusal.hint}. The declaration is the `within` clause at line "
             f"{clause.line} (roadmap item 470)",
        code="G4", category="intent-refinement",
        expected=refusal.declared, actual=refusal.requested)


def _without_stated_crossings(node, stated: frozenset = frozenset()):
    """`node` with every STATED crossing removed, and nothing else.

    Two spellings state themselves, and each is recognised the only way it can
    be. An `emit` STEP is structural: `_check_intent_refinement` runs at the
    step and refuses the step that carries no `acting` clause, so `step ==
    "emit"` already means "compared against the declaration". A stated BINDING
    (`let r = emit svc.op(…) acting { … }`, stage 0) cannot be structural,
    because a marker on the lowered node would be an IR key and this surface
    contributes none — so `stated` carries the identities of the crossing nodes
    `_check_let_intent_refinement` admitted, and a value that IS one of them is
    dropped from its binding.

    Everything else in the body is left exactly as lowered, including an emit
    step's `compensate` and approval slots: a compensation that itself crosses a
    boundary states nothing about that crossing and is not covered by the step's
    own `acting` clause.

    Only the crossing is dropped rather than the whole step, so the residue keeps
    the sibling slots. The result feeds `_method_emissions` and is never lowered,
    so pruning a copy costs no IR.
    """
    if isinstance(node, dict):
        drop = ("step", "expr") if node.get("step") == "emit" else ()
        return {key: _without_stated_crossings(value, stated)
                for key, value in node.items()
                if key not in drop and id(value) not in stated}
    if isinstance(node, list):
        return [_without_stated_crossings(value, stated) for value in node
                if id(value) not in stated]
    return node


def _check_intent_completeness(decl, mbody, env, svc_name: str,
                               method_name: str, filename: str,
                               line: int) -> None:
    """A declared intent bounds the OPERATION, not the `emit` steps in it.

    `_check_intent_refinement` closes one hole per crossing: an `emit` step
    under a declaration must state what it does. That leaves the declaration
    vacuous through every OTHER spelling of a crossing, and the tree has two
    that reach a boundary with no `emit` step to hang an `acting` clause on:

      * a direct call to an `emission` extern (`let n = wr(row)`), which the G4
        scope check already counts as a crossing but item 470 never saw;
      * a value-position emission (`let r = emit svc.op(...)`, `EmitExpr`),
        whose marker sits inside an expression where no clause can trail it.
        Stage 0 gives that spelling a stating slot on the BINDING statement
        (`_check_let_intent_refinement`); a binding that uses it is registered
        in `env.stated_crossings` and dropped from the residue below, and one
        that does not is refused here exactly as before;

    and one that hides a crossing behind an extra hop:

      * a helper `fn` the body calls that itself reaches an emission, which the
        same G4 check follows transitively.

    Each of them would let a body declare `within { object: fs.write(path=
    "/tmp"), ... }` and then reach `/etc` with no refusal at all, which is the
    exact direction the `acting`-less `emit` refusal was written to close.

    So the rule is stated over the whole body rather than per step: under a
    declaration, the only crossings admitted are the two that state themselves,
    an `emit` step and a `let` binding whose value is a marked crossing.
    Whatever the body still reaches once those are removed is a
    crossing that states nothing, and a crossing that states nothing cannot be
    shown to refine the declaration (fail closed). The analysis is
    `_method_emissions`, the same one the G4 provider upper bound reads, run
    over the residue, so this check inherits its transitive reach and its
    vocabulary rather than inventing a second one.

    Inert for every operation that declares no intent, which is every operation
    in the tree: `decl.within` is `None`, and the function returns before the
    residue is even built.
    """
    clause = getattr(decl, "within", None)
    if clause is None:
        return
    stated = frozenset(id(crossing) for crossing in env.stated_crossings)
    caused, _caps = _method_emissions(
        _without_stated_crossings(mbody, stated), env)
    if not caused:
        return
    evidence = ", ".join(f"`{item}`" for item in caused)
    declared = _declared_objects(clause)
    raise RevlError(
        filename, line,
        f"`{svc_name}.{method_name}` declares an intent (`within` at line "
        f"{clause.line}), and this implementation reaches {evidence} through a "
        f"crossing that states nothing about itself",
        hint="the declaration bounds the operation, not the `emit` steps "
             "written in it, so a crossing reached any other way would leave it "
             f"vacuous. The intent authorizes `{declared}`: route the crossing "
             "through an `emit <call> acting { verb: <operation> }` step, which "
             "is the one spelling a declaration can be checked against, or drop "
             "the `within` clause (roadmap item 470)",
        code="G4", category="intent-refinement",
        expected=declared, actual=evidence)


def _approval_scope_of(expr_type: str | None) -> str | None:
    """The capability scope `C` of a value typed `Approval[C]`, or None when the
    type is not an approval. `Approval[payment]` -> `"payment"`."""
    if not isinstance(expr_type, str):
        return None
    head, args = parse_type(expr_type)
    if head == "Approval" and len(args) == 1:
        return args[0]
    return None


def _lower_emit_approval(stmt: EmitStmt, node: dict, step: dict, env: Env) -> None:
    """Thread the `with e` edge onto the emit step and enforce the checker
    obligation (item 246, Decision 3). Two halves:

      * if the emit carries `with e`, `e` must type `Approval[C']`; the edge
        (`{"capability": C'}`) is recorded so the runtime frame check and the
        admission walk can read what the crossing was approved for;
      * every capability this crossing crosses that is DECLARATION-approval-
        required (an extern that declared `requires approval`) must be covered by
        that edge, else lowering refuses — the declaration-owned floor that holds
        with no policy file. Policy-owned requirements are the same shape, checked
        at admission over the recorded edge (the policy is not known here)."""
    crossed = _emit_crossed_caps(node, env)
    edge_scope = None
    if stmt.approval is not None:
        appr_node = _lower_expr(stmt.approval, env, mode="pure")
        appr_type = infer_ir(appr_node, env.type_env, env.types, env.services)
        edge_scope = _approval_scope_of(appr_type)
        if edge_scope is None:
            raise RevlError(
                env.filename, stmt.line,
                f"`with` on `emit` expects an `Approval[C]` value, but the "
                f"expression has type {appr_type or 'unknown'}",
                hint="thread the value produced by `await approval[C] { ... }` "
                     "(or an `Approval[C]` parameter) — nothing else produces an "
                     "approval (item 246)")
        step["approval"] = {"capability": edge_scope, "expr": appr_node}
    required = (env.types.get(APPROVAL_KEY) or {}).get("required") or set()
    for token in crossed:
        if token not in required:
            continue
        if edge_scope is None or not _approval_covers(edge_scope, token):
            from . import navigate as _nav  # noqa: PLC0415 — lazy, additive
            _prof = _UntrustedMark if env.untrusted else None
            raise RevlError(
                env.filename, stmt.line,
                f"crossing capability `{token}` requires approval, but this "
                f"`emit` carries no covering `with` edge",
                hint=f"acquire an approval — `let a = await approval[{token}] "
                     f"{{ ... }}` — and thread it: `emit … with a` (item 246, "
                     f"Decision 3, unreachable-without)",
                code="G4", category="approval",
                navigate=_nav.approval_navigate(token=token, profile=_prof))


def _lower_endorse_approval(expr: "ExprEndorse", env: Env, scope: dict,
                            callables: set, pure_only: bool) -> dict | None:
    """Resolve an `endorse[...](...) with <appr>` approval edge (item 249 Slice C,
    on the item 246 surface). `<appr>` must type `Approval[C]`; the recorded edge
    `{capability: C}` is what a `capability declassify.<origin> requires approval`
    policy rule checks coverage against, exactly as an `emit … with a` edge is.

    Returns None when the endorse carries no `with`."""
    if expr.approval is None:
        return None
    from .parser import ExprVar as _EV  # noqa: PLC0415 — lazy, avoids cycle
    appr_node = _lower_component_pure_expr(_EV(expr.approval, expr.line), env,
                                           scope, callables, pure_only)
    appr_type = infer_ir(appr_node, env.type_env, env.types, env.services)
    edge_scope = _approval_scope_of(appr_type)
    if edge_scope is None:
        raise RevlError(
            env.filename, expr.line,
            f"`endorse ... with` expects an `Approval[C]` value, but "
            f"`{expr.approval}` has type {appr_type or 'unknown'}",
            hint="thread the value produced by `await approval[declassify."
                 f"{expr.origin}] {{ ... }}` — nothing else produces an approval "
                 "(item 246/249)")
    return {"capability": edge_scope, "expr": appr_node}


def _resolve_required_stream(stmt: "StreamIterStmt", env: Env,
                             filename: str) -> str:
    """The requirement key an `on <Event> as <x> { … }` with no `in <sub>`
    clause resolves its stream from (item 130 §6, §6b).

    §6's shape is `on <Event> as <x> { … }` and its rule is "the event source is
    the provided `Stream[T]`", so the resolution is BY TYPE: the candidates are
    the component's required streams whose element is this event, and nothing
    else is consulted. A component may hold several stream requirements and host
    a handler for each without ambiguity, because two events are two element
    types.

    A coeffect is a DECLARED requirement, so the failure direction is a refusal
    and never a guess. Three refusals, each naming what it looked at:

    * the component declares no stream requirement at all;
    * it declares some, but none carries this event;
    * it declares more than one carrying this event — ambiguous, and picking
      either would bind the handler to an arbitrary source.

    Binding nothing, or picking the first candidate, are the two outcomes this
    exists to prevent: a handler silently attached to the wrong stream compiles
    and then behaves differently from the program the author wrote, which is
    strictly worse than not compiling."""
    event = stmt.event
    declared = dict(env.stream_requires)
    matches = sorted(key for key, elem in declared.items() if elem == event)
    if len(matches) == 1:
        return matches[0]
    where = f"`on {event} as {stmt.bind}`"
    spell = ", ".join(f"`{k}: Stream[{declared[k]}]`" for k in sorted(declared))
    if not declared:
        raise RevlError(
            filename, stmt.line,
            f"{where} has no stream to resolve — component "
            f"{env.component.name} requires no `Stream[...]`",
            hint=f"declare the source as a coeffect — `component "
                 f"{env.component.name} requires <key>: Stream[{event}]` — and "
                 f"the handler resolves it, or name a subscription you already "
                 f"own with `on {event} as {stmt.bind} in <sub> {{ … }}` "
                 "(item 130 §6b)",
            code="lifecycle", category="lifecycle")
    if not matches:
        raise RevlError(
            filename, stmt.line,
            f"{where} has no required `Stream[{event}]` to resolve — component "
            f"{env.component.name} requires {spell}",
            hint=f"a handler's source is the required stream whose element IS "
                 f"the event, so add `requires <key>: Stream[{event}]`, or name "
                 f"a subscription with `in <sub>` (item 130 §6b)",
            code="lifecycle", category="lifecycle")
    raise RevlError(
        filename, stmt.line,
        f"{where} is ambiguous — {', '.join(f'`{k}`' for k in matches)} are all "
        f"required as `Stream[{event}]`",
        hint=f"subscribe the one this handler pulls and name it: `let sub = "
             f"subscribe {matches[0]} undo sub.close()` then `on {event} as "
             f"{stmt.bind} in sub {{ … }}`. Resolving to either would bind the "
             "handler to an arbitrary source (item 130 §6b)",
        code="lifecycle", category="lifecycle")


def _lower_required_stream_handler(stmt: "StreamIterStmt", env: Env,
                                   filename: str,
                                   callables: set | None = None) -> list:
    """Desugar `on <Event> as <x> { … }` — the handler with no `in <sub>` — into
    the two steps the explicit form spells by hand: the subscription bracket,
    then the iteration over it (item 130 §6, §6b).

    §6 states the desugaring as `every <x> in subscribe(<the Event stream>) { … }`
    and this builds exactly that, by calling `_lower_subscribe_step` on a
    synthesized `subscribe <key> undo <sub>.close()` — so the bracket the handler
    rides is the one Slice 1 proved, registered on the same LIFO stack, with the
    same admission rules applied (single-consumer against the requirement key,
    the same default `error` backpressure policy, the same inverse shape). The
    subscription is ANONYMOUS: it is never entered in `env.locals`, so the
    implicit form cannot be half-spelled — there is no name to iterate a second
    time, close by hand, or collide with a local the author wrote.

    The qualifiers stay with the explicit form. A handler that needs a `policy`,
    a `buffer`, a `drain` window, a combinator chain or a `merge` writes the
    `subscribe` itself and names it with `in <sub>`; this shape is the default
    subscription and nothing else, which is why dropping the clause loses no
    expressiveness."""
    key = _resolve_required_stream(stmt, env, filename)
    safe = _safe_name(f"sub_{key}", env._taken)
    env._taken.add(safe)
    synthetic = LetEffect(
        bind=f"<{key}>",
        acquire=SubscribeExpr(Postfix(key, [], stmt.line), "error", stmt.line),
        undo=None,
        line=stmt.line,
        subscribe=True,
    )
    bracket = _lower_subscribe_step(synthetic, env, filename, bind_safe=safe)
    loop = _lower_stream_iter_step(stmt, env, filename, callables,
                                   subject_safe=safe)
    return [bracket, loop]


def _lower_stream_iter_step(stmt: "StreamIterStmt", env: Env, filename: str,
                            callables: set | None = None,
                            *, subject_safe: str | None = None) -> dict:
    """`every <x> in <sub> { … }` -> a `stream-iter` body step (item 130 Slice 4,
    docs/design/130-stream-reactive-types.md §1, §4.7, §5).

    The step carries the item bind, the subscription it pulls, and the body the
    consumer runs per item. The loop is the async-iteration form the roadmap's
    v1 spec names, and it is defined by the three operations Slice 1 already
    shipped: each turn awaits `<sub>.next()` (a suspension, §2.2), a `Closed`
    terminal ENDS the loop, and a `Faulted` terminal raises out of it.

    Nothing about the lifecycle is new, which is the point:

    * the subscription's bracket is registered by the `subscribe` ABOVE the
      loop, so the core guarantee (§0) is the one Slice 1 proved — unloading the
      owner trips the cancel token, the parked `next` resolves as `Closed`, the
      loop exits, and the bracket inverse `close` runs on the same LIFO stack;
    * the body's emissions lower through the SAME `_lower_emit_step` and the
      SAME `env` as a top-level `emit`, so the effectful callback is bounded by
      exactly the component's declared capabilities (G1) and `_collect_emit_caps`
      — which recurses into a nested `body` — surfaces its reach to the G8 audit
      as component reach, exactly as a timer body's does;
    * a `fail` in the body aborts the iteration (A8): the activation fails, the
      accumulated prefix reverts LIFO, and because the subscription bracket is
      on that prefix the failure CLOSES the subscription. That is the typed-
      events obligation "a failed handler does not leave a subscription active"
      (§6) delivered with no events-specific machinery.

    Two admission rules are this step's own:

    * the subject must name a LIVE subscription — a `Subscription` host-local
      bound by a `subscribe` bracket. Iterating a stream SOURCE, a pool, or any
      other value is refused, naming the `subscribe` that is missing;
    * rule 3.1 extended to the handle: an iteration consumes its subscription to
      the terminal, so a second `every` on the same subscription is a second
      consumer of a single-consumer subscription and is refused."""
    subject = stmt.subject
    name = getattr(subject, "head", None)
    # `subject_safe` is the anonymous bracket the implicit `on <Event> as <x>`
    # handler just registered (see `_lower_required_stream_handler`). It is a
    # `Subscription` host-local by construction, so the two admission rules below
    # cannot fire on it — and it is deliberately not in `env.locals`, so no
    # second `every` can name it.
    safe = subject_safe if subject_safe is not None \
        else (env.locals.get(name) if name else None)
    if safe is None or env.host_locals.get(safe) != "Subscription":
        raise RevlError(
            filename, stmt.line,
            f"`every {stmt.bind} in {name}` needs a live subscription — "
            f"`{name}` is not one",
            hint="iterate the handle a `subscribe` bracket bound, not the stream "
                 "source: `let sub = subscribe <stream> undo sub.close()` then "
                 f"`every {stmt.bind} in sub {{ … }}` (item 130 §1). The "
                 "subscription is what carries the cancellation token the "
                 "iteration ends on.",
            code="lifecycle", category="lifecycle")
    if safe in env.iterated_subs:
        raise RevlError(
            filename, stmt.line,
            f"subscription `{name}` is already iterated — a subscription is "
            "single-consumer (rule 3.1)",
            hint="one `every … in` pulls the subscription to its terminal; a "
                 "second consumer would race it for items. Multicast is a later "
                 "item; compose fan-out from an explicit bridge, one bracket per "
                 "consumer (item 130 §4.1)",
            code="lifecycle", category="lifecycle")
    env.iterated_subs.add(safe)
    contract = _event_contract(stmt, env, filename)
    # The item is bound for the BODY only. A saved/restored `locals`+`_taken`
    # keeps the loop variable out of scope after the loop (it names one delivered
    # item, and there is no last item once the terminal arrived) while still
    # reserving its safe name against a later collision.
    saved_locals = dict(env.locals)
    saved_type_env = dict(env.type_env)
    item = env.bind_local(stmt.bind, stmt.line)
    if contract is not None:
        # Slice 5: under `on <Event> as <x>`, the item has a TYPE — the event's
        # record — for the length of the body. That is the whole "schema
        # compatibility" row of §6 on the checked side: `<x>.<field>` resolves
        # through the ordinary record rules, so a field the event does not
        # declare and a field used at the wrong type are both compile errors,
        # where a plain `every`'s untyped item admits either.
        env.type_env[item] = stmt.event
    body: list = []
    for inner in stmt.body:
        if isinstance(inner, FailStmt):
            body.append({
                "step": "fail",
                "message": _lower_component_pure_expr(
                    inner.message, env, _component_scope(env),
                    callables or set(), pure_only=True,
                ),
            })
            continue
        emit_step = _lower_emit_step(inner, env)
        _admit_emit_async(inner, emit_step, env, filename)
        if contract is not None:
            _check_event_field_reads(emit_step.get("expr"), item, stmt.event,
                                     contract, env, filename, inner.line)
        body.append(emit_step)
    env.locals = saved_locals
    env.type_env = saved_type_env
    step = {
        "step": "stream-iter",
        "bind": item,
        "subject": {"kind": "name", "id": safe},
        "body": body,
    }
    if contract is not None:
        # Additive, and present only under an `on … as` handler, so a Slice 4
        # iteration lowers byte-identically (§5's additive-key discipline).
        step["event"] = {
            "name": stmt.event,
            "key": contract["key"],
            "window": contract["window"],
            "schema": contract["schema"],
        }
    return step


def _event_contract(stmt: "StreamIterStmt", env: Env, filename: str):
    """Resolve the `on <Event> as …` handler's event contract, or None for a
    plain `every … in` (item 130 Slice 5, §6).

    Refuses a name that is not a declared `event`, and says which of the two
    near misses it is — an undeclared name, or a `type` that was never given the
    contract an event carries. A record cannot stand in for an event: the two
    things §6 assigns to events beyond a plain stream (the identity key and the
    dedup that key makes possible) live in the `event` declaration, so `on` over
    a bare record would be `every` with extra syntax."""
    name = getattr(stmt, "event", None)
    if name is None:
        return None
    events = env.types.get(EVENTS_KEY) or {}
    contract = events.get(name)
    if contract is None:
        known = ", ".join(sorted(events)) or "(none declared)"
        declared_type = name in env.types
        raise RevlError(
            filename, stmt.line,
            f"`on {name} as …` names no declared event"
            + (f" — `{name}` is a `type`, not an `event`" if declared_type else ""),
            hint=(f"declare it: `event {name}(key: <field>) {{ … }}`. An event is a "
                  "record with a contract (item 130 §6) — the identity key its "
                  "handler dedups on is what a plain `type` does not carry"
                  if declared_type else
                  f"declare it: `event {name}(key: <field>) {{ … }}`. Declared "
                  f"events: {known} (item 130 §6)"),
            code="lifecycle", category="lifecycle")
    return contract


def _check_event_field_reads(node, item: str, event: str, contract: dict,
                             env: Env, filename: str, line: int) -> None:
    """Refuse a read of a field the event does not declare (item 130 Slice 5).

    Scoped deliberately to reads rooted at the handler's ITEM. The emit-argument
    typing already compares an inferred field's type against the emission's
    parameter, but an UNKNOWN field infers to `None`, which that comparison
    treats as "no information" and admits — so the misspelling the event
    contract exists to catch would compile clean and fail at the host. This walk
    is the one that names it, and it names it against the event, which is the
    diagnostic an author of an `on` handler wants."""
    fields = (env.types.get(event) or {}).get("fields") or {}
    stack = [node]
    while stack:
        cur = stack.pop()
        if isinstance(cur, list):
            stack.extend(cur)
            continue
        if not isinstance(cur, dict):
            continue
        target = cur.get("target")
        if cur.get("kind") in ("field", "optfield") \
                and isinstance(target, dict) and target.get("kind") == "name" \
                and target.get("id") == item and cur.get("name") not in fields:
            listed = ", ".join(sorted(fields)) or "none"
            raise RevlError(
                filename, line,
                f"`event {event}` has no field `{cur.get('name')}` "
                f"(fields: {listed})",
                hint="an event's items are validated against the schema derived "
                     "from its declared fields before the body runs, so a field "
                     "the declaration does not carry can never arrive "
                     "(item 130 §6)",
                code="T1", category="type-mismatch")
        stack.extend(cur.values())


def _lower_timer_step(stmt: TimerStmt, env: Env) -> dict:
    """`every`/`after` -> a `timer` body step (item 57, docs/time-coeffect.md).

    A timer is a revertible schedule; the step carries the delay and the
    emissions the firing runs. The body's `emit` statements lower through the
    *same* `_lower_emit_step` and the *same* `env` as a top-level emit, so the
    firing is bounded by exactly the component's declared capabilities — a
    timer body reaching an undeclared service is refused at G1/G4 like any other
    emission, and `_collect_emit_caps` (which recurses into the nested `body`)
    surfaces the firing's reach to the G8 audit as component reach. The schedule
    itself is not an emission (crossing time is not crossing the system
    boundary); its inverse is the runtime's cancellation, derived like any other
    effect teardown, so it carries no `undo` slot in the IR."""
    body = [_lower_emit_step(inner, env) for inner in stmt.body]
    step = {
        "step": "timer",
        "mode": stmt.mode,
        "interval_ms": stmt.interval_ms,
        "body": body,
    }
    # async colouring (item 170): a timer body reaching an async op — a
    # req-target async service operation (`emit agent.run_in(...)`, the
    # scheduled-agent-run shape) or an async callable (an async extern / a
    # phase-2 colored fn) — is ADMITTED and coloured async, not refused. The
    # firing then opens an `Async[T]` in-flight window (item 106): the runtime
    # awaits the body on the tick and CANCELS any pending firing + in-flight
    # work on unload (the timer's revertible-effect/undo contract, now covering
    # the async case — R4/A8). A sync timer body carries no `async` key and is
    # byte-identical to before.
    if _timer_body_reaches_async(body, env):
        step["async"] = True
    return step


def _timer_body_reaches_async(body, env) -> bool:
    """True if a lowered timer body reaches a suspension (item 170): a
    req-target async service op (rule 3 of the item-92 async-reach), or a call
    of an async-colored callable — an async extern or a phase-2 colored fn
    (rule 1). Mirrors `_arrow_reaches_async`, but a timer body is a list of
    `emit` steps with no intervening arrow value, so nothing is pruned."""
    hit = False

    def walk(n):
        nonlocal hit
        if hit:
            return
        if isinstance(n, dict):
            if _req_op_is_async(n, env):
                hit = True
                return
            for value in n.values():
                walk(value)
        elif isinstance(n, list):
            for value in n:
                walk(value)

    walk(body)
    if hit:
        return True
    called: set = set()
    _calls_in(body, called, stop_async_arrows=True)
    return bool(called & (getattr(env, "async_callables", None) or set()))


def _refuse_unbracketed_host_acquire(root: str, verb: str, where: str,
                                     filename: str | None, line: int) -> None:
    """A host acquire verb is legal ONLY as the acquisition of an
    `effect … undo …` bracket (G4/G6).

    `Pool.open`/`Map.new`/`Stream.source` open a host resource whose release is
    a separate verb. The bracket is the only construct that registers that
    release with the activation's teardown accumulator, so a call anywhere else
    acquires something no teardown reclaims: the runtime reports it as residue
    (`pool#1 (open() with no close())`, R1) on a program the checker admitted.

    The rule was enforced at exactly one position — an activation-body `effect`
    with no `undo` (`g4_missing_undo.rvl`) — and every OTHER position an
    expression can occupy was silent: a `fn`/`test` body, a plain `let` in a
    provide-method body, an `undo`/`compensate` slot. This is the same rule at
    every position, which is why it lives at the two host-call lowering arms
    rather than as a fourth special case.

    The `acquire` EXTERN twin of this refusal is
    `_refuse_effect_position_bound_externs_in_fn_body` (items 399/400); the
    wording below deliberately echoes it."""
    release = _HOST_ACQUIRE_VERBS[f"{root}.{verb}"]
    raise RevlError(
        filename or "<unknown>", line,
        f"host acquisition `{root}.{verb}` cannot be called in {where} — "
        f"nothing registers its `{release}()`, so the resource is acquired "
        f"irreversibly (G4)",
        hint=f"acquire it in a bracket, where the teardown accumulator holds "
             f"the release: `let h = effect {root}.{verb}(…) undo h.{release}()` "
             f"in a component activation body. A `fn` body has no host access at "
             f"all (G6), and a teardown slot may not acquire "
             f"(docs/design/teardown-contract.md)",
        code="G4", category="acquire",
    )


@contextlib.contextmanager
def _acquire_position(env, expr):
    """Mark `expr` as THE acquisition expression of an effect bracket.

    Identity, not shape: only the bracket's own root call is in acquire
    position, so `effect wrap(Pool.open(u, 1)) undo …` — which acquires a pool
    the bracket's inverse never names — is still refused."""
    saved = getattr(env, "_host_acquire_root", None)
    env._host_acquire_root = expr
    try:
        yield
    finally:
        env._host_acquire_root = saved


def _resolve_provision_alias(node, env):
    """A `name` node bound to a spawn-handle provision, resolved back to the
    `instance-get` it names (else `node`, untouched).

    See `Env.provision_locals`. Every consumer of a provision call —
    `_instance_get_call` (G4's marker check), `__main__._boundary` (G8's audit
    fold), `cardinality`, `parallel` — matches the RECEIVER shape, so restoring
    the shape at name resolution is the whole fix: nothing downstream has to
    learn what an alias is. A fresh copy per use keeps the IR a tree."""
    if not isinstance(node, dict) or node.get("kind") != "name":
        return node
    inst = (getattr(env, "provision_locals", None) or {}).get(node.get("id"))
    if inst is None:
        return node
    return copy.deepcopy(inst)


def _note_provision_alias(safe: str, value, env) -> None:
    """Record that `safe` names a spawn-handle provision, when it does.

    Both the direct read (`let t = w.task`) and a second hop (`let u = t`) land
    here, because the second hop's value has already been resolved through this
    same map by `_resolve_provision_alias`."""
    if isinstance(value, dict) and value.get("kind") == "instance-get":
        env.provision_locals[safe] = value


def _check_arrow_param_crossings(arrow, args: list, env: Env,
                                 scope: dict, callables, pure_only: bool) -> None:
    """Follow a spawn-handle provision across an ARROW PARAMETER binding at the
    application site (GHSA-wg4v-r47x-52p2 residual).

    #331 resolved a boundary crossing reached through a `let`/capture binding of
    a spawn handle by mapping the safe IR name back to the provision
    (`provision_locals`) so every consumer judges the aliased spelling exactly
    as the direct one. This is the sibling one indirection further: the handle
    does not name the receiver lexically — it flows in as a call ARGUMENT to a
    local arrow whose PARAMETER carries the service type
    (`let f = (t: Task, s: Str) => t.run(s); f(w.task, p)`). The parameter's
    declared service type IS the provenance the emission analysis has to follow.

    The resolution is #331's, extended to the parameter binding: bind each
    service-typed parameter that receives a provision argument into
    `provision_locals`, then re-lower the arrow body. The receiver `t` then
    lowers back to the provision's `instance-get`, and the SAME instance-get
    consumer that guards the direct handle call (`_instance_get_call`, the G4
    `emit`-marker check at the generic call fall-through) judges `t.run(s)`
    exactly as `w.task.run(s)`: an unmarked crossing is refused naming the real
    subject `w.task.run`, a marked one passes, and a non-emission method or an
    arrow never applied to a provision installs no binding and is untouched.

    A pure check: the re-lowered body is discarded (the emitted arrow is left
    byte-identical), and `provision_locals` / `type_env` are restored."""
    params = list(getattr(arrow, "params", None) or [])
    if not params:
        return
    ptypes = _arrow_declared_param_types(arrow)
    bindings: dict[str, dict] = {}
    for param, ptype, arg in zip(params, ptypes, args):
        if not ptype or not isinstance(arg, dict):
            continue
        head, _ = parse_type(ptype)
        if head not in env.services:
            continue
        resolved = _resolve_provision_alias(arg, env)
        if isinstance(resolved, dict) and resolved.get("kind") == "instance-get":
            bindings[param] = resolved
    if not bindings:
        return
    saved_prov = dict(env.provision_locals)
    type_env = getattr(env, "type_env", None)
    saved_types = {p: type_env.get(p) for p in params} if type_env is not None else {}
    inner = dict(scope)
    try:
        for param, ptype in zip(params, ptypes):
            inner[param] = param
            if type_env is not None:
                if ptype:
                    type_env[param] = ptype
                else:
                    type_env.pop(param, None)
        for param, inst in bindings.items():
            env.provision_locals[param] = inst
        _lower_component_pure_expr(arrow.body, env, inner, callables, pure_only)
    finally:
        env.provision_locals = saved_prov
        if type_env is not None:
            for param, prev in saved_types.items():
                if prev is None:
                    type_env.pop(param, None)
                else:
                    type_env[param] = prev


def _instance_get_call(node: dict, env: Env):
    """If `node` is a method call whose receiver is a provision read off a
    spawn handle (`s.<key>.<method>(...)`), return `(instance_get, decl)`:
    the `instance-get` node and the `MethodDecl` for the method on the service
    that key yields — else `None`.

    A provision method call does not lower to a `req`-target call; the pure
    expression stratum lowers `s.<key>` to an `instance-get`, and the trailing
    `.<method>(...)` wraps it in a `field` callee (`_lower_component_pure_expr`
    ExprCall fall-through). So the receiver is reached through `callee`, not the
    `target` slot a required-service call uses."""
    if node.get("kind") != "call":
        return None
    callee = node.get("callee")
    if not (isinstance(callee, dict) and callee.get("kind") == "field"):
        return None
    recv = callee.get("target")
    if not (isinstance(recv, dict) and recv.get("kind") == "instance-get"):
        return None
    svc = env.services.get(recv.get("service"))
    if svc is None:
        return None
    decl = svc.methods.get(callee.get("name"))
    return (recv, decl) if decl is not None else None


def _is_emission_call(node: dict, env: Env) -> bool:
    # an `emission` extern (or a function reaching one) is a boundary
    # crossing exactly as a service emission is, so `emit` marks it too
    if node.get("kind") == "fn" and node.get("name") in getattr(env, "emitting_fns", ()):
        return True
    if node.get("kind") != "call":
        return False
    target = node.get("target")
    if target is None:
        # a provision method call off a spawn handle carries its receiver in
        # `callee` (an `instance-get`), not the `req` `target` slot — walk the
        # handle's provision to the service and read the method's emission-ness
        # there rather than assuming a `req` target (which KeyError'd here)
        inst = _instance_get_call(node, env)
        return inst is not None and inst[1].emission
    if target.get("kind") == "name":
        # a call whose receiver is a service-typed local or parameter. A value
        # of a service type is a boundary handle — only a provision read or a
        # required binding yields one — so an `emission` method reached through
        # it crosses the boundary exactly as the `req`/handle spellings do. This
        # is what lets a correctly `emit`-marked call through a service-typed
        # ARROW PARAMETER validate (`(t: Task) => emit t.run(p)`), the same way
        # #331 made the aliased handle's `emit t.run(p)` validate rather than
        # refusing the marked form as "not declared emission". The UNMARKED
        # demand is raised where the provision flows into the parameter (the
        # application, `_check_arrow_param_crossings`); this predicate only
        # decides emission-ness (GHSA-wg4v-r47x-52p2 residual).
        head, _ = parse_type((getattr(env, "type_env", None) or {}).get(target.get("id")) or "")
        svc = env.services.get(head)
        decl = svc.methods.get(node.get("method")) if svc is not None else None
        return decl is not None and decl.emission
    if target.get("kind") != "req":
        return False
    svc = env.services[env.requires[target["name"]]]
    decl = svc.methods.get(node["method"])
    return decl is not None and decl.emission


def _lower_lease_step(stmt: "LetEffect", env: Env, filename: str) -> dict:
    """Lower `let l = effect lease <cap> [ttl <d>] [uses <n>] undo l.revoke()`
    (item 294 Slice 2) to a `let-effect` step whose acquire is the reserved
    runtime lease acquisition and whose undo is the own-handle revoke.

    Two dedicated IR nodes keep the lease off the host-verb surface: `lease-
    acquire` emits `_revl_frame.acquire_lease(...)` (the gate mints the grant
    from an approved ticket; the acquire only binds a handle to it), and `lease-
    revoke` emits `<handle>.revoke()` (retiring the grant by its OWN requestId on
    the LIFO teardown — the always-safe direction, revoking your own authority).
    The disposer MUST be exactly `<bind>.revoke()`: the design's scoped exemption
    is the own-requestId revoke only; any other disposer would name a grant the
    scope did not mint and belongs on the ordinary 379 gate, which no source form
    reaches."""
    acq: LeaseAcquire = stmt.acquire            # type: ignore[assignment]
    from .parser import ExprCall, ExprField, ExprVar  # noqa: PLC0415
    undo = stmt.undo
    ok = (isinstance(undo, ExprCall) and not undo.args
          and isinstance(undo.callee, ExprField)
          and undo.callee.name == "revoke"
          and isinstance(undo.callee.target, ExprVar)
          and undo.callee.target.name == stmt.bind)
    if not ok:
        raise RevlError(
            filename, acq.line,
            f"a lease's `undo` must be `{stmt.bind}.revoke()` — its own revoke",
            hint="a lease is torn down by revoking the grant it acquired; the "
                 "own-requestId revoke is the only exempt disposer (item 294). "
                 "A disposer naming another grant goes through the operator "
                 "revoke gate (item 379), which no source form reaches",
            code="G4", category="capability")
    safe = env.bind_local(stmt.bind, stmt.line)
    step = {
        "step": "let-effect",
        "bind": safe,
        "lease": {"capability": acq.capability,
                  "ttlMs": acq.ttl_ms, "uses": acq.uses},
        "acquire": {"kind": "lease-acquire", "capability": acq.capability,
                    "ttlMs": acq.ttl_ms, "uses": acq.uses, "line": acq.line},
        "undo": {"kind": "lease-revoke", "handle": safe, "line": acq.line},
    }
    return step


def _lower_spawn(expr: SpawnExpr, env: Env, mode: str) -> dict:
    """Lower `spawn <Component> with { ... }` to the frozen spawn IR node
    (docs/design-v2-instances.md).

    An instance is an acquisition: the node rides in the `acquire` slot of a
    `let-effect` step, the handle is that step's `bind`, and the teardown is
    its `undo`.  Instance identity + local realm are carried by `realms` — the
    keys the target provides, each isolated into a *fresh* local realm at spawn
    time so any number of instances coexist without a G2 collision (decision 3,
    5).  The target is a *template*: it never joins the static composition, so
    its provisions never enter the link-time G2/G3 table (decision 5/6)."""
    reg = getattr(env, "spawn_reg", None)
    if reg is None or expr.component not in reg["by_name"]:
        raise RevlError(
            env.filename, expr.line,
            f"`spawn {expr.component}` names an unknown component",
            hint="a spawn target is a component declared in this composition "
                 "(docs/design-v2-instances.md); a running/ambient component "
                 "cannot be spawned in phase 1",
        )
    if mode != "setup":
        # spawn is only meaningful as an acquisition; `undo`/`emit` positions
        # have no handle to bind and no teardown to invert
        raise RevlError(
            env.filename, expr.line,
            "`spawn` is only valid as an acquisition — `let s = effect spawn "
            f"{expr.component} … undo s.dispose()`",
        )
    target = reg["by_name"][expr.component]
    tconfig = {f.name: f for f in target.config}
    lowered_cfg: dict[str, dict] = {}
    for field, vexpr in expr.config.items():
        if field not in tconfig:
            raise RevlError(
                env.filename, expr.line,
                f"`{field}` is not a config field of {expr.component}",
                hint="spawn config carries the target's declared `config { }` fields",
            )
        # item 378: type-check the config VALUE against the (data-only) declared
        # config type, exactly as `load C with { … }` does. Without this the
        # producer seam was open: a spawn config value was lowered with no
        # check_ast, so a wrong-typed (or callable-carrying) value smuggled in.
        check_ast(vexpr, tconfig[field].type, env.type_env, env.types,
                  env.filename, f"config field `{field}` of {expr.component}")
        lowered_cfg[field] = _lower_expr(vexpr, env, "setup")
        # item 308, B1 clause 6: a resource-tainted spawn config value seats the
        # handle in the child's activation for its whole lifetime (a
        # per-invocation borrow escalated to an activation-lifetime hold).
        _taint308, _ = _resource_ctx(env.types)
        _cfg_res = (resource_in(tconfig[field].type, _taint308)
                    or _node_resource(lowered_cfg[field], env, _taint308))
        if _cfg_res:
            raise RevlError(
                env.filename, expr.line,
                _b1_message("spawn", "borrowed", _cfg_res),
                hint=_b1_hint("spawn"), code="G7", category="ownership")
    # item 350: a `boot` component is the composition's environment-contract
    # arrival point, not a runtime template. Spawning one would mint instances
    # whose config comes from an author-written `with { … }` that no admission
    # check bounds, so the contract's declared bounds would apply to the
    # host-injected instance and not to the spawned ones — exactly the silent
    # widening the contract exists to remove. Refused.
    if getattr(target, "boot", False):
        raise RevlError(
            env.filename, expr.line,
            f"`{expr.component}` is a `boot` component and cannot be spawned",
            hint="a boot component declares the ENVIRONMENT CONTRACT and is composed "
                 "once, at admission, from the values the host injects; a spawn would "
                 "mint instances whose config bypasses that check. Move the spawnable "
                 "work into an ordinary component (item 350)",
        )
    for f in target.config:
        if f.default is None and f.name not in expr.config:
            raise RevlError(
                env.filename, expr.line,
                f"spawn {expr.component} is missing required config field `{f.name}`",
                hint=f"provide it: `spawn {expr.component} with {{ {f.name}: … }}`",
            )
    realms = sorted(key for key, _svc, _line in target.provides)
    reg["edges"].append((env.component.name, expr.component))
    reg["templates"].add(expr.component)
    node = {
        "kind": "spawn",
        "component": expr.component,
        "config": lowered_cfg,
        # each provided key gets its own fresh LOCAL realm at runtime; this is
        # how per-instance non-collision is carried into every tier's IR
        "realms": realms,
        "line": expr.line,
    }
    # item 10 placement horizon: an optional NAMED INSTANCE. `as "<name>"`
    # stamps the spawn with a stable author-declared address. It is present on
    # the node ONLY when written, so an unnamed spawn is byte-identical to
    # before (no shape change for existing programs). The address makes no
    # location claim yet — the instance still lands in the spawning process —
    # so no tier's lowering has to honour it; it is the identity a later
    # placement slice keys on so the spawn shape need not bake "same process"
    # in as its only possibility (docs/design-v2-instances.md).
    if expr.name is not None:
        seen = reg["names"].setdefault(env.component.name, set())
        if expr.name in seen:
            raise RevlError(
                env.filename, expr.line,
                f"duplicate spawn instance name `{expr.name}` in "
                f"{env.component.name}",
                hint="a named instance is an ADDRESS: two instances of one "
                     "component cannot share it, or the address is ambiguous. "
                     "Give each a distinct name (docs/design-v2-instances.md)",
            )
        seen.add(expr.name)
        node["name"] = expr.name
        # item 10 placement horizon, next slice: surface every named instance
        # at the COMPOSITION layer. The address landed on this deeply-nested
        # acquire node (#454), but nothing above it could enumerate named
        # instances — the stated prerequisite for teaching the placement plan
        # to assign one to a process. Record (spawner, name, target component,
        # line) here; `_link` sorts these into `manifest["named_instances"]`.
        # Purely additive: absent when no spawn is named, so the manifest is
        # byte-identical for existing programs (docs/design-v2-instances.md).
        reg["named_instances"].append({
            "spawner": env.component.name,
            "name": expr.name,
            "component": expr.component,
            "line": expr.line,
        })
    return node


def _instance_handle_component(node: dict, env: Env) -> str | None:
    """`C` if `node` is a name bound to a spawn handle typed `Instance[C]`,
    else None.

    The type is recorded only when the current component itself binds a
    `spawn` acquisition (`env.type_env[handle] = "Instance[C]"`), so a name
    can carry it only for a handle *this* component holds. There is no surface
    that names another component's handle, which is exactly why `s.<key>`
    cannot reach a sibling's or the root's provision — it keeps instance
    addressing on the supervision tree (docs/design-v2-instances.md 1/2)."""
    if not isinstance(node, dict) or node.get("kind") != "name":
        return None
    head, args = parse_type(env.type_env.get(node.get("id")))
    if head == "Instance" and args:
        return args[0]
    return None


def _lower_instance_get(target: dict, key: str, line: int,
                        component_name: str, env: Env) -> dict:
    """Lower `s.<key>` (a provision read off a spawn handle) to the frozen
    `instance-get` IR node (docs/design-v2-instances.md).

    `<key>` must be a key the target component *provides*; reading a key it
    does not provide is a compile error. At runtime every tier resolves `key`
    through the handle's stored instance context — the private local realm the
    matching `spawn` node isolated the key into — so the read yields *that
    instance's* provision and no other's."""
    reg = getattr(env, "spawn_reg", None)
    target_decl = reg["by_name"].get(component_name) if reg else None
    provides = {k: svc for k, svc, _line in (target_decl.provides if target_decl else [])}
    if key not in provides:
        known = ", ".join(f"`{k}`" for k in sorted(provides)) or "<nothing>"
        raise RevlError(
            env.filename, line,
            f"`{key}` is not a provision of {component_name}",
            hint=f"a spawn handle reads only a key its component provides — "
                 f"{component_name} provides {known}",
        )
    return {
        "kind": "instance-get",
        "target": target,
        "component": component_name,
        "key": key,
        # the service type the key yields — the typing rule's result, frozen
        # inline so no tier re-derives it (mirrors `spawn.realms` carrying the
        # provided keys); advisory, like any host-frontier value's type
        "service": provides[key],
        "line": line,
    }


def _lower_expr(expr, env: Env, mode: str):
    """mode: 'setup' | 'undo' | 'emit'.

    Emission calls are illegal in 'setup' (must be marked `emit`; the outer
    call of an `emit` statement is verified by `_lower_emit`) and — documented
    v0 exception — permitted bare in 'undo', where the expression position
    leaves no room for a marker (DESIGN §3.5 note; the compensate slot
    arrives with IR v1/A5).
    """
    if isinstance(expr, SpawnExpr):
        return _lower_spawn(expr, env, mode)
    if isinstance(expr, Lit):
        if expr.value is None:
            raise null_error(env.filename, expr.line)
        return {"kind": "lit", "value": _literal_value(expr.value, env.filename, expr.line)}
    if isinstance(expr, Interp):
        template = []
        args = []
        for kind, value in expr.parts:
            if kind == "text":
                template.append(value.replace("$", "$$"))  # A4: literal dollars
            else:
                template.append(f"${len(args)}")
                # `value` is a full expression AST; lower it in this context
                args.append(_lower_expr(value, env, mode))
        return {"kind": "format", "template": "".join(template), "args": args}
    if isinstance(expr, Postfix):
        return _lower_postfix(expr, env, mode)
    # v2.0 unified grammar: component positions carry the full pure-expression
    # stratum; the mode/context ride on env so the shared lowering needs no
    # signature churn (finding 1 — strata compose)
    saved = getattr(env, "_expr_mode", None), getattr(env, "_plain_body", None)
    env._expr_mode, env._plain_body = mode, True
    try:
        return _lower_component_pure_expr(
            expr, env, _component_scope(env), getattr(env, "callables", set()))
    finally:
        env._expr_mode, env._plain_body = saved


def _lower_postfix(expr: Postfix, env: Env, mode: str):
    comp = env.component
    head = expr.head
    ops = list(expr.ops)

    if head == "config":
        if not ops or ops[0].args is not None:
            raise RevlError(env.filename, expr.line, "`config` is accessed as `config.<field>`")
        field = ops.pop(0)
        if field.name not in env.config_fields:
            raise RevlError(env.filename, field.line,
                            f"`{field.name}` is not a config field of {comp.name}")
        node = {"kind": "config", "field": field.name}
    elif head in env.params or head in env.locals:
        node = _resolve_provision_alias(
            {"kind": "name", "id": env.params.get(head) or env.locals[head]}, env)
    elif head in env.stream_requires:
        # item 130: a required `Stream[T]` coeffect. The capability has no
        # methods — `subscribe` is the whole surface — so the ONLY position a
        # bare read is admitted in is a `subscribe` head, and any method call on
        # it is refused by name rather than resolved against a service table the
        # requirement was never in.
        _refuse_stream_requirement_as_service(
            env, head, ops[0].name if ops else None, expr.line)
        if not getattr(env, "_stream_head_position", False):
            _refuse_stream_requirement_read(env, head, env.filename, expr.line)
        node = {"kind": "req", "name": head}
    elif head in env.requires:
        if not ops or ops[0].args is None:
            raise RevlError(env.filename, expr.line,
                            f"a required service is used through its methods: `{head}.<method>(...)`")
        node = {"kind": "req", "name": head}
    elif head[:1].isupper() and ops and ops[0].args is not None:
        call = ops.pop(0)
        # the Map VALUE constructor (docs/stdlib-2.0.md §Map): a value, not
        # a host acquisition — intercepted before host_check.
        if head == "Map" and call.name == "empty":
            if call.args:
                raise RevlError(
                    env.filename, expr.line,
                    f"`Map.empty()` takes no arguments, {len(call.args)} given",
                    hint="build up an empty map with `set`: "
                         "`Map.empty().set(\"k\", v)`",
                )
            node = {"kind": "maplit", "entries": []}
            for op in ops:
                if op.args is None:
                    raise RevlError(env.filename, expr.line,
                                    "field access `.{}` is not supported in v0 — only method calls".format(op.name))
                node = {"kind": "builtin", "method": op.name,
                        "target": node,
                        "args": [_lower_expr(a, env, mode) for a in op.args]}
            return node
        host_args = [_lower_expr(a, env, mode) for a in call.args]
        host_check(f"{head}.{call.name}",
                   [infer_ir(a, env.type_env, env.types, env.services)
                    for a in host_args],
                   env.filename, expr.line)
        node = {"kind": "host", "fn": f"{head}.{call.name}", "args": host_args}
    else:
        declared = ", ".join(f"`{r}`" for r in env.requires) or "<nothing>"
        raise RevlError(
            env.filename, expr.line,
            f"`{head}` is not a declared requirement of {comp.name}",
            hint=f"component {comp.name} requires {declared} — add `requires {head}: <Service>`?",
        )

    for op in ops:
        if op.args is None:
            # The one legal bare field access in a component/method body is
            # reading a provision off a spawn handle: `s.<key>` where
            # `s : Instance[C]` and `<key>` is a key C provides. Only a name
            # the current component itself bound to a handle can carry the
            # `Instance[C]` type, so this never becomes a lookup of a sibling's
            # or the root's provision — it is the parent reaching *its own*
            # instance (supervision-tree addressing, docs/design-v2-instances.md
            # decision 1/2).
            inst = _instance_handle_component(node, env)
            if inst is not None:
                node = _lower_instance_get(node, op.name, op.line, inst, env)
                continue
            raise RevlError(env.filename, op.line,
                            f"field access `.{op.name}` is not supported in v0 — only method calls")
        if node["kind"] == "req":
            svc = env.services[env.requires[node["name"]]]
            decl = svc.methods.get(op.name)
            if decl is None:
                raise RevlError(env.filename, op.line,
                                f"`{node['name']}.{op.name}` is not a method of service {svc.name}")
            if len(op.args) != len(decl.params):
                raise RevlError(env.filename, op.line,
                                f"`{node['name']}.{op.name}` takes {len(decl.params)} "
                                f"argument(s), {len(op.args)} given")
            if decl.emission and mode == "setup":
                raise RevlError(
                    env.filename, op.line,
                    f"call to emission `{node['name']}.{op.name}` must be marked `emit` (G4)",
                    hint="an emission crosses the system boundary and cannot be reverted; "
                         "`emit` makes that visible at the call site",
                )
            lowered = [_lower_expr(a, env, mode) for a in op.args]
            for arg, (pname, ptype) in zip(lowered, decl.params):
                actual = infer_ir(arg, env.type_env, env.types, env.services)
                if ptype and actual and not compatible(ptype, actual, env.types):
                    raise mismatch(env.filename, op.line,
                                   f"`{node['name']}.{op.name}` argument `{pname}`",
                                   ptype, actual)
            node = {"kind": "call", "target": node, "method": op.name, "args": lowered}
            continue
        # host provenance (docs/stdlib-2.0.md §Map): a verb call on a local
        # bound to a host acquisition (`effect store.insert(k, v)` in an
        # activation or provide-method body) is checked against that family's
        # surface (item 401). An unknown verb is refused here (HOST-METHOD)
        # instead of lowering to a call that only crashes at the host runtime,
        # the item-84 shape. Only the FIRST verb off the host local is checked;
        # a host verb's RESULT is opaque, so a chained call reads no family.
        host_args = [_lower_expr(a, env, mode) for a in op.args]
        if node.get("kind") == "name" and node.get("id") in env.host_locals:
            _check_host_verb(
                env.host_locals[node["id"]], op.name, len(host_args),
                env.filename, op.line)
        node = {
            "kind": "call",
            "target": node,
            "method": op.name,
            "args": host_args,
        }
    return node


def _node_desc(node: dict) -> str:
    if node.get("kind") == "call":
        target = node.get("target")
        if isinstance(target, dict) and target.get("kind") == "req":
            return f"`{target['name']}.{node['method']}`"
        callee = node.get("callee")
        if isinstance(callee, dict) and callee.get("kind") == "field":
            recv = callee.get("target")
            if isinstance(recv, dict) and recv.get("kind") == "instance-get":
                # a provision method call off a spawn handle: name it the way
                # it was written, `<key>.<method>`, so the diagnostic points at
                # the provision access rather than "a call to <method>"
                return f"`{recv.get('key')}.{callee.get('name')}`"
            return f"a call to `{callee.get('name')}`"
        return f"a call to `{node.get('method')}`"
    return f"a {node.get('kind', 'value')} expression"


# ---------------------------------------------------------------- linker

def _link(program: Program, components: list[dict], ambient_components: list[dict],
          templates: set | None = None, errors: list | None = None) -> dict:
    """G2/G3 over the union of ambient (running) and new components, and the
    composition manifest (cordisc-compatible schema: components with
    name/file/inject/provides, plus loadOrder).

    `templates` names components that are *spawn targets* — runtime instances,
    not static composition members (docs/design-v2-instances.md). They are
    excluded from `entries`, so their provisions never enter the link-time
    G2/G3 table and they take no place in `loadOrder`: at runtime each is
    instantiated into its own fresh local realm by `spawn`, disjoint by
    construction (decision 5/6). Non-spawning programs have no templates, so
    the manifest is byte-identical to before.

    `errors` (item 386, Change 2): when a collect-all sink is supplied, every G2
    provision conflict, multi-realm route gap, and G3 cycle is APPENDED to it
    instead of raised, so the linker reports all of them in one pass — capped at
    one reported cycle per strongly-connected set to avoid overlapping-path
    noise. When `errors is None` (a direct caller), the first refusal is raised,
    the legacy fail-fast behavior."""
    templates = templates or set()

    def _fail(err: RevlError) -> None:
        """Collect the refusal if a sink was supplied, else raise it (legacy)."""
        if errors is None:
            raise err
        errors.append(err)

    # name-keyed, not positionally zipped: a collected duplicate-component
    # refusal (item 386) can leave `components` shorter than
    # `program.components`, which would misalign a `zip`. First declaration of
    # a name wins its line.
    lines: dict[str, int] = {}
    for decl in program.components:
        lines.setdefault(decl.name, decl.line)

    entries: list[dict] = []
    for amb in ambient_components:
        entry = {
            "name": amb.get("name"),
            "file": amb.get("file", ""),
            "inject": list(amb.get("inject") or []),
            "provides": list(amb.get("provides") or []),
        }
        if amb.get("isolate"):
            entry["isolate"] = dict(amb["isolate"])
        if amb.get("intercept"):
            entry["intercept"] = dict(amb["intercept"])
        if amb.get("routes"):
            entry["routes"] = {k: dict(v) for k, v in amb["routes"].items()}
        entries.append(entry)
    for comp in components:
        if comp["name"] in templates:
            # a spawn target is instantiated at runtime, not composed: its
            # provisions live in fresh per-instance local realms, so it never
            # participates in the static G2/G3 table or loadOrder (decision 5/6)
            continue
        entry = {
            "name": comp["name"],
            "file": comp.get("source", ""),
            "inject": sorted(comp["requires"]),
            "provides": sorted(comp["provides"]),
        }
        if comp.get("isolate"):
            entry["isolate"] = dict(comp["isolate"])
        if comp.get("intercept"):
            entry["intercept"] = dict(comp["intercept"])
        if comp.get("routes"):
            entry["routes"] = {k: dict(v) for k, v in comp["routes"].items()}
        # item 350: the boot marking travels into the composition manifest, so a
        # consumer reading the manifest alone (the linker, `revl audit`, a
        # deploy conductor) can find the environment contract's arrival point
        # without re-reading source. Conditional, so a boot-free composition's
        # manifest is byte-identical.
        if comp.get("boot"):
            entry["boot"] = True
        entries.append(entry)

    def _line(name: str) -> int:
        return lines.get(name, 1)

    # item 350: AT MOST ONE boot component per composition. The boot component is
    # the composition's single declared arrival point for host-injected
    # environment values; two of them would mean two contracts, and an admission
    # check against "the" contract would silently check only one of them — a
    # fail-open the check exists to remove. Ambient (running) components are in
    # `entries` too, so a swap that would introduce a second boot component is
    # caught at link, before the generation is admitted.
    boot_names = [entry["name"] for entry in entries if entry.get("boot")]
    if len(boot_names) > 1:
        first, *rest = boot_names
        _fail(RevlError(
            program.filename, _line(rest[0]),
            "a composition declares at most one `boot` component, found "
            + ", ".join(boot_names),
            hint="the boot component IS the environment contract — the exhaustive, "
                 "typed list of what the host must inject. Two contracts cannot both "
                 "be the exhaustive one, so merge the fields into "
                 f"`boot component {first}` and drop `boot` from the rest (item 350)",
        ))

    # why-trace locations: a locally compiled component knows its own file and
    # declaration line; an *ambient* entry (read back from a running manifest)
    # has a file but no line, so `line` stays None there rather than lying.
    by_name = {entry["name"]: entry for entry in entries}

    def _where(name: str) -> tuple[str | None, int | None]:
        entry = by_name.get(name) or {}
        file = entry.get("file") or program.filename or None
        return (file, lines.get(name))

    def _realm(entry: dict, key: str) -> str:
        return (entry.get("isolate") or {}).get(key, SHARED_REALM)

    # v2: provision disjointness is per-(key, realm) — same key in different
    # realms is the multi-tenancy feature, same realm is the conflict. The
    # realm is named only when it isn't the shared one, so v1 diagnostics
    # are unchanged.
    provider_of: dict[tuple[str, str], str] = {}
    for entry in entries:
        for key in entry["provides"]:
            realm = _realm(entry, key)
            where = "" if realm == SHARED_REALM else f" in realm `{realm}`"
            if (key, realm) in provider_of:
                first = provider_of[(key, realm)]
                # both exhibits, both locations: the message names them, the
                # trace says where to go and look (why.py)
                detail = f"provides `{key}`{where}"
                why = WhyTrace(
                    kind="provision-conflict", subject=key, shape=SET,
                    steps=[
                        TraceStep(first, "provider", *_where(first), detail),
                        TraceStep(entry["name"], "provider",
                                  *_where(entry["name"]), detail),
                    ])
                _fail(RevlError(
                    program.filename, _line(entry["name"]),
                    f"provision conflict: key `{key}`{where} is provided "
                    f"by both {provider_of[(key, realm)]} and {entry['name']} (G2)",
                    why=why,
                ))
                # keep the FIRST provider registered (item 386): the conflict is
                # reported once, and downstream route/edge resolution still finds
                # a provider for the key rather than fabricating a "no provider".
                continue
            provider_of[(key, realm)] = entry["name"]

    def _routes(entry: dict) -> dict:
        return entry.get("routes") or {}

    # multi-realm bind verification (item 162): a `realms(...)` route binds the
    # key across N named realms, and the consumer routes across them at runtime.
    # The compiler verifies EACH named realm has a provider of the key — a route
    # that names a realm with no provider would dangle at that leg. This does NOT
    # relax G2 (one provider per (key, realm) is still enforced above); it is the
    # dual existence check on the consumption side. Providers of a routed key may
    # sit in the shared realm too (`realm` unnamed) — a route target is matched
    # against the same per-(key, realm) table, so the named realm must have its
    # own provider.
    for entry in entries:
        for key, route in _routes(entry).items():
            for realm in route["realms"]:
                if (key, realm) not in provider_of:
                    strat = route.get("strategy")
                    strat_where = f" strategy(`{strat}`)" if strat else ""
                    why = WhyTrace(
                        kind="unmet-requirement", subject=key, shape=CHAIN,
                        steps=[TraceStep(entry["name"], "consumer",
                                         *_where(entry["name"]),
                                         f"routes `{key}` across "
                                         f"{len(route['realms'])} realms{strat_where}")])
                    _fail(RevlError(
                        program.filename, _line(entry["name"]),
                        f"multi-realm bind of `{key}` in {entry['name']} names realm "
                        f"`{realm}`, but no component provides `{key}` in realm `{realm}` "
                        f"(item 162: every routed realm needs a provider)",
                        hint="a `realms(...)` route distributes across backend realms; each "
                             "named realm must have its own provider of the key (G2 keeps it "
                             "to exactly one). Add a provider isolated into realm "
                             f"`{realm}`, or drop `{realm}` from the route",
                        why=why,
                    ))

    # edges: provider -> consumer where the consumer's realm for a key
    # matches the provider's — realm separation legitimately breaks cycles
    graph: dict[str, list[str]] = {entry["name"]: [] for entry in entries}
    indegree: dict[str, int] = {entry["name"]: 0 for entry in entries}
    # which key carries each provider -> consumer edge, so a cycle can say
    # *what* is being waited on at every hop and not just who waits
    edge_key: dict[tuple[str, str], str] = {}
    for entry in entries:
        # a routed key is resolved per-realm below, not through the single-realm
        # table — skip it here so a stray shared-realm provider does not shadow
        # the route's own targets.
        routed = _routes(entry)
        for key in entry["inject"]:
            if key in routed:
                # one edge per routed realm: every backend provider must be
                # ACTIVE before the consumer that routes to it (loadOrder), and
                # each leg can still surface in a cycle trace by its key.
                for realm in routed[key]["realms"]:
                    provider = provider_of.get((key, realm))
                    if provider == entry["name"]:  # pragma: no cover — a route
                        # targets a *required* key; a self-provision in a routed
                        # realm cannot arise (the key is not this comp's provision)
                        continue
                    if provider is not None:
                        graph[provider].append(entry["name"])
                        edge_key.setdefault((provider, entry["name"]), key)
                        indegree[entry["name"]] += 1
                continue
            provider = provider_of.get((key, _realm(entry, key)))
            if provider == entry["name"]:
                name = entry["name"]
                _fail(RevlError(
                    program.filename, _line(name),
                    f"component {name} requires a key it provides itself (`{key}`) (G3)",
                    why=WhyTrace(
                        kind="dependency-cycle", subject=name, shape=CHAIN,
                        steps=[TraceStep(name, "component", *_where(name),
                                         f"provides and requires `{key}`")]),
                ))
                continue
            if provider is not None:
                graph[provider].append(entry["name"])
                edge_key.setdefault((provider, entry["name"]), key)
                indegree[entry["name"]] += 1

    state: dict[str, int] = {}
    stack: list[str] = []
    # item 386, Change 2: nodes already named in a reported cycle. A single
    # strongly-connected set has many overlapping cycles; reporting each is
    # noise, so once any node of a cycle is reported we suppress further cycles
    # that touch it — one G3 per SCC.
    cycled: set = set()

    def visit(name: str):
        state[name] = 1
        stack.append(name)
        for succ in graph[name]:
            if state.get(succ) == 1:
                cycle = stack[stack.index(succ):] + [succ]
                # one step per hop: each names the key it provides onward, so
                # the closing repeat shows the edge that shuts the loop
                steps = [
                    TraceStep(node, "component", *_where(node),
                              (f"provides `{edge_key[(node, cycle[i + 1])]}`"
                               if i + 1 < len(cycle) else None))
                    for i, node in enumerate(cycle)
                ]
                cyc_err = RevlError(
                    program.filename, _line(succ),
                    "dependency cycle: " + " -> ".join(cycle) + " (G3)",
                    why=WhyTrace(kind="dependency-cycle", subject=succ,
                                 steps=steps, shape=CHAIN))
                if errors is None:
                    raise cyc_err
                if not any(node in cycled for node in cycle):
                    cycled.update(cycle)
                    errors.append(cyc_err)
            if state.get(succ, 0) == 0:
                visit(succ)
        stack.pop()
        state[name] = 2

    for entry in entries:
        if state.get(entry["name"], 0) == 0:
            visit(entry["name"])

    # providers-first load order (Kahn, stable in entry order)
    order: list[str] = []
    ready = deque(e["name"] for e in entries if indegree[e["name"]] == 0)
    while ready:
        name = ready.popleft()
        order.append(name)
        for succ in graph[name]:
            indegree[succ] -= 1
            if indegree[succ] == 0:
                ready.append(succ)

    manifest = {"components": entries, "loadOrder": order}
    if templates:
        # G8: the instance dimension is dynamic. These components are not
        # statically composed — each is instantiated `× dynamic` times at
        # runtime — so they carry no loadOrder position; the audit reports
        # them separately (docs/design-v2-instances.md, decision 7).
        manifest["templates"] = sorted(templates)
    return manifest


# ------------------------------------------------------------------ spawn G4

def _find_spawn_nodes(node) -> "list[dict]":
    """Every `spawn` acquire node reachable in a lowered body subtree."""
    out: list[dict] = []
    if isinstance(node, dict):
        if node.get("kind") == "spawn":
            out.append(node)
        for value in node.values():
            out.extend(_find_spawn_nodes(value))
    elif isinstance(node, list):
        for value in node:
            out.extend(_find_spawn_nodes(value))
    return out


def _collect_emit_caps(node, caps: set) -> None:
    """The capabilities an `emit` step in a lowered body crosses. A req-keyed
    emission is capability = the key (G2 names the boundary); any host emission
    is the unnameable `*` (no `emission[...]` list can name it)."""
    if isinstance(node, dict):
        if node.get("step") == "emit":
            expr = node.get("expr") or {}
            target = expr.get("target") or {}
            if target.get("kind") == "req":
                caps.add(target.get("name"))
            else:
                caps.add("*")
        for value in node.values():
            _collect_emit_caps(value, caps)
    elif isinstance(node, list):
        for value in node:
            _collect_emit_caps(value, caps)


# The token namespace for a boundary that has NO declared capability token: the
# G2 wiring key names it. A declared capability token is a dotted identifier
# (`_capability_list`/`_capability_params` in parser.py), so a token carrying a
# `:` is UNSPELLABLE in source and a wiring key can never collide with — and so
# never be mistaken by `covers` for — a declared boundary. Rendered back to the
# bare key by `_cap_render`, so refusal messages and the G8 audit chain read
# exactly as before.
_WIRE_NS = "key:"


def _wire_cap(key: str) -> "object":
    """The fold element for a wiring key with no declared capability token."""
    from . import cap_order  # noqa: PLC0415 - lazy, avoids an import cycle
    return cap_order.Cap(_WIRE_NS + key, ())


def _cap_render(cap: "object") -> str:
    """The source-facing spelling of a fold element: a namespaced wiring key
    renders as the bare key, everything else as its canonical `(T, P)`."""
    text = cap.to_str()
    return text[len(_WIRE_NS):] if text.startswith(_WIRE_NS) else text


def _cap_keyed(key: str, cap_str: str) -> "object":
    """The key-to-token bridge (item 294): resolve a declared emission token
    string to the `Cap` it names — the DECLARED token and its valuation.

    `key` is the local `requires` spelling the declaration was reached through
    and is deliberately NOT the token: two components wire the same boundary
    under whatever key each likes, so keying the fold element by the wiring key
    compared two identifiers that name nothing in common. `covers` clause 1 is a
    BOUNDARY identity test, so both sides must be spelled in the one namespace
    the boundary actually has — the declared token, the same source of truth
    `parallel._resolve_emission` reads for the very same crossings. The wiring
    key still names the boundary where the declaration does NOT (a method with
    `emission` and no `capabilities[...]` list, an unresolvable service): that
    element is built by `_wire_cap` in its own token namespace, so a key spelling
    can never masquerade as a declared token.

    A malformed stored spelling (impossible on a validated IR) degrades to the
    unnameable `*`, which is fail-closed on BOTH sides: as a reach element it is
    covered by nothing, as a held element it covers nothing but `*`."""
    from . import cap_order  # noqa: PLC0415 - lazy, avoids an import cycle
    del key  # the boundary is the declared token, never the local wiring key
    try:
        return cap_order.parse_cap(cap_str)
    except cap_order.CapError:
        return cap_order.Cap("*", ())


def _emit_step_caps_pairs(node: dict, requires_map: dict, services: dict) -> list:
    """The `Cap`(s) a single lowered `emit` step crosses, resolved through the
    key-to-token bridge. A req-keyed emission resolves key -> requires-target
    service -> the method being called -> that method's `emission[...]`
    valuation(s); a bare or unresolvable method declares no token, so the G2
    wiring key names the boundary (`_wire_cap`, its own namespace); a host
    emission is the unnameable `*`."""
    from . import cap_order  # noqa: PLC0415 - lazy, avoids an import cycle
    expr = node.get("expr") or {}
    target = expr.get("target") or {}
    if target.get("kind") != "req":
        return [cap_order.Cap("*", ())]
    key = target.get("name")
    svc = services.get(requires_map.get(key)) if requires_map else None
    decl = svc.methods.get(expr.get("method")) if svc is not None else None
    cap_strs = getattr(decl, "capabilities", None) if decl is not None else None
    if not cap_strs:
        return [_wire_cap(key)]
    return [_cap_keyed(key, s) for s in cap_strs]


def _collect_emit_caps_pairs(node, caps: set, requires_map: dict,
                             services: dict) -> None:
    """`_collect_emit_caps`, resolved to structured `Cap`s through the bridge.
    Same traversal (emit STEPS only), so a parameter-free body yields the same
    set of elements as today, spelled as bare `Cap`s."""
    if isinstance(node, dict):
        if node.get("step") == "emit":
            caps.update(_emit_step_caps_pairs(node, requires_map, services))
        for value in node.values():
            _collect_emit_caps_pairs(value, caps, requires_map, services)
    elif isinstance(node, list):
        for value in node:
            _collect_emit_caps_pairs(value, caps, requires_map, services)


def _spawn_reached_surface_pairs(components: list[dict],
                                 services: dict) -> dict[str, set]:
    """Per-component actual capability reach as structured `(T, P)` pairs,
    resolved through the bridge: the boundaries a component's own code crosses
    (the key-and-valuation of every `emit` step, `*` for a host emission), so a
    parameterized crossing survives into the attenuation fold as its valuation
    rather than degrading to a bare wiring key."""
    surface: dict[str, set] = {}
    for comp in components:
        requires_map = comp.get("requires") or {}
        caps: set = set()
        _collect_emit_caps_pairs(comp.get("body") or [], caps, requires_map,
                                 services)
        surface[comp["name"]] = caps
    return surface


def _held_capabilities_pairs(comp: dict, base_surface: set,
                             services: dict) -> set:
    """What a component holds (the capabilities it may pass down to a child it
    spawns, item 66, lineage) as structured `(T, P)` pairs. A requires key
    resolves, through the same bridge, to the DECLARED emission token(s) of the
    service it wires — the boundary the wiring reaches, not the local spelling
    it was reached through — carrying each declaration's valuation, which is what
    lets a parent that holds `fs.write(path="/tmp")` refuse a child reaching
    wider. A method that declares `emission` with no capability list names no
    token, so the G2 wiring key names that boundary (`_wire_cap`, its own token
    namespace). A plain or unresolvable service likewise keeps the namespaced
    key; a child cannot reach a non-emission key, so that element only ever
    covers another key-named boundary of the same name."""
    held: set = set(base_surface)
    for key, svcname in (comp.get("requires") or {}).items():
        svc = services.get(svcname)
        emission_methods = ([m for m in svc.methods.values() if m.emission]
                            if svc is not None else [])
        if not emission_methods:
            held.add(_wire_cap(key))
            continue
        for m in emission_methods:
            if not m.capabilities:
                held.add(_wire_cap(key))
            else:
                for s in m.capabilities:
                    held.add(_cap_keyed(key, s))
    return held


def _spawn_emission_surface(components: list[dict], services: dict) -> dict[str, set]:
    """Per-component upper bound on what activating an instance of it can emit.

    A conservative, sound over-approximation (decision 8): the union of every
    emission method declared by the services it provides (uncapped -> `*`), its
    own `emit` steps, and — by fixpoint over the spawn graph — everything its
    own spawned children can emit. Never under-approximates, so the bound it
    enforces on a spawner can only be tighter than the truth, never looser."""
    surface: dict[str, set] = {}
    for comp in components:
        caps: set = set()
        for _key, svcname in (comp.get("provides") or {}).items():
            svc = services.get(svcname)
            if svc is None:
                continue
            for m in svc.methods.values():
                if m.emission:
                    caps.update({"*"} if m.capabilities is None else set(m.capabilities))
        _collect_emit_caps(comp.get("body") or [], caps)
        surface[comp["name"]] = caps
    # the transitive closure over the spawn graph is applied by the caller,
    # which holds the edge list
    return surface


def _spawn_surface_closure(base: dict[str, set], edges: list) -> dict[str, set]:
    """Fold the spawn graph into a per-component base surface: after this, a
    component's set is everything it can emit *plus* everything its transitive
    spawned children can (`docs/capabilities.md`). The least fixed point the
    edge list induces — the same closure `_check_spawn_emission_bounds` takes,
    factored out so the attenuation check reads the *reachable* set of a child
    (its own emissions and its descendants') against what a spawner holds."""
    closed: dict[str, set] = {name: set(caps) for name, caps in base.items()}
    changed = True
    while changed:
        changed = False
        for parent, child in edges:
            before = len(closed.setdefault(parent, set()))
            closed[parent].update(closed.get(child, set()))
            if len(closed[parent]) != before:
                changed = True
    return closed


def _activation_spawn_sites(comp: dict) -> "list[dict]":
    """The `spawn` nodes in a component's *activation* body — the top-level
    supervision `let s = effect spawn C ...`, excluding spawns nested inside a
    `provide` method. Provide-method spawns carry an `emission[...]` clause that
    already bounds them (`_check_spawn_emission_bounds`); the activation body
    has no such clause, which is exactly the hole item 66 closes: without an
    attenuation rule a supervisor is a capability amplifier."""
    sites: list[dict] = []
    for step in comp.get("body") or []:
        if step.get("step") == "provide":
            continue
        sites.extend(_find_spawn_nodes(step))
    return sites


def _spawn_literal_bindings(spawn: dict) -> dict:
    """The spawn-site `with { field: <literal> }` bindings that resolve a child's
    per-instance `config.` capability symbols (item 294, Slice 2).

    Maps a config field to its python STRING-literal value. A field bound to any
    NON-literal expression (a name, a call, a config passthrough) is OMITTED, so
    its symbol stays unresolved - incomparable to a literal parent, hence refused
    (fail closed). This is the design's first symbol rule: only a literal `with`
    binding substitutes."""
    out: dict = {}
    for field, node in (spawn.get("config") or {}).items():
        if (isinstance(node, dict) and node.get("kind") == "lit"
                and isinstance(node.get("value"), str)):
            out[field] = node["value"]
    return out


def _cap_offending(cap: "object") -> str:
    """Render an uncovered capability for a refusal message: the unnameable host
    boundary reads in words, everything else as its canonical `(T, P)` spelling
    (`fs.write`, `fs.write(path="/etc")`, or the bare wiring key that names a
    boundary no declaration tokens)."""
    return ("an unnameable host boundary" if cap.token == "*"
            else f"`{_cap_render(cap)}`")


def _widening_reason(cap: "object", held: set) -> str | None:
    """Why a child capability is not covered by any held one, when the token IS
    held but the VALUATION widens it (the item 294 case). Names the parameter
    and the direction; returns None when the token itself is absent (today's
    missing-boundary case, whose message is enough)."""
    same_token = sorted((h for h in held
                         if h.token == cap.token and h.token != "*"),
                        key=lambda h: h.to_str())
    if not same_token:
        return None
    from . import cap_order  # noqa: PLC0415 - lazy, avoids an import cycle
    child_params = cap.param_map()
    # an UNRESOLVED per-instance symbol (item 294 Slice 2): opaque to the order,
    # so incomparable to the parent's literal cone. Names the fix - bind the
    # config field to a literal at the spawn site so it resolves into the cone.
    for name, cval in cap.params:
        if isinstance(cval, cap_order.Symbol):
            return (f"a per-instance value `{cval.ref}` on `{cap.token}` is "
                    f"unresolved, so it is incomparable to the parent's cone "
                    f"(`{_cap_render(same_token[0])}`); bind `{cval.field}` to a "
                    f"string literal in the spawn's `with {{ }}` block so the "
                    f"per-instance path resolves into the parent's cone")
    for h in same_token:
        for name, _wide in h.params:
            if name not in child_params:
                return (f"a capability parameter only narrows; "
                        f"`{_cap_render(cap)}` drops `{name}`, which "
                        f"`{_cap_render(h)}` binds; a dropped parameter is "
                        f"wider, so the child reaches more than the parent "
                        f"holds")
    # the token is held with the parameter bound on both sides but the value
    # widens (e.g. a path outside the held cone)
    h = same_token[0]
    return (f"a capability parameter only narrows; `{_cap_render(cap)}` is wider "
            f"than the held `{_cap_render(h)}` (its value is not within the "
            f"parent's cone)")


def _cap_sorted_strs(caps: set) -> list[str]:
    """Canonical spellings of a Cap set, sorted (the audit-chain rendering). A
    key-named boundary renders as the bare key, byte-identical to the old
    string, so a parameter-free chain is unchanged."""
    return sorted(_cap_render(c) for c in caps)


def _declares_calls_ceiling(services: dict) -> bool:
    """Whether ANY emission method declares a static `calls`/`requests` budget
    ceiling. The static budget check (`_check_declared_ceilings`) is gated on
    this so a budget-free composition runs no cardinality pass and is
    byte-identical: the whole feature is inert unless a program opts in."""
    from . import cap_order  # noqa: PLC0415 - lazy, avoids an import cycle
    for svc in services.values():
        for m in svc.methods.values():
            for capstr in (m.capabilities or ()):
                try:
                    _, ceils = cap_order.split_ceilings(cap_order.parse_cap(capstr))
                except cap_order.CapError:
                    continue
                if "calls" in ceils:
                    return True
    return False


def _check_declared_ceilings(components: list[dict], services: dict,
                             fns: list, externs: list, filename: str) -> None:
    """The STATIC budget check (item 260 §3.2): `budget.requests`/`calls`
    reconciles onto the SAME quantity the cardinality analysis (§2) proves, so
    the check is exactly "proved-max <= declared calls".

    For every component capability that declares a `calls` ceiling, refuse when
    the proved per-activation maximum EXCEEDS it (a G4 count-axis refusal,
    sharpening G4's set bound, §4), and refuse a declared FINITE ceiling over a
    body whose count is `unbounded` or only `bounded-symbolic`, an unprovable
    ceiling (§3.2: "a runaway loop becomes a red compile"). Gated by
    `_declares_calls_ceiling`, so a budget-free program never reaches here."""
    if not _declares_calls_ceiling(services):
        return
    from . import cap_order  # noqa: PLC0415 - lazy, avoids an import cycle
    from .cardinality import cardinality  # noqa: PLC0415 - lazy, avoids a cycle

    # the minimal IR projection `cardinality` reads: components, the services'
    # emission/capabilities, and the fn/extern reach it folds over.
    services_ir = {
        name: {"methods": {
            m.name: {"emission": m.emission,
                     **({"capabilities": list(m.capabilities)}
                        if m.capabilities is not None else {})}
            for m in svc.methods.values()}}
        for name, svc in services.items()}
    card_ir: dict = {"components": components, "services": services_ir}
    if fns:
        card_ir["functions"] = fns
    if externs:
        card_ir["externs"] = externs

    report = cardinality(card_ir)
    comp_line = {c["name"]: c.get("line", 1) for c in components}
    comp_src = {c["name"]: c.get("source") for c in components}
    for cname in sorted(report):
        entry = report[cname]
        for token, cell in entry["per_capability"].items():
            _, ceils = cap_order.split_ceilings(cap_order.parse_cap(token))
            declared = ceils.get("calls")
            if declared is None:
                continue
            bare = cap_order.split_ceilings(cap_order.parse_cap(token))[0].to_str()
            line = comp_line.get(cname, 1)
            src = comp_src.get(cname) or filename
            if cell["kind"] == "bounded" and cell["bound"] > declared:
                raise RevlError(
                    src, line,
                    f"`{cname}` may cross `{bare}` up to {cell['bound']} times "
                    f"per activation but its declaration caps `calls={declared}`",
                    hint="a `budget.requests`/`calls` ceiling bounds the proved "
                         "per-activation crossing count (item 260 §3.2); lower "
                         "the number of crossings, or raise the declared ceiling "
                         "to at least the proved maximum",
                    code="G4", category="emission-budget",
                )
            if cell["kind"] in ("unbounded", "bounded-symbolic"):
                why = (cell.get("reason") if cell["kind"] == "unbounded"
                       else "its ceiling is symbolic until composition pins the "
                            f"config field `{cell.get('expr')}`")
                raise RevlError(
                    src, line,
                    f"`{cname}` declares a finite budget `calls={declared}` on "
                    f"`{bare}` but its per-activation crossing count is not "
                    f"statically provable ({why})",
                    hint="a declared finite `calls` ceiling requires a proved "
                         "cardinality bound (item 260 §3.2); make the crossing "
                         "bounded (a decreasing-fuel iteration, §2.2) or drop "
                         "the ceiling and rely on the runtime counter",
                    code="G4", category="emission-budget",
                )


def _strip_ceilings(caps: set) -> set:
    """The resource-only projection of a Cap set (item 260 §3.3): every ceiling
    parameter (`calls`, `size`, `time`) removed. A crossing binds no ceiling, so
    the crossing-coverage fold `covers_set` runs is ceiling-BLIND; budget
    attenuation is a separate question handled by `_ceiling_attenuation_check`
    over the UNSTRIPPED pairs. Byte-identical for a budget-free program (no cap
    carries a ceiling, so nothing is stripped)."""
    from . import cap_order  # noqa: PLC0415 - lazy, avoids an import cycle
    return {cap_order.split_ceilings(c)[0] for c in caps}


def _ceiling_attenuation_check(held: set, child_reach: set) -> "list[dict]":
    """The DEDICATED budget/ceiling attenuation check (item 260 §3.3, the HIGH
    correction). `covers_set` deliberately STRIPS ceilings, so it never sees a
    budget: a child budget WIDER than its parent's would slip past the
    crossing-coverage fold. This parallel check reads the UNSTRIPPED `(T, P)`
    pairs and refuses, per ceiling param `p`, any `child_ceiling(p) >
    parent_ceiling(p)`, and a child that DROPS a ceiling its parent declares,
    since a missing child ceiling reads as `+inf` (unbounded, hence wider). It
    reuses the SAME `_param_leq` ceiling order `covers` would have used.

    The parent's held ceiling for a crossing is its DECLARED ceiling (the §5.3
    conservative first cut: the parent's own pre-spawn spend is NOT yet
    subtracted). A budget is scoped to a RESOURCE CONE, never to a bare token:
    the only held caps that can license a child crossing are those whose
    resource-only projection COVERS the crossing's own (`covers` on the stripped
    pairs, the same cone test the crossing fold uses). Aggregating per token
    instead — the old `max` over every same-token held cap — let a generous
    budget on a sibling cone (`fs(calls=100,path="/b")`) license a crossing on a
    cone the parent barely holds (`fs(calls=1,path="/a")`), which is conservative
    in the UNSOUND direction.

    Nor is the rule a per-parameter `max` over the covering caps: a parent
    holding `fs(path="/a",calls=1,size=100)` and `fs(path="/a",calls=100,size=1)`
    holds neither `calls=100` AND `size=100` together. The sound rule is
    EXISTENTIAL — one single held cap must license the whole crossing: its cone
    covers, and every ceiling it binds is bound at-or-below by the child. A
    covering cap that binds NO ceiling licenses freely (the parent declares no
    budget on that cone at all), which is the byte-identical no-ceiling path.

    Returns a list of violations `{cap, param, child, parent}` (the failures of
    the closest-fitting covering cap, so the message names one real bound);
    empty means the child attenuates."""
    from . import cap_order  # noqa: PLC0415 - lazy, avoids an import cycle
    # (held cap, resource-only cone, declared ceilings), sorted so the violation
    # reported for an unlicensed crossing is deterministic.
    split = []
    for h in sorted(held, key=lambda c: c.to_str()):
        h_res, h_ceils = cap_order.split_ceilings(h)
        split.append((h_res, h_ceils))
    violations: list[dict] = []
    for c in sorted(child_reach, key=lambda c: c.to_str()):
        c_res, child_ceils = cap_order.split_ceilings(c)
        closest: list[dict] | None = None
        for h_res, h_ceils in split:
            if not cap_order.covers(h_res, c_res):
                continue                     # a sibling cone licenses nothing
            fails: list[dict] = []
            for p, wide in sorted(h_ceils.items()):
                narrow = child_ceils.get(p)  # None == dropped == +inf == wider
                if narrow is None or not cap_order._param_leq(p, narrow, wide):
                    fails.append({"cap": c, "param": p,
                                  "child": narrow, "parent": wide})
            if not fails:
                closest = None               # this held cap licenses the whole
                break                        # crossing: admitted, cone and all
            if closest is None or len(fails) < len(closest):
                closest = fails
        # `closest is None` also covers "no held cap's cone covers this crossing"
        # — unreachable here, since the crossing fold refuses that first.
        if closest:
            violations.extend(closest)
    return violations


def _check_spawn_attenuation(components: list[dict], services: dict,
                             spawn_reg: dict, filename: str,
                             untrusted: bool = False) -> list[dict]:
    """Capability attenuation on spawn (item 66, extended by item 294): a
    spawned child's capability set must be a **checked subset** of its
    spawner's (monotone shrinkage, the direction §5 admits for purity). A spawn
    may narrow (pass down less), never widen (grant a boundary the parent does
    not hold), so spawning cannot amplify authority and each per-tenant instance
    gets least-authority for free: an instance whose template reaches only
    `kv_a` provably cannot reach `kv_b`, even when the spawner holds both.

    The fold compares structured `(T, P)` capabilities via `cap_order.covers`,
    resolved through the key-to-token bridge (`_cap_keyed`) on BOTH sides, so a
    parameterized token is actually compared: a child declaring
    `fs.write(path="/etc")` under a parent holding `fs.write(path="/tmp")` is
    refused, and a bare `fs.write` child under that parent is refused too (a
    dropped parameter widens). Where G4 bounds a component's declaration, item
    33 the composition, and item 55 the operators, this bounds **lineage**.

    Both sides are spelled in the BOUNDARY's namespace, never in a component's
    local `requires` spelling: `covers` clause 1 is a boundary identity test, so
    the element carries the DECLARED capability token — the same source of truth
    `parallel._resolve_emission` reads for the very same crossings. Keying it by
    the wiring key instead compared two identifiers that name nothing in common,
    and renaming a child's `requires` key was enough to launder any boundary
    past the invariant quoted above. A boundary that no declaration tokens (a
    method with `emission` and no capability list) is still named by its G2
    wiring key, in its own token namespace (`_wire_cap`), so a key spelling can
    never masquerade as a declared token.

    Applies to activation-body spawns (see `_activation_spawn_sites`); returns
    the per-instance attenuation chain (spawner → child narrowing) for the G8
    audit surface. Raises on a widening spawn, naming the chain.

    Per-instance substitution (item 294, Slice 2): a child crossing spelled
    `fs.write(path=config.job_root)` carries a `config.` SYMBOL, opaque to the
    order. At a spawn site whose `with { }` block binds that field to a string
    literal, the symbol is resolved (`cap_order.substitute`) so the per-instance
    reach is compared - and the chain shown - as the resolved path. Substitution
    is LEAF-SCOPED: it applies only when the child's reachable set is exactly its
    OWN crossings (it spawns nothing transitively), because a symbol names the
    config of the component that DECLARED the crossing, bound at the edge that
    spawns THAT component. A child that itself spawns carries grandchild reach
    whose symbols belong to a different config bound at a different edge, so
    deeper per-instance resolution is left to a later slice and an unresolved
    symbol stays refused (fail closed), never admitted."""
    edges = spawn_reg.get("edges") or []
    if not edges:
        return []
    from . import cap_order  # noqa: PLC0415 - lazy, avoids an import cycle
    base = _spawn_reached_surface_pairs(components, services)
    reachable = _spawn_surface_closure(base, edges)

    chain: list[dict] = []
    seen: set = set()
    for comp in components:
        held = _held_capabilities_pairs(comp, base.get(comp["name"], set()),
                                        services)
        for spawn in _activation_spawn_sites(comp):
            child = spawn.get("component")
            full_reach = reachable.get(child, set())
            direct_reach = base.get(child, set())
            # per-instance substitution (item 294, Slice 2): resolve the child's
            # own `config.` capability symbols against this spawn's literal
            # `with { }` bindings. Sound only when the child's reach is exactly
            # its OWN crossings (`full_reach == direct_reach`, a leaf that spawns
            # nothing): then every symbol names THIS child's config, bound here.
            # A symbol left unresolved stays symbol-compared, hence refused
            # against a literal parent (fail closed). Inert - byte-identical -
            # when no symbol is present, so a parameter-free reach is unchanged.
            bindings = _spawn_literal_bindings(spawn)
            if (bindings and full_reach == direct_reach and any(
                    isinstance(v, cap_order.Symbol)
                    for c in direct_reach for _n, v in c.params)):
                child_reach = {cap_order.substitute(c, bindings)
                               for c in direct_reach}
            else:
                child_reach = full_reach
            line = spawn.get("line", comp.get("line", 1))
            # Crossing coverage (item 66/294): does the child reach only
            # boundaries the parent holds? Ceilings are EXEMPT from this question
            # (a narrower `calls` must not make one crossing "cover" another), so
            # the fold runs over the resource-only projection, ceiling-BLIND by
            # construction (item 260 §3.3). Budget attenuation is the separate
            # `_ceiling_attenuation_check` below.
            held_res = _strip_ceilings(held)
            extra = cap_order.covers_set(held_res, _strip_ceilings(child_reach))
            if extra:
                extra = sorted(extra, key=lambda c: c.to_str())
                held_str = ", ".join(
                    f"`{s}`" for s in _cap_sorted_strs(held_res)) \
                    or "no capabilities"
                offending = ", ".join(_cap_offending(c) for c in extra)
                # the reason reads the resource-only held set: a ceiling param
                # is not a resource-widening cause (that is the dedicated
                # ceiling check below), so it must not surface here as a
                # spurious "drops `calls`" hint.
                reasons = [r for r in (_widening_reason(c, held_res)
                                       for c in extra) if r is not None]
                extra_hint = ("; " + "; ".join(reasons)) if reasons else ""
                from . import navigate as _nav  # noqa: PLC0415 — lazy, additive
                _prof = _UntrustedMark if untrusted else None
                raise RevlError(
                    comp.get("source") or filename, line,
                    f"`{comp['name']}` spawns `{child}`, granting it {offending}, "
                    f"but `{comp['name']}` holds only {held_str} — a spawn may "
                    "narrow a child's capabilities, never widen them",
                    hint="a spawned child's capability set must be covered by "
                         f"its spawner's (attenuation, item 66/294); "
                         f"`{comp['name']}` cannot pass down {offending} it does "
                         f"not hold; add the matching `requires` to "
                         f"`{comp['name']}` so it holds what it grants, or narrow "
                         f"the capability on `{child}` "
                         "(monotone shrinkage: narrowing is sound, widening is "
                         "not)" + extra_hint,
                    code="G4", category="capability-attenuation",
                    # a resource crossing (path/host) held set is a STATIC fact at
                    # the refusal site, so narrowing the child to it clears the
                    # gate; raising the bound is operator-enacted at `comp`.
                    navigate=_nav.ceiling_navigate(
                        param=offending, child_value=offending,
                        parent_bound=held_str, bound_site=f"`{comp['name']}`",
                        is_budget=False, profile=_prof),
                )
            # DEDICATED budget/ceiling attenuation (item 260 §3.3, the HIGH
            # correction): the crossing-coverage fold above is ceiling-blind, so
            # a child budget WIDER than the parent's, or a DROPPED budget clause
            # that silently widens to unbounded, is refused HERE, over the
            # unstripped pairs, never by `covers_set`.
            budget_bad = _ceiling_attenuation_check(held, child_reach)
            if budget_bad:
                budget_bad.sort(key=lambda v: (v["cap"].to_str(), v["param"]))
                offending = ", ".join(
                    (f"`{v['cap'].to_str()}` drops the `{v['param']}` budget "
                     f"(a missing ceiling is unbounded, hence wider)"
                     if v["child"] is None else
                     f"`{v['cap'].to_str()}` widens `{v['param']}` to "
                     f"{v['child']} over the parent's {v['parent']}")
                    for v in budget_bad)
                from . import navigate as _nav  # noqa: PLC0415 — lazy, additive
                _prof = _UntrustedMark if untrusted else None
                _bad0 = budget_bad[0]
                raise RevlError(
                    comp.get("source") or filename, line,
                    f"`{comp['name']}` spawns `{child}` with a wider resource "
                    f"budget than it holds: {offending}. A spawned child's "
                    "budget may only narrow, never widen (attenuation, item "
                    "66/294/260)",
                    hint="a budget ceiling (`requests`/`calls`, `bytes`/`size`, "
                         "`time`) attenuates on delegation: the child's ceiling "
                         "must be <= the parent's, and a child may not DROP a "
                         "ceiling the parent declares (that widens it to "
                         "unbounded); narrow the budget on the child, or widen "
                         f"`{comp['name']}`'s own declared budget",
                    code="G4", category="capability-attenuation",
                    # a budget ceiling is a LIVE `remainingUses`/lease counter
                    # (item 294/260): the in-bounds number may already be spent at
                    # the retry (TOCTOU), so the narrowing is `candidate`/`live`,
                    # never `clears-this-gate` (the HIGH fix / soundness sweep).
                    navigate=_nav.ceiling_navigate(
                        param=str(_bad0["param"]),
                        child_value=("(dropped)" if _bad0["child"] is None
                                     else str(_bad0["child"])),
                        parent_bound=str(_bad0["parent"]),
                        bound_site=f"`{comp['name']}`",
                        is_budget=True, profile=_prof),
                )
            edge = (comp["name"], child)
            if edge in seen:
                continue
            seen.add(edge)
            # the attenuation chain per instance: what the spawner holds, what
            # the instance is granted (its reachable set), and what was dropped
            # on the way down — the least-authority proof, per lineage edge.
            chain.append({
                "parent": comp["name"],
                "child": child,
                "holds": _cap_sorted_strs(held),
                "granted": _cap_sorted_strs(child_reach),
                "attenuated": _cap_sorted_strs(held - child_reach),
                "line": line,
            })
    return chain


def _check_spawn_emission_bounds(components: list[dict], services: dict,
                                 spawn_reg: dict, filename: str) -> None:
    """G4/G6 across the spawn boundary (decision 8): a spawner's declared
    emission bound must cover what its spawned instances emit, so emissions
    cannot escape their bound by being moved into a spawned child.

    Only *bounded* spawn sites are constrained — a spawn inside a provide-method
    whose service declares `plain` or `emission[caps]`. A spawn in an activation
    body has no emission clause to widen (as body-level `emit` has none), so it
    is unconstrained here, exactly as today."""
    if not spawn_reg.get("edges"):
        return
    surface = _spawn_emission_surface(components, services)
    # fold the spawn graph into each surface (transitive closure)
    edges = spawn_reg["edges"]
    changed = True
    while changed:
        changed = False
        for parent, child in edges:
            before = len(surface.get(parent, set()))
            surface.setdefault(parent, set()).update(surface.get(child, set()))
            if len(surface[parent]) != before:
                changed = True

    for comp in components:
        for step in comp.get("body") or []:
            if step.get("step") != "provide":
                continue
            key = step.get("name")
            svc = services.get((comp.get("provides") or {}).get(key) or "")
            if svc is None:
                continue
            for method in step.get("methods") or []:
                decl = svc.methods.get(method.get("name"))
                if decl is None:
                    continue
                for spawn in _find_spawn_nodes(method.get("body") or []):
                    target = spawn.get("component")
                    tsurf = surface.get(target, set())
                    if not tsurf:
                        continue
                    line = spawn.get("line", step.get("line", 1))
                    where = f"{svc.name}.{method.get('name')}"
                    if not decl.emission:
                        evidence = ", ".join(f"`{c}`" for c in sorted(tsurf))
                        raise RevlError(
                            comp.get("source") or filename, line,
                            f"`{where}` is declared plain, but it spawns "
                            f"`{target}`, which emits through {evidence}",
                            hint="a spawner's emission bound must cover its "
                                 "instances' — declare `emission fn "
                                 f"{method.get('name')}(...)` on service `{svc.name}`, "
                                 "or move the spawn out of this method (G4)",
                            code="G4", category="emission-propagation",
                        )
                    if decl.capabilities is not None:
                        extra = sorted(tsurf - set(decl.capabilities))
                        if extra:
                            declared = ", ".join(decl.capabilities) or "no capabilities"
                            offending = ", ".join(
                                "an unnameable host boundary" if c == "*" else f"`{c}`"
                                for c in extra)
                            raise RevlError(
                                comp.get("source") or filename, line,
                                f"`{where}` is declared `emission[{declared}]`, but it "
                                f"spawns `{target}`, which emits through {offending}",
                                hint="a spawner's emission bound must cover its "
                                     f"instances' — widen `emission[...]` on service "
                                     f"`{svc.name}` to include {offending}, or move the "
                                     "spawn out of this method (G4)",
                                code="G4", category="emission-capability",
                            )
