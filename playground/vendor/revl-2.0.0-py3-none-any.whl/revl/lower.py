"""Checking and lowering: typed AST -> backend IR (docs/backend-ir.md).

Guarantee enforcement map (DESIGN.md §4):
  G1 undeclared access        -> _lower_postfix name resolution
  G2 provision disjointness   -> link()
  G3 dependency cycles        -> link()
  G4 inverse-or-emit          -> parser (missing undo) + emission checks here
  G5 no teardown registration -> by construction (undo is an expression;
                                 there is no syntactic position for effects)
  G6 purity outside effects   -> by construction (statement grammar)
  A2 no acquisition after provide -> check_component body scan
"""

from __future__ import annotations

import dataclasses
import keyword

from . import holes
from .errors import RevlError
from .why import CHAIN, SET, TraceStep, WhyTrace
from .typecheck import (
    CASES_KEY,
    FNS_KEY,
    _SIZED_HEADS,
    check_ast,
    collect_tparams,
    validate_explicit_tparams,
    render_type,
    mark_tparams,
    check_type_wellformed,
    compatible,
    format_type,
    host_check,
    infer_ast,
    infer_ir,
    mismatch,
    pin_hole,
    null_error,
    parse_type,
    substitute,
    unify,
    _is_wildcard,
    _check_method_namespace_disjoint,
)
from .parser import (
    _describe_expr,
    AdvanceStmt,
    AssertStmt,
    AssignStmt,
    AwaitStmt,
    CallStmt,
    ComponentDecl,
    EffectStmt,
    EmitExpr,
    EmitStmt,
    FailStmt,
    ExprArrow,
    ExprBin,
    ExprBlockArm,
    ExprCall,
    ExprField,
    ExprHole,
    ExprIf,
    ExprIndex,
    ExprList,
    ExprLit,
    ExprMatch,
    ExprOptCall,
    ExprOptField,
    ExprRecord,
    ExprRecordUpdate,
    ExprStmt,
    ExprUn,
    ExprVar,
    FnDecl,
    ForStmt,
    HandoffStmt,
    IfStmt,
    Interp,
    InterceptStmt,
    IsolateStmt,
    LetEffect,
    LetPatternStmt,
    LetStmt,
    LoadStmt,
    ListPattern,
    Lit,
    Postfix,
    Program,
    ProvideStmt,
    RecordPattern,
    ResidueStmt,
    ReturnStmt,
    RouteStmt,
    ServiceDecl,
    SpawnExpr,
    TestDecl,
    TimerStmt,
    TypeDecl,
    UnloadStmt,
    WhileStmt,
)

IR_VERSION = 1

# finding 6: the specified stdlib surface (docs/stdlib-2.0.md). Method calls
# on values must name one of these (arity-checked); everything else is a
# compile error — never a verbatim pass-through to whatever the host object
# happens to have. Names are chosen to be collision-free with the v1 host
# stub objects (open/close/query/execute/new/get/insert/remove/drop).
_BUILTIN_METHODS = {
    "length": 0, "push": 1, "slice": 2, "charAt": 1,
    "charCodeAt": 1, "indexOf": 1, "concat": 1,
    "split": 1, "join": 1, "repeat": 1,
    # The prefix/suffix probes (FR-6, docs/stdlib-2.0.md §Str.startsWith):
    # Str-only, one Str argument.
    "startsWith": 1, "endsWith": 1,
    # Single-character ASCII classification (item 233, docs/stdlib-2.0.md
    # §Str.is_alnum): Str-only, no argument. Cuts the self-host lexer's
    # per-byte revl-fn-call + code-point-range tax to a native inline test.
    "is_alnum": 0, "is_digit": 0, "is_alpha": 0, "is_space": 0,
    # Integer division and modulo. `/` and `%` keep the meaning TypeScript
    # gives them (§0); these name what they do, so no tier has to guess and
    # none can quietly pick its host's convention (docs/arithmetic.md).
    "div_trunc": 1, "div_floor": 1, "div_euclid": 1, "mod": 1,
    # Int/Int32 width conversions (docs/arithmetic.md). `to_int` widens an
    # Int32 to Int (lossless); `to_int32` narrows an Int to Int32 (checked,
    # traps out of the 32-bit range).
    "to_int": 0, "to_int32": 0,
    # The total forms (docs/arithmetic.md): a zero divisor is the *point*
    # here, so these are deliberately absent from _DIVIDES_BY below — a
    # literal zero argument is refused for the faulting operations only.
    "checked_div_trunc": 1, "checked_div_floor": 1,
    "checked_div_euclid": 1, "checked_mod": 1,
    # The Map value type (docs/stdlib-2.0.md §Map). Names disjoint from the
    # host verb set (open/close/query/execute/new/get/insert/remove/drop):
    # the two method namespaces stay collision-free by construction.
    "set": 2, "lookup": 1, "has": 1,
    # The iteration/remove step (docs/stdlib-2.0.md §Map): same namespace
    # discipline — disjoint from the host verb set by construction.
    "size": 0, "keys": 0, "remove": 1,
    # The rendering builtin (docs/stdlib-2.0.md §Int.to_str).
    "to_str": 0,
}

# The disjointness this comment block promises is a *checked* claim, enforced
# at module load (table-edit time), not at golden-diff time: editing this
# table with a name from the host stub surface reclassifies every host call
# site of that name and surfaces only as broken tests across the suite
# (roadmap 75(b) tooling half; dogfood/findings-mapiter.md §2). `remove` is
# the ONE sanctioned overlap (docs/stdlib-2.0.md §Map) — dispatch by receiver
# kind is what makes it safe.
_check_method_namespace_disjoint(_BUILTIN_METHODS, "_BUILTIN_METHODS")


# Integer division and modulo are undefined at zero, and every tier says so
# differently — python raises, rust and wasm trap, java throws, and TypeScript
# used to hand back Infinity. A *literal* zero divisor is never a program
# anyone meant to write, so it does not need to reach any of them.
_DIVIDES_BY = ("div_trunc", "div_floor", "div_euclid", "mod")


def _refuse_zero_divisor(method: str, args, filename: str, line: int) -> None:
    from .parser import ExprLit as _Lit

    if method not in _DIVIDES_BY or not args:
        return
    divisor = args[0]
    if isinstance(divisor, _Lit) and divisor.value == 0:
        raise RevlError(
            filename, line,
            f"`{method}` by a literal zero is undefined",
            hint="integer division and modulo have no value at zero; guard the "
                 "divisor (`if (b == 0) { ... }`) or use a non-zero constant")


def _refuse_unpinned_stdlib_method(method: str, recv_t: str | None,
                                   filename: str, line: int) -> None:
    """The stdlib-named-method sliver (roadmap 75(b), docs/contract-errata.md
    "Typing gaps"): a method call on a receiver whose type no constructor pins
    must not lower as the builtin. At runtime the value is whatever the host
    returned (or whatever the type parameter was instantiated with), not a
    Str/List/Int/Int32/Bytes/Map value, so the builtin dispatch misbehaves on
    every tier. Only a receiver the checker can *prove* is a stdlib value may
    take the builtin table; everything else stays on the G8 audit surface,
    refused here with the same HOST-METHOD diagnostic the family surface uses."""
    shown = render_type(recv_t) or "unknown"
    raise RevlError(
        filename, line,
        f"stdlib method `{method}` on a value of {shown} type — no constructor "
        "pins this receiver as a Str/List/Int/Int32/Bytes/Map value, so the "
        "checker refuses to lower the call as the builtin",
        hint="host-object results carry no type (G8): annotate the binding "
             "(`let v: Str = ...`) or route the value through a declared type "
             "before calling methods on it",
        code="HOST-METHOD", category="host-boundary",
    )


def _is_host_valued(expr, scope) -> bool:
    """A receiver holding a HOST object (Map.new(), Pool.open(...), or a let
    bound to one): its methods belong to the host stub, not the stdlib
    table, and stay verbatim."""
    from .parser import ExprCall as _C, ExprField as _F, ExprVar as _V

    if isinstance(expr, _V):
        return scope.get(expr.name) == "host"
    if isinstance(expr, _C) and isinstance(expr.callee, _F)             and isinstance(expr.callee.target, _V):
        # `Map.empty()` is the Map VALUE constructor (docs/stdlib-2.0.md
        # §Map) — a pure value, not a host acquisition. Its constructor ROOT
        # is a host callable, so without this exclusion a `let m =
        # Map.empty()` bound the name as "host" and every later
        # m.set/m.lookup/m.has lowered as a verbatim *field* call: unchecked
        # at compile time, AttributeError-shaped at runtime.
        if expr.callee.target.name == "Map" and expr.callee.name == "empty":
            return False
        return expr.callee.target.name in _HOST_CALLABLES
    return False
IR_VERSION_V2 = 2  # emitted only when a compiled component uses realms/interception
IR_VERSION_V3 = 3  # emitted when a program uses full-language features (fn/type)

# ── IR expression-kind schema (roadmap item 76a) ─────────────────────────────
# The complete set of expression kinds this frontend can lower, split by the
# positions in which each can appear. This is the *registration point* for a
# new expression kind: adding one to the lowering MUST add it to the position
# set(s) that match where the frontend can produce it — which automatically
# adds it to EXPR_KINDS — and then
# tests/test_expr_dispatcher_conformance.py fails until every backend declares
# where it handles or deliberately refuses the kind in each dispatcher. A kind
# that ships without a registration is exactly the "patched one of two paths"
# failure the test exists to turn red.
#
#   FN        — a pure-function body (``_lower_pure_expr``).
#   COMPONENT — a component body / provide-method body / block-effect setup
#               (``_lower_component_pure_expr`` + component step lowering).
#
# The split is factual, not aspirational: `len` and `interp` are produced only
# in fn bodies (component positions spell `.length` as a `field` and templates
# as `format`), while `name`/`config`/`req`/`host`/`format`/`fn`/`spawn`/
# `instance-get` are produced only in component positions. Everything else can
# appear in both.
EXPR_KINDS_FN: frozenset[str] = frozenset({
    "adt", "arrow", "bin", "builtin", "call", "field", "hole", "if", "index",
    "interp", "len", "list", "lit", "maplit", "match", "optcall", "optfield",
    "record", "record_update", "un", "var",
})
EXPR_KINDS_COMPONENT: frozenset[str] = frozenset({
    "adt", "arrow", "bin", "builtin", "call", "config", "field", "fn",
    "format", "hole", "host", "if", "index", "instance-get", "list", "lit",
    "maplit", "match", "name", "optcall", "optfield", "record",
    "record_update", "req", "spawn", "un", "var",
})
EXPR_KINDS: frozenset[str] = EXPR_KINDS_FN | EXPR_KINDS_COMPONENT

# the default shared realm (paper Def. 28: an unisolated key resolves to
# its own realm); rendered as "shared" in diagnostics
SHARED_REALM = ""

# multi-realm require routing strategies (roadmap item 162). The name is an
# annotation the runtime router (item 161) consumes to pick a distribution
# policy across the bound realms; the frontend validates it against this
# closed set so a typo (`strategy(round_robbin)`) is a compile-time refusal,
# not a silent runtime fallback. `None` (strategy omitted) records "router's
# default" and is always accepted.
KNOWN_STRATEGIES: frozenset[str] = frozenset({
    "round_robin",   # rotate across the realms in declaration order
    "least_loaded",  # route to the realm whose provider reports least load
    "random",        # uniform random pick
    "sticky",        # pin a caller-derived key to one realm (session affinity)
})

# key namespacing (docs/namespacing.md): a provision key may be written
# `ns::local`. The *full* string is the key's wiring identity — G2
# disjointness, injection resolution and the admission gate all compare the
# qualified string, so two authors' `acme::db` and `bcorp::db` never collide.
# The trailing segment is the code-facing binding name a `requires` introduces
# (the consumer still writes `db.query(...)` in its body). An unqualified key
# has an empty namespace and a binding equal to itself, so v1 programs are
# unaffected in every respect.
KEY_NAMESPACE_SEP = "::"


def _key_binding(key: str) -> str:
    """The code-facing local name of a (possibly namespaced) provision key.

    `acme::db` binds `db`; an unqualified `db` binds itself. This is the name
    a `requires` clause introduces into the component body and type env."""
    return key.rsplit(KEY_NAMESPACE_SEP, 1)[-1]

# A3: identifiers that must never appear verbatim in emitted code on either
# host. Python keywords come from the keyword module; the rest is a curated
# union of TS reserved words and backend-adapter names.
_HOST_RESERVED = {
    "ctx", "config", "frame", "fiber", "self",
    "function", "var", "let", "const", "new", "class", "this", "typeof",
    "delete", "in", "of", "instanceof", "void", "export", "default",
    "require", "module", "exports", "import", "yield", "async", "await",
    "true", "false", "null", "undefined", "NaN",
}


def _safe_name(name: str, taken: set[str]) -> str:
    candidate = name
    while (
        candidate in _HOST_RESERVED
        or keyword.iskeyword(candidate)
        or keyword.issoftkeyword(candidate)
        or candidate in taken
    ):
        candidate += "_"
    return candidate


class Env:
    def __init__(self, component: ComponentDecl, services: dict[str, ServiceDecl], filename: str,
                 types: dict | None = None):
        self.component = component
        self.services = services
        self.filename = filename
        self.types = types or {}
        # names whose call reaches an irreversible host effect (set by
        # check_and_lower once externs/fns are lowered)
        self.emitting_fns: set = set()
        # the same relation refined to *which* boundaries each one reaches:
        # name -> capability set (docs/capabilities.md)
        self.emitting_caps: dict[str, set] = {}
        # why-trace support for the above (why.py); None when unavailable,
        # in which case rejections carry no derivation but are unchanged
        self.emission_evidence: "_EmissionEvidence | None" = None
        # names of `witnessed`-classified externs in scope (item 243, Slice 2,
        # docs/design/243-witnessed-externs.md): set by `_lower_component` so
        # an effect-position acquisition calling one of these lowers to the
        # transactional accumulator entry instead of an ordinary bracket.
        self.witnessed_externs: set = set()
        # async externs in scope (roadmap item 80): name -> its ExternDecl, so
        # the v1 coloring check can name/locate an async extern a method reaches
        # (docs/design/async-extern.md §3). Set alongside the emitting sets.
        self.async_externs: dict = {}
        # the phase-2 async-colored set (async externs + transitively colored
        # fns, docs/design/async-extern.md §3): what a provide-method admission
        # tests membership against. Set alongside `async_externs`.
        self.async_callables: set = set()
        # component-body type environment: safe-name -> type, plus the
        # "config.<field>" and "req.<local>" markers infer_ir resolves
        self.type_env: dict[str, str] = {}
        for cfg_field in component.config:
            self.type_env[f"config.{cfg_field.name}"] = cfg_field.type
        self.config_fields = {f.name for f in component.config}
        self.requires = dict()  # binding (local name) -> service name
        # binding -> the qualified wiring key it resolves against; for an
        # unqualified requirement this is the binding itself (docs/namespacing.md)
        self.require_keys: dict[str, str] = dict()
        for key, svc, line in component.requires:
            if svc not in services:
                raise RevlError(filename, line, f"unknown service `{svc}` in `requires` of {component.name}")
            binding = _key_binding(key)
            if binding in self.requires:
                raise RevlError(filename, line, f"duplicate requirement name `{binding}` in {component.name}")
            self.requires[binding] = svc
            self.require_keys[binding] = key
            self.type_env[f"req.{binding}"] = svc
        self.locals: dict[str, str] = {}  # surface name -> host-safe IR name (A3)
        self.params: dict[str, str] = {}
        self._taken: set[str] = set()
        # host provenance (docs/stdlib-2.0.md §Map): component locals bound to
        # a host acquisition (`let store = effect Map.new()`). Their method
        # calls belong to the host stub surface and stay verbatim — checked
        # BEFORE the stdlib builtin table, so a value-type method that shares
        # a spelling with a host verb (`remove`) cannot capture them.
        self.host_locals: set[str] = set()

    def bind_local(self, name: str, line: int) -> str:
        if name in self.locals or name in self.requires or name in self.params:
            raise RevlError(self.filename, line, f"name `{name}` is already bound in {self.component.name}")
        safe = _safe_name(name, self._taken)
        self._taken.add(safe)
        self.locals[name] = safe
        return safe

    def bind_params(self, names: list[str], line: int) -> dict[str, str]:
        params: dict[str, str] = {}
        taken = set(self._taken)
        for name in names:
            if name in params:
                raise RevlError(self.filename, line, f"duplicate parameter `{name}`")
            safe = _safe_name(name, taken)
            taken.add(safe)
            params[name] = safe
        return params


# ---------------------------------------------------------------------------
# v2.0: type declarations & pure functions (docs/syntax-2.0.md §2–§3)
# ---------------------------------------------------------------------------

# builtin (non-record) type heads: destructuring a value of one of these with
# a record/list pattern is a type error, not a host pass-through
_BUILTIN_NONRECORD = {"Str", "Int", "Int32", "Bool", "Float", "Bytes", "Unit",
                      "List", "Map", "Opt", "Result"}

# host roots a pure fn may call without an explicit binding (DESIGN §7 builtins)
_HOST_CALLABLES = {"Map", "Pool", "Job"}
# Opt/Result constructors, recognized so `Some(x)`/`Ok(r)` resolve (syntax-2.0 §2)
_BUILTIN_CONSTRUCTORS = {"Some", "None", "Ok", "Err"}


# Builtin heads a `type X = Y` right-hand side may name. `Any`/`Never` are the
# type algebra's wildcards; the rest are the declared builtin surface.
_ALIASABLE_BUILTINS = _BUILTIN_NONRECORD | {"Any", "Never"}


def _alias_target(decl: TypeDecl, declared: set[str]) -> str | None:
    """The type `type X = Y` aliases, or None when the decl is a real variant.

    `type X = Y` is TypeScript's alias spelling, and syntax-2.0's governing
    principle is that no construct may exist in both languages with silently
    different meaning. So the split follows TypeScript's own:

    - Where TypeScript *compiles* it — `Y` names an existing type — revl means
      what TypeScript means: a transparent alias. `type Sku = Str` used to
      declare a one-case variant whose case was named `Str`, which made the
      author's own alias unusable (`f("abc")` was refused for a `Sku`
      parameter) while `return Str` was accepted as a case constructor.
    - Where TypeScript *rejects* it — `Y` is undeclared (TS2304) — revl is free
      to mean something else, because there is no shared meaning to diverge
      from. `type Status = Pending` keeps its one-case-variant reading, which
      is how an opaque nominal is spelled today.

    A payload makes it a newtype (`type W = Wrap(Int)`), never an alias.
    """
    if decl.fields or len(decl.cases) != 1:
        return None
    case = decl.cases[0]
    if case.payload is not None:
        return None
    head, args = parse_type(case.name)
    if args:
        return case.name  # a type application; the parser only builds these here
    if head in _ALIASABLE_BUILTINS or head in declared:
        return case.name
    return None


def _resolve_type_aliases(program: Program, filename: str) -> None:
    """Erase transparent type aliases from the program, in place.

    Aliases are substituted at every declaration site and their declarations
    dropped, so nothing downstream — the type table, the checker, the IR, the
    backends — ever sees the alias name. That is what `transparent` means, and
    it is the reading TypeScript has: `Sku` and `Str` are interchangeable in
    both directions. A *nominal* alias would be a distinct type needing
    construction syntax revl does not have, and would re-commit the very sin
    this fixes (both languages compiling `type X = Y` with different meanings).
    """
    declared = {d.name for d in program.type_decls}
    aliases: dict[str, TypeDecl] = {}
    for decl in program.type_decls:
        target = _alias_target(decl, declared)
        if target is None:
            continue
        if decl.params:
            raise RevlError(
                filename, decl.line,
                f"type alias `{decl.name}` cannot declare type parameters",
                hint="an alias is substituted verbatim, so it has nothing to "
                     "instantiate — drop the parameters, or declare a variant "
                     "with named cases (syntax-2.0 §2)",
            )
        # an alias is a declaration, so its right-hand side is checked here
        # rather than only where the alias happens to be used
        check_type_wellformed(filename, decl.line, target)
        aliases[decl.name] = decl
    if not aliases:
        return

    def expand(type_name: str, stack: tuple) -> str:
        head, args = parse_type(type_name)
        if args:
            return format_type(head, [expand(a, stack) for a in args])
        if head not in aliases:
            return head
        if head in stack:
            chain = " -> ".join(stack[stack.index(head):] + (head,))
            raise RevlError(
                filename, aliases[head].line,
                f"type alias cycle: {chain}",
                hint="an alias is substituted verbatim, so a cycle has no "
                     "expansion — break it, or declare one of them as a variant",
            )
        return expand(_alias_target(aliases[head], declared), stack + (head,))

    resolved = {name: expand(_alias_target(decl, declared), (name,))
                for name, decl in aliases.items()}

    def subst(type_name):
        if not type_name:
            return type_name
        head, args = parse_type(type_name)
        if args:
            return format_type(head, [subst(a) for a in args])
        return resolved.get(head, head)

    # every declaration site that carries a type annotation; kept in step with
    # `_validate_declared_types` below, which enumerates the same surface
    for fn in program.fn_decls:
        for p in fn.params:
            p.type = subst(p.type)
        fn.returns = subst(fn.returns)
    for ext in program.externs:
        for p in ext.params:
            p.type = subst(p.type)
        ext.returns = subst(ext.returns)
    for svc in program.services:
        for m in svc.methods.values():
            m.params = [(pname, subst(ptype)) for pname, ptype in m.params]
            m.returns = subst(m.returns)
    for decl in program.type_decls:
        for fld in decl.fields:
            fld.type = subst(fld.type)
        for case in decl.cases:
            case.payload = subst(case.payload)
    for comp in program.components:
        for cfg in comp.config:
            cfg.type = subst(cfg.type)
        for stmt in comp.body:
            if not isinstance(stmt, ProvideStmt):
                continue
            for method in stmt.methods:
                method.param_types = [subst(t) for t in method.param_types]
                method.returns = subst(method.returns)
                _subst_body_annotations(method.body, subst)
    for fn in program.fn_decls:
        _subst_body_annotations(fn.body, subst)
    for test in program.tests:
        _subst_body_annotations(test.body, subst)

    program.type_decls = [d for d in program.type_decls if d.name not in aliases]


def _subst_body_annotations(stmts: list, subst) -> None:
    """Expand type aliases in the annotations a *body* can carry.

    `let g: Handler = …` and `(v: Handler) => …` are type annotations like any
    other, but they live inside statements rather than at a declaration site,
    so the declaration sweep above cannot reach them — and an alias that
    survived here would reach the checker as an undeclared type name."""
    def walk_expr(expr) -> None:
        if isinstance(expr, ExprArrow):
            expr.param_types = [subst(t) for t in expr.param_types]
            walk_expr(expr.body)
        elif isinstance(expr, ExprBin):
            walk_expr(expr.left)
            walk_expr(expr.right)
        elif isinstance(expr, ExprUn):
            walk_expr(expr.operand)
        elif isinstance(expr, ExprCall):
            walk_expr(expr.callee)
            for arg in expr.args:
                walk_expr(arg)
        elif isinstance(expr, (ExprField, ExprOptField)):
            walk_expr(expr.target)
        elif isinstance(expr, ExprOptCall):
            walk_expr(expr.target)
            for arg in expr.args:
                walk_expr(arg)
        elif isinstance(expr, ExprIndex):
            walk_expr(expr.target)
            walk_expr(expr.index)
        elif isinstance(expr, ExprIf):
            walk_expr(expr.cond)
            walk_expr(expr.then)
            walk_expr(expr.otherwise)
        elif isinstance(expr, ExprRecord):
            for _, value in expr.fields:
                walk_expr(value)
        elif isinstance(expr, ExprRecordUpdate):
            walk_expr(expr.base)
            for _, value in expr.updates:
                walk_expr(value)
        elif isinstance(expr, ExprList):
            for item in expr.items:
                walk_expr(item)
        elif isinstance(expr, ExprMatch):
            walk_expr(expr.scrutinee)
            for _, _, body in expr.arms:
                walk_expr(body)
                if isinstance(body, ExprBlockArm):
                    for stmt in body.stmts:
                        walk_expr(stmt.value)
                    walk_expr(body.tail)
        elif isinstance(expr, Interp):
            for kind, part in expr.parts:
                if kind == "expr":
                    walk_expr(part)

    def walk_stmt(stmt) -> None:
        if isinstance(stmt, LetStmt):
            stmt.type = subst(stmt.type)
            walk_expr(stmt.value)
        elif isinstance(stmt, (LetPatternStmt, AssignStmt)):
            walk_expr(stmt.value)
        elif isinstance(stmt, (ExprStmt, AssertStmt, FailStmt, AwaitStmt)):
            walk_expr(stmt.expr)
        elif isinstance(stmt, ReturnStmt):
            if stmt.expr is not None:
                walk_expr(stmt.expr)
        elif isinstance(stmt, IfStmt):
            walk_expr(stmt.cond)
            for child in list(stmt.then) + list(stmt.otherwise or []):
                walk_stmt(child)
        elif isinstance(stmt, WhileStmt):
            walk_expr(stmt.cond)
            for child in stmt.body:
                walk_stmt(child)
        elif isinstance(stmt, ForStmt):
            walk_expr(stmt.iterable)
            for child in stmt.body:
                walk_stmt(child)

    for stmt in stmts:
        walk_stmt(stmt)


def _validate_declared_types(program: Program, filename: str) -> None:
    """Reject malformed type annotations (bare builtin generics like `Opt`,
    `List[]`) at every declaration site before checking begins — otherwise a
    zero-arg generic reaches the type algebra and crashes it."""
    for fn in program.fn_decls:
        for p in fn.params:
            # A module `fn` parameter is the one v1 position that admits an
            # async function type `(…) -> Async[T]` (item 92).
            check_type_wellformed(filename, p.line, p.type,
                                  allow_async_param=not fn.verified)
        check_type_wellformed(filename, fn.line, fn.returns)
    for ext in program.externs:
        for p in ext.params:
            check_type_wellformed(filename, p.line, p.type)
        check_type_wellformed(filename, ext.line, ext.returns)
    for svc in program.services:
        for m in svc.methods.values():
            for _, ptype in m.params:
                check_type_wellformed(filename, m.line, ptype)
            check_type_wellformed(filename, m.line, m.returns)
    for decl in program.type_decls:
        for field in decl.fields:
            check_type_wellformed(filename, field.line, field.type)
        for case in decl.cases:
            check_type_wellformed(filename, case.line, case.payload)
    for comp in program.components:
        for cfg in comp.config:
            check_type_wellformed(filename, cfg.line, cfg.type)


def _lower_type_decls(program: Program, filename: str) -> dict:
    types: dict[str, dict] = {}
    for decl in program.type_decls:
        if decl.name in types:
            raise RevlError(filename, decl.line, f"duplicate type `{decl.name}`")
        if decl.fields:
            fields: dict[str, str] = {}
            for field in decl.fields:
                if field.name in fields:
                    raise RevlError(filename, field.line,
                                    f"duplicate field `{field.name}` in record `{decl.name}`")
                fields[field.name] = field.type
            types[decl.name] = {"params": decl.params, "kind": "record", "fields": fields}
        else:
            cases: list[dict] = []
            seen: set[str] = set()
            for case in decl.cases:
                if case.name in seen:
                    raise RevlError(filename, case.line,
                                    f"duplicate case `{case.name}` in type `{decl.name}`")
                seen.add(case.name)
                cases.append({"name": case.name, "payload": case.payload})
            types[decl.name] = {"params": decl.params, "kind": "variant", "cases": cases}
    return types


def _fn_call_graph(program: Program) -> dict[str, set[str]]:
    """Direct-call graph over the file's functions.

    Host roots and constructors are not function declarations, so they are
    ignored: only `ExprVar` callees whose name is another `fn` are edges.
    """
    fn_names = {fn.name for fn in program.fn_decls}
    graph = {fn.name: set() for fn in program.fn_decls}

    def collect_expr(expr) -> None:
        if isinstance(expr, ExprCall):
            if isinstance(expr.callee, ExprVar) and expr.callee.name in fn_names:
                graph[decl.name].add(expr.callee.name)
            collect_expr(expr.callee)
            for arg in expr.args:
                collect_expr(arg)
        elif isinstance(expr, ExprBin):
            collect_expr(expr.left)
            collect_expr(expr.right)
        elif isinstance(expr, ExprUn):
            collect_expr(expr.operand)
        elif isinstance(expr, ExprField):
            collect_expr(expr.target)
        elif isinstance(expr, ExprIndex):
            collect_expr(expr.target)
            collect_expr(expr.index)
        elif isinstance(expr, ExprIf):
            collect_expr(expr.cond)
            collect_expr(expr.then)
            collect_expr(expr.otherwise)
        elif isinstance(expr, ExprRecord):
            for _, value in expr.fields:
                collect_expr(value)
        elif isinstance(expr, ExprRecordUpdate):
            collect_expr(expr.base)
            for _, value in expr.updates:
                collect_expr(value)
        elif isinstance(expr, ExprList):
            for item in expr.items:
                collect_expr(item)
        elif isinstance(expr, ExprArrow):
            collect_expr(expr.body)

    def collect_stmt(stmt) -> None:
        if isinstance(stmt, LetStmt):
            collect_expr(stmt.value)
        elif isinstance(stmt, LetPatternStmt):
            collect_expr(stmt.value)
        elif isinstance(stmt, AssignStmt):
            collect_expr(stmt.value)
        elif isinstance(stmt, ReturnStmt):
            if stmt.expr is not None:
                collect_expr(stmt.expr)
        elif isinstance(stmt, IfStmt):
            collect_expr(stmt.cond)
            for branch in (stmt.then, stmt.otherwise or []):
                for child in branch:
                    collect_stmt(child)
        elif isinstance(stmt, WhileStmt):
            collect_expr(stmt.cond)
            for child in stmt.body:
                collect_stmt(child)
        elif isinstance(stmt, ForStmt):
            collect_expr(stmt.iterable)
            for child in stmt.body:
                collect_stmt(child)
        elif isinstance(stmt, (ExprStmt, AssertStmt)):
            collect_expr(stmt.expr)

    for decl in program.fn_decls:
        for stmt in decl.body:
            collect_stmt(stmt)
    return graph


def _reaches_self(start: str, graph: dict[str, set[str]]) -> bool:
    seen: set[str] = set()
    stack = [start]
    while stack:
        node = stack.pop()
        for succ in graph.get(node, ()):
            if succ == start:
                return True
            if succ not in seen:
                seen.add(succ)
                stack.append(succ)
    return False


def _check_verified_totality(program: Program, filename: str) -> None:
    """Totality gate for `verified fn` (syntax-2.0 §7).

    This first cut is deliberately conservative: a verified function may not
    participate in any cycle in the direct-call graph, because the checker
    cannot currently prove structural descent. Loop bodies are traversed so
    recursion through `while`/`for` is still caught.
    """
    verified = [fn for fn in program.fn_decls if fn.verified]
    if not verified:
        return
    graph = _fn_call_graph(program)
    for decl in verified:
        if _reaches_self(decl.name, graph):
            raise RevlError(
                filename,
                decl.line,
                f"verified fn `{decl.name}` is not total: it participates in "
                "direct or mutual recursion (verified totality, syntax-2.0 §7)",
                hint="use structural recursion on a structurally smaller value, "
                     "or a syntactically bounded loop",
            )


def _has_return(stmts) -> bool:
    """True when a `return` appears anywhere in this statement tree."""
    for stmt in stmts:
        if isinstance(stmt, ReturnStmt):
            return True
        if isinstance(stmt, IfStmt):
            if _has_return(stmt.then) or _has_return(stmt.otherwise or []):
                return True
        elif isinstance(stmt, (WhileStmt, ForStmt)):
            if _has_return(stmt.body):
                return True
    return False


def _definitely_returns(stmts) -> bool:
    """True when control cannot reach the end of `stmts` without returning.

    Deliberately the same conservative rule Java and Rust apply, so a body this
    accepts is a body those tiers accept:

    - a `return` terminates;
    - an `if` terminates only when it has an `else` *and* both arms terminate
      (a bare `if` may be skipped);
    - `for` and a conditional `while` may run zero times, so neither terminates;
    - `while (true)` diverges (there is no `break` in the grammar), so nothing
      after it is reachable — Java and Rust agree, and no tier needs a value.
    """
    for stmt in stmts:
        if isinstance(stmt, ReturnStmt):
            return True
        if isinstance(stmt, IfStmt):
            if (stmt.otherwise is not None
                    and _definitely_returns(stmt.then)
                    and _definitely_returns(stmt.otherwise)):
                return True
        elif isinstance(stmt, WhileStmt):
            if isinstance(stmt.cond, ExprLit) and stmt.cond.value is True:
                return True
    return False


def _check_returns_on_every_path(decl: FnDecl, filename: str) -> None:
    """A fn with a declared return type must return on every path.

    Falling off the end is a portability trap, not a nicety: Python (the
    reference backend) silently yields `None`, TypeScript yields `undefined`,
    while Rust refuses with E0308 and Java with "missing return statement". A
    program the checker accepts must compile on every tier, so the strict
    reading is the frontend's.
    """
    if not decl.returns or _definitely_returns(decl.body):
        return
    last_line = getattr(decl.body[-1], "line", decl.line) if decl.body else decl.line
    if not _has_return(decl.body):
        raise RevlError(
            filename, decl.line,
            f"`{decl.name}` is declared to return `{decl.returns}` but its body "
            f"never returns a value",
            hint=f"end the body with `return <{decl.returns}>`, or drop the "
                 f"`-> {decl.returns}` annotation if the fn produces nothing — "
                 "revl has no implicit result (rust E0308, java \"missing return "
                 "statement\")",
            code="T1", category="type-mismatch",
            expected=decl.returns, actual=None,
        )
    raise RevlError(
        filename, last_line,
        f"`{decl.name}` is declared to return `{decl.returns}` but control can "
        f"reach the end of its body without a `return`",
        hint="every path must return: give the trailing `if` an `else` that "
             "returns, or add a final `return` after it — a `for`/`while` may "
             "run zero times and never counts (rust E0308, java \"missing "
             "return statement\")",
        code="T1", category="type-mismatch",
        expected=decl.returns, actual=None,
    )


def _lower_fns(program: Program, filename: str, types: dict | None = None) -> list:
    _check_verified_totality(program, filename)
    types = types or {}
    default_callables = (
        _HOST_CALLABLES
        | _BUILTIN_CONSTRUCTORS
        | {fn.name for fn in program.fn_decls}
        | {ext.name for ext in program.externs}
    )
    fns: list[dict] = []
    seen: set[str] = set()
    # Install the block-arm lift sink for the duration of fn-body lowering: a
    # statement-block match arm is lambda-lifted into a synthetic helper fn
    # (`_lift_block_arm`) collected here, then appended to `fns` below. `taken`
    # seeds the fresh-name search so a helper never shadows a user fn/extern.
    # setdefault installs the sink into `types` for the duration of fn-body
    # lowering (drained below); `_lift_block_arm` reads it back via
    # `types.get(LIFT_SINK)`, so the return value is not needed here.
    types.setdefault(LIFT_SINK, {
        "fns": [],
        "n": 0,
        "taken": ({fn.name for fn in program.fn_decls}
                  | {ext.name for ext in program.externs}),
    })
    for decl in program.fn_decls:
        # In a multi-file composition `filename` is only the first source
        # (paths[0]); a fn parsed from a LATER file carries its own `source`, so
        # its diagnostics must name that file, not paths[0] (roadmap 312).
        decl_file = decl.source or filename
        if decl.name in seen:
            raise RevlError(decl_file, decl.line, f"duplicate function `{decl.name}`")
        seen.add(decl.name)
        # the body sees the *marked* signature: this fn's own type parameters
        # are wildcards inside it (they are universally quantified there), while
        # a one-letter nominal type stays checked
        sig = (types.get(FNS_KEY) or {}).get(decl.name) or {}
        marked_params = sig.get("params") or [p.type for p in decl.params]
        marked_returns = sig.get("returns", decl.returns)
        scope: dict[str, bool] = {}
        type_env: dict[str, str] = {}
        for param, marked in zip(decl.params, marked_params):
            if param.name in scope:
                raise RevlError(decl_file, param.line,
                                f"duplicate parameter `{param.name}` in fn {decl.name}")
            scope[param.name] = False
            type_env[param.name] = marked
        module_callables = program.fn_scopes.get(id(decl), default_callables)
        callables = _HOST_CALLABLES | _BUILTIN_CONSTRUCTORS | set(module_callables) | {ext.name for ext in program.externs}
        alias_fns = program.fn_alias_scopes.get(id(decl), {})
        body: list[dict] = []
        for stmt in decl.body:
            _lower_pure_stmt(stmt, scope, callables, alias_fns, body, decl_file, type_env, types,
                             expected_return=marked_returns)
        _check_returns_on_every_path(decl, decl_file)
        # phase-2 async coloring (docs/design/async-extern.md §3): a module
        # `fn` that reaches an async extern — directly or transitively — is no
        # longer refused here; it becomes async-colored by the `_async_callables`
        # fixed point in `check_and_lower`, which then stamps `"async": True` on
        # this entry. First-class *value* use of an async callable stays refused
        # (an arrow type carries no color), also in that post-pass once the
        # colored set is known. This function is now pure lowering.
        entry = {
            "name": decl.name,
            "params": [{"name": p.name, "type": p.type} for p in decl.params],
            "returns": decl.returns,
            "public": decl.public,
            "body": body,
        }
        if decl.verified:
            entry["verified"] = True
        if decl.source:
            _retarget_holes(entry["body"], decl.source)
        fns.append(entry)
    # Drain the lift sink: synthetic arm helpers join the functions list, so the
    # async-coloring and emission fixed points that run over `fns` see them.
    lifted = types.pop(LIFT_SINK, None)
    if lifted and lifted["fns"]:
        fns.extend(lifted["fns"])
    return fns


def _signature_table(program: Program, types: dict | None = None) -> dict:
    """{name: {"params": [type...], "returns": type|None, "tparams": set}} for
    fns + externs.

    Each signature's type parameters are marked here, once, so the rest of the
    checker can tell a universally quantified `T` from a nominal type that
    merely has a one-letter name. The set is the explicit `fn id[T](...)`
    names the decl carries (validated for shadowing here — see
    `validate_explicit_tparams`), plus — only when the decl carries NO list —
    the implicit single-uppercase names (roadmap 75(c): an explicit list
    turns the heuristic off; declared means declared).
    Marked types never reach the IR — this table is the checker's view, and
    `_lower_fns`/`_lower_externs` emit the author's spelling, byte-identical
    whether a parameter was implicit or explicit."""
    declared = {name: spec for name, spec in (types or {}).items()
                if not name.startswith("__")}
    sigs: dict = {}
    for decl in list(program.fn_decls) + list(program.externs):
        raw_params = [p.type for p in decl.params]
        explicit = validate_explicit_tparams(
            getattr(decl, "type_params", ()) or (), declared,
            program.filename, decl.line)
        tparams = collect_tparams(raw_params + [decl.returns], declared,
                                  explicit=explicit)
        # default-value expressions (roadmap item 187), aligned with `params`.
        # `None` for a parameter without a default; the ordering invariant
        # (defaults are trailing) is enforced in the parser, so `required` is
        # simply the count of leading non-defaulted parameters. Externs never
        # carry defaults (`FnParam.default` stays `None` there), so this is a
        # no-op for the extern half of the table.
        defaults = [getattr(p, "default", None) for p in decl.params]
        required = next((i for i, d in enumerate(defaults) if d is not None),
                        len(defaults))
        sigs[decl.name] = {
            "params": [mark_tparams(t, tparams) for t in raw_params],
            "returns": mark_tparams(decl.returns, tparams),
            "tparams": tparams,
            "defaults": defaults,
            "required": required,
        }
    return sigs


def _with_default_args(callee_name: str, given: list, types: dict, lower_one):
    """Append default-value IR for omitted trailing parameters (item 187).

    Call-site resolution: the emitters only ever see a fully-supplied argument
    list, so no tier needs default-parameter machinery. `given` is the
    already-lowered actual arguments; `lower_one` lowers one default
    *expression* AST to IR in the caller's context (a default is a pure
    expression that closes over nothing, so the caller's scope is immaterial).
    A signature with no defaults, or a call that supplies every argument,
    returns `given` unchanged — byte-identical to before item 187."""
    sig = (types.get(FNS_KEY) or {}).get(callee_name)
    if not sig:
        return given
    defaults = sig.get("defaults") or []
    if len(given) >= len(defaults):
        return given
    out = list(given)
    for d in defaults[len(given):]:
        # `d` is non-None here: the arity check admitted this call only because
        # every omitted trailing parameter carries a default.
        out.append(lower_one(d))
    return out


def _case_table(types: dict) -> dict:
    """ADT constructor table: case name -> {"adt", "payload"}. Builtins first;
    ambiguous user cases (same name in two ADTs) are dropped to stay silent."""
    cases: dict = {
        "Some": {"adt": "Opt[Any]", "payload": None},
        "None": {"adt": "Opt[Any]", "payload": None},
        "Ok": {"adt": "Result[Any, Any]", "payload": None},
        "Err": {"adt": "Result[Any, Any]", "payload": None},
    }
    ambiguous: set = set()
    for type_name, spec in types.items():
        if type_name.startswith("__") or spec.get("kind") != "variant":
            continue
        for case in spec.get("cases", []):
            name = case["name"]
            # `Some`/`None` are reserved for `Opt` (host-null representation);
            # a user ADT reusing them is ambiguous and dropped.
            if name in ("Some", "None"):
                ambiguous.add(name)
                cases.pop(name, None)
                continue
            # a user ADT may reuse `Ok`/`Err`: the user's declaration shadows
            # the built-in `Result` (the docs' own `type Outcome = Ok(Row) | …`
            # does exactly this).
            if name in ("Ok", "Err") and cases.get(name, {}).get("adt", "").startswith("Result"):
                cases[name] = {"adt": type_name, "payload": case["payload"]}
                continue
            if name in cases or name in ambiguous:
                ambiguous.add(name)
                cases.pop(name, None)
                continue
            cases[name] = {"adt": type_name, "payload": case["payload"]}
    return cases


def _arrow_param_types(expr) -> list:
    """An arrow's parameter types, one per parameter (None where unknown).

    The checker writes what it resolved back onto the AST node
    (`typecheck.py::_resolve_arrow`), so this is either the author's `(v: Int)`
    annotations, the types the expected function type supplied, or Nones when
    the arrow is still on the unchecked frontier."""
    written = list(getattr(expr, "param_types", None) or [])
    written += [None] * (len(expr.params) - len(written))
    return written[:len(expr.params)]


def _expr_static_type(expr, type_env: dict, types: dict) -> str | None:
    """Best-effort static type of a pure expression.

    match exhaustiveness is a best-effort check: when the scrutinee's type is
    not recoverable from the local type environment, lowering still proceeds
    (the Python emitter adds a runtime fallback for those cases).
    """
    # delegated to the bidirectional checker's inference (non-raising form)
    return infer_ast(expr, type_env, types)


def _type_arg(type_name: str | None, base: str) -> str | None:
    """Best-effort inner type of ``base[...]``."""
    if type_name and type_name.startswith(base + "["):
        return type_name[len(base) + 1 : -1]
    return None


def _is_sized_type(type_name: str | None) -> bool:
    return type_name in ("Str", "Bytes") or bool(type_name and type_name.startswith("List["))


def _variant_case_payload(types: dict, type_name: str | None, case_name: str) -> str | None:
    spec = types.get(type_name or "")
    if spec is None or spec.get("kind") != "variant":
        return None
    for case in spec.get("cases", []):
        if case["name"] == case_name:
            return case["payload"]
    return None


def _arm_payload_type(scrutinee_type: str | None, pattern: str, types: dict) -> str | None:
    """The payload type bound by a match arm. User variants come from the case
    table; built-in Opt/Result payloads come from the scrutinee's type args
    (`Opt[T]` -> Some binds T; `Result[T, E]` -> Ok binds T, Err binds E)."""
    user = _variant_case_payload(types, scrutinee_type, pattern)
    if user is not None:
        return user
    head, args = parse_type(scrutinee_type)
    if head == "Opt" and pattern == "Some" and args:
        return args[0]
    if head == "Result" and args and len(args) == 2:
        if pattern == "Ok":
            return args[0]
        if pattern == "Err":
            return args[1]
    return None


def _check_match_exhaustiveness(expr: ExprMatch, type_env: dict, types: dict, filename: str) -> None:
    type_name = _expr_static_type(expr.scrutinee, type_env, types)
    spec = types.get(type_name or "")
    if spec is None or spec.get("kind") != "variant":
        return
    # An arm naming something that is not a case of the scrutinee's ADT has no
    # meaning on any tier: Java emits a `case` label for a constant that does
    # not exist ("cannot find symbol") and the Rust emitter raises EmitError.
    # Python/TS silently never take the arm, so the divergence is a portability
    # bug rather than a compile error there — which is exactly what revl exists
    # to refuse.
    declared = [case["name"] for case in spec.get("cases", [])]
    for pattern, _, _ in expr.arms:
        if pattern != "_" and pattern not in declared:
            raise RevlError(
                filename, expr.line,
                f"`{pattern}` is not a case of `{type_name}` "
                f"(cases: {', '.join(f'`{c}`' for c in declared)})",
                hint="a match arm names one of the ADT's declared cases, or `_` for "
                     "a catch-all — a bare name is not a binding pattern "
                     "(syntax-2.0 §3.3); check the spelling or add the case to "
                     f"`type {type_name}`",
            )
    covered = {pattern for pattern, _, _ in expr.arms if pattern != "_"}
    if "_" in {pattern for pattern, _, _ in expr.arms}:
        return
    missing = [case["name"] for case in spec.get("cases", []) if case["name"] not in covered]
    if not missing:
        return
    if len(missing) == 1:
        rendered = f"`{missing[0]}`"
        plural = "case"
    else:
        rendered = ", ".join(f"`{name}`" for name in missing)
        plural = "cases"
    raise RevlError(filename, expr.line, f"non-exhaustive match: missing {plural} {rendered}")


def _mutable_free_vars(expr, scope: dict, bound: set[str] | None = None) -> set[str]:
    """Mutable `var` names referenced by ``expr`` and not shadowed by a
    lambda parameter.  Arrow literals snapshot these by value."""
    bound = set(bound or ())
    if isinstance(expr, ExprVar):
        if expr.name not in bound and scope.get(expr.name) is True:
            return {expr.name}
        return set()
    if isinstance(expr, ExprArrow):
        return _mutable_free_vars(expr.body, scope, bound | set(expr.params))
    if isinstance(expr, ExprBin):
        return _mutable_free_vars(expr.left, scope, bound) | _mutable_free_vars(expr.right, scope, bound)
    if isinstance(expr, ExprUn):
        return _mutable_free_vars(expr.operand, scope, bound)
    if isinstance(expr, ExprCall):
        found = _mutable_free_vars(expr.callee, scope, bound)
        for arg in expr.args:
            found |= _mutable_free_vars(arg, scope, bound)
        return found
    if isinstance(expr, ExprField):
        return _mutable_free_vars(expr.target, scope, bound)
    if isinstance(expr, ExprIndex):
        return _mutable_free_vars(expr.target, scope, bound) | _mutable_free_vars(expr.index, scope, bound)
    if isinstance(expr, ExprIf):
        return (
            _mutable_free_vars(expr.cond, scope, bound)
            | _mutable_free_vars(expr.then, scope, bound)
            | _mutable_free_vars(expr.otherwise, scope, bound)
        )
    if isinstance(expr, ExprRecord):
        found: set[str] = set()
        for _, value in expr.fields:
            found |= _mutable_free_vars(value, scope, bound)
        return found
    if isinstance(expr, ExprRecordUpdate):
        found = _mutable_free_vars(expr.base, scope, bound)
        for _, value in expr.updates:
            found |= _mutable_free_vars(value, scope, bound)
        return found
    if isinstance(expr, ExprList):
        found = set()
        for item in expr.items:
            found |= _mutable_free_vars(item, scope, bound)
        return found
    if isinstance(expr, ExprMatch):
        found = _mutable_free_vars(expr.scrutinee, scope, bound)
        for _, bind, body in expr.arms:
            arm_bound = set(bound)
            if bind is not None:
                arm_bound.add(bind)
            found |= _mutable_free_vars(body, scope, arm_bound)
        return found
    return set()


def _block_arm_unimplemented(filename: str, line: int) -> RevlError:
    """Block-bodied match arms lower by lambda-lifting into a synthetic helper
    fn (`_lift_block_arm`), which needs a lift sink in scope. A position without
    one (e.g. an extern undo expression) cannot lift, so it refuses loudly
    rather than half-emit."""
    return RevlError(
        filename, line,
        "a block-bodied match arm (`=> { … ; expr }`) is not lowerable here",
        hint="block arms lower inside a module `fn` body; lift the block into a "
             "named helper `fn` for this position (docs/records.md §6)",
    )


# The lift sink threads a synthetic-fn accumulator through fn-body lowering
# under a private (`__`-prefixed, so never serialised) key on the shared
# `types` dict. `_lower_fns` installs it and drains it into the functions list.
LIFT_SINK = "__arm_lift__"


def _pattern_binds(pattern) -> list[str]:
    """The names a `let`-pattern binds (record fields, list binds, list rest)."""
    names = list(getattr(pattern, "fields", None) or [])
    names += list(getattr(pattern, "binds", None) or [])
    rest = getattr(pattern, "rest", None)
    if rest:
        names.append(rest)
    return names


def _collect_arm_names(node, referenced: set[str], bound: set[str]) -> None:
    """Collect the names a block-arm subtree *reads* into ``referenced`` and the
    names it *declares* into ``bound``, so `_lift_block_arm` can capture exactly
    the enclosing bindings the arm uses.

    A generic AST walk: only the name-reading node (`ExprVar`, and the target of
    an assignment) and the name-binding nodes (`let`/`var`, `let`-pattern, `for`)
    are special-cased; every other node recurses over its dataclass fields."""
    if isinstance(node, list):
        for item in node:
            _collect_arm_names(item, referenced, bound)
        return
    if isinstance(node, ExprVar):
        referenced.add(node.name)
        return
    if isinstance(node, LetStmt):
        _collect_arm_names(node.value, referenced, bound)
        bound.add(node.name)
        return
    if isinstance(node, LetPatternStmt):
        _collect_arm_names(node.value, referenced, bound)
        for name in _pattern_binds(node.pattern):
            bound.add(name)
        return
    if isinstance(node, ForStmt):
        _collect_arm_names(node.iterable, referenced, bound)
        bound.add(node.bind)
        _collect_arm_names(node.body, referenced, bound)
        return
    if isinstance(node, AssignStmt):
        # the target names an existing binding the block writes into
        referenced.add(node.name)
        _collect_arm_names(node.value, referenced, bound)
        return
    if dataclasses.is_dataclass(node):
        for field in dataclasses.fields(node):
            _collect_arm_names(getattr(node, field.name), referenced, bound)
        return
    # scalars (str/int/None) carry no names


def _lift_block_arm(expr, scope: dict, callables: set, alias_fns: dict,
                    filename: str, type_env: dict, types: dict) -> dict:
    """Lower a statement-block match arm by lambda-lifting it into a synthetic
    helper fn (docs/records.md §6).

    The arm's statements become the helper's body, its final expression becomes
    the helper's `return`, and every enclosing name the block reads becomes a
    parameter. The arm's value is then a *call* to that helper — an expression,
    so the IR arm-body-as-expression invariant holds and every backend that
    emits a fn call emits the arm without new emit support.

    The body is lowered with the ordinary fn-body machinery (`_lower_pure_stmt`),
    so the arm obeys exactly the purity/effect rules of any pure value block: an
    effect statement, or an assignment to a captured (now immutable) name, is
    refused just as it would be in a normal block that produces a value."""
    sink = types.get(LIFT_SINK)
    if sink is None:
        raise _block_arm_unimplemented(filename, expr.line)

    referenced: set[str] = set()
    bound: set[str] = set()
    for stmt in expr.stmts:
        _collect_arm_names(stmt, referenced, bound)
    _collect_arm_names(expr.tail, referenced, bound)
    captures = sorted(n for n in referenced if n in scope and n not in bound)

    params: list[dict] = []
    arm_scope: dict = {}
    arm_type_env: dict = {}
    for cap in captures:
        ctype = type_env.get(cap)
        if ctype is None:
            raise RevlError(
                filename, expr.line,
                f"a match block arm reads `{cap}`, whose type is not known here",
                hint="annotate the binding this arm reads so the lifted arm "
                     "helper can type its parameter (docs/records.md §4)")
        params.append({"name": cap, "type": ctype})
        # a captured `var` enters the helper as an immutable parameter: reading
        # it is fine, assigning to it is refused, which is exactly the purity a
        # value-producing block owes its enclosing scope.
        arm_scope[cap] = "host" if scope.get(cap) == "host" else False
        arm_type_env[cap] = ctype

    arm_body: list = []
    for stmt in expr.stmts:
        _lower_pure_stmt(stmt, arm_scope, callables, alias_fns, arm_body,
                         filename, arm_type_env, types)
    ret_type = infer_ast(expr.tail, arm_type_env, types, filename)
    arm_body.append({
        "step": "return",
        "expr": _lower_pure_expr(expr.tail, arm_scope, callables, alias_fns,
                                 filename, arm_type_env, types),
    })

    # A fresh, backend-safe helper name: no leading underscore (emitters reserve
    # that for scaffolding) and never a user fn/extern name.
    taken = sink["taken"]
    name = f"match_arm_{sink['n']}"
    while name in taken:
        sink["n"] += 1
        name = f"match_arm_{sink['n']}"
    sink["n"] += 1
    taken.add(name)
    sink["fns"].append({
        "name": name,
        "params": params,
        "returns": ret_type,
        "public": False,
        "body": arm_body,
    })
    return {"kind": "call",
            "callee": {"kind": "var", "name": name},
            "args": [{"kind": "var", "name": cap} for cap in captures]}


class _LaxScope(dict):
    """Permissive scope for extern undo/compensate refs.

    Host blocks are verbatim text; their undo/compensate expressions are
    host-level names (e.g. `close(socket)`) and are not checked against revl
    function scope.
    """

    def __contains__(self, key) -> bool:
        return True


def _lower_extern_expr(expr, filename: str) -> dict:
    return _lower_pure_expr(expr, _LaxScope(), set(), {}, filename)


def _check_extern_undo(expr, decl_name: str, slot: str, types: dict,
                       filename: str, result_type: str | None = None) -> None:
    """The extern-level `undo`/`compensate` slot, checked.

    Component-site `effect ... undo ...` runs through the component
    expression machinery, so it resolves every name against the bindings
    in scope at the effect site. An extern declares no bindings, so the
    slot's variable namespace is almost empty — with ONE exception. The
    `undo` of an acquire extern with a declared return type binds `result`,
    the acquired value: the teardown exists to release exactly what the
    acquisition produced (the WIT resource model is the canonical user —
    `extern acquire fn r_new(...) -> R undo r_drop(result)`). Nothing else
    is visible: the extern's own parameters are *not* implicitly captured
    (no tier defines teardown parameter capture; inventing that here would
    be unsound speculation), and `compensate` — a best-effort follow-up to
    a one-way emission, not an inverse — binds nothing at all. What the
    slot must satisfy mirrors the component-site rules plus the arity/type
    rigor of every other call:

    1. the callee is a plain call to a DECLARED callable (fn/extern via the
       shared signature table, host builtin, ADT constructor);
    2. self-reference is refused — the teardown exists to INVERT the
       acquisition; calling the extern again would re-acquire mid-cleanup;
    3. arity and argument types are checked against the declared signature,
       with `result: T` in scope exactly when described above.
    """
    from .parser import ExprCall, ExprField, ExprVar

    def _walk(e):
        if isinstance(e, ExprVar):
            if e.name == "result":
                if result_type is not None:
                    return  # the one implicit binding: the acquired value
                if slot == "compensate":
                    raise RevlError(
                        filename, e.line,
                        f"`result` is not bound in the `compensate` slot of "
                        f"extern `{decl_name}`",
                        hint="`result` names the value an acquire returns; a "
                             "compensation follows a one-way emission, which "
                             "acquires nothing — compensate from constants or "
                             "other declared fns")
                raise RevlError(
                    filename, e.line,
                    f"`result` does not exist here — extern `{decl_name}` "
                    "declares no return type, so there is no acquired value "
                    "to bind",
                    hint="declare `-> T` on the extern to give the teardown "
                         "its `result`, or tear down from constants")
            # any other bare name: the only implicit binding is `result`
            # (undo of an acquire) — locals don't exist, and the extern's
            # own parameters are not visible (no tier defines teardown
            # parameter capture)
            if result_type is not None:
                raise RevlError(
                    filename, e.line,
                    f"`{e.name}` is not declared — the `{slot}` slot of "
                    f"extern `{decl_name}` sees only the implicit `result` "
                    "binding",
                    hint="`result` is the acquired value; the extern's own "
                         "parameters are not visible to its teardown, so "
                         "anything else must travel as constants or through "
                         "other declared fns")
            raise RevlError(
                filename, e.line,
                f"`{e.name}` is not declared — the `{slot}` slot of extern "
                f"`{decl_name}` runs with no variables in scope",
                hint="an extern's own parameters are not visible to its "
                     "teardown; the undo must work from constants or from "
                     "other declared fns")
        if isinstance(e, ExprCall):
            if isinstance(e.callee, ExprVar):
                name = e.callee.name
                if name == decl_name:
                    raise RevlError(
                        filename, e.line,
                        f"extern `{decl_name}`'s `{slot}` cannot call the "
                        "extern itself",
                        hint="the teardown runs to invert this acquisition — "
                             "calling it again would re-acquire during "
                             "cleanup; call the declared inverse instead")
                if (name not in (types.get(FNS_KEY) or {})
                        and name not in (types.get(CASES_KEY) or {})
                        and name not in _HOST_CALLABLES
                        and name not in _BUILTIN_CONSTRUCTORS):
                    raise RevlError(
                        filename, e.line,
                        f"`{name}` is not declared — the `{slot}` slot of "
                        f"extern `{decl_name}` may only call a declared fn, "
                        "extern, or host builtin",
                        hint="an extern binds no callables (only the acquire's "
                             "`result` value is ever in scope), so every "
                             "callee must be a module-level declaration")
            elif isinstance(e.callee, ExprField):
                raise RevlError(
                    filename, e.line,
                    f"the `{slot}` slot of extern `{decl_name}` must be a "
                    "plain call to a declared fn or extern",
                    hint="host objects cannot be acquired inside a teardown "
                         "expression; call the declared inverse directly")
            for a in e.args:
                _walk(a)
            return
        # generic recursion over the dataclass children (bin operands, record
        # fields, match arms, template parts, ...)
        for f in type(e).__dataclass_fields__:
            v = getattr(e, f)
            if hasattr(v, "__dataclass_fields__"):
                _walk(v)
            elif isinstance(v, (list, tuple)):
                for x in v:
                    if hasattr(x, "__dataclass_fields__"):
                        _walk(x)
                    elif isinstance(x, (list, tuple)):
                        for y in x:
                            if hasattr(y, "__dataclass_fields__"):
                                _walk(y)

    _walk(expr)
    # the tenv carries exactly what the slot binds: `result: T` for the undo
    # of an acquire with a declared return, nothing otherwise — so argument
    # type-checking sees the acquired value at its declared type
    tenv = {"result": result_type} if result_type is not None else {}
    check_ast(expr, None, tenv, types, filename,
              f"{slot} of extern `{decl_name}`")


_UNIT_RETURNS = (None, "Unit")


def _check_deferred_extern(decl, filename: str) -> None:
    """The `deferred` checker obligations (docs/design/245-session-commit.md,
    Decision 2). Every rule keeps class (b) — the deferrable emission — an exact
    type judgment: the checker can enforce the abort/commit semantics only
    because these hold at declaration.

    1. `deferred` only on an `emission`. `pure` has nothing to defer; `acquire`
       and `witnessed` must run mid-session (their return is the resource or the
       witness).
    2. A deferred emission returns `Unit`. The call completes before the action
       fires, so no value can flow back; a non-Unit return would be a lie the
       program could branch on. This is also the mechanical (b)/(c) boundary: an
       emission whose response the task needs mid-session cannot type `deferred`.
    3. `deferred` and `compensate` are mutually exclusive. A compensation offsets
       a fired emission on abort; a deferred emission's abort drops the queue
       (nothing fired, nothing to offset), so the pair is dead code.
    4. `deferred` and `async` are mutually exclusive (v1): there is no response
       to await.
    """
    if decl.classification != "emission":
        raise RevlError(
            filename, decl.line,
            f"`deferred` is only valid on an `emission` extern; `{decl.name}` is "
            f"`{decl.classification}`",
            hint="a `pure` extern has nothing to defer, and an `acquire` or "
                 "`witnessed` extern must run mid-session — its return is the "
                 "resource or the witness (docs/design/245-session-commit.md)",
            code="G4", category="deferred")
    if decl.returns not in _UNIT_RETURNS:
        raise RevlError(
            filename, decl.line,
            f"a `deferred` emission must return `Unit`; `{decl.name}` returns "
            f"`{decl.returns}`",
            hint="a deferred emission returns before the world changes, so no "
                 "value can flow back from it — an emission whose response the "
                 "task needs mid-session stays an immediate emission (drop "
                 "`deferred`)",
            code="G4", category="deferred")
    if decl.compensate is not None:
        raise RevlError(
            filename, decl.line,
            f"a `deferred` emission cannot declare `compensate`; `{decl.name}` "
            f"declares both",
            hint="a compensation offsets a fired emission on abort, but a "
                 "deferred emission's abort drops the queue — nothing fired, so "
                 "there is nothing to offset. The pair is dead code by "
                 "construction (docs/design/245-session-commit.md)",
            code="G5", category="deferred")
    if decl.async_:
        raise RevlError(
            filename, decl.line,
            f"a `deferred` emission cannot be `async` (v1); `{decl.name}` is both",
            hint="a deferred emission returns Unit at the call and fires later at "
                 "the session commit, so there is no response to await",
            code="G4", category="deferred")


def _check_deferred_not_in_teardown(program, filename: str) -> None:
    """Rule: deferred emissions are refused in teardown positions — the `undo`
    and `compensate` slots (docs/design/245-session-commit.md, Decision 2).
    Teardown runs at or after the verdict; enqueueing into a queue that is
    already flushing or dropped is unanswerable (the same spirit as 247's "a
    compensation emits and returns; it does not accumulate")."""
    from .parser import ExprCall, ExprVar

    deferred = {d.name for d in program.externs if d.deferred}
    if not deferred:
        return

    def _scan(expr, decl_name: str, slot: str) -> None:
        if isinstance(expr, ExprCall):
            callee = expr.callee
            if isinstance(callee, ExprVar) and callee.name in deferred:
                raise RevlError(
                    filename, callee.line,
                    f"the `{slot}` slot of extern `{decl_name}` calls deferred "
                    f"emission `{callee.name}` — deferred emissions are refused "
                    f"in teardown positions",
                    hint="teardown runs at or after the session verdict; a "
                         "deferred emission would enqueue into a queue that is "
                         "already flushing or dropped, which is unanswerable "
                         "(docs/design/245-session-commit.md)",
                    code="G5", category="deferred")
            for arg in expr.args or []:
                _scan(arg, decl_name, slot)

    for decl in program.externs:
        if decl.undo is not None:
            _scan(decl.undo, decl.name, "undo")
        if decl.compensate is not None:
            _scan(decl.compensate, decl.name, "compensate")


def _check_witnessed_inverse(decl, extern_class: dict, filename: str) -> None:
    """Rule 3 (docs/design/243-witnessed-externs.md): a witnessed extern's
    declared inverse must be classified **non-emission AND non-witnessed**.

    An emission inverse would cross a one-way boundary during teardown — the
    exact thing G5's no-emission-in-undo forbids, and it degrades a proof-grade
    rollback into best-effort residue. A witnessed inverse is infinite regress:
    its own inverse would need registering, and so on. The declared inverse is
    a host-LOCAL restore, so only `pure`/`acquire` callees are admissible.

    `undo some_emission(result)` passes `_check_extern_undo` today (the shared
    `mode="undo"` machinery only checks the callee is *declared*), so this walk
    is the explicit close: every extern a witnessed `undo` calls is held to the
    rule, which also fences the latent acquire hole the same expression opens.
    """
    from .parser import ExprCall, ExprVar

    def _walk(e):
        if isinstance(e, ExprCall):
            if isinstance(e.callee, ExprVar):
                name = e.callee.name
                bad = extern_class.get(name)
                if bad in ("emission", "witnessed"):
                    kind = ("an emission" if bad == "emission"
                            else "itself witnessed")
                    why = ("emissions are one-way boundary crossings and may not "
                           "run in teardown (G5)" if bad == "emission"
                           else "a witnessed inverse would need its own inverse "
                                "registered — infinite regress")
                    raise RevlError(
                        filename, e.line,
                        f"the inverse of witnessed extern `{decl.name}` calls "
                        f"`{name}`, which is {kind} — a witnessed inverse must be "
                        f"a host-local restore (G5)",
                        hint=f"{why}; declare the inverse `pure` or `acquire` "
                             f"(docs/design/243-witnessed-externs.md)",
                        code="G5", category="witnessed",
                    )
            for a in e.args:
                _walk(a)
            return
        for f in type(e).__dataclass_fields__:
            v = getattr(e, f)
            if hasattr(v, "__dataclass_fields__"):
                _walk(v)
            elif isinstance(v, (list, tuple)):
                for x in v:
                    if hasattr(x, "__dataclass_fields__"):
                        _walk(x)

    _walk(decl.undo)


def _witnessed_extern_names(program: Program) -> set[str]:
    """Names of every `witnessed`-classified extern declared in *program*
    (docs/design/243-witnessed-externs.md). Shared by the effect-position
    refusal (rule 1) below and the call-site transactional lowering
    (Slice 2, `_lower_component`)."""
    return {ext.name for ext in program.externs if ext.classification == "witnessed"}


def _refuse_witnessed_outside_effect_position(program: Program, filename: str) -> None:
    """Rule 1 (docs/design/243-witnessed-externs.md): a witnessed extern is
    refused outside effect position — no bare call from a plain `fn`/`test`
    body.

    A witnessed mutation is reversible only because the teardown accumulator
    auto-registers its declared inverse. A `fn`/`test` body has no accumulator,
    so a call there would mutate the host with the inverse dropped on the floor
    — silently irreversible, the one outcome the classification exists to
    prevent. Every extern is otherwise callable from a fn/test body (they seed
    the `callables` set), so this is an explicit refusal, checked over the
    author's AST where the call site still has a line."""
    from .parser import ExprCall, ExprVar

    witnessed = _witnessed_extern_names(program)
    if not witnessed:
        return

    def _walk(node, where: str):
        if isinstance(node, ExprCall) and isinstance(node.callee, ExprVar) \
                and node.callee.name in witnessed:
            raise RevlError(
                filename, node.line,
                f"witnessed extern `{node.callee.name}` cannot be called in {where} "
                f"— a witnessed mutation is only valid in effect position (G4)",
                hint="its declared inverse is auto-registered by the teardown "
                     "accumulator, which exists only in a component activation; a "
                     "fn/test body has none, so the mutation would be irreversible "
                     "(docs/design/243-witnessed-externs.md)",
                code="G4", category="witnessed",
            )
        if hasattr(node, "__dataclass_fields__"):
            for f in type(node).__dataclass_fields__:
                _walk(getattr(node, f), where)
        elif isinstance(node, (list, tuple)):
            for x in node:
                _walk(x, where)

    for fn in program.fn_decls:
        for stmt in fn.body:
            _walk(stmt, f"the body of fn `{fn.name}`")
    for test in program.tests:
        for stmt in test.body:
            _walk(stmt, f"the body of test `{test.name}`")


def _lower_externs(program: Program, filename: str, types: dict) -> list:
    externs: list[dict] = []
    seen: set[str] = set()
    # classification of every extern by name, so a declared inverse can be held
    # to the "non-emission AND non-witnessed" rule (docs/design/243 rule 3): an
    # inverse that itself emits crosses a one-way boundary in teardown (G5), and
    # a witnessed inverse is infinite regress. Built before the loop so an
    # inverse may name an extern declared later in the file.
    extern_class = {d.name: d.classification for d in program.externs}
    # item 245: a deferred emission may not appear in any extern's teardown slot
    # (a whole-program check, so an `undo`/`compensate` naming a deferred extern
    # declared later in the file is still caught).
    _check_deferred_not_in_teardown(program, filename)
    for decl in program.externs:
        if decl.name in seen:
            raise RevlError(filename, decl.line, f"duplicate extern `{decl.name}`")
        seen.add(decl.name)
        if decl.classification == "acquire" and decl.undo is None:
            raise RevlError(
                filename, decl.line,
                f"acquire extern `{decl.name}` must declare `undo` (G4)",
                hint="an `acquire` crosses into an observable effect and needs a teardown inverse",
            )
        if decl.classification == "pure" and (decl.undo is not None or decl.compensate is not None):
            raise RevlError(
                filename, decl.line,
                f"pure extern `{decl.name}` cannot declare `undo` or `compensate`",
                hint="`pure` means no observable effect, so there is nothing to invert or compensate",
            )
        if decl.classification == "emission" and decl.undo is not None:
            raise RevlError(
                filename, decl.line,
                f"emission extern `{decl.name}` cannot declare `undo`",
                hint="emissions are one-way boundary crossings; use `compensate` for a best-effort cleanup",
            )
        # witnessed-inverse externs (docs/design/243-witnessed-externs.md). A
        # witnessed mutation is a transaction, not a bracket: its declared `undo`
        # is auto-registered by the accumulator and replays on abort only. The
        # correctness envelope is checked here, before the descriptor reaches the
        # IR — the Slice-2 runtime seam trusts these invariants.
        witness_type: str | None = None
        if decl.classification == "witnessed":
            if decl.compensate is not None:
                raise RevlError(
                    filename, decl.line,
                    f"witnessed extern `{decl.name}` cannot declare `compensate`",
                    hint="a witnessed mutation carries a proof-grade `undo`; "
                         "`compensate` is the best-effort form for one-way emissions",
                    code="G5", category="witnessed",
                )
            if decl.undo is None:
                raise RevlError(
                    filename, decl.line,
                    f"witnessed extern `{decl.name}` must declare `undo` (G4)",
                    hint="a witnessed mutation is reversible only because it names the "
                         "inverse the accumulator auto-registers; declare "
                         "`undo <inverse>(result)`",
                    code="G4", category="witnessed",
                )
            # The witness is the return value, and it must be a `Result[W, E]` so
            # the inverse registers on `Ok` only (a failed mutation touched
            # nothing): rule "registered only on Ok" (docs/design/243).
            head, args = parse_type(decl.returns)
            if head != "Result" or len(args) != 2:
                raise RevlError(
                    filename, decl.line,
                    f"witnessed extern `{decl.name}` must return "
                    f"`Result[Witness, Error]` — the fallible witness the inverse "
                    f"binds (G4)",
                    hint="every host mutation can fail (ENOENT/EPERM/disk-full); the "
                         "inverse is auto-registered on the `Ok` branch only, so the "
                         "return must be a `Result`",
                    code="G4", category="witnessed",
                )
            witness_type = args[0]
            # The witness must be WAL-serializable DATA, not a host handle: a
            # crash leaves only the write-ahead log, and an inverse closing over
            # an in-process object is residue, not recovery (recovery.py). A host
            # object type (Map/Pool/Job) cannot be reconstructed from the WAL.
            wt_head, _ = parse_type(witness_type)
            if wt_head in _HOST_CALLABLES:
                raise RevlError(
                    filename, decl.line,
                    f"witnessed extern `{decl.name}` witness `{witness_type}` is a "
                    f"host object — the witness must be WAL-serializable data (G8)",
                    hint="a host handle dies with the process; after a crash only the "
                         "write-ahead log survives, so the witness must be durable data "
                         "(paths, refs, a record) the inverse can be rebuilt from",
                    code="G8", category="witnessed",
                )
        # `async` validity (docs/design/async-extern.md §1): the modifier is
        # legal only on `emission` externs, and an async extern may not declare
        # `compensate` in v1 (the compensation seam is synchronous on every
        # tier). These sit next to the classification rules above and refuse
        # with honest messages before the flag reaches the IR.
        if decl.async_:
            if decl.classification == "pure":
                raise RevlError(
                    filename, decl.line,
                    f"`pure` extern `{decl.name}` cannot be `async` — a suspension is "
                    f"observable; classify it `emission`",
                    hint="pure externs are callable from every pure position (tests, "
                         "match guards, undo slots), which have no async story",
                )
            if decl.classification == "acquire":
                raise RevlError(
                    filename, decl.line,
                    f"`acquire` extern `{decl.name}` cannot be `async` yet — an "
                    f"acquire's `undo` runs on the synchronous teardown/unwind path",
                    hint="classify it `emission`, or file the need if an awaited "
                         "teardown ever becomes real",
                )
            if decl.classification == "witnessed":
                raise RevlError(
                    filename, decl.line,
                    f"`witnessed` extern `{decl.name}` cannot be `async` yet — its "
                    f"declared inverse replays on the synchronous abort/teardown path",
                    hint="classify it `emission`, or file the need if an awaited "
                         "rollback ever becomes real",
                )
            if decl.compensate is not None:
                raise RevlError(
                    filename, decl.line,
                    "an `async` extern cannot declare `compensate` yet — the "
                    "compensation seam is synchronous on every tier",
                )
        # `deferred` validity (docs/design/245-session-commit.md, Decision 2).
        # The class of an action is a total function of its checked
        # classification: nothing at runtime or in the harness can move an
        # action between classes, so the rules that keep class (b) honest are
        # enforced here, before the flag reaches the IR.
        if decl.deferred:
            _check_deferred_extern(decl, filename)
        bodies: dict[str, str] = {}
        for body in decl.bodies:
            if body.backend in bodies:
                raise RevlError(filename, body.line,
                                f"duplicate @{body.backend} body for extern `{decl.name}`")
            bodies[body.backend] = body.text
        entry: dict = {
            "name": decl.name,
            "class": decl.classification,
            "params": [{"name": p.name, "type": p.type} for p in decl.params],
            "returns": decl.returns,
            "bodies": bodies,
            # additive async flag (docs/design/async-extern.md §4), mirroring
            # the service-method spelling at lower.py:2583. Absent means sync;
            # `ir_version` stays 3 (confirmed human decision, §4).
            **({"async": True} if decl.async_ else {}),
            # additive deferred flag (docs/design/245-session-commit.md,
            # Decision 2): class (b), the deferrable emission. Absent means the
            # emission fires at the call (class c). Only an `emission` extern may
            # carry it (checked above), so no non-emission extern's IR changes.
            **({"deferred": True} if decl.deferred else {}),
        }
        if decl.classification == "witnessed":
            # The witnessed descriptor the Slice-2 runtime teardown loop reads
            # (docs/design/243-witnessed-externs.md). `entry_kind: "transactional"`
            # is the SECOND accumulator entry kind — distinct from an acquire's
            # bracket: it replays on abort ONLY and is discharged (+ its witness
            # GC'd) on commit, where a bracket also replays on clean unload.
            # `ok_conditional` records that the inverse auto-registers on the
            # Result's `Ok` branch only; `witness` is the WAL-serializable data
            # type the inverse is reconstructed from.
            entry["entry_kind"] = "transactional"
            entry["revertible"] = True
            entry["ok_conditional"] = True
            entry["witness"] = witness_type
            if decl.capabilities:
                entry["capabilities"] = list(decl.capabilities)
        if decl.undo is not None:
            # An acquire binds its declared return as `result`; a witnessed
            # extern binds the `Ok` witness (the Result's success payload), which
            # is exactly what the auto-registered inverse receives on abort.
            undo_result_type = (witness_type if decl.classification == "witnessed"
                                else decl.returns)
            # Classification of the inverse before its arg types: a witnessed or
            # emission inverse is refused on principle, whatever it is applied to.
            if decl.classification == "witnessed":
                _check_witnessed_inverse(decl, extern_class, filename)
            _check_extern_undo(decl.undo, decl.name, "undo", types, filename,
                               result_type=undo_result_type)
            entry["undo"] = _lower_extern_expr(decl.undo, filename)
        if decl.compensate is not None:
            _check_extern_undo(decl.compensate, decl.name, "compensate",
                               types, filename)
            entry["compensate"] = _lower_extern_expr(decl.compensate, filename)
        externs.append(entry)
    return externs


def _lower_tests(program: Program, filename: str, types: dict,
                 services: dict | None = None) -> list:
    """Lower `test` and `lifecycle test` blocks to IR v3 test units (§7/§7.1).

    `types` (the case/signature table) is threaded through so a `test` body is
    the same expression scope a `fn` body is: nullary user-ADT constructors
    resolve as values (`let s = FirstTime`) and statements are type-checked.
    """
    if not program.tests:
        return []
    # A `test` body is the same callable scope a `fn` body is (mirrors
    # `_lower_fns`' `default_callables` and `_lower_prop_tests`): module `fn`s
    # AND `extern`s, plus the host callables/constructors already in fn scope.
    # Without the externs an in-module `extern pure fn` visible to fn bodies was
    # invisible inside a `test`, forcing every extern-backed helper to be
    # wrapped in a `fn` just to be unit-tested in-file (roadmap item 182).
    callables = (_HOST_CALLABLES | _BUILTIN_CONSTRUCTORS
                 | {fn.name for fn in program.fn_decls}
                 | {ext.name for ext in program.externs})
    tests: list[dict] = []
    seen: set[str] = set()
    for decl in program.tests:
        if decl.name in seen:
            raise RevlError(filename, decl.line, f"duplicate test `{decl.name}`")
        seen.add(decl.name)
        if decl.lifecycle:
            tests.append({
                "name": decl.name,
                "lifecycle": True,
                "body": _lower_lifecycle_body(decl, program, services or {}, filename,
                                              callables, types),
            })
            continue
        scope: dict[str, bool] = {}
        type_env: dict[str, str] = {}
        body: list[dict] = []
        for stmt in decl.body:
            _lower_pure_stmt(stmt, scope, callables, {}, body, filename, type_env, types)
        tests.append({"name": decl.name, "body": body})
    return tests


# ---------------------------------------------------------------- prop tests
#
# `prop test "name" (params) { assert … }` (roadmap item 37): the parameters
# are *generated inputs*, and the body is a pure property that must hold for
# every generated value.  Lowering does two things a plain `test` does not:
#
#   * it validates that every parameter type is one the generator can DERIVE a
#     value from (a primitive, an `Opt`/`List`/`Result` of one, or a declared
#     record/ADT), so an ungeneratable parameter is a compile error rather than
#     a runtime surprise; and
#   * it records the parameters (with their resolved types) alongside the
#     lowered body in a `prop_tests` IR section, from which the py runner
#     (src/revl/fault.py) derives the generators and the shrinker.
#
# The body itself lowers exactly as a `fn`/`test` body does, with the
# parameters in scope — so `assert` reads identically to everywhere else.
_GENERATABLE_PRIMITIVES = {"Int", "Int32", "Bool", "Str", "Float", "F64", "Num"}


def _check_generatable(filename: str, line: int, type_name: str, types: dict,
                       propname: str, record_stack: tuple = (),
                       variant_seen: frozenset = frozenset()) -> None:
    """Reject a prop-test parameter (or nested) type the generator cannot make.

    Generatable: a primitive; `Opt[T]`/`List[T]` of a generatable argument; a
    declared record whose fields are generatable; a declared ADT whose case
    payloads are generatable.  A record that (transitively) contains
    itself is genuinely non-constructible and is named as such; recursive ADTs
    are fine (they have a base case, and the runner bounds generation depth).
    """
    head, args = parse_type(type_name)
    if head in _GENERATABLE_PRIMITIVES and not args:
        return
    if head == "Opt" and len(args) == 1:
        _check_generatable(filename, line, args[0], types, propname,
                           record_stack, variant_seen)
        return
    if head == "List" and len(args) == 1:
        _check_generatable(filename, line, args[0], types, propname,
                           record_stack, variant_seen)
        return
    spec = types.get(head) if head and not args else None
    if spec and spec.get("kind") == "record":
        if head in record_stack:
            cycle = " -> ".join(record_stack + (head,))
            raise RevlError(
                filename, line,
                f"prop test `{propname}`: record type `{head}` contains itself "
                f"({cycle}) and cannot be generated",
                hint="a record always holds all its fields, so a self-containing record "
                     "has no finite value; break the cycle with an `Opt[...]` or `List[...]`")
        for ftype in spec.get("fields", {}).values():
            _check_generatable(filename, line, ftype, types, propname,
                               record_stack + (head,), variant_seen)
        return
    if spec and spec.get("kind") == "variant":
        if head in variant_seen:
            # already validated on this path — a recursive ADT is fine (it has a
            # base case; the depth-bounded generator handles it). Stop rather
            # than descend forever.
            return
        for case in spec.get("cases") or []:
            if case.get("payload") is not None:
                # a case payload may reference the ADT recursively — the record
                # cycle stack is not carried across the ADT boundary (that split
                # is a valid base/recursive one), but the variant set is, to
                # terminate on a self-referential ADT
                _check_generatable(filename, line, case["payload"], types, propname,
                                   (), variant_seen | {head})
        return
    raise RevlError(
        filename, line,
        f"prop test `{propname}`: parameter type `{type_name}` cannot be generated",
        hint="a prop-test parameter must be a type the checker can derive inputs from: "
             "`Int`/`Int32`/`Bool`/`Str`/`Float`, an `Opt[...]`/`List[...]` of one, or a "
             "declared record/ADT (docs/prop-test.md)")


def _lower_prop_tests(program: Program, filename: str, types: dict,
                      services: dict | None = None) -> list:
    """Lower `prop test` blocks to IR prop units (docs/prop-test.md)."""
    if not program.prop_tests:
        return []
    callables = (_HOST_CALLABLES | _BUILTIN_CONSTRUCTORS
                 | {fn.name for fn in program.fn_decls}
                 | {ext.name for ext in program.externs})
    units: list[dict] = []
    seen: set[str] = set()
    for decl in program.prop_tests:
        if decl.name in seen:
            raise RevlError(filename, decl.line, f"duplicate prop test `{decl.name}`")
        seen.add(decl.name)
        scope: dict[str, bool] = {}
        type_env: dict[str, str] = {}
        for param in decl.params:
            check_type_wellformed(filename, param.line, param.type)
            _check_generatable(filename, param.line, param.type, types, decl.name)
            scope[param.name] = False
            type_env[param.name] = param.type
        body: list[dict] = []
        for stmt in decl.body:
            _lower_pure_stmt(stmt, scope, callables, {}, body, filename, type_env, types)
        units.append({
            "name": decl.name,
            "params": [{"name": p.name, "type": p.type} for p in decl.params],
            "body": body,
        })
    return units


# `fail at effect X` is sugar: it resolves to the index of the body step that
# binds X, so every backend and the runner see exactly one addressing scheme
# (a step index).  Index is the primitive because it is total — *every* body
# step has one, including `emit`, `provide`, `await` and unbound `effect`
# blocks — while a name only exists for `let effect NAME = …`.  The name form
# is the refactor-stable one to write, so both spellings are kept and the
# diagnostics always report the pair.
_FAULT_ASSERTS = (
    "failed", "no-residue", "inverses-lifo", "no-emissions", "siblings-unaffected",
)


def _fault_effect_index(body: list, name: str) -> int | None:
    """1-based index of the top-level `let-effect` step binding *name*."""
    for index, step in enumerate(body, 1):
        if step.get("step") == "let-effect" and step.get("bind") == name:
            return index
    return None


def _lower_fault_tests(program: Program, components: list, filename: str) -> list:
    """Lower `fault test` blocks to IR fault units (docs/fault-tests.md).

    Runs after component lowering: the injection point is validated against
    the *lowered* body, so `fail at step 4` is a compile error when the
    component only has three steps rather than a confusing runtime miss.
    """
    if not program.fault_tests:
        return []
    by_name = {component["name"]: component for component in components}
    units: list[dict] = []
    seen: set[str] = set()
    for decl in program.fault_tests:
        if decl.name in seen:
            raise RevlError(filename, decl.line, f"duplicate fault test `{decl.name}`")
        seen.add(decl.name)
        component = by_name.get(decl.component)
        if component is None:
            known = ", ".join(sorted(by_name)) or "(none in this composition)"
            raise RevlError(filename, decl.line,
                            f"fault test `{decl.name}` names unknown component `{decl.component}`",
                            hint=f"components in this composition: {known}")
        body = component.get("body") or []
        if not body:
            raise RevlError(filename, decl.line,
                            f"component `{decl.component}` has an empty activation body — "
                            f"there is no point at which it can fail")
        if decl.at_effect is not None:
            step = _fault_effect_index(body, decl.at_effect)
            if step is None:
                bindings = [s.get("bind") for s in body if s.get("step") == "let-effect"]
                known = ", ".join(f"`{b}`" for b in bindings) or "(none)"
                raise RevlError(
                    filename, decl.line,
                    f"fault test `{decl.name}`: component `{decl.component}` has no "
                    f"`let … effect` step bound to `{decl.at_effect}`",
                    hint=f"effect bindings in `{decl.component}`: {known}")
        else:
            step = decl.at_step
            if step > len(body):
                raise RevlError(
                    filename, decl.line,
                    f"fault test `{decl.name}`: `fail at step {step}` is past the end of "
                    f"`{decl.component}` (its activation body has {len(body)} step(s))")
        known_config = {field.get("name") for field in component.get("config") or []}
        for key in decl.config:
            if key not in known_config:
                fields = ", ".join(sorted(known_config)) or "(none)"
                raise RevlError(
                    filename, decl.line,
                    f"fault test `{decl.name}`: `{decl.component}` has no config field `{key}`",
                    hint=f"config fields of `{decl.component}`: {fields}")
        asserts: list[str] = []
        for kind, line in decl.asserts:
            if kind not in _FAULT_ASSERTS:  # pragma: no cover — parser gates the spelling
                raise RevlError(filename, line, f"unknown fault-test assertion `{kind}`")
            if kind not in asserts:
                asserts.append(kind)
        unit = {
            "name": decl.name,
            "component": decl.component,
            "at": {"step": step},
            "assert": asserts,
        }
        if decl.at_effect is not None:
            unit["at"]["effect"] = decl.at_effect
        if decl.config:
            unit["config"] = dict(decl.config)
        units.append(unit)
    return units

def _lower_lifecycle_body(decl: TestDecl, program: Program, services: dict, filename: str,
                          callables: set, types: dict) -> list:
    """Lower a `lifecycle test` body (syntax-2.0 §7.1).

    The body is a *linear script* over a live composition, so the checker can
    track exactly what is loaded and what keys are provided at every point —
    every diagnostic below is a compile error, not a runtime surprise.

    G2 (provision disjointness) is what makes this tractable and is also the
    reason there is no `swap C -> C2` statement: two components may not
    provide the same key in one document, so a replacement *provider* is not
    expressible; a replacement *instance* is `unload C` then `load C with
    { ... }`, which this statement set already spells.
    """
    components = {comp.name: comp for comp in program.components}
    loaded: dict[str, ComponentDecl] = {}    # component name -> decl
    provided: dict[str, str] = {}            # provision key -> component name
    scope: dict[str, bool] = {}
    type_env: dict[str, str] = {}
    body: list[dict] = []

    def _known() -> str:
        return ", ".join(f"`{name}`" for name in sorted(components)) or "<none>"

    for stmt in decl.body:
        if isinstance(stmt, LoadStmt):
            comp = components.get(stmt.component)
            if comp is None:
                raise RevlError(filename, stmt.line,
                                f"unknown component `{stmt.component}`",
                                hint=f"a lifecycle test loads components declared in this "
                                     f"document: {_known()}")
            if stmt.component in loaded:
                raise RevlError(
                    filename, stmt.line,
                    f"`{stmt.component}` is already loaded",
                    hint="one instance per component at a time — `unload` it first; two live "
                         "providers of one key is exactly what G2 forbids (§7.1)",
                )
            config = _lower_lifecycle_config(stmt, comp, filename, scope, callables,
                                             type_env, types)
            for key, _svc, _line in comp.provides:
                provided[key] = comp.name
            loaded[comp.name] = comp
            body.append({"step": "load", "component": comp.name, "config": config})
        elif isinstance(stmt, UnloadStmt):
            if stmt.component not in loaded:
                if stmt.component not in components:
                    raise RevlError(filename, stmt.line,
                                    f"unknown component `{stmt.component}`",
                                    hint=f"declared components: {_known()}")
                raise RevlError(filename, stmt.line,
                                f"`{stmt.component}` is not loaded at this point")
            comp = loaded.pop(stmt.component)
            for key, _svc, _line in comp.provides:
                provided.pop(key, None)
            body.append({"step": "unload", "component": comp.name})
        elif isinstance(stmt, CallStmt):
            body.append(_lower_lifecycle_call(stmt, provided, components, services, filename,
                                              scope, callables, type_env, types))
        elif isinstance(stmt, AdvanceStmt):
            # item 102: drive the clock coeffect (item 57) forward. Nothing else
            # in a lifecycle test moves the clock, so this is what makes a
            # timer's firing an assertable timeline step.
            body.append({"step": "advance", "ms": stmt.ms})
        elif isinstance(stmt, ResidueStmt):
            body.append({"step": "assert_no_residue"})
        elif isinstance(stmt, AssertStmt):
            expr = stmt.expr
            if isinstance(expr, ExprVar) and expr.name not in scope:
                raise RevlError(
                    filename, stmt.line,
                    f"unknown lifecycle assertion `{expr.name}`",
                    hint="the lifecycle assertion is `assert no_residue` (§7.1); anything else "
                         "after `assert` is a Bool expression over this test's `let` bindings",
                )
            _bool_cond(expr, type_env, types, filename, "assert")
            body.append({"step": "assert",
                         "expr": _lower_pure_expr(expr, scope, callables, {}, filename,
                                                  type_env, types)})
        else:  # pragma: no cover — the lifecycle grammar produces nothing else
            raise RevlError(filename, getattr(stmt, "line", decl.line),
                            "unexpected statement in a lifecycle test body")

    return body


def _lower_lifecycle_config(stmt: LoadStmt, comp: ComponentDecl, filename: str, scope: dict,
                            callables: set, type_env: dict, types: dict) -> dict:
    """Check and lower `load C with { field: expr, ... }` against C's `config`."""
    fields = {cfg.name: cfg for cfg in comp.config}
    given: dict[str, dict] = {}
    for name, value, line in stmt.config:
        cfg = fields.get(name)
        if cfg is None:
            known = ", ".join(f"`{f}`" for f in fields) or "<none>"
            raise RevlError(filename, line,
                            f"`{name}` is not a config field of {comp.name}",
                            hint=f"config fields of {comp.name}: {known}")
        if name in given:
            raise RevlError(filename, line, f"duplicate config field `{name}`")
        check_ast(value, cfg.type, type_env, types, filename,
                  f"config field `{name}` of {comp.name}")
        given[name] = _lower_pure_expr(value, scope, callables, {}, filename, type_env, types)
    missing = [cfg.name for cfg in comp.config if cfg.default is None and cfg.name not in given]
    if missing:
        listed = ", ".join(f"`{name}`" for name in missing)
        raise RevlError(filename, stmt.line,
                        f"`load {comp.name}` is missing required config {listed}",
                        hint=f"write `load {comp.name} with {{ {missing[0]}: ... }}`")
    return given


def _lower_lifecycle_call(stmt: CallStmt, provided: dict, components: dict, services: dict,
                          filename: str, scope: dict, callables: set,
                          type_env: dict, types: dict) -> dict:
    """Check and lower `call key.op(args)` / `let x = call key.op(args)`.

    A lifecycle test drives the composition from *outside* it — it is not a
    provider — so G4's `emit` marker does not apply here: the bound G4
    enforces is a service declaration bounding *its providers*, and a test has
    no declaration to exceed (§7.1).
    """
    owner = provided.get(stmt.key)
    if owner is None:
        keys = sorted({key for comp in components.values() for key, _s, _l in comp.provides})
        if stmt.key in keys:
            raise RevlError(
                filename, stmt.line,
                f"no provider for key `{stmt.key}` at this point",
                hint="load the component that provides it before calling through the key",
            )
        listed = ", ".join(f"`{key}`" for key in keys) or "<none>"
        raise RevlError(filename, stmt.line,
                        f"unknown provision key `{stmt.key}`",
                        hint=f"keys provided in this document: {listed}")
    comp = components[owner]
    service_name = next(svc for key, svc, _line in comp.provides if key == stmt.key)
    svc = services.get(service_name)
    if svc is None:  # pragma: no cover — checked when the component was lowered
        raise RevlError(filename, stmt.line, f"unknown service `{service_name}`")
    method = svc.methods.get(stmt.method)
    if method is None:
        listed = ", ".join(f"`{name}`" for name in svc.methods) or "<none>"
        raise RevlError(filename, stmt.line,
                        f"`{stmt.key}.{stmt.method}` is not an operation of service "
                        f"{service_name}",
                        hint=f"operations of {service_name}: {listed}")
    if len(stmt.args) != len(method.params):
        raise RevlError(filename, stmt.line,
                        f"`{stmt.key}.{stmt.method}` takes {len(method.params)} "
                        f"argument(s), {len(stmt.args)} given")
    args = []
    for arg, (pname, ptype) in zip(stmt.args, method.params):
        check_ast(arg, ptype, type_env, types, filename,
                  f"`{stmt.key}.{stmt.method}` argument `{pname}`")
        args.append(_lower_pure_expr(arg, scope, callables, {}, filename, type_env, types))
    node = {"step": "call", "key": stmt.key, "method": stmt.method, "args": args}
    if stmt.bind is not None:
        if stmt.bind in scope:
            raise RevlError(filename, stmt.line,
                            f"`{stmt.bind}` is already declared in this lifecycle test",
                            hint="bindings are test-scoped, not block-scoped — "
                                 "sibling branches share one namespace; rename "
                                 "or reuse the existing binding")
        scope[stmt.bind] = False
        if method.returns:
            type_env[stmt.bind] = method.returns
        node["bind"] = stmt.bind
    return node


def _bool_cond(expr, type_env: dict, types: dict, filename: str, where: str) -> None:
    # a condition is a check position like any other: `if (hole "…")` is a
    # `Bool` obligation, not an untyped hole (docs/holes.md)
    if pin_hole(expr, "Bool", filename, f"`{where}` condition"):
        return
    t = infer_ast(expr, type_env, types, filename)
    if t is not None and t != "Bool":
        raise mismatch(filename, getattr(expr, "line", 0), f"`{where}` condition", "Bool", t)


def _lower_pure_stmt(stmt, scope: dict, callables: set, alias_fns: dict, body: list, filename: str,
                     type_env: dict | None = None, types: dict | None = None,
                     expected_return: str | None = None) -> None:
    type_env = type_env if type_env is not None else {}
    types = types if types is not None else {}
    if isinstance(stmt, LetStmt):
        if stmt.name in scope:
            raise RevlError(filename, stmt.line,
                            f"`{stmt.name}` is already declared in this function",
                            hint="a `let` binds a name once per scope — rename this "
                                 "binding, or use `=` to reassign an existing `var`. "
                                 "(Disjoint sibling blocks — the two arms of an "
                                 "if/else — may reuse a name, since only one is live.)")
        # host provenance: a let bound to a host constructor call carries
        # host-object methods, exempt from the stdlib method table
        if not stmt.mutable and _is_host_valued(stmt.value, scope):
            scope[stmt.name] = "host"
        else:
            scope[stmt.name] = stmt.mutable
        declared = getattr(stmt, "type", None)
        if declared is not None:
            # `let g: (Int) -> Int = v => v + 1` — the annotation is the
            # checking position for the right-hand side, which is what gives an
            # un-annotated arrow its parameter and return types.
            check_type_wellformed(filename, stmt.line, declared)
            check_ast(stmt.value, declared, type_env, types, filename,
                      f"`let {stmt.name}: {render_type(declared)}`")
            type_env[stmt.name] = declared
            actual_declared = infer_ast(stmt.value, type_env, types, None)
        else:
            inferred = infer_ast(stmt.value, type_env, types, filename)
            if inferred is not None:
                type_env[stmt.name] = inferred
            actual_declared = None
        lowered_value = _lower_pure_expr(stmt.value, scope, callables, alias_fns, filename, type_env, types)
        # an annotated `let x: Float = 3` is a coercion site too (docs/arithmetic.md)
        _mark_widen(declared, actual_declared, lowered_value)
        _pin_empty_literal(declared, lowered_value)
        body.append({"step": "let", "name": stmt.name,
                     "value": lowered_value,
                     "mutable": stmt.mutable})
    elif isinstance(stmt, LetPatternStmt):
        _lower_let_pattern_stmt(stmt, scope, callables, alias_fns, body, filename, type_env, types)
    elif isinstance(stmt, AssignStmt):
        if stmt.name not in scope:
            raise RevlError(filename, stmt.line, f"`{stmt.name}` is not declared in this function",
                            hint="declare it with `let` (single-assignment) or `var` (mutable)")
        if not scope[stmt.name]:
            raise RevlError(filename, stmt.line,
                            f"cannot reassign `{stmt.name}` — it is `let` (single-assignment)",
                            hint="declare it with `var` to make it mutable (syntax-2.0 §3.5)")
        if stmt.op == "=":
            value = stmt.value
        else:
            # `x += e` desugars to `x = x + e`; the parser only composes the
            # operator, so lowering never has to remember it beyond this point.
            value = ExprBin(stmt.op[:-1], ExprVar(stmt.name, stmt.line), stmt.value, stmt.line)
        declared = type_env.get(stmt.name)
        if isinstance(value, ExprArrow) and declared:
            # reassigning a `var` of function type: the arrow needs the
            # declaration as its *checking* position, exactly as at the `let`.
            # Inference alone returns nothing for an un-annotated arrow, so the
            # comparison below would pass anything (docs/function-types.md).
            check_ast(value, declared, type_env, types, filename,
                      f"assignment to `{stmt.name}` (a `{render_type(declared)}` variable)")
        inferred = infer_ast(value, type_env, types, filename)
        if declared and inferred and not compatible(declared, inferred):
            raise mismatch(filename, stmt.line,
                           f"assignment to `{stmt.name}` (a `{render_type(declared)}` variable)",
                           declared, inferred)
        if inferred is not None and declared is None:
            type_env[stmt.name] = inferred
        lowered_value = _lower_pure_expr(value, scope, callables, alias_fns, filename, type_env, types)
        # assigning into a `Float`-declared variable is a coercion site too
        _mark_widen(declared, inferred, lowered_value)
        body.append({"step": "assign", "name": stmt.name,
                     "value": lowered_value})
    elif isinstance(stmt, ReturnStmt):
        if stmt.expr is not None:
            check_ast(stmt.expr, expected_return, type_env, types, filename, "this function's return")
        elif expected_return:
            raise RevlError(filename, stmt.line,
                            f"bare `return` in a function declared to return `{expected_return}`")
        lowered = (None if stmt.expr is None else
                   _lower_pure_expr(stmt.expr, scope, callables, alias_fns,
                                    filename, type_env, types))
        if lowered is not None and expected_return:
            actual_ret = infer_ast(stmt.expr, type_env, types, filename)
            # `return 3` in a `-> Float` fn is a coercion site (docs/arithmetic.md)
            _mark_widen(expected_return, actual_ret, lowered)
            lowered = _inject_opt(expected_return,
                                  actual_ret,
                                  lowered)
        body.append({"step": "return", "expr": lowered})
    elif isinstance(stmt, IfStmt):
        then: list[dict] = []
        _bool_cond(stmt.cond, type_env, types, filename, "if")
        # Each arm is its own block: it snapshots the enclosing scope/type_env
        # (as `while`/`for`/`match` arms already do) rather than sharing one flat
        # dict. This block-scopes the arm's `let`s — they do not leak past the
        # `if`, and the two arms cannot collide with each other, so disjoint
        # sibling branches may reuse a name. A redeclaration *within* one arm, or
        # in one straight-line scope, still hits the guard: the snapshot is
        # mutated in sequence, so the second `let` sees the first.
        then_scope = dict(scope)
        then_type_env = dict(type_env)
        for s in stmt.then:
            _lower_pure_stmt(s, then_scope, callables, alias_fns, then, filename, then_type_env, types, expected_return)
        otherwise = None
        if stmt.otherwise is not None:
            otherwise = []
            else_scope = dict(scope)
            else_type_env = dict(type_env)
            for s in stmt.otherwise:
                _lower_pure_stmt(s, else_scope, callables, alias_fns, otherwise, filename, else_type_env, types, expected_return)
        body.append({"step": "if", "cond": _lower_pure_expr(stmt.cond, scope, callables, alias_fns, filename, type_env, types),
                     "then": then, "else": otherwise})
    elif isinstance(stmt, WhileStmt):
        _bool_cond(stmt.cond, type_env, types, filename, "while")
        cond = _lower_pure_expr(stmt.cond, scope, callables, alias_fns, filename, type_env, types)
        inner_scope = dict(scope)
        inner_type_env = dict(type_env)
        inner_body: list[dict] = []
        for s in stmt.body:
            _lower_pure_stmt(s, inner_scope, callables, alias_fns, inner_body, filename, inner_type_env, types, expected_return)
        body.append({"step": "while", "cond": cond, "body": inner_body})
    elif isinstance(stmt, ForStmt):
        if stmt.bind in scope:
            raise RevlError(filename, stmt.line,
                            f"`{stmt.bind}` is already declared in this function",
                            hint="a loop binding shadows nothing already in scope — "
                                 "rename it. (Disjoint sibling blocks may reuse a "
                                 "name, since only one is live.)")
        iter_diag = infer_ast(stmt.iterable, type_env, types, filename)
        if iter_diag is not None and parse_type(iter_diag)[0] != "List":
            raise RevlError(filename, stmt.line,
                            f"`for ... of` iterates a `List[...]`, got `{render_type(iter_diag)}`")
        iterable = _lower_pure_expr(stmt.iterable, scope, callables, alias_fns, filename, type_env, types)
        inner_scope = dict(scope)
        inner_type_env = dict(type_env)
        inner_scope[stmt.bind] = False
        iter_type = _expr_static_type(stmt.iterable, type_env, types)
        element_type = _type_arg(iter_type, "List")
        if element_type is not None:
            inner_type_env[stmt.bind] = element_type
        inner_body = []
        for s in stmt.body:
            _lower_pure_stmt(s, inner_scope, callables, alias_fns, inner_body, filename, inner_type_env, types, expected_return)
        body.append({"step": "for", "bind": stmt.bind, "iterable": iterable, "body": inner_body})
    elif isinstance(stmt, ExprStmt):
        infer_ast(stmt.expr, type_env, types, filename)
        body.append({"step": "expr", "expr": _lower_pure_expr(stmt.expr, scope, callables, alias_fns, filename, type_env, types)})
    elif isinstance(stmt, AssertStmt):
        _bool_cond(stmt.expr, type_env, types, filename, "assert")
        body.append({"step": "assert", "expr": _lower_pure_expr(stmt.expr, scope, callables, alias_fns, filename, type_env, types)})
    else:  # pragma: no cover — grammar prevents it
        raise RevlError(filename, getattr(stmt, "line", 1), "unexpected statement in fn body")


def _lower_let_pattern_stmt(stmt: LetPatternStmt, scope: dict, callables: set, alias_fns: dict,
                            body: list, filename: str, type_env: dict, types: dict) -> None:
    """Lower a `let`/`var` destructuring to one ``let_pattern`` step."""
    pattern = stmt.pattern
    if isinstance(pattern, RecordPattern):
        names = list(pattern.fields)
        if not names:
            raise RevlError(filename, pattern.line, "record destructuring needs at least one field")
        if len(set(names)) != len(names):
            raise RevlError(filename, pattern.line, "duplicate name in record destructuring")
        for name in names:
            if name in scope:
                raise RevlError(filename, stmt.line,
                                f"`{name}` is already declared in this function",
                                hint="a `let` binds a name once per scope — rename this "
                                     "binding, or use `=` to reassign an existing `var`. "
                                     "(Disjoint sibling blocks may reuse a name, since "
                                     "only one is live.)")
        value_type = _expr_static_type(stmt.value, type_env, types)
        spec = types.get(value_type or "")
        if spec is not None:
            if spec.get("kind") != "record":
                raise RevlError(
                    filename, stmt.line,
                    f"record destructuring requires a record, but `{render_type(value_type)}` is not a record",
                )
            fields = spec.get("fields", {})
            for name in names:
                if name not in fields:
                    raise RevlError(filename, pattern.line,
                                    f"`{name}` is not a field of record `{render_type(value_type)}`")
        elif value_type is not None and parse_type(value_type)[0] in _BUILTIN_NONRECORD:
            raise RevlError(
                filename, stmt.line,
                f"record destructuring requires a record, but `{render_type(value_type)}` is not a record",
            )
        value_ir = _lower_pure_expr(stmt.value, scope, callables, alias_fns, filename, type_env, types)
        for name in names:
            scope[name] = stmt.mutable
            if spec is not None:
                type_env[name] = spec.get("fields", {})[name]
        body.append({
            "step": "let_pattern",
            "pattern": "record",
            "names": names,
            "value": value_ir,
            "mutable": stmt.mutable,
        })
        return

    if isinstance(pattern, ListPattern):
        if not pattern.binds:
            raise RevlError(filename, pattern.line,
                            "list destructuring needs at least one binding before `...rest`")
        names = list(pattern.binds)
        if pattern.rest is not None:
            names.append(pattern.rest)
        if len(set(names)) != len(names):
            raise RevlError(filename, pattern.line, "duplicate name in list destructuring")
        for name in names:
            if name in scope:
                raise RevlError(filename, stmt.line,
                                f"`{name}` is already declared in this function",
                                hint="a `let` binds a name once per scope — rename this "
                                     "binding, or use `=` to reassign an existing `var`. "
                                     "(Disjoint sibling blocks may reuse a name, since "
                                     "only one is live.)")
        value_type = _expr_static_type(stmt.value, type_env, types)
        if value_type is not None and parse_type(value_type)[0] != "List" and (
            types.get(value_type) is not None
            or parse_type(value_type)[0] in _BUILTIN_NONRECORD
        ):
            raise RevlError(
                filename, stmt.line,
                f"list destructuring requires a `List[...]`, but `{render_type(value_type)}` is not a list",
            )
        value_ir = _lower_pure_expr(stmt.value, scope, callables, alias_fns, filename, type_env, types)
        element_type = _type_arg(value_type, "List")
        for name in pattern.binds:
            scope[name] = stmt.mutable
            if element_type is not None:
                type_env[name] = element_type
        if pattern.rest is not None:
            scope[pattern.rest] = stmt.mutable
            if value_type is not None:
                type_env[pattern.rest] = value_type
        body.append({
            "step": "let_pattern",
            "pattern": "list",
            "names": pattern.binds,
            "rest": pattern.rest,
            "value": value_ir,
            "mutable": stmt.mutable,
        })
        return

    raise RevlError(filename, stmt.line, "unexpected destructuring pattern")


def _tagged_case(name: str, types: dict) -> dict | None:
    """If `name` is a *tagged* ADT constructor — the built-in `Result`
    (`Ok`/`Err`) or any user variant case — return its case-table entry.
    `Opt` (`Some`/`None`) is not tagged: it stays host-null/value, so it is
    excluded here and handled as identity/null."""
    if name in ("Some", "None"):
        return None
    return (types.get(CASES_KEY) or {}).get(name)


def _lower_hole(expr: ExprHole, filename: str) -> dict:
    """`hole` -> the IR's one non-executable node (docs/holes.md).

    A hole must know its type by now: the checker pins it from context in
    check position, and `hole[T]` states it outright. Anywhere else the
    honest answer is a rejection — guessing would hand the author a type the
    compiler invented, which is exactly the drowning-in-noise failure holes
    exist to fix.
    """
    type_name = expr.known_type
    if type_name is None:
        raise RevlError(
            filename, expr.line,
            "this `hole` has no expected type — nothing in its context says "
            "what it must eventually be",
            hint="annotate it (`hole[Str] \"why\"`), or put it somewhere with a "
                 "declared type: a `fn`'s `-> T`, a service method's return, or "
                 "an argument of a declared function (docs/holes.md)",
            code="T3", category="hole",
        )
    check_type_wellformed(filename, expr.line, type_name)
    node = {"kind": "hole", "type": type_name, "file": filename, "line": expr.line}
    if expr.message is not None:
        node["message"] = expr.message
    return node


def _retarget_holes(node, source: str) -> None:
    """Point holes at the file they were written in.

    Lowering runs over one merged program, so its `filename` is the first
    root path; a declaration carries its own provenance and an obligation an
    agent must go and fill is worthless with the wrong path on it.
    """
    if isinstance(node, dict):
        if node.get("kind") == "hole":
            node["file"] = source
        for value in node.values():
            _retarget_holes(value, source)
    elif isinstance(node, list):
        for value in node:
            _retarget_holes(value, source)


# Operators whose meaning depends on whether the operands are Int or Float.
# `/` and `%` because integer and float division differ; `+`, `-` and `*`
# because Int is a *bounded* 64-bit type whose overflow traps, and a tier
# cannot check a bound it does not know applies. Comparisons and booleans
# gain nothing from the annotation, so they do not carry it.
_TYPED_ARITH_OPS = ("/", "%", "+", "-", "*")


def _str_literal_value(value):
    """Canonical IR form for a `Str` literal: a sequence of Unicode scalar
    values (code points), never UTF-16 surrogate pairs (docs/strings.md,
    roadmap item 51 — the string wave).

    The lexer stores raw source characters and a Python `str` is already a
    code-point sequence, so for a well-formed program this is the identity.
    It is stated explicitly here because it is the invariant every backend's
    literal escaper depends on: each emitter reads this value and must escape
    *from code points* (`\\u{1F600}` on rust, `\\U0001F600` on go, the raw
    scalar in wasm's UTF-8 pool), never re-encode it as UTF-16. A lone
    surrogate reaching this point would mean an upstream path re-introduced
    UTF-16 — the exact defect that made astral literals uncompilable on go and
    rust — so it is rejected here rather than emitted as invalid source.
    """
    if isinstance(value, str):
        for ch in value:
            if 0xD800 <= ord(ch) <= 0xDFFF:
                raise ValueError(
                    "string literal carries a lone surrogate; a Str literal is "
                    "a sequence of Unicode code points (docs/strings.md)")
    return value


def _mark_widen(expected: str | None, actual: str | None, node: dict | None) -> dict | None:
    """Mark an implicit `Int` -> `Float` coercion site in the IR.

    `compatible` lets an `Int` stand where a `Float` is declared, but until
    now the widening was invisible: a `call` argument, a `let` value or a
    `return` expression reached every backend as a bare `lit`/`var`, and the
    tiers that keep `Int` and `Float` apart split three ways on `ident(3)`
    (docs/arithmetic.md) — rust refused with E0308, TypeScript computed the
    wrong answer (`3n === 3` is false), and python/go/java absorbed it behind
    a host rule. This is the same shape of gap `operands` closed for `/`, and
    it closes the same way: the frontend — the single IR producer, and the
    only stage that knows both types — annotates the coercion site, and every
    backend can emit the conversion.

    The marker is additive (`"widen": "Float"` on the coerced node), so no
    `ir_version` changes and v1/v2/v3 reference documents stay
    byte-identical: a coercion site requires a declared `Float` position,
    which only full-language (v3) sources can express.
    """
    if node is None:
        return node
    ehead = parse_type(expected)[0]
    ahead = parse_type(actual)[0]
    if ehead == "Float" and ahead in ("Int", "Int32"):
        node["widen"] = "Float"
    elif ehead == "Int" and ahead == "Int32":
        # Int32 -> Int is a lossless *widening* the tiers that keep the two
        # widths apart (rust i32/i64, wasm, go, java, ts number/bigint) must
        # emit explicitly, exactly as Int -> Float is marked. `"widen": "Int"`
        # names the target width; python absorbs it (one int type).
        node["widen"] = "Int"
    return node


def _pin_empty_literal(declared: str | None, node: dict | None) -> None:
    """An annotated `let`/`var` pins an empty-collection literal (roadmap 76b, 107).

    `var m: Map[Str, Int] = Map.empty()` lowers to a `maplit` node that knows
    nothing about the author's annotation — the checker accepts the empty map
    (it types `Map[Str, Never]`, bottom, and flows into any `Map[K, V]`) but
    the go tier refuses an unpinned empty Map because Go infers composite
    literals positionally, not from later use. The annotation the author
    already wrote is the pin, so the frontend — the single IR producer, and
    the only stage that knows the declared type — attaches it to the literal:
    ``"expected": "Map[Str, Int]"`` on the `maplit` node. The marker is
    additive and appears only where an annotation exists, so v1/v2/v3
    reference documents without one stay byte-identical.
    """
    if declared is None or not isinstance(node, dict):
        return
    kind = node.get("kind")
    if kind == "maplit":
        node["expected"] = declared
    elif (
        kind == "list"
        and not (node.get("items") or [])
        and declared.startswith("List[")
    ):
        # `var out: List[Int] = []` (roadmap 107): the checker accepts the empty
        # list (it types `List[Never]`, bottom, and flows into any `List[T]`) but
        # a positional emitter — the wasm tier — has no element to infer from and
        # refuses. The author's annotation is the pin, threaded onto the literal
        # exactly as the empty-Map case above, so the emitter can type it.
        node["expected"] = declared


def _lower_pure_expr(expr, scope: dict, callables: set, alias_fns: dict, filename: str,
                     type_env: dict | None = None, types: dict | None = None) -> dict:
    type_env = type_env if type_env is not None else {}
    types = types if types is not None else {}
    if isinstance(expr, ExprHole):
        return _lower_hole(expr, filename)
    # ADT construction (Result / user variants) lowers to a tagged `adt` node
    # (Opt's Some/None are not tagged — handled as identity/null downstream).
    _cases = types.get(CASES_KEY) or {}
    if isinstance(expr, ExprCall) and isinstance(expr.callee, ExprVar) \
            and _tagged_case(expr.callee.name, types) is not None:
        info = _cases[expr.callee.name]
        return {"kind": "adt", "type": info["adt"], "case": expr.callee.name,
                "args": [_lower_pure_expr(a, scope, callables, alias_fns, filename, type_env, types)
                         for a in expr.args]}
    if isinstance(expr, ExprVar):
        info = _tagged_case(expr.name, types)
        if info is not None and info.get("payload") is None \
                and not str(info.get("adt", "")).startswith(("Result", "Opt")):
            return {"kind": "adt", "type": info["adt"], "case": expr.name, "args": []}
    # Module-namespace call: `alias.fn(args)` desugars to the imported public
    # function by its original name (IR functions are top-level, not nested
    # in namespace objects).
    if (
        isinstance(expr, ExprCall)
        and isinstance(expr.callee, ExprField)
        and isinstance(expr.callee.target, ExprVar)
    ):
        alias = expr.callee.target.name
        if alias in alias_fns:
            name = expr.callee.name
            if name not in alias_fns[alias]:
                raise RevlError(
                    filename,
                    expr.callee.line,
                    f"`{alias}.{name}` is not a public function in module `{alias}`",
                    hint=f"`use ... as {alias}` imports only `pub` declarations (G1)",
                )
            return {
                "kind": "call",
                "callee": {"kind": "var", "name": name},
                "args": [_lower_pure_expr(a, scope, callables, alias_fns, filename, type_env, types) for a in expr.args],
            }
    if isinstance(expr, ExprLit):
        if expr.value is None:
            raise null_error(filename, expr.line)
        return {"kind": "lit", "value": _str_literal_value(expr.value)}
    if isinstance(expr, ExprVar):
        if expr.name not in scope and expr.name not in callables:
            raise RevlError(filename, expr.line, f"`{expr.name}` is not declared in this function",
                            hint="declare it with `let`/`var` or add it as a parameter (G1)")
        return {"kind": "var", "name": expr.name}
    if isinstance(expr, ExprBin):
        node = {"kind": "bin", "op": expr.op,
                "left": _lower_pure_expr(expr.left, scope, callables, alias_fns, filename, type_env, types),
                "right": _lower_pure_expr(expr.right, scope, callables, alias_fns, filename, type_env, types)}
        # `/` and `%` mean different things on Int and Float, and a backend
        # cannot tell them apart from the node alone: python and TypeScript
        # both render `7 / 2` as 3.5 while rust renders 3, and neither is
        # wrong given what it was told. Carrying the *operand* type (not the
        # result) is what makes the arithmetic specifiable at all — see
        # docs/arithmetic.md. Inference runs without a filename so an
        # undetermined operand is an absent annotation, never an error.
        if expr.op in _TYPED_ARITH_OPS:
            left_type = infer_ast(expr.left, type_env, types, None)
            right_type = infer_ast(expr.right, type_env, types, None)
            if left_type == "Int32" and right_type == "Int32":
                # Int32 arithmetic traps at the i32 edge, the same discipline
                # `Int` has at i64 (docs/arithmetic.md). `/` still yields Float
                # and `%` is width-agnostic; only `+ - *` need the i32 helper.
                node["operands"] = "Int32"
            elif left_type == "Int" and right_type == "Int":
                node["operands"] = "Int"
            elif "Float" in (left_type, right_type):
                node["operands"] = "Float"
        return node
    if isinstance(expr, ExprUn):
        node = {"kind": "un", "op": expr.op,
                "operand": _lower_pure_expr(expr.operand, scope, callables, alias_fns, filename, type_env, types)}
        # Unary minus is arithmetic too: negating Int.MIN overflows, and a
        # backend cannot tell an Int negation from a Float one without the
        # operand type — the same information `bin` carries for the same
        # reason. Only `Int` is annotated: it is the type whose bound a
        # backend must re-impose (docs/arithmetic.md), and no tier needs to
        # treat Float negation specially.
        if expr.op == "-":
            operand_type = infer_ast(expr.operand, type_env, types, None)
            if operand_type in ("Int", "Int32"):
                # `-x` is `0 - x`; on Int32, `0 - Int32.MIN` overflows the i32
                # range just as `0 - Int.MIN` overflows i64, so the bound is
                # re-imposed at the tier (docs/arithmetic.md).
                node["operands"] = operand_type
        return node
    if isinstance(expr, ExprCall):
        _callee = expr.callee
        # the Map VALUE constructor (docs/stdlib-2.0.md §Map): intercepted
        # before the host-receiver test, because `Map` is a host root — but
        # `empty` is a value-namespace name, disjoint from the host verbs.
        if (isinstance(_callee, ExprField)
                and isinstance(_callee.target, ExprVar)
                and _callee.target.name == "Map"
                and _callee.target.name not in scope
                and _callee.name == "empty"):
            if expr.args:
                raise RevlError(
                    filename, expr.line,
                    f"`Map.empty()` takes no arguments, {len(expr.args)} given",
                    hint="build up an empty map with `set`: `Map.empty().set(\"k\", v)`",
                )
            return {"kind": "maplit", "entries": []}
        _host_receiver = isinstance(_callee, ExprField) and (
            _is_host_valued(_callee.target, scope)
            # the constructor root itself (Map.new(), Pool.open(...)):
            or (isinstance(_callee.target, ExprVar)
                and _callee.target.name in _HOST_CALLABLES
                and _callee.target.name not in scope)
        )
        if isinstance(expr.callee, ExprField) and not _host_receiver:
            method = expr.callee.name
            arity = _BUILTIN_METHODS.get(method)
            if arity is None:
                raise RevlError(
                    filename, expr.line,
                    f"no builtin method `{method}` on values — the stdlib surface is "
                    f"{', '.join(sorted(_BUILTIN_METHODS))} (docs/stdlib-2.0.md)",
                    hint="records carry data, not methods; call functions as `f(x)`, "
                         "and call arrows through a `let` binding",
                )
            # The stdlib-named-method sliver (roadmap 75(b)): only a receiver
            # the checker can *prove* is a stdlib value (Str/List/Int/Int32/
            # Bytes/Map) may take the builtin table. A receiver whose
            # provenance no constructor pins — an extern's return, a
            # host-object result, a type parameter — used to lower a
            # stdlib-named method as that builtin and misdispatch at runtime.
            # Refuse it like any other host-boundary method (HOST-METHOD); the
            # fence then closes to exactly "host-object results are on the
            # audit surface" (G8).
            recv_t = _expr_static_type(expr.callee.target, type_env, types)
            if _is_wildcard(recv_t):
                _refuse_unpinned_stdlib_method(method, recv_t, filename,
                                               expr.line)
            if len(expr.args) != arity:
                raise RevlError(filename, expr.line,
                                f"builtin `{method}` takes {arity} argument(s), "
                                f"{len(expr.args)} given")
            _refuse_zero_divisor(method, expr.args, filename, expr.line)
            node: dict = {"kind": "builtin", "method": method,
                          "target": _lower_pure_expr(expr.callee.target, scope, callables, alias_fns, filename, type_env, types),
                          "args": [_lower_pure_expr(a, scope, callables, alias_fns, filename, type_env, types) for a in expr.args]}
            if method == "to_int":
                # `to_int` is spelled for two receiver families (Int32 widen,
                # Str parse) — the backends must dispatch on the receiver's
                # static type, which the IR node would otherwise not carry
                # (the same reason `un` annotates Int negation). Annotate it,
                # exactly as the checker selected the row.
                node["recv"] = infer_ast(expr.callee.target, type_env, types, None)
            return node
        # A call argument that widens Int -> Float is marked on the argument
        # node (`_mark_widen`) so every backend emits the conversion — the
        # `ident(3)` gap in docs/arithmetic.md. Generic signatures are
        # instantiated first, exactly as the checker does, so a `T` bound to
        # `Float` by this call marks too. Inference runs without a filename:
        # the checking pass has already diagnosed real mismatches, so this is
        # annotation only.
        if isinstance(expr.callee, ExprVar):
            sig = (types.get(FNS_KEY) or {}).get(expr.callee.name)
            if sig is not None and sig.get("params"):
                params = list(sig["params"])
                if sig.get("tparams"):
                    subst: dict = {}
                    arg_types = [infer_ast(a, type_env, types, None) for a in expr.args]
                    for p, a in zip(params, arg_types):
                        unify(p, a, subst)
                    params = [substitute(p, subst) for p in params]
                lowered_args = [_lower_pure_expr(a, scope, callables, alias_fns, filename, type_env, types)
                                for a in expr.args]
                for p, a, node in zip(params,
                                      [infer_ast(a, type_env, types, None) for a in expr.args],
                                      lowered_args):
                    _mark_widen(p, a, node)
                # item 187: fill omitted trailing arguments with each defaulted
                # parameter's default expression. Lower each default here and
                # mark the Int->Float widening on it exactly as a written
                # argument would get, so a `Float = 0` default emits correctly.
                sig = types.get(FNS_KEY, {}).get(expr.callee.name) or {}
                defaults = sig.get("defaults") or []
                for i in range(len(lowered_args), len(params)):
                    dexpr = defaults[i]
                    dnode = _lower_pure_expr(dexpr, scope, callables, alias_fns,
                                             filename, type_env, types)
                    _mark_widen(params[i], infer_ast(dexpr, type_env, types, None),
                                dnode)
                    lowered_args.append(dnode)
                return {"kind": "call", "callee": _lower_pure_expr(expr.callee, scope, callables, alias_fns, filename, type_env, types),
                        "args": lowered_args}
        return {"kind": "call", "callee": _lower_pure_expr(expr.callee, scope, callables, alias_fns, filename, type_env, types),
                "args": [_lower_pure_expr(a, scope, callables, alias_fns, filename, type_env, types) for a in expr.args]}
    if isinstance(expr, ExprField):
        target_type = _expr_static_type(expr.target, type_env, types)
        if expr.name == "length" and _is_sized_type(target_type):
            return {"kind": "len",
                    "target": _lower_pure_expr(expr.target, scope, callables, alias_fns, filename, type_env, types)}
        return {"kind": "field", "target": _lower_pure_expr(expr.target, scope, callables, alias_fns, filename, type_env, types),
                "name": expr.name}
    if isinstance(expr, ExprIndex):
        return {"kind": "index", "target": _lower_pure_expr(expr.target, scope, callables, alias_fns, filename, type_env, types),
                "index": _lower_pure_expr(expr.index, scope, callables, alias_fns, filename, type_env, types)}
    if isinstance(expr, ExprIf):
        return {"kind": "if", "cond": _lower_pure_expr(expr.cond, scope, callables, alias_fns, filename, type_env, types),
                "then": _lower_pure_expr(expr.then, scope, callables, alias_fns, filename, type_env, types),
                "else": _lower_pure_expr(expr.otherwise, scope, callables, alias_fns, filename, type_env, types)}
    if isinstance(expr, ExprRecord):
        # A record is a value type (syntax-2.0 §3.5): a field is initialised by
        # *copying* the initialiser's value into the record. Reading a `var`'s
        # field into a record (`{ x: v.field }`) has always been allowed for
        # exactly this reason, and a bare `var` read (`{ x: v }`) is the same
        # copy — the value is taken, the mutable cell is not captured, so the
        # `var` still never escapes its function. Both forms lower identically.
        return {"kind": "record",
                "fields": [[name, _lower_pure_expr(e, scope, callables, alias_fns, filename, type_env, types)]
                           for name, e in expr.fields]}
    if isinstance(expr, ExprRecordUpdate):
        return {"kind": "record_update",
                "base": _lower_pure_expr(expr.base, scope, callables, alias_fns, filename, type_env, types),
                "updates": [[name, _lower_pure_expr(e, scope, callables, alias_fns, filename, type_env, types)]
                            for name, e in expr.updates]}
    if isinstance(expr, ExprBlockArm):
        return _lift_block_arm(expr, scope, callables, alias_fns, filename,
                               type_env, types)
    if isinstance(expr, ExprList):
        return {"kind": "list",
                "items": [_lower_pure_expr(e, scope, callables, alias_fns, filename, type_env, types) for e in expr.items]}
    if isinstance(expr, ExprArrow):
        inner = dict(scope)
        inner_type_env = dict(type_env)
        param_types = _arrow_param_types(expr)
        for param, ptype in zip(expr.params, param_types):
            inner[param] = False
            if ptype:
                inner_type_env[param] = ptype
            else:
                inner_type_env.pop(param, None)
        captures = sorted(_mutable_free_vars(expr.body, scope, set(expr.params)))
        node = {"kind": "arrow", "params": expr.params, "captures": captures,
                "body": _lower_pure_expr(expr.body, inner, callables, alias_fns, filename, inner_type_env, types)}
        # IR v3: an arrow that the checker typed carries its signature, so a
        # backend can declare it instead of guessing (docs/function-types.md).
        # Both keys are absent together when the arrow is still untyped.
        if any(p is not None for p in param_types) or expr.returns:
            node["param_types"] = param_types
            node["returns"] = expr.returns
        # item 92: an arrow the checker typed against `(…) -> Async[T]` carries
        # the async color into the IR, so every emitter reads one shape
        # (`.get("async")`) instead of parsing the `returns` string.
        if expr.returns and parse_type(expr.returns)[0] == "Async":
            node["async"] = True
        return node
    if isinstance(expr, ExprMatch):
        scrutinee_type = _expr_static_type(expr.scrutinee, type_env, types)
        _check_match_exhaustiveness(expr, type_env, types, filename)
        scrutinee = _lower_pure_expr(expr.scrutinee, scope, callables, alias_fns, filename, type_env, types)
        arms = []
        for pattern, bind, body in expr.arms:
            inner_scope = dict(scope)
            inner_type_env = dict(type_env)
            payload_type = _arm_payload_type(scrutinee_type, pattern, types)
            if bind is not None:
                inner_scope[bind] = False
                inner_type_env.pop(bind, None)
                if payload_type is not None:
                    inner_type_env[bind] = payload_type
            arm = {
                "pattern": pattern,
                "bind": bind,
                "body": _lower_pure_expr(body, inner_scope, callables, alias_fns, filename, inner_type_env, types),
            }
            # payload type helps backends that must cast (e.g. Java's tagged
            # Result); other emitters ignore it
            if payload_type is not None:
                arm["payload_type"] = payload_type
            arms.append(arm)
        return {"kind": "match", "scrutinee": scrutinee, "arms": arms}
    if isinstance(expr, ExprOptField):
        return {
            "kind": "optfield",
            "target": _lower_pure_expr(expr.target, scope, callables, alias_fns, filename, type_env, types),
            "name": expr.name,
        }
    if isinstance(expr, ExprOptCall):
        return {
            "kind": "optcall",
            "target": _lower_pure_expr(expr.target, scope, callables, alias_fns, filename, type_env, types),
            "method": expr.method,
            "args": [_lower_pure_expr(a, scope, callables, alias_fns, filename, type_env, types) for a in expr.args],
        }
    if isinstance(expr, Interp):
        # each `${...}` segment is a full expression, lowered (and G1/type-
        # checked) like any other; text segments pass through
        parts: list = []
        for kind, value in expr.parts:
            if kind == "text":
                parts.append(["text", value])
            else:
                parts.append(["expr", _lower_pure_expr(
                    value, scope, callables, alias_fns, filename, type_env, types)])
        return {"kind": "interp", "parts": parts}
    raise RevlError(filename, getattr(expr, "line", 1), "unexpected expression in fn body")


def _inject_opt(expected: str | None, actual: str | None, node: dict) -> dict:
    """Materialize the `T` -> `Opt[T]` injection the checker accepts.

    `compatible` lets a `T` stand where an `Opt[T]` is declared (typecheck.py,
    "Opt discipline"), but accepting the *type* is only half of it: the value
    still has to become an optional. Nothing did that, so a method declared
    `-> Opt[Int]` returning `1` emitted `Option<i64> { 1 }` on rust and
    `Optional<Long> { return 1L; }` on java — both rejected by their
    compilers. python and TypeScript never noticed, which is why it survived:
    the injection is invisible on an untyped tier.

    Done here rather than in each backend because the frontend is the single
    IR producer, and because deciding it in a backend needs the very type
    information the emitters do not carry.
    """
    if actual is None:
        return node
    ehead, eargs = parse_type(expected)
    if ehead != "Opt" or not eargs:
        return node
    if parse_type(actual)[0] == "Opt":
        return node          # already an optional; injecting would double-wrap
    return {"kind": "call", "callee": {"kind": "var", "name": "Some"}, "args": [node]}


def _default_expr_callees(expr, out: set) -> None:
    """Collect the names of every function/constructor *called* inside a
    default-value expression (item 187 purity check). Only var-headed call
    callees matter — an effectful operation is always a named extern/fn."""
    if isinstance(expr, ExprCall):
        if isinstance(expr.callee, ExprVar):
            out.add(expr.callee.name)
        _default_expr_callees(expr.callee, out)
        for a in expr.args:
            _default_expr_callees(a, out)
    elif isinstance(expr, ExprBin):
        _default_expr_callees(expr.left, out)
        _default_expr_callees(expr.right, out)
    elif isinstance(expr, ExprUn):
        _default_expr_callees(expr.operand, out)
    elif isinstance(expr, (ExprField, ExprOptField)):
        _default_expr_callees(expr.target, out)
    elif isinstance(expr, ExprOptCall):
        _default_expr_callees(expr.target, out)
        for a in expr.args:
            _default_expr_callees(a, out)
    elif isinstance(expr, ExprIndex):
        _default_expr_callees(expr.target, out)
        _default_expr_callees(expr.index, out)
    elif isinstance(expr, ExprIf):
        _default_expr_callees(expr.cond, out)
        _default_expr_callees(expr.then, out)
        _default_expr_callees(expr.otherwise, out)
    elif isinstance(expr, ExprRecord):
        for _, value in expr.fields:
            _default_expr_callees(value, out)
    elif isinstance(expr, ExprRecordUpdate):
        _default_expr_callees(expr.base, out)
        for _, value in expr.updates:
            _default_expr_callees(value, out)
    elif isinstance(expr, ExprList):
        for item in expr.items:
            _default_expr_callees(item, out)
    elif isinstance(expr, Interp):
        for kind, part in expr.parts:
            if kind == "expr":
                _default_expr_callees(part, out)


def _validate_default_params(program: Program, types: dict,
                             emitting_fns: set) -> None:
    """Decl-site checks for default parameters (item 187): a default is a pure
    expression that type-checks against its parameter. The ordering invariant
    (defaults are trailing) is enforced in the parser; here we (a) refuse an
    effectful default — one that reaches an emission/acquire/witnessed extern
    or an emitting fn, which would smuggle an effect into an otherwise pure
    call-site expansion — and (b) type-check the default against the declared
    parameter type, once, at the declaration rather than at every call."""
    effectful = {ext.name for ext in program.externs
                 if ext.classification != "pure"} | set(emitting_fns or ())
    for decl in program.fn_decls:
        for p in decl.params:
            default = getattr(p, "default", None)
            if default is None:
                continue
            reached: set = set()
            _default_expr_callees(default, reached)
            bad = sorted(reached & effectful)
            if bad:
                raise RevlError(
                    program.filename, p.line,
                    f"default for parameter `{p.name}` calls `{bad[0]}`, which "
                    "is effectful",
                    hint="a default value must be a pure expression — it is "
                         "evaluated at the call site whenever the argument is "
                         "omitted, and an effect there would be invisible in the "
                         "source",
                    code="G6", category="purity",
                )
            dt = infer_ast(default, {}, types, program.filename)
            if dt is not None and not compatible(p.type, dt):
                raise mismatch(program.filename, p.line,
                               f"default for parameter `{p.name}`", p.type, dt)


def check_and_lower(program: Program, ambient: dict | None = None) -> dict:
    """Check and lower a program, optionally against an *ambient* composition
    (a running manifest, DESIGN §4's runtime-admission gate): ambient services
    are in scope without redeclaration, and G2/G3 are checked over the union
    of ambient and newly compiled components.

    `ambient`: {"services": <v1 services table>, "components": [<manifest
    component entries>]} — see compile_files for how it is derived.
    """
    ambient = ambient or {}
    ambient_services = {
        name: _service_from_ir(name, spec)
        for name, spec in (ambient.get("services") or {}).items()
    }

    services: dict[str, ServiceDecl] = {}
    for svc in program.services:
        if svc.name in services:
            raise RevlError(program.filename, svc.line, f"duplicate service `{svc.name}`")
        prior = ambient_services.get(svc.name)
        if prior is not None:
            _admit_service_replacement(program, svc, prior, ambient)
        services[svc.name] = svc
    for name, svc in ambient_services.items():
        services.setdefault(name, svc)

    component_callables = (
        _HOST_CALLABLES
        | _BUILTIN_CONSTRUCTORS
        | {fn.name for fn in program.fn_decls}
        | {ext.name for ext in program.externs}
    )

    # types and signatures are built first so component lowering can
    # type-check service/fn call sites (the sound-typing milestone)
    _resolve_type_aliases(program, program.filename)
    _validate_declared_types(program, program.filename)
    types = _lower_type_decls(program, program.filename)
    types[FNS_KEY] = _signature_table(program, types)
    types[CASES_KEY] = _case_table(types)
    fns = _lower_fns(program, program.filename, types)
    externs = _lower_externs(program, program.filename, types)
    # witnessed externs are refused outside effect position (item 243 rule 1):
    # a fn/test body has no teardown accumulator, so the auto-registered inverse
    # would be dropped and the mutation would be silently irreversible.
    _refuse_witnessed_outside_effect_position(program, program.filename)
    # Slice 2: the set every component's effect-position lowering consults to
    # tell a witnessed acquisition from an ordinary one (docs/design/243-
    # witnessed-externs.md). Computed once — every component shares the same
    # extern table.
    witnessed_externs = _witnessed_extern_names(program)
    # One fixed point, two consumers: `emitting_caps` is what it computes
    # (docs/capabilities.md), `witness` is why (why.py). Evidence never
    # decides a rejection, it only explains one.
    emission_evidence = _EmissionEvidence(program)
    emitting_caps = _emitting_capabilities(fns, externs, emission_evidence.witness)
    emitting_fns = set(emitting_caps)

    # item 187: default-parameter values must be pure and well-typed. Checked
    # here, once the emission fixed point is known, so an effectful default is
    # refused before any call site expands it.
    _validate_default_params(program, types, emitting_fns)

    # phase-2 async coloring (docs/design/async-extern.md §3): the async twin
    # of the emission fixed point above. Seed = async externs; a module `fn`
    # that reaches a colored callee — directly or transitively — is itself
    # colored. `async_witness` records the shortest derivation for diagnostics.
    async_witness: dict[str, str] = {}
    async_colored = _async_callables(fns, externs, async_witness)
    # Stamp `"async": True` on every colored fn entry (the emitters read it
    # with `.get("async")`, needing no reachability analysis of their own),
    # mirroring the extern spelling in `_lower_externs`. And refuse first-class
    # *value* use of an async callable: an arrow type carries no color, so
    # passing an async extern or a colored fn as a value would smuggle a
    # suspension past the checker — the async fixed point never widened for it,
    # so it is a compile error, not a coloring (async-extern.md §3, "First-class
    # values are refused, not widened").
    _fn_decls_by_name = {d.name: d for d in program.fn_decls}
    for entry in fns:
        name = entry["name"]
        called_vals: set = set()
        _calls_in(entry.get("body") or [], set(), values=called_vals)
        passed = sorted(called_vals & async_colored)
        if passed:
            decl = _fn_decls_by_name.get(name)
            raise RevlError(
                (decl.source if decl is not None else None) or program.filename,
                decl.line if decl is not None else 0,
                f"function `{name}` uses async callable `{passed[0]}` as a "
                f"function value, but an async callable has no arrow type",
                hint="call it directly from an async context — an arrow type "
                     "carries no async color, so a suspension cannot be awaited "
                     "through it (A1)",
                code="A1", category="async-propagation",
            )
        # item 92: a sync-typed arrow in a module fn that reaches an async
        # callable (an async extern or a colored fn) is the finding-#21 leak —
        # a compile error now. An arrow the checker typed against `(…) ->
        # Async[T]` carries the async flag and is admitted; a plain one that
        # reaches a suspension is refused. Pure fns have no req keys, so only
        # the named-callable reach applies here (rule 3 is component-only).
        _refuse_leaky_pure_arrow(entry.get("body") or [], async_colored,
                                 _fn_decls_by_name.get(name), program.filename)
        if name in async_colored:
            entry["async"] = True

    # instance-parametric components: one registry shared across the lowering
    # of every component, so `spawn C` can resolve C's config/provisions and
    # the linker can learn which components are runtime templates and what the
    # spawn (instance) graph is (docs/design-v2-instances.md).
    spawn_reg: dict = {
        "by_name": {c.name: c for c in program.components},
        "edges": [],        # (spawner, target) — the instance graph
        "templates": set(),  # components that are spawn targets (excluded from static composition)
        "sites": [],        # G4 spawn-boundary obligations, checked after lowering
    }

    components = []
    seen = set()
    for comp in program.components:
        if comp.name in seen:
            raise RevlError(comp.source or program.filename, comp.line,
                            f"duplicate component `{comp.name}`")
        seen.add(comp.name)
        # A multi-file composition merges declarations from several sources into
        # one Program whose `filename` is only the first argument (paths[0]).
        # Body diagnostics render through `env.filename`, so a component from a
        # LATER file must lower under its own `source`. Otherwise its rejection
        # names the first source with this file's line number (roadmap 312).
        lowered_comp = _lower_component(comp, services,
                                        comp.source or program.filename,
                                        component_callables, types, emitting_fns,
                                        emitting_caps, emission_evidence, spawn_reg,
                                        async_colored, witnessed_externs)
        if comp.source:
            _retarget_holes(lowered_comp, comp.source)
        # async coloring (docs/design/async-extern.md §3, "Component bodies"):
        # a setup/activation body (an `emit` step, an `effect`, an `await`
        # step) may not reach an async callable — an async extern *or* a
        # phase-2 colored fn — because divert/inertia semantics are out of
        # scope for v1. Provide-method bodies are checked at their own site
        # above, so they are pruned here.
        if async_colored:
            _reached: set = set()
            _async_reached_outside_provide(lowered_comp, async_colored, _reached)
            if _reached:
                _culprit = sorted(_reached)[0]
                _kind = "extern" if _culprit in {
                    e.name for e in program.externs if e.async_} else "function"
                raise RevlError(
                    comp.source or program.filename, comp.line,
                    f"component `{comp.name}` reaches async {_kind} "
                    f"`{_culprit}` in a setup/activation body, which "
                    f"cannot suspend a fiber (A1)",
                    hint="wrap the suspending call in an `async fn` service "
                         "operation and drive it from a provide method — v1 does "
                         "not lower an awaited `emit` step",
                    code="A1", category="async-propagation",
                )
        components.append(lowered_comp)

    # state hand-off admission (roadmap item 53): a candidate provider that
    # *accepts* a `handoff` on a key some running provider *exports* must accept
    # a §5-compatible shape — else the swap would drop the predecessor's state.
    # No-op unless the ambient carries running hand-offs (a swap against a
    # stateful running provider), so a fresh compile is unaffected.
    _admit_handoff_replacement(program, components, ambient)

    # G4/G6 across the spawn boundary: a spawner's declared emission upper
    # bound must cover what its spawned instances emit (decision 8). Checked
    # here, after every component's emission surface is known.
    _check_spawn_emission_bounds(components, services, spawn_reg, program.filename)

    # Capability attenuation across the spawn boundary (item 66): a child's
    # capability set must be a checked subset of its spawner's held authority,
    # so lineage narrows monotonically and a supervisor cannot amplify. Returns
    # the per-instance attenuation chain for the G8 audit surface.
    attenuation_chain = _check_spawn_attenuation(
        components, spawn_reg, program.filename)

    fault_tests = _lower_fault_tests(program, components, program.filename)

    manifest = _link(program, components, ambient.get("components") or [],
                     templates=spawn_reg["templates"])
    if attenuation_chain:
        # additive, spawn-only: a non-spawning composition has no `instances`
        # key, so its manifest is byte-identical to before (docs/capability-
        # attenuation.md).
        manifest["instances"] = attenuation_chain

    # lifecycle tests are lowered last: they check against the component
    # declarations, so a broken component must report itself first
    tests = _lower_tests(program, program.filename, types, services)
    prop_tests = _lower_prop_tests(program, program.filename, types, services)

    uses_components_2 = any(
        isinstance(stmt, (FailStmt, IfStmt))
        or (isinstance(stmt, (LetEffect, EffectStmt)) and stmt.setup)
        for comp in program.components
        for stmt in comp.body
    )
    # a timer (`every`/`after`, item 57) is additive v3: a consumer predating
    # the construct refuses the whole document rather than silently dropping a
    # `timer` body step it cannot schedule (docs/time-coeffect.md). ir_version
    # stays 3 — no bump beyond it.
    uses_timers = any(
        isinstance(stmt, TimerStmt)
        for comp in program.components
        for stmt in comp.body
    )
    uses_v2 = any(
        comp.get("isolate") or comp.get("intercept") or comp.get("routes")
        for comp in components)
    uses_v3 = any(not name.startswith("__") for name in types) or bool(fns) or bool(externs) or bool(tests)
    uses_v3 = uses_v3 or any(
        svc.commutative or any(m.async_ or m.commutative or m.idempotent
                               for m in svc.methods.values())
        for svc in services.values()
    )
    uses_v3 = uses_v3 or uses_components_2
    uses_v3 = uses_v3 or uses_timers
    # a `fault_tests` section is an additive v3 feature; the version bump is
    # itself a guard, so a consumer that predates the section refuses the
    # whole document instead of silently dropping the fault tests
    uses_v3 = uses_v3 or bool(fault_tests)
    # a `prop_tests` section is likewise additive v3 (roadmap item 37)
    uses_v3 = uses_v3 or bool(prop_tests)

    def _has_builtin(node) -> bool:
        if isinstance(node, dict):
            # a tagged ADT construction is a v3 feature too (`adt` node)
            if node.get("kind") in ("builtin", "adt"):
                return True
            return any(_has_builtin(v) for v in node.values())
        if isinstance(node, list):
            return any(_has_builtin(v) for v in node)
        return False

    uses_v3 = uses_v3 or any(_has_builtin(comp.get("body")) for comp in components)
    # instance-parametric components are a v3 feature: a `spawn` node in any
    # body bumps the version so a consumer predating the feature refuses the
    # document rather than mis-composing a runtime template as a static entry
    # (docs/design-v2-instances.md)
    uses_v3 = uses_v3 or bool(spawn_reg["templates"])

    result = {
        "ir_version": IR_VERSION_V3 if uses_v3 else (IR_VERSION_V2 if uses_v2 else IR_VERSION),
        "services": {
            name: {
                **({"commutative": True} if svc.commutative else {}),
                "methods": {
                    m.name: {
                        "params": [{"name": p, "type": t} for p, t in m.params],
                        "returns": m.returns,
                        "emission": m.emission,
                        # only a *scoped* emission carries the key: bare
                        # `emission` means "any capability", and its absence
                        # is exactly that (so no pre-capability IR changes)
                        **({"capabilities": list(m.capabilities)}
                           if m.capabilities is not None else {}),
                        **({"async": True} if m.async_ else {}),
                        **({"commutative": True} if m.commutative else {}),
                        # delivery semantics (roadmap item 44): the checked
                        # right for the runtime to auto-retry this emission
                        **({"idempotent": True} if m.idempotent else {}),
                    }
                    for m in svc.methods.values()
                },
            }
            for name, svc in services.items()
        },
        "components": components,
        "manifest": manifest,
    }
    user_types = {name: spec for name, spec in types.items() if not name.startswith("__")}
    if user_types:
        result["types"] = user_types
    if fns:
        result["functions"] = fns
    if externs:
        result["externs"] = externs
    if tests:
        result["tests"] = tests
    # the obligation ledger (docs/holes.md). Present only when the draft has
    # holes, so an IR document for finished code is byte-identical to before.
    obligations = holes.collect(result)
    if obligations:
        result["holes"] = obligations

    if fault_tests:
        result["fault_tests"] = fault_tests
    if prop_tests:
        result["prop_tests"] = prop_tests
    return result


# Admission gate and service-compatibility relation (DESIGN.md §5/§6.6) live
# in `admission.py` (roadmap item 17). Re-exported here so `revl.lower` keeps
# its public import surface: the check-and-lower spine, `plan.py`, and the
# service-compat tests all import these names from `revl.lower`.
from .admission import (  # noqa: E402,F401
    _Drift,
    _Touchers,
    _admit_handoff_replacement,
    _admit_service_replacement,
    _caps_str,
    _caps_widen,
    _drift_error,
    _handoff_compatible,
    _handoff_error,
    _service_compatible,
    _service_equal,
    _service_from_ir,
    _service_touchers,
)


# ---------------------------------------------------------------- components

def _component_scope(env: Env) -> dict[str, str]:
    scope = {name: safe for name, safe in env.locals.items()}
    scope.update(env.params)
    return scope


def _component_req_call(env: Env, root: str, method: str, args: list, line: int) -> dict:
    if root not in env.requires:
        raise RevlError(env.filename, line,
                        f"`{root}` is not a declared requirement of {env.component.name}")
    svc = env.services[env.requires[root]]
    decl = svc.methods.get(method)
    if decl is None:
        raise RevlError(env.filename, line,
                        f"`{root}.{method}` is not a method of service {svc.name}")
    if len(args) != len(decl.params):
        raise RevlError(env.filename, line,
                        f"`{root}.{method}` takes {len(decl.params)} "
                        f"argument(s), {len(args)} given")
    if decl.emission and getattr(env, "_expr_mode", "setup") == "setup":
        raise RevlError(
            env.filename, line,
            f"call to emission `{root}.{method}` must be marked `emit` (G4)",
            hint="an emission crosses the system boundary and cannot be reverted; "
                 "`emit` makes that visible at the call site",
        )
    for arg, (pname, ptype) in zip(args, decl.params):
        actual = infer_ir(arg, env.type_env, env.types, env.services)
        if ptype and actual and not compatible(ptype, actual):
            raise mismatch(env.filename, line,
                           f"`{root}.{method}` argument `{pname}`", ptype, actual)
    return {"kind": "call", "target": {"kind": "req", "name": root},
            "method": method, "args": args}


def _lower_component_pure_expr(expr, env: Env, scope: dict[str, str], callables: set,
                               pure_only: bool = False) -> dict:
    filename = env.filename
    line = getattr(expr, "line", 0)

    if isinstance(expr, ExprHole):
        return _lower_hole(expr, filename)

    # ADT construction (Result / user variants) — same tagged `adt` node as
    # the pure-fn path; Opt's Some/None stay untagged.
    cases = env.types.get(CASES_KEY) or {}
    if isinstance(expr, ExprCall) and isinstance(expr.callee, ExprVar) \
            and _tagged_case(expr.callee.name, env.types) is not None:
        info = cases[expr.callee.name]
        return {"kind": "adt", "type": info["adt"], "case": expr.callee.name,
                "args": [_lower_component_pure_expr(a, env, scope, callables, pure_only)
                         for a in expr.args]}
    if isinstance(expr, ExprVar):
        info = _tagged_case(expr.name, env.types)
        if info is not None and info.get("payload") is None \
                and not str(info.get("adt", "")).startswith(("Result", "Opt")):
            return {"kind": "adt", "type": info["adt"], "case": expr.name, "args": []}

    if isinstance(expr, EmitExpr):
        # the value of an irreversible call; the marker stays at the call site
        saved_mode = getattr(env, "_expr_mode", "setup")
        env._expr_mode = "emit"
        try:
            node = _lower_component_pure_expr(expr.expr, env, scope, callables, pure_only)
        finally:
            env._expr_mode = saved_mode
        if not _is_emission_call(node, env):
            raise RevlError(
                filename, expr.line,
                f"`emit` on {_node_desc(node)}, which is not declared `emission`",
                hint="only calls to `emission` service operations cross the boundary; "
                     "drop the `emit` marker (G4)",
                code="G4", category="emission",
            )
        return node
    if isinstance(expr, ExprMatch):
        # the ADT eliminator, available in component and method bodies too:
        # a component consuming a Result should not have to call out to a fn
        scrutinee = _lower_component_pure_expr(expr.scrutinee, env, scope,
                                               callables, pure_only)
        scrutinee_type = _expr_static_type(expr.scrutinee, env.type_env, env.types)
        _check_match_exhaustiveness(expr, env.type_env, env.types, filename)
        arms = []
        for pattern, bind, body in expr.arms:
            inner = dict(scope)
            payload_type = _arm_payload_type(scrutinee_type, pattern, env.types)
            if bind is not None:
                safe = _safe_name(bind, set(scope.values()))
                inner[bind] = safe
            arm = {
                "pattern": pattern,
                "bind": inner.get(bind) if bind is not None else None,
                "body": _lower_component_pure_expr(body, env, inner, callables, pure_only),
            }
            # the payload type a match arm binds, when the scrutinee's static
            # type is recoverable — the same key the pure-fn lowering
            # (`_lower_pure_expr`) writes, so a backend that must cast (java's
            # tagged Result) can do so in component/method bodies too
            if payload_type is not None:
                arm["payload_type"] = payload_type
            arms.append(arm)
        return {"kind": "match", "scrutinee": scrutinee, "arms": arms}
    if isinstance(expr, ExprLit):
        if expr.value is None:
            raise null_error(filename, line)
        return {"kind": "lit", "value": _str_literal_value(expr.value)}
    if isinstance(expr, Interp):
        return _lower_expr(expr, env, mode=getattr(env, "_expr_mode", "setup"))
    if isinstance(expr, ExprVar):
        name = expr.name
        if name in scope:
            return {"kind": "name", "id": scope[name]}
        info = _tagged_case(name, env.types)
        if info is not None and info.get("payload") is None \
                and not str(info.get("adt", "")).startswith(("Result", "Opt")):
            return {"kind": "adt", "type": info["adt"], "case": name, "args": []}
        if name in callables:
            return {"kind": "var", "name": name}
        if getattr(env, "_plain_body", False):
            declared = ", ".join(f"`{r}`" for r in env.requires) or "<nothing>"
            raise RevlError(
                filename, line,
                f"`{name}` is not a declared requirement of {env.component.name}",
                hint=f"component {env.component.name} requires {declared} — "
                     f"add `requires {name}: <Service>`?",
            )
        raise RevlError(filename, line,
                        f"`{name}` is not declared in this component effect block",
                        hint="declare it with `let` in the effect block, or use a "
                             "requirement/config field (G1)")
    if isinstance(expr, ExprField):
        if isinstance(expr.target, ExprVar) and expr.target.name == "config":
            if expr.name not in env.config_fields:
                raise RevlError(filename, line,
                                f"`{expr.name}` is not a config field of {env.component.name}")
            return {"kind": "config", "field": expr.name}
        lowered_target = _lower_component_pure_expr(expr.target, env, scope, callables,
                                                    pure_only)
        # `s.<key>` on a spawn handle is a provision read, not a record field
        # (docs/design-v2-instances.md). Only a name this component bound to a
        # handle carries `Instance[C]`, so it stays on the supervision tree.
        inst = _instance_handle_component(lowered_target, env)
        if inst is not None:
            return _lower_instance_get(lowered_target, expr.name, line, inst, env)
        return {"kind": "field", "target": lowered_target, "name": expr.name}
    if isinstance(expr, ExprCall):
        args = [_lower_component_pure_expr(a, env, scope, callables, pure_only)
                for a in expr.args]
        if isinstance(expr.callee, ExprField) and isinstance(expr.callee.target, ExprVar):
            root = expr.callee.target.name
            method = expr.callee.name
            if root in _HOST_CALLABLES:
                # the Map VALUE constructor (docs/stdlib-2.0.md §Map) — a
                # pure value, not an effect; intercepted before the host
                # builtin check (`empty` is not a host verb).
                if root == "Map" and method == "empty":
                    if args:
                        raise RevlError(
                            filename, line,
                            f"`Map.empty()` takes no arguments, {len(args)} given",
                            hint="build up an empty map with `set`: "
                                 "`Map.empty().set(\"k\", v)`",
                        )
                    return {"kind": "maplit", "entries": []}
                if pure_only:
                    raise RevlError(
                        filename, line,
                        f"host builtin `{root}.{method}` is an effect and cannot appear "
                        "in pure setup",
                        hint="move the acquisition to the final expression of the effect block (G6)",
                    )
                host_check(f"{root}.{method}",
                           [infer_ir(a, env.type_env, env.types, env.services)
                            for a in args],
                           filename, line)
                return {"kind": "host", "fn": f"{root}.{method}", "args": args}
            # host provenance (docs/stdlib-2.0.md §Map): a local bound to a
            # host acquisition keeps its stub verb surface verbatim — checked
            # BEFORE the builtin table so the sanctioned `remove` overlap
            # dispatches by receiver kind, never by name alone.
            if scope.get(root) in env.host_locals:
                return {"kind": "call",
                        "target": {"kind": "name", "id": scope[root]},
                        "method": method, "args": args}
            if root in env.requires:
                if pure_only:
                    raise RevlError(
                        filename, line,
                        f"call to required service `{root}.{method}` is an effect and cannot "
                        "appear in pure setup",
                        hint="service calls must be acquired with `effect ... undo ...` or "
                             "marked `emit` (G4/G6)",
                    )
                return _component_req_call(env, root, method, args, line)
            if method in _BUILTIN_METHODS:
                # The stdlib-named-method sliver (roadmap 75(b)), same rule as
                # a `fn` body: only a receiver the checker can *prove* is a
                # stdlib value may take the builtin table. A local of unknown
                # type (a host-object result such as `let v = store.get(k)`)
                # used to lower a stdlib-named method as that builtin and
                # misdispatch at runtime; refuse it (HOST-METHOD). Undeclared
                # roots fall through and are caught by G1 name resolution.
                if root in scope:
                    recv_t = infer_ir({"kind": "name", "id": scope[root]},
                                      env.type_env, env.types, env.services)
                    if _is_wildcard(recv_t):
                        _refuse_unpinned_stdlib_method(method, recv_t,
                                                       filename, line)
                if len(args) != _BUILTIN_METHODS[method]:
                    raise RevlError(filename, line,
                                    f"builtin `{method}` takes {_BUILTIN_METHODS[method]} "
                                    f"argument(s), {len(args)} given")
                node: dict = {"kind": "builtin", "method": method,
                              "target": _lower_component_pure_expr(expr.callee.target, env, scope,
                                                                   callables, pure_only),
                              "args": args}
                if method == "to_int":
                    # receiver-family dispatch (`recv`), as in a fn body
                    node["recv"] = infer_ir({"kind": "name", "id": scope[root]},
                                            env.type_env, env.types, env.services)
                return node
            if root in scope:
                # A method on a local that is a *known* stdlib-bearing value
                # (Str/List/Bytes) must be a builtin — builtins were already
                # handled above, so a non-builtin here is a typo/misuse, not a
                # host method. Receivers of unknown/host type infer to None and
                # stay lenient (host provenance is exempt — docs/stdlib-2.0.md).
                recv_t = infer_ir({"kind": "name", "id": scope[root]},
                                  env.type_env, env.types, env.services)
                if parse_type(recv_t)[0] in _SIZED_HEADS:
                    raise RevlError(
                        filename, line,
                        f"no builtin method `{method}` on `{recv_t}` — the stdlib surface is "
                        f"{', '.join(sorted(_BUILTIN_METHODS))} (docs/stdlib-2.0.md)",
                        hint="records carry data, not methods; call functions as `f(x)` (G6)",
                    )
                return {"kind": "call",
                        "target": {"kind": "name", "id": scope[root]},
                        "method": method, "args": args}
        if isinstance(expr.callee, ExprVar):
            name = expr.callee.name
            # ADT/Opt construction lowers exactly as it does in a `fn` body:
            # tagged variants to an `adt` node, Some/None to identity/null.
            # Emitting a plain call here would name a constructor the host
            # runtimes do not define (they are not functions).
            if _tagged_case(name, env.types) is not None:
                info = (env.types.get(CASES_KEY) or {})[name]
                return {"kind": "adt", "type": info["adt"], "case": name, "args": args}
            if name in _BUILTIN_CONSTRUCTORS:
                return {"kind": "call", "callee": {"kind": "var", "name": name},
                        "args": args}
            if name in callables:
                # item 187: fill omitted trailing arguments with their default
                # expressions before async coercion, so the module-fn call the
                # emitters see is fully supplied (no per-tier default handling).
                filled = _with_default_args(
                    name, args, env.types,
                    lambda d: _lower_component_pure_expr(d, env, scope,
                                                         callables, pure_only))
                return {"kind": "fn", "name": name,
                        "args": _coerce_async_args(name, filled, env, line)}
        if isinstance(expr.callee, ExprField) and expr.callee.name in _BUILTIN_METHODS:
            method = expr.callee.name
            # the same sliver guard as the var-root path above: a non-var
            # receiver of unknown type (e.g. `open_pool("pg://").remove(k)`)
            # must not lower as the builtin either
            target = _lower_component_pure_expr(expr.callee.target, env, scope,
                                                callables, pure_only)
            recv_t = infer_ir(target, env.type_env, env.types, env.services)
            if _is_wildcard(recv_t):
                _refuse_unpinned_stdlib_method(method, recv_t, filename, line)
            if len(args) != _BUILTIN_METHODS[method]:
                raise RevlError(filename, line,
                                f"builtin `{method}` takes {_BUILTIN_METHODS[method]} "
                                f"argument(s), {len(args)} given")
            node: dict = {"kind": "builtin", "method": method, "target": target,
                          "args": args}
            if method == "to_int":
                # receiver-family dispatch (`recv`), as in a fn body
                node["recv"] = infer_ast(expr.callee.target, env.type_env,
                                         env.types, None)
            return node
        callee_node = _lower_component_pure_expr(expr.callee, env, scope, callables,
                                                 pure_only)
        # a provision method call off a spawn handle (`s.<key>.<method>(...)`)
        # crosses the boundary exactly as a `req` emission does, so the same
        # `emit`-marker discipline applies — an unmarked emission is refused
        # (G4), not silently lowered. The `req` path enforces this inline
        # (`_component_req_call`); the handle path reaches the generic
        # fall-through, so the check lives here.
        inst = _instance_get_call({"kind": "call", "callee": callee_node,
                                   "args": args}, env)
        if inst is not None:
            recv, decl = inst
            if decl.emission and getattr(env, "_expr_mode", "setup") == "setup":
                handle = recv.get("target") if isinstance(recv.get("target"), dict) else {}
                spelled = ".".join(p for p in (handle.get("id"), recv.get("key"),
                                               callee_node.get("name")) if p)
                raise RevlError(
                    filename, line,
                    f"call to emission `{spelled}` must be marked `emit` (G4)",
                    hint="an emission crosses the system boundary and cannot be reverted; "
                         "`emit` makes that visible at the call site",
                    code="G4", category="emission",
                )
        return {"kind": "call", "callee": callee_node, "args": args}
    if isinstance(expr, ExprBin):
        return {"kind": "bin", "op": expr.op,
                "left": _lower_component_pure_expr(expr.left, env, scope, callables,
                                                   pure_only),
                "right": _lower_component_pure_expr(expr.right, env, scope, callables,
                                                    pure_only)}
    if isinstance(expr, ExprUn):
        return {"kind": "un", "op": expr.op,
                "operand": _lower_component_pure_expr(expr.operand, env, scope, callables,
                                                      pure_only)}
    if isinstance(expr, ExprIndex):
        return {"kind": "index",
                "target": _lower_component_pure_expr(expr.target, env, scope, callables,
                                                     pure_only),
                "index": _lower_component_pure_expr(expr.index, env, scope, callables,
                                                    pure_only)}
    if isinstance(expr, ExprIf):
        return {"kind": "if",
                "cond": _lower_component_pure_expr(expr.cond, env, scope, callables,
                                                   pure_only),
                "then": _lower_component_pure_expr(expr.then, env, scope, callables,
                                                   pure_only),
                "else": _lower_component_pure_expr(expr.otherwise, env, scope, callables,
                                                   pure_only)}
    if isinstance(expr, ExprRecord):
        return {"kind": "record",
                "fields": [[name, _lower_component_pure_expr(e, env, scope, callables,
                                                             pure_only)]
                           for name, e in expr.fields]}
    if isinstance(expr, ExprRecordUpdate):
        return {"kind": "record_update",
                "base": _lower_component_pure_expr(expr.base, env, scope, callables,
                                                   pure_only),
                "updates": [[name, _lower_component_pure_expr(e, env, scope, callables,
                                                              pure_only)]
                            for name, e in expr.updates]}
    if isinstance(expr, ExprBlockArm):
        raise _block_arm_unimplemented(filename, expr.line)
    if isinstance(expr, ExprList):
        return {"kind": "list",
                "items": [_lower_component_pure_expr(e, env, scope, callables, pure_only)
                          for e in expr.items]}
    if isinstance(expr, ExprArrow):
        # Arrow parameters bind in the arrow's body scope — including inside
        # provide-method bodies (roadmap 77a / FR-1): the pure-helper +
        # callback-arrow escape depends on `msgs2 => emit model.complete(msgs2)`
        # resolving `msgs2` to the arrow parameter, not misreading it as a
        # missing component requirement. Same shape as the pure-fn path below:
        # params shadow the enclosing scope; free vars captured from it are
        # snapshotted by value (unchanged).
        inner = dict(scope)
        param_types = _arrow_param_types(expr)
        for param, ptype in zip(expr.params, param_types):
            # the component path resolves names through `id` (unlike the
            # pure-fn path's raw `var`), so the arrow parameter maps to its
            # own name — the emitted lambda binds params positionally, and a
            # `name` node for the parameter must render to exactly that.
            inner[param] = param
            if ptype:
                env.type_env[param] = ptype
            else:
                env.type_env.pop(param, None)
        captures = sorted(_mutable_free_vars(expr.body, scope, set(expr.params)))
        node = {"kind": "arrow", "params": expr.params, "captures": captures,
                "body": _lower_component_pure_expr(expr.body, env, inner, callables,
                                                   pure_only)}
        if any(p is not None for p in param_types) or expr.returns:
            node["param_types"] = param_types
            node["returns"] = expr.returns
        return node
    if isinstance(expr, ExprOptField):
        return {
            "kind": "optfield",
            "target": _lower_component_pure_expr(expr.target, env, scope, callables, pure_only),
            "name": expr.name,
        }
    if isinstance(expr, ExprOptCall):
        return {
            "kind": "optcall",
            "target": _lower_component_pure_expr(expr.target, env, scope, callables, pure_only),
            "method": expr.method,
            "args": [_lower_component_pure_expr(a, env, scope, callables, pure_only) for a in expr.args],
        }
    raise RevlError(filename, line, "unsupported expression in component effect block",
                    hint="block-effect setup is stratum-1 pure code (G6)")


def _lower_component_setup_stmt(stmt, env: Env, scope: dict[str, str], callables: set,
                                mutables: set[str], out: list) -> None:
    filename = env.filename

    def _sweep(node, line):
        # Run the raising type oracle over a lowered setup node (HOLE 3(c) /
        # HOLE 2): definite operator/builtin misuse in stratum-1 setup code now
        # raises, exactly as it does in a `fn` body. Unknown/host operands infer
        # to None and are left alone. Returns the inferred type (or None).
        return infer_ir(node, env.type_env, env.types, env.services, filename, line)

    if isinstance(stmt, LetStmt):
        safe = env.bind_local(stmt.name, stmt.line)
        scope[stmt.name] = safe
        if stmt.mutable:
            mutables.add(stmt.name)
        value = _lower_component_pure_expr(stmt.value, env, scope, callables,
                                           pure_only=True)
        inferred = _sweep(value, stmt.line)
        if inferred is not None:
            env.type_env[safe] = inferred
        out.append({"step": "let", "name": safe, "value": value})
    elif isinstance(stmt, AssignStmt):
        if stmt.name not in scope:
            raise RevlError(filename, stmt.line,
                            f"`{stmt.name}` is not declared in this effect block",
                            hint="declare it with `let`/`var` first (G1)")
        if stmt.name not in mutables:
            raise RevlError(filename, stmt.line,
                            f"cannot reassign `{stmt.name}` — it is `let` (single-assignment)",
                            hint="declare it with `var` to make it mutable (syntax-2.0 §3.5)")
        value = _lower_component_pure_expr(stmt.value, env, scope, callables,
                                           pure_only=True)
        _sweep(value, stmt.line)
        out.append({"step": "assign", "name": scope[stmt.name], "value": value})
    elif isinstance(stmt, ExprStmt):
        expr = _lower_component_pure_expr(stmt.expr, env, scope, callables,
                                          pure_only=True)
        _sweep(expr, stmt.line)
        out.append({"step": "expr", "expr": expr})
    elif isinstance(stmt, IfStmt):
        cond = _lower_component_pure_expr(stmt.cond, env, scope, callables,
                                          pure_only=True)
        cond_t = _sweep(cond, stmt.line)
        if cond_t is not None and cond_t != "Bool":
            raise mismatch(filename, stmt.line, "`if` condition", "Bool", cond_t)
        then: list[dict] = []
        for s in stmt.then:
            _lower_component_setup_stmt(s, env, scope, callables, mutables, then)
        otherwise = None
        if stmt.otherwise is not None:
            otherwise = []
            for s in stmt.otherwise:
                _lower_component_setup_stmt(s, env, scope, callables, mutables, otherwise)
        out.append({"step": "if", "cond": cond, "then": then})
        if otherwise is not None:
            out[-1]["else"] = otherwise
    elif isinstance(stmt, AssertStmt):
        expr = _lower_component_pure_expr(stmt.expr, env, scope, callables,
                                          pure_only=True)
        assert_t = _sweep(expr, stmt.line)
        if assert_t is not None and assert_t != "Bool":
            raise mismatch(filename, stmt.line, "`assert`", "Bool", assert_t)
        out.append({"step": "assert", "expr": expr})
    else:
        raise RevlError(filename, getattr(stmt, "line", 0),
                        "unsupported statement in effect block setup",
                        hint="effect block setup is stratum-1 pure code: "
                             "`let`/`var`/`if`/pure calls are allowed (G6)")


def _lower_component_guard_stmts(stmts: list, env: Env, callables: set) -> list[dict]:
    out: list[dict] = []
    for stmt in stmts:
        if isinstance(stmt, FailStmt):
            out.append({
                "step": "fail",
                "message": _lower_component_pure_expr(
                    stmt.message, env, _component_scope(env), callables,
                    pure_only=True,
                ),
            })
        elif isinstance(stmt, IfStmt):
            out.append(_lower_component_if(stmt, env, callables))
        else:
            raise RevlError(env.filename, getattr(stmt, "line", 0),
                            "only `fail` (and nested `if` guards) may appear in a component guard",
                            hint="component `if` is for deliberate L-Raise decisions, not general "
                                 "control flow (G6)")
    return out


def _lower_component_if(stmt: IfStmt, env: Env, callables: set) -> dict:
    scope = _component_scope(env)
    # a guard condition is a `Bool` position, so a hole there is a `Bool`
    # obligation rather than an untyped one (docs/holes.md)
    pin_hole(stmt.cond, "Bool", env.filename, "`if` guard condition")
    step = {
        "step": "if",
        "cond": _lower_component_pure_expr(stmt.cond, env, scope, callables,
                                           pure_only=True),
        "then": _lower_component_guard_stmts(stmt.then, env, callables),
    }
    if stmt.otherwise is not None:
        step["else"] = _lower_component_guard_stmts(stmt.otherwise, env, callables)
    return step


def _config_default_type(value) -> str | None:
    """Surface type of a config-default literal (bool before int: bool is an
    int subclass)."""
    if isinstance(value, bool):
        return "Bool"
    if isinstance(value, int):
        return "Int"
    if isinstance(value, float):
        return "Float"
    if isinstance(value, str):
        return "Str"
    return None


# Emission reachability, capability sets, and the G4 evidence trail live in
# `emission_analysis.py` (roadmap item 17). Re-exported here so `revl.lower`
# keeps its public import surface: the spine, `query.py`, `__main__.py`, and
# the capability tests all import these names from `revl.lower`.
from .emission_analysis import (  # noqa: E402,F401
    _EmissionEvidence,
    _async_callables,
    _is_async_fn_type,
    _calls_in,
    _capability_hint,
    _emission_chain,
    _emitting_capabilities,
    _emitting_fns,
    _method_emissions,
    _witness_depth,
)


def _async_reached_outside_provide(node, async_names: set, acc: set) -> None:
    """Async extern names a lowered component body reaches, *excluding*
    provide-method and timer bodies (those get their own in-flight window —
    async-extern.md §3, item 170). Mirrors `_calls_in`'s call/value detection
    but prunes provide steps and timer steps.

    A `timer` body (item 57) reaching an async op is no longer refused here: a
    timer is a spawned in-flight handle (item 106's `Async[T]` window), so it is
    coloured async in `_lower_timer_step` and its firing is awaited/cancelled by
    the runtime, exactly like a provide method's own async reach is admitted at
    its site above (docs/time-coeffect.md §async)."""
    if isinstance(node, dict):
        if node.get("step") in ("provide", "timer"):
            return
        kind = node.get("kind")
        if kind == "fn" and node.get("name") in async_names:
            acc.add(node["name"])
        callee = node.get("callee")
        if kind == "call" and isinstance(callee, dict) \
                and callee.get("kind") == "var" and callee.get("name") in async_names:
            acc.add(callee["name"])
        if kind == "var" and node.get("name") in async_names:
            acc.add(node["name"])
        for value in node.values():
            _async_reached_outside_provide(value, async_names, acc)
    elif isinstance(node, list):
        for value in node:
            _async_reached_outside_provide(value, async_names, acc)


def _req_op_is_async(node, env) -> bool:
    """A lowered call/emit node that reaches an async service operation through
    a required key — rule 3 of the item-92 async-reach (a suspension source the
    name-based `_calls_in` is blind to)."""
    if not isinstance(node, dict):
        return False
    target = node.get("target")
    method = node.get("method")
    if isinstance(target, dict) and target.get("kind") == "req" and method:
        svc = env.services.get(env.requires.get(target.get("name")) or "")
        decl = svc.methods.get(method) if svc is not None else None
        return bool(decl is not None and getattr(decl, "async_", False))
    return False


def _reached_async_req_ops(node, env, acc: list) -> None:
    """Collect req-target async service ops (`req.method` whose op is `async
    fn`) a lowered method body reaches DIRECTLY — in statement OR expression
    position (a ternary arm, a nested expression), the blind spot item 117
    closes. The name-based `_calls_in` the A1 provide-method check runs sees
    async *callables* (externs, colored fns) but never an async *service
    operation* reached through a required key (rule 3 of the item-92 async-
    reach), so a sync method whose ternary returns `emit m.op(x)` slipped
    through as admitted (finding #40).

    Any nested arrow is pruned: an arrow value's async-reach is the concern of
    `_refuse_leaky_arrow`/`_refuse_leaky_pure_arrow` (finding #21), which raise
    the arrow-color diagnostic instead — this walk owns only the ops the method
    body reaches without an intervening arrow. Each hit is
    `(req_name, method, op_decl)`."""
    if isinstance(node, dict):
        if node.get("kind") == "arrow":
            return
        if _req_op_is_async(node, env):
            target = node.get("target")
            method = node.get("method")
            svc = env.services.get(env.requires.get(target.get("name")) or "")
            op_decl = svc.methods.get(method) if svc is not None else None
            acc.append((target.get("name"), method, op_decl))
        for value in node.values():
            _reached_async_req_ops(value, env, acc)
    elif isinstance(node, list):
        for value in node:
            _reached_async_req_ops(value, env, acc)


def _arrow_reaches_async(body, env) -> bool:
    """True if a lowered arrow body reaches a suspension (item 92 §3): a
    req-target async service op (rule 3), or a call of an async-colored callable
    — an async extern or a phase-2 colored fn (rules 1). A nested async-flagged
    arrow is a *value* whose suspension is its own, so it is pruned."""
    hit = False

    def walk(n):
        nonlocal hit
        if hit:
            return
        if isinstance(n, dict):
            if n.get("kind") == "arrow" and n.get("async"):
                return
            if _req_op_is_async(n, env):
                hit = True
                return
            for value in n.values():
                walk(value)
        elif isinstance(n, list):
            for value in n:
                walk(value)

    walk(body)
    if hit:
        return True
    called: set = set()
    _calls_in(body, called, stop_async_arrows=True)
    return bool(called & (env.async_callables or set()))


def _refuse_leaky_arrow(node, env, source: str, line: int = 0) -> None:
    """Walk a lowered body for a *sync-typed* arrow that reaches an async
    operation — the item-92 leak (finding #21), now a compile error instead of
    an unawaited coroutine at runtime. An async-flagged arrow is admitted; a
    plain one that reaches a suspension is refused with the A1 diagnostic."""
    if isinstance(node, dict):
        if node.get("kind") == "arrow":
            if not node.get("async") and _arrow_reaches_async(node.get("body"), env):
                raise RevlError(
                    source or env.filename, node.get("line") or line or 0,
                    "this arrow reaches an async operation, but its type carries "
                    "no async color — the caller would receive an unawaited "
                    "suspension (A1)",
                    hint="declare the receiving parameter `(…) -> Async[T]` so "
                         "every call through it is awaited, or move the "
                         "suspending call out of the arrow "
                         "(docs/design/async-function-values.md)",
                    code="A1", category="async-propagation",
                )
            # its own body still walked below (a sync inner arrow may leak)
        for value in node.values():
            _refuse_leaky_arrow(value, env, source)
    elif isinstance(node, list):
        for value in node:
            _refuse_leaky_arrow(value, env, source)


def _coerce_async_args(callee_name, args, env, line):
    """At a component-body call to a module `fn`, admit an arrow into each
    parameter declared `(…) -> Async[T]` (item 92) by stamping the async color
    into the IR. The component path never runs `_check_arrow`, so this is where
    the color is placed; the pure-fn path gets it from `_resolve_arrow` instead.

    v1 admits only an *arrow* in an async slot (the harness's shape — a sync
    arrow is the accepted sync->async coercion, an async-bodied one is colored).
    A non-arrow value (a bare callable name, a fn-typed local) is refused: it
    would need an `as_async` wrapper the blocking backends do not yet erase —
    a filed follow-up, refused here rather than leaked."""
    sig = (env.types.get(FNS_KEY) or {}).get(callee_name)
    if not sig:
        return args
    params = sig.get("params") or []
    out = list(args)
    for i, ptype in enumerate(params):
        if i >= len(out) or not _is_async_fn_type(ptype):
            continue
        arg = out[i]
        if isinstance(arg, dict) and arg.get("kind") == "arrow":
            arg["async"] = True
            if not arg.get("returns"):
                arg["returns"] = render_type(parse_type(ptype)[1][-1])
        else:
            raise RevlError(
                env.filename, line,
                f"argument {i + 1} of `{callee_name}(...)` is declared "
                f"`{render_type(ptype)}` (async), but only an arrow may be "
                "passed into an async parameter in v1",
                hint="wrap it in an arrow, e.g. `x => f(x)`, so the emitter can "
                     "place the async boundary "
                     "(docs/design/async-function-values.md)",
                code="A1", category="async-propagation",
            )
    return out


def _refuse_leaky_pure_arrow(node, async_colored, decl, filename) -> None:
    """The module-fn twin of `_refuse_leaky_arrow`: a sync-typed arrow whose
    body reaches an async callable (a colored name — pure fns have no req keys)
    is the item-92 leak. Admitted (async-flagged) arrows are skipped."""
    if isinstance(node, dict):
        if node.get("kind") == "arrow" and not node.get("async"):
            called: set = set()
            _calls_in(node.get("body"), called, stop_async_arrows=True)
            hit = sorted(called & (async_colored or set()))
            if hit:
                raise RevlError(
                    (decl.source if decl is not None else None) or filename,
                    getattr(decl, "line", 0) or 0,
                    f"this arrow reaches async callable `{hit[0]}`, but its type "
                    "carries no async color — the caller would receive an "
                    "unawaited suspension (A1)",
                    hint="declare the receiving parameter `(…) -> Async[T]` so "
                         "every call through it is awaited, or move the "
                         "suspending call out of the arrow "
                         "(docs/design/async-function-values.md)",
                    code="A1", category="async-propagation",
                )
        for value in node.values():
            _refuse_leaky_pure_arrow(value, async_colored, decl, filename)
    elif isinstance(node, list):
        for value in node:
            _refuse_leaky_pure_arrow(value, async_colored, decl, filename)


def _lower_effect_step(acquire: dict, undo_expr, env: "Env", filename: str, line: int,
                       *, bind: str | None, raw_acquire=None) -> dict:
    """Build the `effect`/`let-effect` IR step for one activation-body
    acquisition (item 243 Slice 2, docs/design/243-witnessed-externs.md).

    A witnessed acquisition auto-registers its extern's DECLARED inverse as a
    transactional accumulator entry — there is no site-spelled undo, so the
    step carries no `"undo"` key at all (the parser already refuses a site
    `undo` token there; this is the defensive twin, and the checked source of
    the shape). `backends/python/emit.py._witnessed_extern` recognises this
    shape by matching the acquisition's callee name against the externs
    table, not by an IR step field, reads the DECLARED inverse from there,
    and emits the Ok-conditional transactional registration (Slice 2a). Every
    other acquisition keeps its ordinary site-spelled undo, lowered exactly
    as before — this helper changes no IR for a non-witnessed program.

    Deferred parser gate (item 315): a bare-name call missing its `undo` is
    admitted by the parser even when the callee's classification is not yet
    known — `use` imports resolve one file at a time, after parsing, so the
    parser cannot tell a same-file witnessed call from an IMPORTED one (or
    from a plain extern that is simply missing its `undo`) at parse time.
    `env.witnessed_externs` is built from `_witnessed_extern_names` over the
    MERGED, post-import program (`check_and_lower`), so by the time this runs
    an imported witnessed extern is indistinguishable from a same-file one —
    this is where the parser's deferred call is finally decided. If the
    callee turns out not to be witnessed after all, this raises the exact
    "effect has no `undo`" refusal (G4) the parser used to raise directly;
    `raw_acquire` (the original AST expression) is needed only to render that
    message the same way `_describe_expr` always has."""
    step_kind = "let-effect" if bind is not None else "effect"
    wit_name = acquire.get("name") if acquire.get("kind") == "fn" else None
    if wit_name is not None and wit_name in env.witnessed_externs:
        if undo_expr is not None:
            raise RevlError(
                filename, line,
                f"witnessed extern `{wit_name}` cannot declare a site `undo`",
                hint="its declared inverse is auto-registered by the teardown "
                     "accumulator on the `Ok` branch; the accumulator owns "
                     "the inverse, not the call site "
                     "(docs/design/243-witnessed-externs.md)",
                code="G4", category="witnessed",
            )
        step = {"step": step_kind, "acquire": acquire}
    elif undo_expr is None:
        head = _describe_expr(raw_acquire) if raw_acquire is not None else "the expression"
        raise RevlError(
            filename, line,
            f"effect has no `undo` and {head} is not pure",
            hint=f"write `effect {head}(...) undo <expr>`, or mark the call "
                 "`emit` if it deliberately crosses the system boundary (G4)",
            code="G4", category="witnessed",
        )
    else:
        undo = _lower_expr(undo_expr, env, mode="undo")
        step = {"step": step_kind, "acquire": acquire, "undo": undo}
    if bind is not None:
        step["bind"] = bind
    return step


def _lower_component(comp: ComponentDecl, services: dict[str, ServiceDecl], filename: str,
                     callables: set | None = None, types: dict | None = None,
                     emitting_fns: set | None = None,
                     emitting_caps: dict | None = None,
                     emission_evidence: "_EmissionEvidence | None" = None,
                     spawn_reg: dict | None = None,
                     async_colored: set | None = None,
                     witnessed_externs: set | None = None) -> dict:
    env = Env(comp, services, filename, types)
    env.emitting_fns = emitting_fns or set()
    env.emitting_caps = emitting_caps or {}
    env.emission_evidence = emission_evidence
    env.witnessed_externs = witnessed_externs or set()
    env.async_externs = dict(emission_evidence.async_externs) if emission_evidence else {}
    # the phase-2 async-colored set (async externs + fns that transitively
    # reach one, docs/design/async-extern.md §3): the provide-method admission
    # tests membership here, not just direct extern calls, so a sync method
    # reaching a colored fn is refused too. Falls back to the extern names
    # alone when the fixed point was not supplied (older callers/tests).
    env.async_callables = set(async_colored) if async_colored is not None \
        else set(env.async_externs)
    env.callables = callables or set()  # module fns/externs/hosts for unified expressions
    # instance-parametric components: the registry of spawn targets, edges,
    # templates and G4 spawn-boundary sites (docs/design-v2-instances.md)
    env.spawn_reg = spawn_reg

    # a config default must fit its declared field type (config typing);
    # a `null` default is the documented optional exception and is allowed
    for cfg in comp.config:
        if cfg.default is None:
            continue
        lit_type = _config_default_type(cfg.default)
        if lit_type is not None and not compatible(cfg.type, lit_type):
            raise mismatch(filename, cfg.line,
                           f"config field `{cfg.name}` default", cfg.type, lit_type)

    provides = {}
    for key, svc, line in comp.provides:
        if svc not in services:
            raise RevlError(filename, line, f"unknown service `{svc}` in `provides` of {comp.name}")
        if key in provides:
            raise RevlError(filename, line, f"duplicate provision key `{key}` in {comp.name}")
        provides[key] = svc

    body = []
    provided_keys: set[str] = set()
    provide_seen_line: int | None = None
    isolate: dict[str, str] = {}
    intercept: dict[str, dict] = {}
    routes: dict[str, dict] = {}
    handoff: dict | None = None
    action_seen = False
    for stmt in comp.body:
        if isinstance(stmt, HandoffStmt):
            # `handoff <key>: <Type>` (roadmap item 53): the verified state
            # hand-off of a stateful provider. A prelude declaration — it names
            # what this provider's live state *is*, before any effect creates
            # it — and targets a key this component provides (its own state
            # crosses to whoever re-provides that key). At most one per
            # component: a component's activation frame holds one resource
            # vector, so one declared shape describes it without ambiguity.
            if action_seen:
                raise RevlError(
                    filename, stmt.line,
                    "`handoff` must precede every effect, emit, await, and provide statement",
                    hint="a hand-off declares the provider's state shape before any "
                         "effect creates it (prelude rule, docs/state-handoff.md)",
                )
            if stmt.key not in provides:
                raise RevlError(
                    filename, stmt.line,
                    f"`{stmt.key}` is not a declared provision of {comp.name}",
                    hint="`handoff` targets a key this component provides — it is the "
                         "state a successor re-providing that key inherits (item 53)",
                )
            if handoff is not None:
                raise RevlError(
                    filename, stmt.line,
                    f"{comp.name} declares more than one `handoff` — a component has one "
                    f"activation frame, so it hands off one state shape",
                    hint="thread every piece of live state through the one hand-off type "
                         "(a record or Map), docs/state-handoff.md",
                )
            handoff = {"key": stmt.key, "type": stmt.state_type}
            continue
        if isinstance(stmt, RouteStmt):
            # multi-realm bind (item 162): `isolate <key> in realms(...) [strategy(...)]`.
            # A prelude declaration, exactly like `isolate`/`intercept` — it derives
            # the resolution context (the router's realm set) before any dependency
            # access, so it must precede every action.
            if action_seen:
                raise RevlError(
                    filename, stmt.line,
                    "`isolate ... in realms(...)` must precede every effect, emit, await, "
                    "and provide statement",
                    hint="realm bindings derive the resolution context before any dependency "
                         "access (prelude rule, docs/design-v2-realms.md)",
                )
            required_keys = set(env.require_keys.values())
            # routing distributes a *consumer's* dependency across N backend
            # realms — it targets a REQUIRED key. A provision has one installed
            # instance in one realm (G2), so routing a provision is meaningless.
            if stmt.key not in required_keys:
                if stmt.key in provides:
                    raise RevlError(
                        filename, stmt.line,
                        f"`isolate ... in realms(...)` routes a *required* key — `{stmt.key}` "
                        f"is a provision of {comp.name}",
                        hint="a multi-realm bind distributes a consumer's dependency across "
                             "backend realms (item 162); a provision has one installed "
                             "instance in one realm (G2). Route the key you require, not the "
                             "one you provide",
                    )
                raise RevlError(
                    filename, stmt.line,
                    f"`{stmt.key}` is not a declared requirement of {comp.name}",
                    hint="`isolate ... in realms(...)` targets a key from the `requires` "
                         "clause (G1)",
                )
            # one binding per key: a key is pinned to one realm *or* routed across
            # a realm set, never both, and never two conflicting route sets.
            if stmt.key in isolate:
                raise RevlError(
                    filename, stmt.line,
                    f"key `{stmt.key}` is already isolated to a single realm in {comp.name} — "
                    f"it cannot also be routed across `realms(...)`",
                    hint="use either `isolate <key> in realm(<name>)` (pin) or "
                         "`isolate <key> in realms(...)` (route), not both",
                )
            if stmt.key in routes:
                raise RevlError(
                    filename, stmt.line,
                    f"key `{stmt.key}` is routed twice in {comp.name}",
                )
            if stmt.strategy is not None and stmt.strategy not in KNOWN_STRATEGIES:
                known = ", ".join(sorted(KNOWN_STRATEGIES))
                raise RevlError(
                    filename, stmt.line,
                    f"unknown routing strategy `{stmt.strategy}` for `{stmt.key}` in "
                    f"{comp.name}",
                    hint=f"a strategy is validated at compile time so a typo is not a silent "
                         f"runtime fallback; known strategies are: {known} (or omit "
                         f"`strategy(...)` for the router's default)",
                )
            routes[stmt.key] = {"realms": list(stmt.realms), "strategy": stmt.strategy}
            continue
        if isinstance(stmt, (IsolateStmt, InterceptStmt)):
            # prelude rule: realm/metadata declarations derive the resolution
            # context (Def. 27/29) and must precede every dependency access
            if action_seen:
                kw = "isolate" if isinstance(stmt, IsolateStmt) else "intercept"
                raise RevlError(
                    filename, stmt.line,
                    f"`{kw}` must precede every effect, emit, await, and provide statement",
                    hint="realm and metadata declarations derive the resolution context "
                         "before any dependency access (prelude rule, docs/design-v2-realms.md)",
                )
            # isolate/intercept name a key by its *qualified* wiring identity,
            # the same string G2 and the linker compare (docs/namespacing.md)
            required_keys = set(env.require_keys.values())
            if isinstance(stmt, IsolateStmt):
                if stmt.key not in required_keys and stmt.key not in provides:
                    raise RevlError(
                        filename, stmt.line,
                        f"`{stmt.key}` is not a declared requirement or provision of {comp.name}",
                        hint="`isolate` targets a key from the component header (G1)",
                    )
                if stmt.key in isolate:
                    raise RevlError(filename, stmt.line,
                                    f"key `{stmt.key}` is isolated twice in {comp.name}")
                isolate[stmt.key] = stmt.realm
            else:
                if stmt.key in provides and stmt.key not in required_keys:
                    raise RevlError(
                        filename, stmt.line,
                        f"`intercept` applies to required keys only — `{stmt.key}` is a provision",
                        hint="interception is the component-declared metadata d(k) of Def. 30, "
                             "whose domain is the dependency set; providers receive metadata "
                             "from their consumers' declarations",
                    )
                if stmt.key not in required_keys:
                    raise RevlError(
                        filename, stmt.line,
                        f"`{stmt.key}` is not a declared requirement of {comp.name}",
                        hint="`intercept` targets a key from the `requires` clause (G1)",
                    )
                if stmt.key in intercept:
                    raise RevlError(filename, stmt.line,
                                    f"key `{stmt.key}` is intercepted twice in {comp.name}")
                intercept[stmt.key] = stmt.metadata
            continue
        action_seen = True
        if isinstance(stmt, (LetEffect, EffectStmt, TimerStmt)) and provide_seen_line is not None:
            raise RevlError(
                filename, stmt.line,
                "acquisition after `provide` — an effect acquired after a provision "
                "would be reverted while dependents can still call the service",
                hint="move acquisitions above the `provide` block (linker rule A2). "
                     "A timer is an acquisition too: its schedule is armed at "
                     "activation and cancelled on teardown (docs/time-coeffect.md)"
                     if isinstance(stmt, TimerStmt) else
                     "move acquisitions above the `provide` block (linker rule A2)",
            )
        if isinstance(stmt, EffectStmt) and isinstance(stmt.acquire, SpawnExpr):
            # a spawn's inverse is the instance's own teardown, which needs a
            # handle to name — so a spawn must be bound (decision 2)
            raise RevlError(
                filename, stmt.line,
                "`spawn` must be bound to a handle: "
                f"`let s = effect spawn {stmt.acquire.component} … undo s.dispose()`",
            )
        if isinstance(stmt, LetEffect):
            if stmt.setup:
                saved_locals = dict(env.locals)
                saved_taken = set(env._taken)
                saved_type_env = dict(env.type_env)
                setup_steps: list[dict] = []
                scope = _component_scope(env)
                mutables: set[str] = set()
                for setup_stmt in stmt.setup:
                    _lower_component_setup_stmt(setup_stmt, env, scope, callables or set(),
                                                mutables, setup_steps)
                acquire = _lower_component_pure_expr(stmt.acquire, env, scope, callables or set())
                env.locals = saved_locals
                env._taken = saved_taken
                # setup-let types are block-scoped; drop them so a recycled safe
                # name (env._taken is restored above) can't read a stale type
                env.type_env = saved_type_env
            else:
                setup_steps = []
                acquire = _lower_expr(stmt.acquire, env, mode="setup")
            safe = env.bind_local(stmt.bind, stmt.line)
            # host provenance: an effect-acquired HOST object (`Map.new()`)
            # keeps its verb surface verbatim, exempt from the stdlib table —
            # see Env.host_locals.
            if acquire.get("kind") == "host":
                env.host_locals.add(safe)
            acquired_type = infer_ir(acquire, env.type_env, env.types, env.services)
            if acquired_type is not None:
                env.type_env[safe] = acquired_type
            step = _lower_effect_step(acquire, stmt.undo, env, filename, stmt.line,
                                      bind=safe, raw_acquire=stmt.acquire)
            if setup_steps:
                step["setup"] = setup_steps
            if getattr(stmt, "verified", False):
                step["verified"] = True
            body.append(step)
        elif isinstance(stmt, EffectStmt):
            if stmt.setup:
                saved_locals = dict(env.locals)
                saved_taken = set(env._taken)
                saved_type_env = dict(env.type_env)
                setup_steps = []
                scope = _component_scope(env)
                mutables = set()
                for setup_stmt in stmt.setup:
                    _lower_component_setup_stmt(setup_stmt, env, scope, callables or set(),
                                                mutables, setup_steps)
                acquire = _lower_component_pure_expr(stmt.acquire, env, scope, callables or set())
                env.locals = saved_locals
                env._taken = saved_taken
                env.type_env = saved_type_env
            else:
                setup_steps = []
                acquire = _lower_expr(stmt.acquire, env, mode="setup")
            step = _lower_effect_step(acquire, stmt.undo, env, filename, stmt.line,
                                      bind=None, raw_acquire=stmt.acquire)
            if setup_steps:
                step["setup"] = setup_steps
            if getattr(stmt, "verified", False):
                step["verified"] = True
            body.append(step)
        elif isinstance(stmt, FailStmt):
            body.append({
                "step": "fail",
                "message": _lower_component_pure_expr(
                    stmt.message, env, _component_scope(env), callables or set(),
                    pure_only=True,
                ),
            })
        elif isinstance(stmt, IfStmt):
            body.append(_lower_component_if(stmt, env, callables or set()))
        elif isinstance(stmt, EmitStmt):
            body.append(_lower_emit_step(stmt, env))
        elif isinstance(stmt, TimerStmt):
            body.append(_lower_timer_step(stmt, env))
        elif isinstance(stmt, AwaitStmt):
            body.append({"step": "await", "expr": _lower_expr(stmt.expr, env, mode="setup")})
        elif isinstance(stmt, ProvideStmt):
            provide_seen_line = stmt.line
            body.append(_lower_provide(stmt, provides, provided_keys, env))
        else:  # pragma: no cover — grammar prevents it
            raise RevlError(filename, stmt.line, "unexpected statement in component body")

    lowered = {
        "name": comp.name,
        "source": comp.source or filename,
        "config": [{"name": f.name, "type": f.type, "default": f.default} for f in comp.config],
        # the IR carries the *qualified* wiring key (G2 / injection identity),
        # not the code-facing binding; for unqualified keys the two coincide,
        # so v1 documents stay byte-identical (docs/namespacing.md)
        "requires": {env.require_keys[binding]: svc for binding, svc in env.requires.items()},
        "provides": provides,
        "body": body,
    }
    # v2 fields appear only when used, so v1 documents stay byte-identical
    if isolate:
        lowered["isolate"] = isolate
    if intercept:
        lowered["intercept"] = intercept
    # multi-realm bind (item 162), additive — a component with no `realms(...)`
    # route carries no `routes` key, so its IR is byte-identical to before.
    if routes:
        lowered["routes"] = routes
    # item 53: the state hand-off contract, additive — a stateless component
    # (the overwhelming majority) carries no `handoff` key, so its IR is
    # byte-identical to before. `ir_version` stays 3.
    if handoff is not None:
        lowered["handoff"] = handoff
    return lowered


def _lower_provide(stmt: ProvideStmt, provides: dict[str, str], provided_keys: set[str], env: Env) -> dict:
    filename = env.filename
    comp = env.component
    if stmt.key not in provides:
        declared = ", ".join(f"`{k}`" for k in provides) or "none"
        raise RevlError(
            filename, stmt.line,
            f"`{stmt.key}` is not declared in the `provides` clause of {comp.name} (A9)",
            hint=f"rename the provide block to a declared key (declared: {declared}), "
                 f"or add `{stmt.key}: <Service>` to the `provides` clause of {comp.name}",
        )
    if stmt.key in provided_keys:
        raise RevlError(filename, stmt.line, f"provision `{stmt.key}` is installed twice in {comp.name}")
    provided_keys.add(stmt.key)

    svc = env.services[provides[stmt.key]]
    methods = []
    implemented = set()
    for method in stmt.methods:
        decl = svc.methods.get(method.name)
        if decl is None:
            raise RevlError(filename, method.line,
                            f"`{method.name}` is not a method of service {svc.name}")
        if len(method.params) != len(decl.params):
            raise RevlError(
                filename, method.line,
                f"method `{method.name}` of provision `{stmt.key}` takes {len(method.params)} "
                f"params but service {svc.name} declares {len(decl.params)}",
            )
        if method.async_ != decl.async_:
            raise RevlError(
                filename, method.line,
                f"method `{method.name}` of provision `{stmt.key}` is "
                f"{'async' if method.async_ else 'not async'} but service {svc.name} "
                f"declares it {'async' if decl.async_ else 'not async'}",
            )
        if method.name in implemented:
            raise RevlError(filename, method.line, f"duplicate method `{method.name}` in provision `{stmt.key}`")
        implemented.add(method.name)

        # optional param annotations (syntax-2.0: models write `fn query(sql:
        # Str)` on autopilot): well-formed and checked against the service's
        # declared type (A6 — the service is the source of truth).
        for surface, annotation, (_, svc_ptype) in zip(
            method.params, method.param_types or [None] * len(method.params), decl.params
        ):
            if annotation is None:
                continue
            check_type_wellformed(filename, method.line, annotation)
            if svc_ptype and not (compatible(svc_ptype, annotation)
                                  and compatible(annotation, svc_ptype)):
                raise mismatch(
                    filename, method.line,
                    f"parameter `{surface}` of `{method.name}` (from service `{svc.name}`)",
                    svc_ptype, annotation)
        # optional `-> T` return annotation, checked against the service
        if method.returns is not None:
            check_type_wellformed(filename, method.line, method.returns)
            if decl.returns and not (compatible(decl.returns, method.returns)
                                     and compatible(method.returns, decl.returns)):
                raise mismatch(
                    filename, method.line,
                    f"return type of `{method.name}` (from service `{svc.name}`)",
                    decl.returns, method.returns)

        saved = env.params
        env.params = env.bind_params(method.params, method.line)
        # method params carry the service's declared types (A6): surface
        # names bind the body, the service contributes the signature
        saved_tenv = dict(env.type_env)
        method_locals: dict[str, str] = {}
        for surface, (_, ptype) in zip(method.params, decl.params):
            env.type_env[env.params[surface]] = ptype
        mbody = []
        returned = False
        for mstmt in method.body:
            if returned:
                raise RevlError(filename, mstmt.line, "unreachable statement after `return`")
            if getattr(mstmt, "verified", False):
                # `verified effect` is inverse round-trip tested by activating
                # the component and tearing it down (roadmap item 26); that
                # round-trip is only well-defined for an *activation-body*
                # effect, whose inverse the fiber's teardown runs. A
                # method-body effect runs per request, so it has no such
                # closed activate/teardown window — reject rather than accept
                # a marker the runner cannot honour.
                raise RevlError(
                    filename, mstmt.line,
                    "`verified effect` is only allowed in a component activation body",
                    hint="inverse round-trip testing activates the component and tears it "
                         "down; a provide-method effect runs per request and has no such "
                         "window (docs/verified-effect.md). Drop `verified`, or move the "
                         "effect to the activation body.")
            if isinstance(mstmt, LetEffect):
                # item zero (docs/design-v2-instances.md): a spawn inside a
                # provide-method is a request-scoped instance. It gets its own
                # nested teardown scope (its child fiber), so `s.dispose()`
                # reclaims it when the instance dies, not when the component
                # tears down. Only `spawn` may be acquired here in phase 1 —
                # a general method-body acquisition is a separate feature.
                if not isinstance(mstmt.acquire, SpawnExpr):
                    raise RevlError(
                        filename, mstmt.line,
                        "only `spawn` may be acquired inside a provide-method body",
                        hint="a request-scoped instance gets a nested teardown "
                             "scope; other acquisitions belong in the activation "
                             "body (docs/design-v2-instances.md)")
                if mstmt.bind in env.params or mstmt.bind in method_locals:
                    raise RevlError(filename, mstmt.line,
                                    f"`{mstmt.bind}` is already bound in `{method.name}`")
                safe = _safe_name(mstmt.bind,
                                  set(env.params.values()) | set(method_locals.values()))
                acquire = _lower_expr(mstmt.acquire, env, mode="setup")
                method_locals[mstmt.bind] = safe
                env.params[mstmt.bind] = safe  # visible to later statements
                # record the handle's `Instance[C]` type so a later `s.<key>`
                # provision read (docs/design-v2-instances.md) resolves here too
                handle_type = infer_ir(acquire, env.type_env, env.types, env.services)
                if handle_type is not None:
                    env.type_env[safe] = handle_type
                undo = _lower_expr(mstmt.undo, env, mode="undo")
                mbody.append({"step": "let-effect", "bind": safe,
                              "acquire": acquire, "undo": undo})
            elif isinstance(mstmt, EffectStmt):
                if isinstance(mstmt.acquire, SpawnExpr):
                    raise RevlError(
                        filename, mstmt.line,
                        "`spawn` must be bound to a handle: "
                        f"`let s = effect spawn {mstmt.acquire.component} … undo s.dispose()`",
                    )
                # item 318 (docs/design/243-witnessed-externs.md): a witnessed
                # effect is now valid in a provide-method body — THE dominant
                # H1 gate. An agent's fs mutation fires per tool call from a
                # provide-method, not the activation body; its declared inverse
                # auto-registers into the ENCLOSING COMPONENT'S activation frame
                # as a transactional entry (`Frame.transactional_method`), which
                # is component-long and whose commit/abort already discharges on
                # a clean unload / reverts on abort (Slice 2a). A witnessed call
                # carries no site `undo`; a plain effect still requires one.
                # `_lower_effect_step` makes exactly that distinction (the same
                # call the activation body uses): a witnessed acquisition lowers
                # to a `{"step": "effect", "acquire": ...}` with no `undo` key
                # (emit's `_method_witnessed_step` keys the transactional
                # registration off the acquisition's callee), and a plain
                # missing-undo effect raises the unchanged G4 refusal.
                acquire = _lower_expr(mstmt.acquire, env, mode="setup")
                mbody.append(_lower_effect_step(
                    acquire, mstmt.undo, env, filename, mstmt.line,
                    bind=None, raw_acquire=mstmt.acquire))
            elif isinstance(mstmt, EmitStmt):
                mbody.append(_lower_emit_step(mstmt, env))
            elif isinstance(mstmt, AwaitStmt):
                if not decl.async_:
                    raise RevlError(
                        filename, mstmt.line,
                        "`await` is only allowed in a component body",
                        hint="a provide method runs while the component is ACTIVE; iteration "
                             "boundaries (paper §4.3.2) exist only during activation (A1)",
                    )
                mbody.append({"step": "await", "expr": _lower_expr(mstmt.expr, env, mode="setup")})
            elif isinstance(mstmt, LetStmt):
                # a plain value binding: name an intermediate result instead
                # of nesting every call into a single expression
                if mstmt.name in env.params or mstmt.name in method_locals:
                    raise RevlError(filename, mstmt.line,
                                    f"`{mstmt.name}` is already bound in `{method.name}`")
                safe = _safe_name(mstmt.name, set(env.params.values()) | set(method_locals.values()))
                value = _lower_expr(mstmt.value, env, mode="setup")
                method_locals[mstmt.name] = safe
                env.params[mstmt.name] = safe  # visible to later statements
                if mstmt.type is not None:
                    # a `let x: T` annotation in a provide-method body. It is
                    # recorded rather than ignored so `infer_ir` sees it, but
                    # this is stratum 3: the value is *not* checked against it
                    # (docs/function-types.md §limits).
                    check_type_wellformed(filename, mstmt.line, mstmt.type)
                    env.type_env[safe] = mstmt.type
                    # ... and it pins an empty-collection literal on the right:
                    # `var m: Map[Str, Int] = Map.empty()` is the author's own
                    # expected type (roadmap 76b), carried on the `maplit` node
                    _pin_empty_literal(mstmt.type, value)
                else:
                    # record the inferred type exactly as the activation-body
                    # setup sweep does, so a later method on the binding is
                    # checked against the *real* type (`let xs = [1, 2]` then
                    # `xs.length()` is a List length, not an unpinned call) —
                    # the stdlib-named-method guard (roadmap 75(b)) depends on
                    # provable receiver types.
                    inferred = infer_ir(value, env.type_env, env.types,
                                        env.services)
                    if inferred is not None:
                        env.type_env[safe] = inferred
                mbody.append({"step": "let", "name": safe, "value": value,
                              "mutable": bool(mstmt.mutable)})
            elif isinstance(mstmt, AssignStmt):
                if mstmt.name not in method_locals:
                    raise RevlError(filename, mstmt.line,
                                    f"`{mstmt.name}` is not declared in `{method.name}`",
                                    hint="declare it with `let` (single-assignment) or "
                                         "`var` (mutable)")
                mbody.append({"step": "assign", "name": method_locals[mstmt.name],
                              "value": _lower_expr(mstmt.value, env, mode="setup")})
            elif isinstance(mstmt, ReturnStmt):
                if mstmt.expr is None:
                    # a void operation: `fn f(x) { return }`
                    if decl.returns:
                        raise RevlError(
                            filename, mstmt.line,
                            f"`{method.name}` returns `{decl.returns}` but this "
                            "`return` carries no value")
                    mbody.append({"step": "return", "expr": None})
                    returned = True
                    continue
                # a hole in return position takes the *service's* declared
                # return type: the service is the source of truth for the
                # signature (A6), so it is also the source of the obligation
                pin_hole(mstmt.expr, decl.returns, filename,
                         f"`{method.name}` returns")
                lowered_return = _lower_expr(mstmt.expr, env, mode="setup")
                if decl.returns:
                    actual = infer_ir(lowered_return, env.type_env, env.types, env.services)
                    if actual and not compatible(decl.returns, actual):
                        raise mismatch(filename, mstmt.line,
                                       f"`{method.name}` returns", decl.returns, actual)
                    lowered_return = _inject_opt(decl.returns, actual, lowered_return)
                mbody.append({"step": "return", "expr": lowered_return})
                returned = True
            else:  # pragma: no cover
                raise RevlError(filename, mstmt.line, "unexpected statement in method body")
        if decl.returns and not returned:
            # same guarantee as a `fn` with a declared return, on the other
            # surface that has one: the emitted java method and rust trait impl
            # both fall off the end ("missing return statement" / E0308) while
            # python hands the caller a silent None
            raise RevlError(
                comp.source or filename, method.line,
                f"`{method.name}` implements `{svc.name}.{method.name}`, which "
                f"returns `{render_type(decl.returns)}`, but this body never "
                f"returns a value",
                hint=f"end the body with `return <{render_type(decl.returns)}>` — a "
                     f"provider must produce what its service promises, or "
                     f"consumers bound to `{svc.name}` receive nothing (rust E0308, "
                     'java "missing return statement")',
                code="T1", category="type-mismatch",
                expected=decl.returns, actual=None,
            )
        safe_params = [env.params[p] for p in method.params]
        env.params = saved
        env.type_env = saved_tenv

        # A service declaration is an *upper bound* on its providers' effects:
        # consumers bind to the service, not to this component, and a provider
        # may be purer than declared but never less. Without this, a plain
        # declaration hides an irreversible call from every consumer — and from
        # the G8 audit, which enumerates a caller's emissions by reading the
        # declarations of the methods it calls.
        if not decl.emission:
            caused_steps: dict[str, list] = {}
            caused, caps_used = _method_emissions(mbody, env, caused_steps)
            if caused:
                evidence = ", ".join(f"`{item}`" for item in caused)
                # the derivation for the *first* culprit: the message already
                # names them all, and one worked example is what the author
                # needs to see. The chain runs method -> ... -> emission.
                chain = caused_steps.get(caused[0]) or []
                why = None
                if chain:
                    head = TraceStep(method.name, "provide-method",
                                     comp.source or filename, method.line,
                                     f"provision `{stmt.key}`")
                    why = WhyTrace(kind="emission-propagation",
                                   subject=f"{svc.name}.{method.name}",
                                   steps=[head, *chain], shape=CHAIN)
                hint = (
                    f"a service declaration bounds what its providers may do — "
                    f"mark it `emission fn {method.name}(...)` in service "
                    f"`{svc.name}`, or move the irreversible call out of this "
                    f"method (G4)"
                )
                if "*" in caps_used:
                    # the capability set carries `*`: somewhere in the chain a
                    # call dispatches through a first-class function value
                    # (an arrow-typed parameter or binding), so the analysis
                    # cannot name what that call runs. Say so — the author is
                    # looking at a helper that looks pure and is not.
                    hint += (
                        ". This trace crosses a first-class dispatch: a call "
                        "invokes a function *value* (an arrow-typed parameter "
                        "or binding) rather than a named `fn`, so revl cannot "
                        "statically bound what it runs and must treat the "
                        "whole chain as possibly emitting"
                    )
                raise RevlError(
                    # the offending body lives in the component's own file,
                    # which is not the merged program filename
                    comp.source or filename, method.line,
                    f"`{svc.name}.{method.name}` is declared plain, but this "
                    f"implementation reaches {evidence}",
                    hint=hint,
                    code="G4", category="emission-propagation",
                    why=why,
                )
        elif decl.capabilities is not None:
            # the same upper bound, one refinement finer: `emission[db]` says
            # *where* a provider may cross, so the body's capability set must
            # be a subset. A provider using fewer capabilities is purer than
            # declared, which is the sound direction (docs/capabilities.md).
            caused, used = _method_emissions(mbody, env)
            extra = sorted(used - set(decl.capabilities))
            if extra:
                declared = ", ".join(decl.capabilities)
                offending = ", ".join(
                    "an unnameable host boundary" if cap == "*" else f"`{cap}`"
                    for cap in extra)
                evidence = ", ".join(f"`{item}`" for item in caused)
                raise RevlError(
                    comp.source or filename, method.line,
                    f"`{svc.name}.{method.name}` is declared "
                    f"`emission[{declared}]`, but this implementation emits "
                    f"through {offending}"
                    + (f" (reaching {evidence})" if evidence else ""),
                    hint=_capability_hint(svc.name, method.name,
                                          decl.capabilities, extra),
                    code="G4", category="emission-capability",
                )

        # async coloring (docs/design/async-extern.md §3): an async call is
        # admitted only inside a provide method whose service operation is
        # declared `async fn`. The admission tests membership in the phase-2
        # *colored* set (async externs and any fn that transitively reaches
        # one), not just direct extern calls, so a sync method reaching a
        # colored helper fn is refused too — the twin of the emission-
        # propagation diagnostic above. The service declaration is the upper
        # bound on its providers, so asynchrony, like emission-ness, is a
        # declared property (A1).
        if env.async_callables:
            called: set = set()
            values: set = set()
            _calls_in(mbody, called, values=values)

            def _async_kind(name: str) -> str:
                return "extern" if name in env.async_externs else "function"

            def _async_locate(name: str):
                cdecl = (env.async_externs.get(name)
                         or (env.emission_evidence._decls.get(name)
                             if env.emission_evidence is not None else None))
                ev = env.emission_evidence
                return (ev.locate(cdecl) if ev is not None and cdecl is not None
                        else (None, getattr(cdecl, "line", None)))

            # a first-class reference to an async callable is refused in every
            # context, even an async method: an arrow type carries no color, so
            # the emitter cannot know to await it (async-extern.md §3, "refused,
            # not widened").
            passed_async = sorted(values & env.async_callables)
            if passed_async:
                culprit = passed_async[0]
                raise RevlError(
                    comp.source or filename, method.line,
                    f"`{svc.name}.{method.name}` uses async {_async_kind(culprit)} "
                    f"`{culprit}` as a function value, but an async callable has no "
                    f"arrow type",
                    hint="call it directly from an async context — an arrow type "
                         "carries no async color, so a suspension cannot be awaited "
                         "through it (A1)",
                    code="A1", category="async-propagation",
                )
            called_async = sorted(called & env.async_callables)
            if called_async and not decl.async_:
                culprit = called_async[0]
                cfile, cline = _async_locate(culprit)
                head = TraceStep(method.name, "provide-method",
                                 comp.source or filename, method.line,
                                 f"provision `{stmt.key}`")
                tail = TraceStep(culprit, f"async-{_async_kind(culprit)}",
                                 cfile, cline, f"async {_async_kind(culprit)}")
                why = WhyTrace(kind="async-propagation",
                               subject=f"{svc.name}.{method.name}",
                               steps=[head, tail], shape=CHAIN)
                evidence = ", ".join(f"`{name}`" for name in called_async)
                reached = (f"async extern {evidence}"
                           if culprit in env.async_externs
                           else f"async function {evidence}")
                raise RevlError(
                    comp.source or filename, method.line,
                    f"`{svc.name}.{method.name}` is declared sync, but this "
                    f"implementation reaches {reached} — a sync "
                    f"method has no in-flight window (A1)",
                    hint=f"declare the operation `async fn {method.name}(...)` in "
                         f"service `{svc.name}`, or move the suspending call out of "
                         f"this method",
                    code="A1", category="async-propagation",
                    why=why,
                )

        # item 117 (finding #40): the name-based reach above is blind to an
        # async *service operation* reached through a required key — the
        # complement of the async-callable case. A sync provide method that
        # reaches such an op in ANY position (a `let x = emit m.op(...)`
        # statement, or nested in a ternary arm / expression) has no in-flight
        # window to await it in, so it is refused — the expression-position
        # complement of item 141, which awaits the same emission inside an
        # *async* method (that path, `decl.async_`, is deliberately left
        # admitted here). Not guarded by `env.async_callables`: an async svc op
        # can be reached with no async externs/colored fns present at all.
        if not decl.async_:
            reached_ops: list = []
            _reached_async_req_ops(mbody, env, reached_ops)
            if reached_ops:
                req_name, op_method, op_decl = reached_ops[0]
                culprit = f"{req_name}.{op_method}"
                head = TraceStep(method.name, "provide-method",
                                 comp.source or filename, method.line,
                                 f"provision `{stmt.key}`")
                tail = TraceStep(culprit, "async-operation",
                                 getattr(op_decl, "source", None),
                                 getattr(op_decl, "line", None),
                                 "async service operation")
                why = WhyTrace(kind="async-propagation",
                               subject=f"{svc.name}.{method.name}",
                               steps=[head, tail], shape=CHAIN)
                raise RevlError(
                    comp.source or filename, method.line,
                    f"`{svc.name}.{method.name}` is declared sync, but this "
                    f"implementation reaches async operation `{culprit}` — a "
                    f"sync method has no in-flight window (A1)",
                    hint=f"declare the operation `async fn {method.name}(...)` "
                         f"in service `{svc.name}`, or move the suspending call "
                         f"out of this method",
                    code="A1", category="async-propagation",
                    why=why,
                )

        # item 92: a sync-typed arrow in this method that reaches an async
        # operation is the finding-#21 leak — a compile error now, not an
        # unawaited coroutine at runtime. Admitted (async-flagged) arrows are
        # skipped inside the walk.
        _refuse_leaky_arrow(mbody, env, comp.source or filename, method.line)

        methods.append({"name": method.name, "params": safe_params, "body": mbody})

    missing = set(svc.methods) - implemented
    if missing:
        name = sorted(missing)[0]
        raise RevlError(filename, stmt.line,
                        f"provision `{stmt.key}` is missing method `{name}` declared by service {svc.name}")

    return {"step": "provide", "name": stmt.key, "service": svc.name, "methods": methods}


# ---------------------------------------------------------------- expressions

def _lower_emit_step(stmt: EmitStmt, env: Env) -> dict:
    node = _lower_expr(stmt.expr, env, mode="emit")
    if not _is_emission_call(node, env):
        desc = _node_desc(node)
        raise RevlError(env.filename, stmt.line,
                        f"`emit` on {desc}, which is not declared `emission`",
                        hint="only calls to `emission` service operations cross the boundary; "
                             "drop the `emit` marker (G4)")
    step = {"step": "emit", "expr": node}
    if stmt.compensate is not None:
        # compensation is teardown-position: emissions are permitted bare (A5)
        step["compensate"] = _lower_expr(stmt.compensate, env, mode="undo")
    return step


def _lower_timer_step(stmt: TimerStmt, env: Env) -> dict:
    """`every`/`after` -> a `timer` body step (item 57, docs/time-coeffect.md).

    A timer is a revertible schedule; the step carries the delay and the
    emissions the firing runs. The body's `emit` statements lower through the
    *same* `_lower_emit_step` and the *same* `env` as a top-level emit, so the
    firing is bounded by exactly the component's declared capabilities — a
    timer body reaching an undeclared service is refused at G1/G4 like any other
    emission, and `_collect_emit_caps` (which recurses into the nested `body`)
    surfaces the firing's reach to the G8 audit as component reach. The schedule
    itself is not an emission (crossing time is not crossing the system
    boundary); its inverse is the runtime's cancellation, derived like any other
    effect teardown, so it carries no `undo` slot in the IR."""
    body = [_lower_emit_step(inner, env) for inner in stmt.body]
    step = {
        "step": "timer",
        "mode": stmt.mode,
        "interval_ms": stmt.interval_ms,
        "body": body,
    }
    # async colouring (item 170): a timer body reaching an async op — a
    # req-target async service operation (`emit agent.run_in(...)`, the
    # scheduled-agent-run shape) or an async callable (an async extern / a
    # phase-2 colored fn) — is ADMITTED and coloured async, not refused. The
    # firing then opens an `Async[T]` in-flight window (item 106): the runtime
    # awaits the body on the tick and CANCELS any pending firing + in-flight
    # work on unload (the timer's revertible-effect/undo contract, now covering
    # the async case — R4/A8). A sync timer body carries no `async` key and is
    # byte-identical to before.
    if _timer_body_reaches_async(body, env):
        step["async"] = True
    return step


def _timer_body_reaches_async(body, env) -> bool:
    """True if a lowered timer body reaches a suspension (item 170): a
    req-target async service op (rule 3 of the item-92 async-reach), or a call
    of an async-colored callable — an async extern or a phase-2 colored fn
    (rule 1). Mirrors `_arrow_reaches_async`, but a timer body is a list of
    `emit` steps with no intervening arrow value, so nothing is pruned."""
    hit = False

    def walk(n):
        nonlocal hit
        if hit:
            return
        if isinstance(n, dict):
            if _req_op_is_async(n, env):
                hit = True
                return
            for value in n.values():
                walk(value)
        elif isinstance(n, list):
            for value in n:
                walk(value)

    walk(body)
    if hit:
        return True
    called: set = set()
    _calls_in(body, called, stop_async_arrows=True)
    return bool(called & (getattr(env, "async_callables", None) or set()))


def _instance_get_call(node: dict, env: Env):
    """If `node` is a method call whose receiver is a provision read off a
    spawn handle (`s.<key>.<method>(...)`), return `(instance_get, decl)`:
    the `instance-get` node and the `MethodDecl` for the method on the service
    that key yields — else `None`.

    A provision method call does not lower to a `req`-target call; the pure
    expression stratum lowers `s.<key>` to an `instance-get`, and the trailing
    `.<method>(...)` wraps it in a `field` callee (`_lower_component_pure_expr`
    ExprCall fall-through). So the receiver is reached through `callee`, not the
    `target` slot a required-service call uses."""
    if node.get("kind") != "call":
        return None
    callee = node.get("callee")
    if not (isinstance(callee, dict) and callee.get("kind") == "field"):
        return None
    recv = callee.get("target")
    if not (isinstance(recv, dict) and recv.get("kind") == "instance-get"):
        return None
    svc = env.services.get(recv.get("service"))
    if svc is None:
        return None
    decl = svc.methods.get(callee.get("name"))
    return (recv, decl) if decl is not None else None


def _is_emission_call(node: dict, env: Env) -> bool:
    # an `emission` extern (or a function reaching one) is a boundary
    # crossing exactly as a service emission is, so `emit` marks it too
    if node.get("kind") == "fn" and node.get("name") in getattr(env, "emitting_fns", ()):
        return True
    if node.get("kind") != "call":
        return False
    target = node.get("target")
    if target is None:
        # a provision method call off a spawn handle carries its receiver in
        # `callee` (an `instance-get`), not the `req` `target` slot — walk the
        # handle's provision to the service and read the method's emission-ness
        # there rather than assuming a `req` target (which KeyError'd here)
        inst = _instance_get_call(node, env)
        return inst is not None and inst[1].emission
    if target.get("kind") != "req":
        return False
    svc = env.services[env.requires[target["name"]]]
    decl = svc.methods.get(node["method"])
    return decl is not None and decl.emission


def _lower_spawn(expr: SpawnExpr, env: Env, mode: str) -> dict:
    """Lower `spawn <Component> with { ... }` to the frozen spawn IR node
    (docs/design-v2-instances.md).

    An instance is an acquisition: the node rides in the `acquire` slot of a
    `let-effect` step, the handle is that step's `bind`, and the teardown is
    its `undo`.  Instance identity + local realm are carried by `realms` — the
    keys the target provides, each isolated into a *fresh* local realm at spawn
    time so any number of instances coexist without a G2 collision (decision 3,
    5).  The target is a *template*: it never joins the static composition, so
    its provisions never enter the link-time G2/G3 table (decision 5/6)."""
    reg = getattr(env, "spawn_reg", None)
    if reg is None or expr.component not in reg["by_name"]:
        raise RevlError(
            env.filename, expr.line,
            f"`spawn {expr.component}` names an unknown component",
            hint="a spawn target is a component declared in this composition "
                 "(docs/design-v2-instances.md); a running/ambient component "
                 "cannot be spawned in phase 1",
        )
    if mode != "setup":
        # spawn is only meaningful as an acquisition; `undo`/`emit` positions
        # have no handle to bind and no teardown to invert
        raise RevlError(
            env.filename, expr.line,
            "`spawn` is only valid as an acquisition — `let s = effect spawn "
            f"{expr.component} … undo s.dispose()`",
        )
    target = reg["by_name"][expr.component]
    tconfig = {f.name: f for f in target.config}
    lowered_cfg: dict[str, dict] = {}
    for field, vexpr in expr.config.items():
        if field not in tconfig:
            raise RevlError(
                env.filename, expr.line,
                f"`{field}` is not a config field of {expr.component}",
                hint="spawn config carries the target's declared `config { }` fields",
            )
        lowered_cfg[field] = _lower_expr(vexpr, env, "setup")
    for f in target.config:
        if f.default is None and f.name not in expr.config:
            raise RevlError(
                env.filename, expr.line,
                f"spawn {expr.component} is missing required config field `{f.name}`",
                hint=f"provide it: `spawn {expr.component} with {{ {f.name}: … }}`",
            )
    realms = sorted(key for key, _svc, _line in target.provides)
    reg["edges"].append((env.component.name, expr.component))
    reg["templates"].add(expr.component)
    return {
        "kind": "spawn",
        "component": expr.component,
        "config": lowered_cfg,
        # each provided key gets its own fresh LOCAL realm at runtime; this is
        # how per-instance non-collision is carried into every tier's IR
        "realms": realms,
        "line": expr.line,
    }


def _instance_handle_component(node: dict, env: Env) -> str | None:
    """`C` if `node` is a name bound to a spawn handle typed `Instance[C]`,
    else None.

    The type is recorded only when the current component itself binds a
    `spawn` acquisition (`env.type_env[handle] = "Instance[C]"`), so a name
    can carry it only for a handle *this* component holds. There is no surface
    that names another component's handle, which is exactly why `s.<key>`
    cannot reach a sibling's or the root's provision — it keeps instance
    addressing on the supervision tree (docs/design-v2-instances.md 1/2)."""
    if not isinstance(node, dict) or node.get("kind") != "name":
        return None
    head, args = parse_type(env.type_env.get(node.get("id")))
    if head == "Instance" and args:
        return args[0]
    return None


def _lower_instance_get(target: dict, key: str, line: int,
                        component_name: str, env: Env) -> dict:
    """Lower `s.<key>` (a provision read off a spawn handle) to the frozen
    `instance-get` IR node (docs/design-v2-instances.md).

    `<key>` must be a key the target component *provides*; reading a key it
    does not provide is a compile error. At runtime every tier resolves `key`
    through the handle's stored instance context — the private local realm the
    matching `spawn` node isolated the key into — so the read yields *that
    instance's* provision and no other's."""
    reg = getattr(env, "spawn_reg", None)
    target_decl = reg["by_name"].get(component_name) if reg else None
    provides = {k: svc for k, svc, _line in (target_decl.provides if target_decl else [])}
    if key not in provides:
        known = ", ".join(f"`{k}`" for k in sorted(provides)) or "<nothing>"
        raise RevlError(
            env.filename, line,
            f"`{key}` is not a provision of {component_name}",
            hint=f"a spawn handle reads only a key its component provides — "
                 f"{component_name} provides {known}",
        )
    return {
        "kind": "instance-get",
        "target": target,
        "component": component_name,
        "key": key,
        # the service type the key yields — the typing rule's result, frozen
        # inline so no tier re-derives it (mirrors `spawn.realms` carrying the
        # provided keys); advisory, like any host-frontier value's type
        "service": provides[key],
        "line": line,
    }


def _lower_expr(expr, env: Env, mode: str):
    """mode: 'setup' | 'undo' | 'emit'.

    Emission calls are illegal in 'setup' (must be marked `emit`; the outer
    call of an `emit` statement is verified by `_lower_emit`) and — documented
    v0 exception — permitted bare in 'undo', where the expression position
    leaves no room for a marker (DESIGN §3.5 note; the compensate slot
    arrives with IR v1/A5).
    """
    if isinstance(expr, SpawnExpr):
        return _lower_spawn(expr, env, mode)
    if isinstance(expr, Lit):
        if expr.value is None:
            raise null_error(env.filename, expr.line)
        return {"kind": "lit", "value": _str_literal_value(expr.value)}
    if isinstance(expr, Interp):
        template = []
        args = []
        for kind, value in expr.parts:
            if kind == "text":
                template.append(value.replace("$", "$$"))  # A4: literal dollars
            else:
                template.append(f"${len(args)}")
                # `value` is a full expression AST; lower it in this context
                args.append(_lower_expr(value, env, mode))
        return {"kind": "format", "template": "".join(template), "args": args}
    if isinstance(expr, Postfix):
        return _lower_postfix(expr, env, mode)
    # v2.0 unified grammar: component positions carry the full pure-expression
    # stratum; the mode/context ride on env so the shared lowering needs no
    # signature churn (finding 1 — strata compose)
    saved = getattr(env, "_expr_mode", None), getattr(env, "_plain_body", None)
    env._expr_mode, env._plain_body = mode, True
    try:
        return _lower_component_pure_expr(
            expr, env, _component_scope(env), getattr(env, "callables", set()))
    finally:
        env._expr_mode, env._plain_body = saved


def _lower_postfix(expr: Postfix, env: Env, mode: str):
    comp = env.component
    head = expr.head
    ops = list(expr.ops)

    if head == "config":
        if not ops or ops[0].args is not None:
            raise RevlError(env.filename, expr.line, "`config` is accessed as `config.<field>`")
        field = ops.pop(0)
        if field.name not in env.config_fields:
            raise RevlError(env.filename, field.line,
                            f"`{field.name}` is not a config field of {comp.name}")
        node = {"kind": "config", "field": field.name}
    elif head in env.params or head in env.locals:
        node = {"kind": "name", "id": env.params.get(head) or env.locals[head]}
    elif head in env.requires:
        if not ops or ops[0].args is None:
            raise RevlError(env.filename, expr.line,
                            f"a required service is used through its methods: `{head}.<method>(...)`")
        node = {"kind": "req", "name": head}
    elif head[:1].isupper() and ops and ops[0].args is not None:
        call = ops.pop(0)
        # the Map VALUE constructor (docs/stdlib-2.0.md §Map): a value, not
        # a host acquisition — intercepted before host_check.
        if head == "Map" and call.name == "empty":
            if call.args:
                raise RevlError(
                    env.filename, expr.line,
                    f"`Map.empty()` takes no arguments, {len(call.args)} given",
                    hint="build up an empty map with `set`: "
                         "`Map.empty().set(\"k\", v)`",
                )
            node = {"kind": "maplit", "entries": []}
            for op in ops:
                if op.args is None:
                    raise RevlError(env.filename, expr.line,
                                    "field access `.{}` is not supported in v0 — only method calls".format(op.name))
                node = {"kind": "builtin", "method": op.name,
                        "target": node,
                        "args": [_lower_expr(a, env, mode) for a in op.args]}
            return node
        host_args = [_lower_expr(a, env, mode) for a in call.args]
        host_check(f"{head}.{call.name}",
                   [infer_ir(a, env.type_env, env.types, env.services)
                    for a in host_args],
                   env.filename, expr.line)
        node = {"kind": "host", "fn": f"{head}.{call.name}", "args": host_args}
    else:
        declared = ", ".join(f"`{r}`" for r in env.requires) or "<nothing>"
        raise RevlError(
            env.filename, expr.line,
            f"`{head}` is not a declared requirement of {comp.name}",
            hint=f"component {comp.name} requires {declared} — add `requires {head}: <Service>`?",
        )

    for op in ops:
        if op.args is None:
            # The one legal bare field access in a component/method body is
            # reading a provision off a spawn handle: `s.<key>` where
            # `s : Instance[C]` and `<key>` is a key C provides. Only a name
            # the current component itself bound to a handle can carry the
            # `Instance[C]` type, so this never becomes a lookup of a sibling's
            # or the root's provision — it is the parent reaching *its own*
            # instance (supervision-tree addressing, docs/design-v2-instances.md
            # decision 1/2).
            inst = _instance_handle_component(node, env)
            if inst is not None:
                node = _lower_instance_get(node, op.name, op.line, inst, env)
                continue
            raise RevlError(env.filename, op.line,
                            f"field access `.{op.name}` is not supported in v0 — only method calls")
        if node["kind"] == "req":
            svc = env.services[env.requires[node["name"]]]
            decl = svc.methods.get(op.name)
            if decl is None:
                raise RevlError(env.filename, op.line,
                                f"`{node['name']}.{op.name}` is not a method of service {svc.name}")
            if len(op.args) != len(decl.params):
                raise RevlError(env.filename, op.line,
                                f"`{node['name']}.{op.name}` takes {len(decl.params)} "
                                f"argument(s), {len(op.args)} given")
            if decl.emission and mode == "setup":
                raise RevlError(
                    env.filename, op.line,
                    f"call to emission `{node['name']}.{op.name}` must be marked `emit` (G4)",
                    hint="an emission crosses the system boundary and cannot be reverted; "
                         "`emit` makes that visible at the call site",
                )
            lowered = [_lower_expr(a, env, mode) for a in op.args]
            for arg, (pname, ptype) in zip(lowered, decl.params):
                actual = infer_ir(arg, env.type_env, env.types, env.services)
                if ptype and actual and not compatible(ptype, actual):
                    raise mismatch(env.filename, op.line,
                                   f"`{node['name']}.{op.name}` argument `{pname}`",
                                   ptype, actual)
            node = {"kind": "call", "target": node, "method": op.name, "args": lowered}
            continue
        node = {
            "kind": "call",
            "target": node,
            "method": op.name,
            "args": [_lower_expr(a, env, mode) for a in op.args],
        }
    return node


def _node_desc(node: dict) -> str:
    if node.get("kind") == "call":
        target = node.get("target")
        if isinstance(target, dict) and target.get("kind") == "req":
            return f"`{target['name']}.{node['method']}`"
        callee = node.get("callee")
        if isinstance(callee, dict) and callee.get("kind") == "field":
            recv = callee.get("target")
            if isinstance(recv, dict) and recv.get("kind") == "instance-get":
                # a provision method call off a spawn handle: name it the way
                # it was written, `<key>.<method>`, so the diagnostic points at
                # the provision access rather than "a call to <method>"
                return f"`{recv.get('key')}.{callee.get('name')}`"
            return f"a call to `{callee.get('name')}`"
        return f"a call to `{node.get('method')}`"
    return f"a {node.get('kind', 'value')} expression"


# ---------------------------------------------------------------- linker

def _link(program: Program, components: list[dict], ambient_components: list[dict],
          templates: set | None = None) -> dict:
    """G2/G3 over the union of ambient (running) and new components, and the
    composition manifest (cordisc-compatible schema: components with
    name/file/inject/provides, plus loadOrder).

    `templates` names components that are *spawn targets* — runtime instances,
    not static composition members (docs/design-v2-instances.md). They are
    excluded from `entries`, so their provisions never enter the link-time
    G2/G3 table and they take no place in `loadOrder`: at runtime each is
    instantiated into its own fresh local realm by `spawn`, disjoint by
    construction (decision 5/6). Non-spawning programs have no templates, so
    the manifest is byte-identical to before."""
    templates = templates or set()
    lines = {comp["name"]: decl.line for comp, decl in zip(components, program.components)}

    entries: list[dict] = []
    for amb in ambient_components:
        entry = {
            "name": amb.get("name"),
            "file": amb.get("file", ""),
            "inject": list(amb.get("inject") or []),
            "provides": list(amb.get("provides") or []),
        }
        if amb.get("isolate"):
            entry["isolate"] = dict(amb["isolate"])
        if amb.get("intercept"):
            entry["intercept"] = dict(amb["intercept"])
        if amb.get("routes"):
            entry["routes"] = {k: dict(v) for k, v in amb["routes"].items()}
        entries.append(entry)
    for comp in components:
        if comp["name"] in templates:
            # a spawn target is instantiated at runtime, not composed: its
            # provisions live in fresh per-instance local realms, so it never
            # participates in the static G2/G3 table or loadOrder (decision 5/6)
            continue
        entry = {
            "name": comp["name"],
            "file": comp.get("source", ""),
            "inject": sorted(comp["requires"]),
            "provides": sorted(comp["provides"]),
        }
        if comp.get("isolate"):
            entry["isolate"] = dict(comp["isolate"])
        if comp.get("intercept"):
            entry["intercept"] = dict(comp["intercept"])
        if comp.get("routes"):
            entry["routes"] = {k: dict(v) for k, v in comp["routes"].items()}
        entries.append(entry)

    def _line(name: str) -> int:
        return lines.get(name, 1)

    # why-trace locations: a locally compiled component knows its own file and
    # declaration line; an *ambient* entry (read back from a running manifest)
    # has a file but no line, so `line` stays None there rather than lying.
    by_name = {entry["name"]: entry for entry in entries}

    def _where(name: str) -> tuple[str | None, int | None]:
        entry = by_name.get(name) or {}
        file = entry.get("file") or program.filename or None
        return (file, lines.get(name))

    def _realm(entry: dict, key: str) -> str:
        return (entry.get("isolate") or {}).get(key, SHARED_REALM)

    # v2: provision disjointness is per-(key, realm) — same key in different
    # realms is the multi-tenancy feature, same realm is the conflict. The
    # realm is named only when it isn't the shared one, so v1 diagnostics
    # are unchanged.
    provider_of: dict[tuple[str, str], str] = {}
    for entry in entries:
        for key in entry["provides"]:
            realm = _realm(entry, key)
            where = "" if realm == SHARED_REALM else f" in realm `{realm}`"
            if (key, realm) in provider_of:
                first = provider_of[(key, realm)]
                # both exhibits, both locations: the message names them, the
                # trace says where to go and look (why.py)
                detail = f"provides `{key}`{where}"
                why = WhyTrace(
                    kind="provision-conflict", subject=key, shape=SET,
                    steps=[
                        TraceStep(first, "provider", *_where(first), detail),
                        TraceStep(entry["name"], "provider",
                                  *_where(entry["name"]), detail),
                    ])
                raise RevlError(
                    program.filename, _line(entry["name"]),
                    f"provision conflict: key `{key}`{where} is provided "
                    f"by both {provider_of[(key, realm)]} and {entry['name']} (G2)",
                    why=why,
                )
            provider_of[(key, realm)] = entry["name"]

    def _routes(entry: dict) -> dict:
        return entry.get("routes") or {}

    # multi-realm bind verification (item 162): a `realms(...)` route binds the
    # key across N named realms, and the consumer routes across them at runtime.
    # The compiler verifies EACH named realm has a provider of the key — a route
    # that names a realm with no provider would dangle at that leg. This does NOT
    # relax G2 (one provider per (key, realm) is still enforced above); it is the
    # dual existence check on the consumption side. Providers of a routed key may
    # sit in the shared realm too (`realm` unnamed) — a route target is matched
    # against the same per-(key, realm) table, so the named realm must have its
    # own provider.
    for entry in entries:
        for key, route in _routes(entry).items():
            for realm in route["realms"]:
                if (key, realm) not in provider_of:
                    strat = route.get("strategy")
                    strat_where = f" strategy(`{strat}`)" if strat else ""
                    why = WhyTrace(
                        kind="unmet-requirement", subject=key, shape=CHAIN,
                        steps=[TraceStep(entry["name"], "consumer",
                                         *_where(entry["name"]),
                                         f"routes `{key}` across "
                                         f"{len(route['realms'])} realms{strat_where}")])
                    raise RevlError(
                        program.filename, _line(entry["name"]),
                        f"multi-realm bind of `{key}` in {entry['name']} names realm "
                        f"`{realm}`, but no component provides `{key}` in realm `{realm}` "
                        f"(item 162: every routed realm needs a provider)",
                        hint="a `realms(...)` route distributes across backend realms; each "
                             "named realm must have its own provider of the key (G2 keeps it "
                             "to exactly one). Add a provider isolated into realm "
                             f"`{realm}`, or drop `{realm}` from the route",
                        why=why,
                    )

    # edges: provider -> consumer where the consumer's realm for a key
    # matches the provider's — realm separation legitimately breaks cycles
    graph: dict[str, list[str]] = {entry["name"]: [] for entry in entries}
    indegree: dict[str, int] = {entry["name"]: 0 for entry in entries}
    # which key carries each provider -> consumer edge, so a cycle can say
    # *what* is being waited on at every hop and not just who waits
    edge_key: dict[tuple[str, str], str] = {}
    for entry in entries:
        # a routed key is resolved per-realm below, not through the single-realm
        # table — skip it here so a stray shared-realm provider does not shadow
        # the route's own targets.
        routed = _routes(entry)
        for key in entry["inject"]:
            if key in routed:
                # one edge per routed realm: every backend provider must be
                # ACTIVE before the consumer that routes to it (loadOrder), and
                # each leg can still surface in a cycle trace by its key.
                for realm in routed[key]["realms"]:
                    provider = provider_of.get((key, realm))
                    if provider == entry["name"]:  # pragma: no cover — a route
                        # targets a *required* key; a self-provision in a routed
                        # realm cannot arise (the key is not this comp's provision)
                        continue
                    if provider is not None:
                        graph[provider].append(entry["name"])
                        edge_key.setdefault((provider, entry["name"]), key)
                        indegree[entry["name"]] += 1
                continue
            provider = provider_of.get((key, _realm(entry, key)))
            if provider == entry["name"]:
                name = entry["name"]
                raise RevlError(
                    program.filename, _line(name),
                    f"component {name} requires a key it provides itself (`{key}`) (G3)",
                    why=WhyTrace(
                        kind="dependency-cycle", subject=name, shape=CHAIN,
                        steps=[TraceStep(name, "component", *_where(name),
                                         f"provides and requires `{key}`")]),
                )
            if provider is not None:
                graph[provider].append(entry["name"])
                edge_key.setdefault((provider, entry["name"]), key)
                indegree[entry["name"]] += 1

    state: dict[str, int] = {}
    stack: list[str] = []

    def visit(name: str):
        state[name] = 1
        stack.append(name)
        for succ in graph[name]:
            if state.get(succ) == 1:
                cycle = stack[stack.index(succ):] + [succ]
                # one step per hop: each names the key it provides onward, so
                # the closing repeat shows the edge that shuts the loop
                steps = [
                    TraceStep(node, "component", *_where(node),
                              (f"provides `{edge_key[(node, cycle[i + 1])]}`"
                               if i + 1 < len(cycle) else None))
                    for i, node in enumerate(cycle)
                ]
                raise RevlError(program.filename, _line(succ),
                                "dependency cycle: " + " -> ".join(cycle) + " (G3)",
                                why=WhyTrace(kind="dependency-cycle", subject=succ,
                                             steps=steps, shape=CHAIN))
            if state.get(succ, 0) == 0:
                visit(succ)
        stack.pop()
        state[name] = 2

    for entry in entries:
        if state.get(entry["name"], 0) == 0:
            visit(entry["name"])

    # providers-first load order (Kahn, stable in entry order)
    order: list[str] = []
    ready = [e["name"] for e in entries if indegree[e["name"]] == 0]
    while ready:
        name = ready.pop(0)
        order.append(name)
        for succ in graph[name]:
            indegree[succ] -= 1
            if indegree[succ] == 0:
                ready.append(succ)

    manifest = {"components": entries, "loadOrder": order}
    if templates:
        # G8: the instance dimension is dynamic. These components are not
        # statically composed — each is instantiated `× dynamic` times at
        # runtime — so they carry no loadOrder position; the audit reports
        # them separately (docs/design-v2-instances.md, decision 7).
        manifest["templates"] = sorted(templates)
    return manifest


# ------------------------------------------------------------------ spawn G4

def _find_spawn_nodes(node) -> "list[dict]":
    """Every `spawn` acquire node reachable in a lowered body subtree."""
    out: list[dict] = []
    if isinstance(node, dict):
        if node.get("kind") == "spawn":
            out.append(node)
        for value in node.values():
            out.extend(_find_spawn_nodes(value))
    elif isinstance(node, list):
        for value in node:
            out.extend(_find_spawn_nodes(value))
    return out


def _collect_emit_caps(node, caps: set) -> None:
    """The capabilities an `emit` step in a lowered body crosses. A req-keyed
    emission is capability = the key (G2 names the boundary); any host emission
    is the unnameable `*` (no `emission[...]` list can name it)."""
    if isinstance(node, dict):
        if node.get("step") == "emit":
            expr = node.get("expr") or {}
            target = expr.get("target") or {}
            if target.get("kind") == "req":
                caps.add(target.get("name"))
            else:
                caps.add("*")
        for value in node.values():
            _collect_emit_caps(value, caps)
    elif isinstance(node, list):
        for value in node:
            _collect_emit_caps(value, caps)


def _spawn_emission_surface(components: list[dict], services: dict) -> dict[str, set]:
    """Per-component upper bound on what activating an instance of it can emit.

    A conservative, sound over-approximation (decision 8): the union of every
    emission method declared by the services it provides (uncapped -> `*`), its
    own `emit` steps, and — by fixpoint over the spawn graph — everything its
    own spawned children can emit. Never under-approximates, so the bound it
    enforces on a spawner can only be tighter than the truth, never looser."""
    surface: dict[str, set] = {}
    for comp in components:
        caps: set = set()
        for _key, svcname in (comp.get("provides") or {}).items():
            svc = services.get(svcname)
            if svc is None:
                continue
            for m in svc.methods.values():
                if m.emission:
                    caps.update({"*"} if m.capabilities is None else set(m.capabilities))
        _collect_emit_caps(comp.get("body") or [], caps)
        surface[comp["name"]] = caps
    # the transitive closure over the spawn graph is applied by the caller,
    # which holds the edge list
    return surface


def _spawn_reached_surface(components: list[dict]) -> dict[str, set]:
    """Per-component *actual* capability reach — the boundaries a component's
    own code crosses, drawn from its lowered body (`_collect_emit_caps`, the
    G4 capability machinery): the required key of every `emit` step, and `*`
    for any host emission or first-class dispatch that no key can name.

    This is deliberately more precise than `_spawn_emission_surface`, which
    over-approximates from a provided service's *declaration* (a bare
    `emission` provider counts as `*`). Attenuation asks what an instance can
    actually reach — bounded by the keys it wires through `requires` — so the
    least-authority claim is exact: a worker that only ever emits through
    `kv_a` provably does not reach `kv_b`, whatever its service promises."""
    surface: dict[str, set] = {}
    for comp in components:
        caps: set = set()
        _collect_emit_caps(comp.get("body") or [], caps)
        surface[comp["name"]] = caps
    return surface


def _spawn_surface_closure(base: dict[str, set], edges: list) -> dict[str, set]:
    """Fold the spawn graph into a per-component base surface: after this, a
    component's set is everything it can emit *plus* everything its transitive
    spawned children can (`docs/capabilities.md`). The least fixed point the
    edge list induces — the same closure `_check_spawn_emission_bounds` takes,
    factored out so the attenuation check reads the *reachable* set of a child
    (its own emissions and its descendants') against what a spawner holds."""
    closed: dict[str, set] = {name: set(caps) for name, caps in base.items()}
    changed = True
    while changed:
        changed = False
        for parent, child in edges:
            before = len(closed.setdefault(parent, set()))
            closed[parent].update(closed.get(child, set()))
            if len(closed[parent]) != before:
                changed = True
    return closed


def _held_capabilities(comp: dict, base_surface: set) -> set:
    """What a component *holds* — the capabilities it may pass down to a child
    it spawns (item 66, lineage). A component holds a boundary when it has
    wired access to it: every key in its `requires` clause (a `requires db: DB`
    is the right to reach `db`), together with every boundary its own body
    already crosses (`base_surface`: its `emit` steps and the emission methods
    it provides, including the unnameable host `*`). This is the spawner's own
    authority, *not* its transitive spawn closure — a parent cannot launder a
    capability it lacks by routing it through one child into another."""
    return set((comp.get("requires") or {}).keys()) | set(base_surface)


def _activation_spawn_sites(comp: dict) -> "list[dict]":
    """The `spawn` nodes in a component's *activation* body — the top-level
    supervision `let s = effect spawn C ...`, excluding spawns nested inside a
    `provide` method. Provide-method spawns carry an `emission[...]` clause that
    already bounds them (`_check_spawn_emission_bounds`); the activation body
    has no such clause, which is exactly the hole item 66 closes: without an
    attenuation rule a supervisor is a capability amplifier."""
    sites: list[dict] = []
    for step in comp.get("body") or []:
        if step.get("step") == "provide":
            continue
        sites.extend(_find_spawn_nodes(step))
    return sites


def _check_spawn_attenuation(components: list[dict],
                             spawn_reg: dict, filename: str) -> list[dict]:
    """Capability attenuation on spawn (item 66): a spawned child's capability
    set must be a **checked subset** of its spawner's — monotone shrinkage, the
    direction §5 admits for purity. A spawn may narrow (pass down less), never
    widen (grant a boundary the parent does not hold), so spawning cannot
    amplify authority and each per-tenant instance gets least-authority for
    free: an instance whose template reaches only `kv_a` provably cannot reach
    `kv_b`, even when the spawner holds both.

    Reuses the G4 capability-bound machinery (`_spawn_emission_surface`): the
    child's *reachable* set is its emission surface closed over its own spawn
    subtree, the spawner's *held* set is its requires-wired authority. Where G4
    bounds a component's declaration, item 33 the composition, and item 55 the
    operators, this bounds **lineage**.

    Applies to activation-body spawns (see `_activation_spawn_sites`); returns
    the per-instance attenuation chain (spawner → child narrowing) for the G8
    audit surface. Raises on a widening spawn, naming the chain."""
    edges = spawn_reg.get("edges") or []
    if not edges:
        return []
    base = _spawn_reached_surface(components)
    reachable = _spawn_surface_closure(base, edges)

    chain: list[dict] = []
    seen: set = set()
    for comp in components:
        held = _held_capabilities(comp, base.get(comp["name"], set()))
        for spawn in _activation_spawn_sites(comp):
            child = spawn.get("component")
            child_reach = reachable.get(child, set())
            extra = sorted(child_reach - held)
            line = spawn.get("line", comp.get("line", 1))
            if extra:
                held_str = ", ".join(f"`{c}`" for c in sorted(held)) or "no capabilities"
                offending = ", ".join(
                    "an unnameable host boundary" if c == "*" else f"`{c}`"
                    for c in extra)
                raise RevlError(
                    comp.get("source") or filename, line,
                    f"`{comp['name']}` spawns `{child}`, granting it {offending}, "
                    f"but `{comp['name']}` holds only {held_str} — a spawn may "
                    "narrow a child's capabilities, never widen them",
                    hint="a spawned child's capability set must be a subset of "
                         f"its spawner's (attenuation, item 66) — `{comp['name']}` "
                         f"cannot pass down {offending} it does not hold; add the "
                         f"matching `requires` to `{comp['name']}` so it holds what "
                         f"it grants, or drop the capability from `{child}` "
                         "(monotone shrinkage: narrowing is sound, widening is not)",
                    code="G4", category="capability-attenuation",
                )
            edge = (comp["name"], child)
            if edge in seen:
                continue
            seen.add(edge)
            # the attenuation chain per instance: what the spawner holds, what
            # the instance is granted (its reachable set), and what was dropped
            # on the way down — the least-authority proof, per lineage edge.
            chain.append({
                "parent": comp["name"],
                "child": child,
                "holds": sorted(held),
                "granted": sorted(child_reach),
                "attenuated": sorted(held - child_reach),
                "line": line,
            })
    return chain


def _check_spawn_emission_bounds(components: list[dict], services: dict,
                                 spawn_reg: dict, filename: str) -> None:
    """G4/G6 across the spawn boundary (decision 8): a spawner's declared
    emission bound must cover what its spawned instances emit, so emissions
    cannot escape their bound by being moved into a spawned child.

    Only *bounded* spawn sites are constrained — a spawn inside a provide-method
    whose service declares `plain` or `emission[caps]`. A spawn in an activation
    body has no emission clause to widen (as body-level `emit` has none), so it
    is unconstrained here, exactly as today."""
    if not spawn_reg.get("edges"):
        return
    surface = _spawn_emission_surface(components, services)
    # fold the spawn graph into each surface (transitive closure)
    edges = spawn_reg["edges"]
    changed = True
    while changed:
        changed = False
        for parent, child in edges:
            before = len(surface.get(parent, set()))
            surface.setdefault(parent, set()).update(surface.get(child, set()))
            if len(surface[parent]) != before:
                changed = True

    for comp in components:
        for step in comp.get("body") or []:
            if step.get("step") != "provide":
                continue
            key = step.get("name")
            svc = services.get((comp.get("provides") or {}).get(key) or "")
            if svc is None:
                continue
            for method in step.get("methods") or []:
                decl = svc.methods.get(method.get("name"))
                if decl is None:
                    continue
                for spawn in _find_spawn_nodes(method.get("body") or []):
                    target = spawn.get("component")
                    tsurf = surface.get(target, set())
                    if not tsurf:
                        continue
                    line = spawn.get("line", step.get("line", 1))
                    where = f"{svc.name}.{method.get('name')}"
                    if not decl.emission:
                        evidence = ", ".join(f"`{c}`" for c in sorted(tsurf))
                        raise RevlError(
                            comp.get("source") or filename, line,
                            f"`{where}` is declared plain, but it spawns "
                            f"`{target}`, which emits through {evidence}",
                            hint="a spawner's emission bound must cover its "
                                 "instances' — declare `emission fn "
                                 f"{method.get('name')}(...)` on service `{svc.name}`, "
                                 "or move the spawn out of this method (G4)",
                            code="G4", category="emission-propagation",
                        )
                    if decl.capabilities is not None:
                        extra = sorted(tsurf - set(decl.capabilities))
                        if extra:
                            declared = ", ".join(decl.capabilities) or "no capabilities"
                            offending = ", ".join(
                                "an unnameable host boundary" if c == "*" else f"`{c}`"
                                for c in extra)
                            raise RevlError(
                                comp.get("source") or filename, line,
                                f"`{where}` is declared `emission[{declared}]`, but it "
                                f"spawns `{target}`, which emits through {offending}",
                                hint="a spawner's emission bound must cover its "
                                     f"instances' — widen `emission[...]` on service "
                                     f"`{svc.name}` to include {offending}, or move the "
                                     "spawn out of this method (G4)",
                                code="G4", category="emission-capability",
                            )
