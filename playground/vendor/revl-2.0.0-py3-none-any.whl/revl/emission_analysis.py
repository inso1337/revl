"""Emission reachability and the G4 evidence trail (docs/capabilities.md).

Split out of `lower.py` (roadmap item 17): the least-fixed-point that decides
which functions/externs reach an irreversible host effect, the capability sets
they cross, and the witness/evidence machinery that explains a verdict. Pure
code movement — every name here is re-exported from `revl.lower`, so the public
import surface is unchanged. Functions here read only `env`/`program`
attributes (never the lowering spine), so this module does not import from
`lower`.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from .parser import Program
from .typecheck import parse_type, FN_HEAD
from .why import TraceStep

if TYPE_CHECKING:
    # `Env` lives in `lower`, which re-exports this module's names, so importing
    # it at runtime would be circular. Guarded to TYPE_CHECKING: the annotation
    # resolves for type checkers and ruff without adding a runtime dependency on
    # the lowering spine (see the module docstring).
    from .lower import Env


def _is_async_fn_type(type_name: str | None) -> bool:
    """True for a function type whose declared return is `Async[…]` — the one
    spelling that colors a first-class callback (roadmap item 92)."""
    head, args = parse_type(type_name)
    if head != FN_HEAD or not args:
        return False
    return parse_type(args[-1])[0] == "Async"


# item 250 (session branching, fork-rewind review) — the cap-scope discriminator
# a fork rewind keys on. A fork replays a reversal (a witnessed `undo` or an
# item-247 `compensate`) to put the workspace back into an earlier step's state;
# a HOST-CONFINED reversal is safe to run speculatively per explored branch, but
# a reversal that crosses the NETWORK (or IPC, or any outbound boundary) would
# issue a real remote effect per branch — exactly the external residue item 245
# exists to prevent. So the rewind RUNS a reversal only when every cap in its
# scope is host-confined, and ENUMERATES-NOT-RUNS it otherwise.
#
# The quantifier is the one item 254's HIGH 2 pins precisely: a reversal is
# enumerated-not-run IFF its scope contains ANY non-host-confined cap. A single
# net cap TAINTS the whole reversal, so a mixed `[fs, net.x]` scope is never
# speculatively fired even though its `fs` component alone would have run. This
# is deliberately fail-toward-enumerate: an unrecognised realm root is treated
# as non-host-confined, so a new outbound boundary can never silently leak into
# a speculative rewind before this set is taught about it.
#
# Item 250 is not itself landed; this ships the discriminator (and item 254's
# tests pin it) so the contract is ready and cannot be relaxed underneath 250.
_HOST_CONFINED_CAP_ROOTS = frozenset({"fs"})


def _cap_realm_root(token: str) -> str:
    """The realm root (first dotted segment) of a capability token, with any
    item-294 parameter list (`fs.write(path="…")`) stripped first. `net.api` ->
    `net`, `fs` -> `fs`, `fs.write(path="/d")` -> `fs`."""
    return token.split("(", 1)[0].split(".", 1)[0]


def cap_scope_enumerated_not_run(caps) -> bool:
    """The item-250 fork-rewind predicate (item 254 HIGH 2): a reversal whose
    capability scope is `caps` is ENUMERATED-not-run by a fork rewind iff any
    cap in the scope is not host-confined.

        enumerated_not_run(scope)  <=>  exists cap in scope: root(cap) not in
                                        host-confined roots

    A pure `[fs]` scope runs (host-confined); a `[net.*]` scope is
    enumerated-not-run; a mixed `[fs, net.x]` scope is enumerated-not-run because
    its `net.x` component taints the whole reversal. An empty scope is a bare,
    name-as-capability crossing whose boundary cannot be proven host-confined, so
    it is enumerated-not-run too (fail-toward-enumerate)."""
    caps = tuple(caps)
    if not caps:
        return True
    return any(_cap_realm_root(c) not in _HOST_CONFINED_CAP_ROOTS for c in caps)


def _calls_in(node, found: set, values: set | None = None,
              stop_async_arrows: bool = False, _callee_pos: bool = False) -> None:
    """Function/extern names a lowered node calls. Component bodies lower a
    call to `{kind: fn, name}`; pure fn bodies to `{kind: call, callee:
    {kind: var, name}}`.

    With `values` (a set, filled in place), a *first-class* reference — a
    bare `{kind: var, name}` naming a callable in value position, where the
    function value itself flows instead of a call happening — is recorded
    too. The *directly named* callee of a call is not such a reference:
    `f(x)` is a call (already in `found`), not `f` escaping as a value.

    Two things that read alike but are not: NOT RECORDING THE CALLEE NODE AS
    A VALUE, and NOT VISITING THE CALLEE SUBTREE. Only the first is the rule.
    A callee is an arbitrary expression, and a name nested inside a computed
    one — `[send][0](x)`, `pick()(x)`, `(b ? send : other)(x)`, `xs[i](x)` —
    is a real reference: the function value genuinely flows into the
    index/ternary/factory that produces the target. Pruning the whole subtree
    (as this walk once did) hid those names from *both* channels, so a module
    `fn` dispatching through a computed callee entered neither `found` nor
    `values` and the G4/G8/capability/async folds never reached it. The
    subtree is therefore walked; only the immediate callee node is barred
    from the value channel, by `_callee_pos` (internal, one level deep).
    """
    if isinstance(node, dict):
        kind = node.get("kind")
        if stop_async_arrows and kind == "arrow" and node.get("async"):
            # An async-colored arrow is a *value* whose suspension belongs to
            # whoever awaits it, not to the body constructing it (item 92 §3,
            # "the arrow owns its color"). Its internal calls are not the
            # constructor's, so async coloring/admission stop here. Emission
            # analysis passes `stop_async_arrows=False` and keeps bubbling.
            return
        if kind == "fn" and isinstance(node.get("name"), str):
            found.add(node["name"])
        callee = node.get("callee")
        if kind == "call" and isinstance(callee, dict) \
                and callee.get("kind") == "var" and isinstance(callee.get("name"), str):
            found.add(callee["name"])
        elif values is not None and kind == "var" and not _callee_pos \
                and isinstance(node.get("name"), str):
            values.add(node["name"])
        for key, value in node.items():
            _calls_in(value, found, values, stop_async_arrows,
                      _callee_pos=(key == "callee" and kind == "call"))
    elif isinstance(node, list):
        for value in node:
            _calls_in(value, found, values, stop_async_arrows)


def _emitting_fns(fns: list, externs: list, witness: dict | None = None) -> set:
    """Names whose call reaches a host boundary crossing: `emission` **and
    `witnessed`** externs, and functions that reach one transitively.

    An `acquire` extern is revertible by a bracket that the very structure of an
    `effect` form registers, so it is deliberately not here. A `witnessed`
    extern is different: its reversibility is realized only when the accumulator
    actually registers the declared inverse (item 243). Reversibility therefore
    ties to *registration*, not to the mere presence of a declared inverse — a
    witnessed call that registers nothing is as irreversible as an emission and
    must be visible to the item-33 policy gate, not exempted. So a witnessed
    extern crosses a boundary in the same authority namespace as an emission,
    carrying a reversibility flag on its IR node rather than forming a separate
    lattice.

    `witness` (optional, filled in place) records *why* each derived name is
    in the set: `witness[caller] = callee`, the edge that put it there. The
    verdict is unchanged either way — this is only the evidence the fixed
    point would otherwise throw away (why.py)."""
    return set(_emitting_capabilities(fns, externs, witness))


def _emitting_capabilities(fns: list, externs: list,
                           witness: dict | None = None) -> dict[str, set]:
    """`_emitting_fns` refined from a boolean to a *set*: name -> the
    capabilities its call reaches (docs/capabilities.md).

    A host capability is named by the `emission` extern itself — that extern
    *is* the boundary — so `extern emission fn send` contributes `send`, and a
    `fn` contributes the union of what it calls, not its own name. The fixed
    point is the same least one `_emitting_fns` took, now over sets instead of
    a flag, which is why a capability propagates through a chain of `fn`s.

    `witness` is filled in place as the same walk proceeds — the set and the
    derivation come from one traversal, so they cannot disagree."""
    caps: dict[str, set] = {ext["name"]: {ext["name"]}
                            for ext in externs if ext.get("class") == "emission"}
    # A witnessed extern crosses the same boundary as an emission (item 243): it
    # seeds the fixed point too, so an unregistered witnessed reach is never
    # mistaken for revertible. Its capability is the declared scope (`fs`), or
    # its own name when unscoped — the same "the extern is the boundary" rule.
    for ext in externs:
        if ext.get("class") == "witnessed":
            caps[ext["name"]] = set(ext.get("capabilities") or [ext["name"]])
    calls: dict[str, set] = {}
    passed: dict[str, set] = {}  # first-class callable references per fn body
    for fn in fns:
        called: set = set()
        values: set = set()
        _calls_in(fn.get("body") or [], called, values=values)
        calls[fn["name"]] = called
        passed[fn["name"]] = values

    changed = True
    while changed:  # least fixed point over the call graph
        changed = False
        for name, called in calls.items():
            reached: set = set()
            for callee in called:
                reached |= caps.get(callee, set())
            # A first-class reference to an emitting callable: the function
            # *value* escapes this body and may be dispatched by whoever
            # receives it (an arrow-typed parameter, a stored binding), so
            # what it runs is not statically boundable here. `*` is
            # deliberately the capability no `emission[...]` list can name
            # (docs/capabilities.md), so the may-emit propagates through the
            # fixed point exactly like a real emission — a plain service
            # method whose body hands an emitting callable to a dispatcher is
            # refused by the same G4 check as one that calls the extern
            # directly. A dispatching helper that only ever receives pure
            # functions stays clean: nothing emitting is ever referenced as a
            # value on any path that reaches it. The concrete names travel
            # too (`reached |= caps[ref]`): `*` marks the dispatch as
            # unnameable for the declaration checks, while the G8 audit
            # surface still reports which boundaries the chain reaches.
            for ref in sorted(passed.get(name, ())):
                if caps.get(ref):
                    reached.add("*")
                    reached |= caps[ref]
                    if witness is not None:
                        witness.setdefault(name, ref)
            if reached and not reached <= caps.get(name, set()):
                if witness is not None and name not in caps:
                    # of the callees that prove the point, take the one with
                    # the shortest onward chain (ties by name): the author is
                    # asked to read the shortest derivation, deterministically.
                    # A body flagged only by the first-class-value edge has no
                    # emitting name-callee; its witness is already recorded.
                    culprits = sorted(c for c in called if caps.get(c))
                    if culprits:
                        witness[name] = min(
                            culprits,
                            key=lambda callee: _witness_depth(callee, witness))
                caps.setdefault(name, set()).update(reached)
                changed = True
    return caps


def _async_callables(fns: list, externs: list, witness: dict | None = None) -> set:
    """Names an `await` must be inserted for: `async` externs, and functions
    that reach one transitively through the static call graph.

    The async twin of `_emitting_fns` (docs/design/async-extern.md §3, "v2:
    transitive coloring through named `fn`s") — the same monotone closure over
    a finite name set, seeded from the async externs instead of the emission
    ones. A function is colored iff its body *calls* a colored callee; the
    fixed point closes over the static call graph exactly as the emission one
    does, so a `fn` calling a `fn` calling an async extern colors transitively.
    Recursion and mutual recursion terminate: a cycle either contains a
    seed-reaching member (all colored) or none.

    Unlike the emission fixpoint there is deliberately **no `*`/first-class
    widening**: an arrow type carries no color, so a function *value* cannot
    smuggle the async color, and assuming-async would force the emitter to
    `await` in a maybe-sync context, which is not writable. Such value-position
    references are refused at their use site (lower.py), never folded in here.

    `witness` (optional, filled in place) records why each derived name is
    colored: `witness[caller] = callee`, the callee with the shortest onward
    chain first (ties by name), mirroring `_emitting_capabilities` so the
    author reads the shortest derivation deterministically. The graph is
    acyclic by construction — an edge is only ever written for a name that was
    not yet colored, pointing at one that already was."""
    colored: set = {ext["name"] for ext in externs if ext.get("async")}
    calls: dict[str, set] = {}
    async_params: dict[str, set] = {}
    for fn in fns:
        called: set = set()
        # A body constructing an async arrow is not colored by the arrow's
        # internals — the arrow is a value awaited elsewhere (item 92 §3).
        _calls_in(fn.get("body") or [], called, stop_async_arrows=True)
        calls[fn["name"]] = called
        # rule 2 (item 92 §3): a parameter whose declared type is an async
        # function type. A fn that *calls* such a parameter is colored — a
        # declaration-shaped seed, computed once, no new iteration dynamics.
        async_params[fn["name"]] = {
            p["name"] for p in (fn.get("params") or [])
            if _is_async_fn_type(p.get("type"))
        }

    changed = True
    while changed:  # least fixed point over the call graph
        changed = False
        for name, called in calls.items():
            if name in colored:
                continue
            reached = sorted(c for c in called if c in colored)
            calls_async_param = sorted(called & async_params.get(name, set()))
            if reached or calls_async_param:
                colored.add(name)
                if witness is not None:
                    if reached:
                        witness[name] = min(
                            reached, key=lambda c: _witness_depth(c, witness))
                    else:
                        # a one-hop, self-evident witness: no named callee is
                        # colored, the seed is the fn's own async-typed param.
                        witness[name] = calls_async_param[0]
                changed = True
    return colored


def _capability_hint(service: str, method: str, declared, extra: list[str]) -> str:
    """The repair for a provider that exceeds its declared capability set."""
    nameable = [cap for cap in extra if cap != "*"]
    if not nameable:  # nothing to widen *to* — the boundary has no name
        return (f"only a named boundary can be granted — give the emission a "
                f"capability (a required key or an `emission` extern) or declare "
                f"`emission fn {method}(...)` without a scope in service "
                f"`{service}` (G4)")
    widened = list(declared) + [cap for cap in nameable if cap not in declared]
    return (f"a capability-scoped emission bounds *where* a provider may cross "
            f"the boundary — widen the declaration to "
            f"`emission[{', '.join(widened)}] fn {method}(...)` in service "
            f"`{service}`, or route this emission through a declared "
            f"capability (G4)")


def _witness_depth(name: str, witness: dict) -> int:
    """Hops from `name` down to the emission that made it emitting. The
    witness graph is acyclic by construction — an entry is only ever written
    for a name that was *not* yet emitting, pointing at one that was — but
    the guard keeps a malformed map from hanging the compiler."""
    depth, seen = 0, {name}
    while name in witness:
        name = witness[name]
        if name in seen:
            break
        seen.add(name)
        depth += 1
    return depth


def _emission_chain(name: str, witness: dict) -> list[str]:
    """`name` followed to the emission it reaches, e.g.
    ["writeThrough", "audit_log", "audit_write"]."""
    chain, seen = [name], {name}
    while name in witness:
        name = witness[name]
        if name in seen:
            break
        seen.add(name)
        chain.append(name)
    return chain


class _EmissionEvidence:
    """The G4 fixed point's evidence: the witness edge behind each derived
    emitting name, plus enough of the declaration table to give every hop in
    a chain a source location.

    Deliberately a companion of `_emitting_fns` rather than a change to it:
    the set that decides the verdict stays exactly what it was."""

    def __init__(self, program: Program) -> None:
        self.witness: dict[str, str] = {}
        self._files = getattr(program, "decl_files", None) or {}
        self._fallback_file = program.filename
        self._decls: dict[str, object] = {}
        for decl in program.fn_decls:
            self._decls.setdefault(decl.name, decl)
        for decl in program.externs:
            self._decls.setdefault(decl.name, decl)
        self.emission_externs = {
            decl.name for decl in program.externs
            if decl.classification == "emission"
        }
        # async externs (roadmap item 80): name -> decl, for the v1 coloring
        # check to locate an async extern a body reaches (async-extern.md §3).
        # item 388: a poly extern (`fn|async`) is pre-seeded as the async form
        # here too, so an awaited call site resolves during lowering and an A1
        # diagnostic names it as an "extern" (the ordering wrinkle, design
        # §"honest hard part" #3). Its sync clone is split off with the async
        # membership cleared in the post-pass.
        self.async_externs = {
            decl.name: decl for decl in program.externs
            if getattr(decl, "async_", False) or getattr(decl, "colour_poly", False)
        }

    def locate(self, decl) -> tuple[str | None, int | None]:
        if decl is None:
            return (None, None)
        return (self._files.get(id(decl)) or self._fallback_file or None,
                getattr(decl, "line", None))

    def capabilities_of(self, name: str) -> tuple:
        """Which capabilities `name`'s emission reaches.

        Empty today: G4's `emitting_fns` is a plain set, so "emission" is all
        the analysis knows. This is the single seam for the capability-set
        work — the moment a declaration carries a `capabilities` attribute
        every why-trace starts showing it, in the rendering and in the JSON
        alike, with no other edit (see `TraceStep.capabilities`)."""
        return tuple(getattr(self._decls.get(name), "capabilities", ()) or ())

    def step_for(self, name: str, last: bool) -> TraceStep:
        decl = self._decls.get(name)
        file, line = self.locate(decl)
        emission = last or name in self.emission_externs
        return TraceStep(name, "emission" if emission else "call", file, line,
                         "emission" if emission else None,
                         self.capabilities_of(name))

    def chain_steps(self, name: str) -> list[TraceStep]:
        chain = _emission_chain(name, self.witness)
        return [self.step_for(hop, index == len(chain) - 1)
                for index, hop in enumerate(chain)]


def _method_emissions(body: list, env: "Env",
                      steps_out: dict | None = None) -> tuple[list[str], set]:
    """What calling a provide-method irreversibly causes: `emit` steps and
    reachable emitting functions/externs. Teardown-position emissions count
    — calling the method schedules them.

    Returns `(evidence, capabilities)`: the human-readable call sites, and the
    *set* of boundaries they cross (docs/capabilities.md). A call through a
    required key `db` is capability `db` — the key is composition-wide (G2
    makes it unique), so it names the same boundary to every reader; host code
    is named by the `emission` extern it reaches.

    `steps_out` (optional, filled in place) maps each returned label to the
    derivation behind it: a list of `TraceStep`s running from the callee the
    method names down to the emission it reaches. Additive out-parameter for
    the same reason `_emitting_fns` takes one — the labels, and so the
    message, are byte-identical whether or not evidence is collected."""
    found: list[str] = []
    seen: set = set()
    caps: set = set()

    def note(label: str, steps: list | None = None) -> None:
        if label not in seen:
            seen.add(label)
            found.append(label)
            if steps_out is not None and steps is not None:
                steps_out[label] = steps

    def service_emission_step(local: str | None, method: str | None) -> list:
        """The terminal step for `local.method`, an `emission fn` on the
        service bound to `local`."""
        service = env.services.get(env.requires.get(local) or "")
        decl = service.methods.get(method) if service is not None else None
        evidence = getattr(env, "emission_evidence", None)
        # a MethodDecl has a line but no file of its own; its service does
        file, _ = evidence.locate(service) if evidence is not None else (None, None)
        line = getattr(decl, "line", None)
        label = f"{local}.{method}"
        detail = "emission" if service is None else f"emission `{service.name}.{method}`"
        # same seam as `_EmissionEvidence.capabilities_of`, for the service
        # side: whatever the operation declares it may reach, the trace shows
        capabilities = tuple(getattr(decl, "capabilities", ()) or ())
        return [TraceStep(label, "emission", file, line, detail, capabilities)]

    def crossing_caps(local: str | None, method: str | None) -> set:
        """The capability set a `req` seam crossing through `local.method`
        contributes. Ordinarily the require KEY name (the composition-wide
        wiring key naming this boundary). Under item 296 alias token carry-over,
        an aliased require declared `carrying(...)` contributes the
        consumer-facing tokens it stands in for instead, so an adapter's body
        `emit backing.get(...)` computes the consumer's declared reach rather
        than the internal alias key.

        SAFETY (item 296, the load-bearing invariant): the carry must not let a
        real emission escape the consumer's declared reach. So the carry is
        honored only when it faithfully covers the candidate method's DECLARED
        reach: if the candidate is a bare/unbounded emission, or reaches more
        distinct boundaries than the carry names (at least one candidate
        boundary would vanish through the alias), the crossing also contributes
        `*` - the unnameable boundary no `emission[...]` list can name - so the
        LOCAL G4 bound refuses the launder rather than passing it. This keeps
        every fold seeing the candidate's real emission through the alias."""
        carry_map = getattr(env, "require_carry", None) or {}
        carried = carry_map.get(local) if local is not None else None
        if not carried:
            return {local}
        service = env.services.get(env.requires.get(local) or "")
        decl = service.methods.get(method) if service is not None else None
        cand_caps = getattr(decl, "capabilities", None) if decl is not None else None
        result = set(carried)
        if decl is None or cand_caps is None:
            # unknown, or a bare/unbounded candidate emission: a finite carry
            # cannot bound it - refuse via the unnameable boundary.
            result.add("*")
        elif len(set(cand_caps)) > len(set(carried)):
            # the carry names fewer boundaries than the candidate declares:
            # at least one real boundary would be hidden through the alias.
            result.add("*")
        return result

    def walk(node):
        if isinstance(node, dict):
            if node.get("step") == "emit":
                expr = node.get("expr") or {}
                target = expr.get("target") or {}
                if target.get("kind") == "req":
                    note(f"{target.get('name')}.{expr.get('method')}",
                         service_emission_step(target.get("name"), expr.get("method")))
                    caps.update(crossing_caps(target.get("name"), expr.get("method")))
                else:
                    note("a host emission")
                    # every host emission reaches a named `emission` extern
                    # (`_is_emission_call` admits nothing else); `*` is the
                    # unreachable-in-practice fallback, and it is deliberately
                    # a capability no `emission[...]` list can name, so an
                    # unnameable boundary fails the bound rather than passing it
                    reached: set = set()
                    _calls_in(expr, reached)
                    if not reached & env.emitting_fns:
                        caps.add("*")
            # an emission may also appear in value position (`let r = emit …`)
            target = node.get("target")
            if node.get("kind") == "call" and isinstance(target, dict) \
                    and target.get("kind") == "req":
                service = env.services.get(env.requires.get(target.get("name")) or "")
                decl = (service.methods.get(node.get("method"))
                        if service is not None else None)
                if decl is not None and decl.emission:
                    note(f"{target.get('name')}.{node.get('method')}",
                         service_emission_step(target.get("name"), node.get("method")))
                    caps.update(crossing_caps(target.get("name"), node.get("method")))
            calls: set = set()
            values: set = set()
            _calls_in(node, calls, values=values)
            for name in sorted(calls & env.emitting_fns):
                evidence = getattr(env, "emission_evidence", None)
                note(f"{name}()",
                     evidence.chain_steps(name) if evidence is not None else None)
                caps.update(env.emitting_caps.get(name) or {"*"})
            # a first-class reference to an emitting callable: the value may
            # be dispatched by whoever receives it (an arrow-typed parameter,
            # a stored binding), so the method reaches code no bound can
            # name — same verdict as calling it, one indirection later
            for name in sorted(values & env.emitting_fns):
                evidence = getattr(env, "emission_evidence", None)
                note(f"{name} (passed as a function value)",
                     evidence.chain_steps(name) if evidence is not None else None)
                caps.update(env.emitting_caps.get(name) or set())
                caps.add("*")
            for value in node.values():
                walk(value)
        elif isinstance(node, list):
            for value in node:
                walk(value)

    walk(body)
    return found, caps
