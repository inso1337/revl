"""The operator E-Stop's shared vocabulary — roadmap item 443.

`docs/design/443-estop.md` is the reasoning of record. This module holds the
three things that must read IDENTICALLY everywhere the halt is observed, so
the CLI (`revl estop`), the multi-process conductor (`revl run --placement`)
and the py runtime (`backends/python/runtime.py`) cannot drift apart on them:

  * where the latch file is (`latch_path`);
  * what an armed latch means, including a malformed one (`read_latch`);
  * which tiers actually HONOR the latch (`TIERS_WITH_ESTOP`).

The third is the honest half. The tiers that still have no E-Stop seam keep
their cooperative teardown, and a conductor that halted a placement without
saying which of its processes were merely KILLED would be reporting a stop it
did not perform.
"""

from __future__ import annotations

import json
import os

#: The ambient latch path, equivalent to `--estop-latch FILE`.
LATCH_ENV = "REVL_ESTOP_LATCH"

#: The tiers whose runtime checks the latch at every boundary-crossing seam:
#: the py reference tier (item 443), and the go and rust tiers (issue #122),
#: whose placement runners now read the latch, refuse a new crossing at the
#: accept seam, record what is in flight, and — via an idle watcher — print
#: their inventory and die where they stand rather than being SIGKILLed.
#: A component on any OTHER tier (java, wasm, and — until #598 lands — node)
#: keeps its cooperative teardown and has no E-Stop: the only halt available
#: for it is a SIGKILL, which unwinds nothing and leaves its residue UNKNOWN.
#: That is honest and visible rather than a silently degraded halt, and
#: `_estop_halt_report` names every such component individually
#: (docs/design/443-estop.md, "Per-tier status").
TIERS_WITH_ESTOP = frozenset({"py", "go", "rust"})

#: What the py runner prints when the latch trips: its own in-flight
#: inventory, on one line, so the conductor can merge it into the halt report
#: without a second channel.
HALTED_LINE = "HALTED"


def latch_path(latch: str | None = None, wal: str | None = None,
               env: bool = True) -> str | None:
    """The latch file to act on: `--latch`, else `<wal>.estop`, else the
    ambient `REVL_ESTOP_LATCH`.

    Deriving it from the WAL is not a convenience: the WAL is the durable
    rendezvous the reconciliation path already uses (`revl recover --wal`), so
    a halt and its reconciliation name the same session with one argument."""
    if latch:
        return latch
    if wal:
        return f"{wal}.estop"
    if env:
        return os.environ.get(LATCH_ENV) or None
    return None


def read_latch(path: str | None) -> dict | None:
    """The halt an operator armed at `path`, or None when the latch is absent.

    A latch that exists but does not parse still reads as HALTED. Failing open
    on a malformed emergency stop is the one failure mode this feature exists
    to prevent, so every reader — the runtime seam, the CLI and the conductor —
    applies this same rule. The same reasoning covers a latch we cannot READ:
    an EACCES on a latch whose permissions changed, or an EISDIR on a path an
    operator turned into a directory, is an existing-but-unreadable latch, not
    an absent one, so it too reads as HALTED. Only a genuinely absent latch
    (`FileNotFoundError`) reads as not-halted; every other `OSError` fails
    CLOSED, because an operator halt no reader can inspect must never be
    mistaken for the absence of a halt."""
    if not path:
        return None
    try:
        with open(path, encoding="utf-8") as handle:
            record = json.load(handle)
    except FileNotFoundError:
        return None
    except OSError:
        return _unreadable()
    except (ValueError, TypeError):
        return _unreadable()
    return record if isinstance(record, dict) else _unreadable()


def _unreadable() -> dict:
    return {"halted": True, "reason": "operator halt (unreadable latch)",
            "operator": "unknown"}
