"""Recursive-descent parser for revl v0.

Grammar (v0 subset — see DESIGN.md §3):

    program    := (service | component)*
    service    := 'service' IDENT '{' methoddecl* '}'
    methoddecl := modifier* 'fn' IDENT '(' [tparam (',' tparam)*] ')' ['->' type]
    modifier   := 'emission' ['[' IDENT (',' IDENT)* ']'] | 'async' | 'commutative' | 'idempotent'
    tparam     := IDENT ':' type
    type       := IDENT ['[' type (',' type)* ']']
    component  := 'component' IDENT ['requires' binds] ['provides' binds] '{' body '}'
    binds      := IDENT ':' IDENT (',' IDENT ':' IDENT)*
    body       := (configdecl | stmt)*
    configdecl := 'config' '{' cfield (',' cfield)* [','] '}'
    stmt       := 'let' IDENT '=' effectform | effectform | 'emit' expr | provide
    effectform := 'effect' expr 'undo' expr          # G4: undo is not optional
    provide    := 'provide' IDENT '{' pmethod* '}'
    pmethod    := 'fn' IDENT '(' [IDENT (',' IDENT)*] ')' ('=' expr | '{' mstmt* '}')
    mstmt      := effectform | 'emit' expr | 'return' expr
    expr       := postfix
    postfix    := primary ('.' IDENT ['(' [expr (',' expr)*] ')'])*
    primary    := IDENT | INT | STRING | 'true' | 'false' | 'null'
"""

from __future__ import annotations

from dataclasses import dataclass, field

import contextlib
import re
import sys

from .errors import RevlError
from .lexer import Token, lex


# --------------------------------------------------------- recursion bounds
#
# The parser is recursive descent and the precedence ladder alone (`_ternary`
# -> `_or` -> ... -> `_primary`) costs roughly two dozen python frames for
# every nested `(`. Against CPython's default 1000-frame limit that put the
# ceiling at THIRTY-EIGHT nested parentheses and forty nested calls (issue
# #310) — well inside what generated code writes, and reached as a
# `RecursionError` traceback rather than a diagnostic. In `revl.gate`, a
# library with a security contract, that is an input that makes the admission
# gate raise instead of answering.
#
# Two things fix it, and both are needed. `NESTING_LIMIT` is the LANGUAGE's
# answer: a stated bound, refused with a diagnostic that names it, so a
# hostile input costs bounded work and gets an honest no. The headroom is the
# IMPLEMENTATION's: python's own limit must sit far enough above the stated
# bound that the bound — not the interpreter — is what a program meets, and it
# must cover the walkers in lower.py and typecheck.py that later descend the
# same accepted tree.
NESTING_LIMIT = 200

# Realm labels become part of capability addresses on some backends. Keep the
# address grammar deliberately narrower than a general string literal so labels
# cannot introduce namespace or target-language syntax.
_REALM_LABEL_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]*\Z")

# ~27 parser frames per level, and the deepest post-parse walker is shallower
# than that, so this clears `NESTING_LIMIT` with room to spare while staying
# far below anything that would trouble the C stack.
_RECURSION_HEADROOM = 12000


@contextlib.contextmanager
def recursion_headroom(frames: int = _RECURSION_HEADROOM):
    """Raise python's recursion limit for the duration of a compile.

    Restores whatever the embedder had set, and never LOWERS it: a host that
    already asked for more keeps it.
    """
    previous = sys.getrecursionlimit()
    if previous >= frames:
        yield
        return
    sys.setrecursionlimit(frames)
    try:
        yield
    finally:
        sys.setrecursionlimit(previous)


# ---------------------------------------------------------------- AST

@dataclass
class MethodDecl:
    name: str
    params: list[tuple[str, str]]  # (name, type)
    returns: str | None
    emission: bool
    line: int
    async_: bool = False       # `async fn` service operation (§5)
    commutative: bool = False  # Def. 39 order-independence opt-in
    # delivery semantics (docs/delivery-semantics.md, roadmap item 44): the
    # emission may be safely re-delivered — `f(f(x)) == f(x)` on the server.
    # Only an `emission` may claim it; it is the sibling of `commutative` (an
    # algebraic property of the operation) and the precondition for the
    # runtime's auto-retry right.
    idempotent: bool = False
    # capability-scoped emission (docs/capabilities.md): `emission[db, log]`
    # bounds *where* a provider may emit. `None` is bare `emission` — "any
    # capability" — which is what every pre-capability source means, so
    # existing programs keep their meaning.
    capabilities: tuple[str, ...] | None = None
    # taint declassification slot (roadmap item 249, Slice C): the origins a
    # provider of this operation may `endorse[<origin>]` in its body. Declared on
    # the service operation because a provide method is a plain `fn` that inherits
    # its authority (emission-ness, and now declassification rights) from the
    # service declaration. Empty unless the operation declares an endorse slot.
    endorse_origins: frozenset = field(default_factory=frozenset)
    # item 310: the `cache` trailing clause on a service method — the interface
    # contract every provider of the method inherits, so audit attributes the
    # cache to the seam. `None` unless the method declares one, so every existing
    # method's IR is byte-identical (docs/design/310-capability-aware-caching.md).
    cache: "CacheClause | None" = None
    # item 257: the `validated` modifier on an `emission` operation: opt into
    # boundary validation of the completion against a schema derived from the
    # return type (docs/design/257-typed-model-boundary.md). Off by default, so
    # every existing emission's IR is byte-identical; emission-only and
    # non-`Unit`-returning, checked in lower next to the sibling modifier rules.
    validated: bool = False
    # item 257 (Slice 2): the `retry N` validation-retry budget (§5.2), attempts
    # BEYOND the first, on a `validated` emission whose response is malformed. `0`
    # means the clause is absent (one attempt, a validation fault is terminal), so
    # every existing method's IR is byte-identical; `retry N` sets it to a positive
    # literal. Legal only alongside `validated` (there is no validation fault to
    # retry without it), checked in lower next to the sibling modifier rules.
    retry: int = 0


@dataclass
class ServiceDecl:
    name: str
    methods: dict[str, MethodDecl]
    line: int
    commutative: bool = False  # service-wide order-independence opt-in


@dataclass
class CacheClause:
    """A `cache` trailing clause on a `fn`, extern, or service-method declaration
    (roadmap item 310, docs/design/310-capability-aware-caching.md).

    `cache (pure|capability|external) (invalidated_by <tok> (, <tok>)*)? (ttl <dur>)?`
    trails the return type. `cache` is a CONTEXTUAL keyword recognised only in
    this post-return-type slot (the discipline `witnessed`/`deferred`/`confined`
    use), so the lexer's KEYWORDS set is untouched and no program using `cache`
    as an ordinary name (a provided KEY, a require alias — examples/handoff_cache.rvl)
    is broken. `cls` is the source spelling (`pure`/`capability`/`external`),
    lowered to the IR vocabulary (`pure_fn`/`capability_result`/`external_effect`).
    `invalidated_by` is the shared dotted capability namespace (`_capability_token`);
    `ttl_ms` reuses `policy._parse_ttl`'s duration value (bare number = seconds),
    `None` when no `ttl` clause is written. The per-class freshness rules
    (external requires a bound, pure forbids one) and the applicability fold are
    checked in lower, not the parser."""
    cls: str
    invalidated_by: tuple[str, ...]
    ttl_ms: int | None
    line: int


@dataclass
class ConfigField:
    name: str
    type: str
    default: object
    line: int
    # item 256 Slice 3: set by `taint.extract_and_normalize` when the author
    # declared the field `Secret[T]`. The qualifier is stripped off `type` there
    # (so the base checker and every emitter see a bare type, exactly as for a
    # parameter), and this flag is what survives into the IR — the only channel
    # by which the runtime learns the field must not be externalised.
    secret: bool = False
    # item 350: the declared ADMISSION BOUND on a host-injected environment
    # value, legal only inside a `boot component`'s config block (the
    # environment contract). `None` everywhere else, so every existing config
    # field lowers byte-identically. Two shapes:
    #   {"kind": "under", "prefix": <str>}  -- a Str path confined to a prefix
    #   {"kind": "in", "values": [<lit>, ...]} -- an enumerated admissible set
    # The bound is checked at ADMISSION against the value the host injects, so
    # an environment-supplied path or provider identity cannot silently widen
    # what the composition reaches at run time (docs/environment-binding.md).
    bound: dict | None = None


@dataclass
class PostfixOp:
    name: str
    args: list | None  # None = field access, list = call
    line: int


@dataclass
class Postfix:
    head: str
    ops: list[PostfixOp]
    line: int


@dataclass
class Lit:
    value: object
    line: int


@dataclass
class Interp:
    parts: list[tuple[str, str]]
    line: int


@dataclass
class LetEffect:
    bind: str
    acquire: object
    undo: object
    line: int
    setup: list = field(default_factory=list)
    verified: bool = False
    # item 131: the surface carried `effect await …` — the acquisition suspends
    # a fiber and its landed result (not the in-flight value) is bound. The
    # admission pass (lower.py) proves the acquire actually reaches a suspension
    # source; the emitters prefix the acquisition with the tier's await marker.
    is_async: bool = False
    # item 130: the surface spelled `subscribe <stream> undo <close>`. A
    # subscription IS an acquisition (an `effect`-position bracket), spelled its
    # own way so the checker can carry the state-indexed `Stream[T, Active]` type
    # and the single-consumer/admission rules (docs/design/130-...md §3). The
    # `acquire` field holds a `SubscribeExpr`; the bracket lowers exactly like an
    # effect (a `let-effect` step carrying `subscribe: true`).
    subscribe: bool = False


@dataclass
class StreamMergeExpr:
    """`merge(a, b)` — the multi-source fan-in a `subscribe` may acquire
    (item 130 Slice 3, docs/design/130-stream-reactive-types.md §1).

    One consumer, two sources. The merged stream is a DERIVED stream owned by
    the subscription, not a bracket of its own: the subscription's `close`
    closes it, and closing it detaches it from both sources — which are left to
    their own brackets. So multi-source teardown is still the ONE LIFO stack
    Slice 1 proved, and there is no path where a source keeps feeding, or
    holding a reference to, a fan-in whose owner is gone.

    Parsed in the `subscribe` head, exactly as Slice 2 parses its combinator
    chain as `StreamStage`s and for the same reason: a `<src>.merge(..)` method
    spelling would grow the shared host-verb namespace docs/stdlib-2.0.md
    promises is disjoint from the value-method table. A fan-in composes with
    that chain — `subscribe merge(a, b).map(f)` — because a merged stream is
    itself a stream."""
    sources: list
    line: int


@dataclass
class StreamStage:
    """One link of a derived-stream combinator chain (item 130 Slice 2,
    docs/design/130-stream-reactive-types.md §1).

    `map(f)` / `filter(p)` / `take(n)` are *derived streams*: each wraps the
    stream to its left, and the derived subscription's `close` closes its
    upstream link, so the whole chain tears down on the ONE bracket the
    `subscribe` registers (teardown stays one LIFO stack, §1).

    Deliberately NOT a method call. Lowering a combinator as `src.map(…)` would
    put `map`/`filter`/`take` into the shared HOST-VERB namespace, which
    docs/stdlib-2.0.md promises is disjoint from the value-method table (`map`
    and `filter` are value methods there) — the invariant pinned in
    tests/test_map_value_type.py. A chain parsed here, in the one position where
    `subscribe` already controls the grammar, adds zero host verbs."""
    kind: str          # "map" | "filter" | "take"
    arg: object        # an arrow (map/filter) or a positive Int literal (take)
    line: int


@dataclass
class SubscribeExpr:
    """`subscribe <stream>[.<combinator>…] [policy P] [buffer N] [drain <dur>]`
    — the acquisition head of a subscription bracket (item 130,
    docs/design/130-stream-reactive-types.md §1).

    `stream` is the expression naming the `Stream[T]` capability (a required
    stream binding, or a host-acquired stream source on the reference tier);
    `stages` is the derived-stream combinator chain applied to it (Slice 2).

    The subscription is single-consumer with a BOUNDED buffer whose capacity
    (`buffer`) and overflow `policy` are declared here — there are no unbounded
    buffers (§4.4). `policy` defaults to `error` (a full buffer faults the
    subscription with `Faulted(overflow)` and closes; the safe default, no silent
    loss); `drop_newest`/`drop_oldest` are the explicit lossy opt-ins, and
    `block` suspends the provider (the `Paused` state index) until the consumer
    drains. `drain_ms` is the `block`-policy drain window — the time-windowed
    buffering that fires on the deterministic test clock's `advance` (§8);
    `None` means resume the instant the consumer drains."""
    stream: object
    policy: str
    line: int
    stages: list = field(default_factory=list)
    buffer: object = None      # int capacity, or None for the runtime default
    drain_ms: object = None    # int ms (block policy only), or None


@dataclass
class StreamIterStmt:
    """`every <x> in <sub> { <emit>* }` — the async-iteration form of item 130
    Slice 4 (docs/design/130-stream-reactive-types.md §1, §4.7).

    One consumer pulls the subscription to its terminal: each iteration awaits
    `<sub>.next()`, binds the delivered item to `<x>`, and runs the body; a
    `Closed` terminal (an orderly provider close, the owner's own `close`
    tripping the cancel token, or a `take(n)` running out) ENDS the loop, and a
    `Faulted` terminal raises out of it so the activation fails and the
    accumulated prefix — subscription bracket included — reverts LIFO (A8).

    The body is a setup-mode effect context (§4.7): its emissions are
    capability-checked against the consumer's row (G1) and enumerable on its
    boundary (G8), exactly as an activation-body `emit` is, because that is what
    they are. What the body may NOT do is ACQUIRE: an `effect … undo …` inside
    the loop pushes one bracket per item onto the owner's single LIFO
    accumulator, which is unbounded in the length of the stream, and the
    per-iteration discharge that would bound it does not exist. The refusal is
    the parser's (see `_iteration_body`), and it names the fix.

    `bind` is the item name; `subject` names the subscription (a bare
    identifier — a `Subscription` is a host-local with no nominal type, so it
    can be spelled no other way).

    `event` is Slice 5 (§6): the typed-event handler `on <Event> as <x> in <sub>
    { … }` parses to THIS node with the event's name recorded, because an event
    IS a stream item with a contract and its handler IS this iteration. One node
    and one lowering means the two forms cannot drift apart on the properties
    that carry the guarantee — the iteration boundary and the uncaught
    `Faulted` — which is the whole reason §6 makes events a specialization
    rather than a second surface. `None` for a plain `every … in`, so a Slice 4
    program lowers byte-identically."""
    bind: str
    subject: object
    body: list
    line: int
    event: str | None = None


@dataclass
class EventDecl:
    """`event <Name>(key: <field>[, window: <n>]) { <fields> }` — a typed
    external event (item 130 Slice 5,
    docs/design/130-stream-reactive-types.md §6).

    An event is a `Stream[T]` element with a CONTRACT, not a second reactive
    surface (§6): the declaration produces an ordinary record type (carried as a
    sibling `TypeDecl`, so every record rule — field types, literals, field
    reads — applies to it unchanged) plus the two things events add on top of a
    stream, and nothing else.

    * `key` names the field carrying the event's IDENTITY, the value a duplicate
      delivery repeats. It is item 309's keyed-idempotency role in the one place
      a consumer can act on it, spelled the way 309 spells it (`(key: <field>)`,
      the `confined:` precedent); it must name a declared field of scalar-
      serializable type, and it is REQUIRED — an event with no key can deliver
      neither of the obligations §6 lists for it (handler idempotency, duplicate
      handling), and admitting one would ship those two rows as a claim nothing
      backs.
    * `window` bounds the dedup memory: the handler remembers the last N keys it
      admitted, so redelivery inside the window is collapsed. Bounded by
      construction and constant per handler — NOT one entry per delivered item,
      which is the unbounded shape §4.7 refuses. `None` takes the runtime
      default.

    `event` is a CONTEXTUAL keyword (the `boot`/`fault`/`secret` discipline): it
    heads a declaration only as `event <IDENT> (`, so the corpus's existing
    `fn log(event: Str)` parameters keep parsing and neither the lexer's
    KEYWORDS set nor the self-hosted lexer needs a sync."""
    name: str
    key: str
    window: object          # int, or None for the runtime default
    fields: list
    line: int


# item 130: the state index of `Stream[T, State]`. `subscribe` yields `Active`;
# `close` yields `Closed`; `Paused` is the `block`-policy backpressure state
# (Slice 2, §4.4); `Created` is the pre-subscribe state
# (docs/design/130-stream-reactive-types.md §1).
_STREAM_STATES = frozenset({"Created", "Active", "Paused", "Closed"})

# item 130 §1: the v1 pure combinators. `merge` is Slice 3 (multi-source
# teardown ordering); it is deliberately absent so the refusal names it.
_STREAM_COMBINATORS = ("map", "filter", "take")

# item 130 §4.4: the declared overflow policies of a subscription's bounded
# buffer. `error` is the default — deterministic, no silent loss.
_STREAM_POLICIES = ("error", "drop_newest", "drop_oldest", "block")


@dataclass
class EffectStmt:
    acquire: object
    undo: object
    line: int
    setup: list = field(default_factory=list)
    verified: bool = False
    # item 131: the surface carried `effect await …` (see LetEffect.is_async).
    is_async: bool = False


@dataclass
class LeaseAcquire:
    """The acquisition head of `effect lease <cap> [ttl <dur>] [uses <n>]` (item
    294 Slice 2, docs/design/294-parameterized-capabilities.md).

    Not an ordinary `acquire` expression: a lease acquisition is a class-(c)-
    GATED, ticket-mediated mint of a standing grant over `capability`'s cone,
    bounded by `ttl_ms` and/or `uses`. It rides the same `effect … undo …`
    stratum (the undo is `l.revoke()`, riding the LIFO teardown) but lowers to a
    reserved runtime acquisition, so it travels as this dedicated node rather
    than as a call the emitter would treat as a host body. `capability` is the
    canonical `(T, P)` spelling `cap_order` produces (a bare or parameterized
    token). At least one of `ttl_ms`/`uses` bounds the grant; an unbounded lease
    is refused at parse (consent stays bounded, the item-344 rule)."""

    capability: str
    ttl_ms: object            # int milliseconds, or None
    uses: object              # int count, or None
    line: int


@dataclass
class TimerStmt:
    """`every <n><unit> { <emit>* }` / `after <n><unit> { <emit>* }` — a timer
    (docs/time-coeffect.md, roadmap item 57).

    A timer is a **revertible schedule**: acquiring it registers work with the
    clock coeffect, and its inverse is cancellation, so unloading the component
    (or its enclosing frame) provably cancels its timers — no orphaned interval
    outlives the activation that armed it (the residue probe, item 18, would
    otherwise catch the leak). The body runs at activation-time stratum with
    the component's declared capabilities, so a firing cannot smuggle an
    emission past G4/G8; its reach is audited like any other component reach.

    `mode` is `"every"` (periodic) or `"after"` (one-shot delay); `interval_ms`
    is the resolved delay in milliseconds; `body` is the list of `EmitStmt`s
    the timer runs on each firing."""
    mode: str
    interval_ms: int
    body: list
    line: int


@dataclass
class FailStmt:
    message: object
    line: int


@dataclass
class EmitStmt:
    expr: object
    line: int
    compensate: object | None = None
    # item 246, Slice 2: the `with <e>` clause threading an `Approval[C]` value to
    # the crossing. `e` is a pure expression evaluating to a value of type
    # `Approval[C']`; the checker (lower._lower_provide) proves `C` is within
    # `C'`'s scope. None when the crossing carries no approval edge.
    approval: object | None = None
    # item 131: the surface carried `await emit …` — the emission crosses the
    # boundary through a suspending (async) operation and the step awaits it.
    # The boundary marker sits outermost (`await emit`, not `emit await`) because
    # the step is an iteration boundary whose payload is an emission (design §2).
    # Kept last so the positional `EmitStmt(expr, line, compensate, approval)`
    # construction is unchanged.
    is_async: bool = False


@dataclass
class EmitExpr:
    """`emit <call>` in value position — the value of an irreversible call.

    The marker still sits at the call site (G4's point); it no longer forces
    the value to be discarded, which an emission that *returns* data (an LLM
    completion, an HTTP GET) obviously needs."""
    expr: object
    line: int


@dataclass
class SpawnExpr:
    """`spawn <Component> [with { <field>: <expr>, ... }]` — instantiate a
    component at runtime (docs/design-v2-instances.md). Only legal as the
    acquisition of an effect binding: `let s = effect spawn C with {..} undo
    s.dispose()`. The instance is an acquisition whose inverse is its own
    teardown."""
    component: str
    config: dict  # field name -> expression AST (lowered in the spawner's scope)
    line: int


@dataclass
class AwaitStmt:
    expr: object
    line: int


@dataclass
class ApprovalExpr:
    """`await approval[C] { field: expr, ... }` — the only producer of a value of
    type `Approval[C]` (item 246, Decision 3). It suspends until the operator
    grants or refuses; the fields are the human's evidence, rendered in the prompt
    and carried into the ledger and the WAL. `Approval[C]` has no constructor, so
    an approval cannot be forged in-language."""
    capability: str          # the capability token C (e.g. "payment")
    fields: object           # [(name, exprAST), ...] the human's evidence
    line: int


@dataclass
class LetApprovalStmt:
    """`let a = await approval[C] { fields }` — bind an `Approval[C]` value in a
    component activation body (item 246). The suspension is acquisition-shaped,
    so it lives beside `let x = effect …` rather than in the plain-value stratum
    the activation body otherwise forbids."""
    bind: str
    request: ApprovalExpr
    line: int


@dataclass
class ReturnStmt:
    expr: object
    line: int


@dataclass
class IsolateStmt:
    key: str
    realm: str
    line: int


@dataclass
class RouteStmt:
    """`isolate <key> in realms("w1","w2","w3") strategy(round_robin)` — the
    multi-realm bind (roadmap item 162). The plural of `isolate <key> in
    realm(<name>)`: one required key is bound across N named realms, and an
    optional `strategy` names how the runtime router distributes across them.
    This is the CONSUMPTION side of the load-balancer pattern (item 161's
    Router consumes it); it records the binding + strategy for the runtime
    router and does not itself route. `strategy` is `None` when omitted."""
    key: str
    realms: list[str]
    strategy: str | None
    line: int


@dataclass
class InterceptStmt:
    key: str
    metadata: dict
    line: int


@dataclass
class HandoffStmt:
    """`handoff <key>: <Type>` — the verified state hand-off of a stateful
    provider (roadmap item 53, the `code_change` gap). `key` is a provided key
    of this component; `state_type` is the declared shape of the provider's
    live state (its effect-created world — a cache's Map, a session store's
    entries). When this component is *replaced*, that state is the value it
    **exports**; when it is the *replacement*, that type is the shape it
    **accepts**. The admission gate proves the two sides are §5-compatible
    before a swap threads the value across — a stateful provider starts warm,
    not cold. See docs/state-handoff.md."""
    key: str
    state_type: str
    line: int


@dataclass
class ProvideMethod:
    name: str
    params: list[str]
    body: list
    line: int
    async_: bool = False  # `async fn` provide-method declaration (§5)
    # optional per-param type annotations (parallel to `params`, None where
    # omitted): `fn query(sql: Str) = ...`. The service is the source of
    # truth (A6); an annotation, if present, is checked against it.
    param_types: list = field(default_factory=list)
    returns: str | None = None  # optional `-> T` annotation, checked vs service


@dataclass
class ProvideStmt:
    key: str
    methods: list[ProvideMethod]
    line: int


@dataclass
class ComponentDecl:
    name: str
    config: list[ConfigField]
    requires: list[tuple[str, str, int]]  # (local, service, line)
    provides: list[tuple[str, str, int]]  # (key, service, line)
    body: list
    line: int
    source: str = ""  # provenance: the file this component was parsed from
    # item 296: alias token carry-over. A require binding may declare the
    # capability tokens its emission crossings contribute (`requires backing:
    # VendorCache carrying(cache)`), so a crossing through the alias is
    # attributed to the consumer-facing tokens it stands in for, not the local
    # key name. Keyed by local (alias) name -> carried token tuple. Empty for
    # every require with no `carrying(...)` clause, so programs that do not use
    # the feature are byte-identical. This is a GENERAL wiring feature (a
    # hand-written wrapper uses it too, not an adapter special case).
    require_carry: dict = field(default_factory=dict)
    # item 350: the composition's BOOT component (`boot component X { ... }`) —
    # the one declared arrival point for host-injected environment values. Its
    # `config {}` block is the ENVIRONMENT CONTRACT: the exhaustive, typed list
    # of what the host must inject before the composition can boot. At most one
    # per composition. False for every ordinary component, so a composition that
    # declares no boot component is byte-identical through parse, IR and every
    # emitted tier (docs/environment-binding.md).
    boot: bool = False


# --- item 426 S1: composition rows (docs/design/426-composition-layers.md) --

@dataclass
class RowDecl:
    """One row of a composition: one component placed into one composition.

    `label` is IDENTITY (426 decision 1) — declared, stable, and scoped to the
    declaring document's origin. `claims` is the CONTRACT, asserted here and
    checked against the component header at resolution (§1.3). `component` is
    PROVENANCE and never identity (§1.5), so an upstream rename is a non-event.
    """
    label: str
    path: str                      # the `from "..."` source file
    claims: list[tuple[str, int]]  # asserted (key, line); empty == `nothing`
    line: int
    component: str | None = None   # optional disambiguator, provenance only
    config: list[tuple[str, object, int]] = field(default_factory=list)
    # item 424 R2 / 426 §9.3 Part 2: the per-row reach allowlist a confined row
    # may compose against. `None` == the clause was not written (an unconfined,
    # first-party row); a written clause defaults to EMPTY, never to "whatever
    # the row requires".
    granted: list[tuple[str, int]] | None = None


@dataclass
class RemoteRowDecl:
    """A `remote` row: a row whose provider is SYNTHESIZED from a service
    declaration plus a peer address (item 424 D-424c.1, slice C2).

    The wiring stays local — every consumer keeps `requires <key>: <Service>`
    and G2/G3/G4 are unchanged — so remoteness is an ADMISSION fact (a reach, a
    capability, a failure mode) and never a wiring fact. That is the rule
    `docs/interop-bridge.md` §3 already states for a seam ("manifest data, not
    source text"), applied to a callee that is in no manifest at all.

    `remote`, `at`, `host`, `through`, `on_failure` and `redirect` are
    CONTEXTUAL keywords,
    recognised only in this one position inside a `composition` block. The
    lexer's KEYWORDS set is untouched, so the self-host lexer needs no sync and
    no program using any of those words as an ordinary name is broken. `in` and
    `realm` are already keywords and are reused verbatim from `isolate`.
    """
    label: str
    key: str                       # the provision key the row claims
    service: str                   # the locally declared service being remoted
    host: str                      # the peer authority, `host("h:port")`
    line: int
    realm: str | None = None       # `in realm("...")`; None == the shared realm
    transport: str | None = None   # `through <ident>`; None == the default wire
    # D-424c.3: a transport failure is a WITHDRAWAL by default and a value by
    # opt-in. `"result"` is admitted only if every method returns `Result[T, E]`.
    # Silently swallowing a transport failure has no spelling.
    on_failure: str = "withdraw"
    on_failure_line: int = 0
    # `redirect(refuse | same_origin)`; `refuse` is the default and the only
    # value that needs no argument from the operator. The peer address above is
    # what a reader of this row is entitled to believe the crossing reaches, so
    # a transport that followed a `Location` to another host would make the row
    # false. `same_origin` is the declared opt-in and is still bounded: a 307 or
    # 308 on the declared origin, never a 301/302/303 (they re-issue the POST as
    # a GET and drop the body) and never another origin (every header on the
    # request, credentials included, would travel with it).
    redirect: str = "refuse"
    redirect_line: int = 0
    # The line the address itself is written on, so an address refusal points at
    # the address rather than at the row's first line.
    host_line: int = 0


@dataclass
class CompositionDecl:
    name: str
    rows: list[RowDecl]
    line: int
    uses: list[tuple[str, int]] = field(default_factory=list)
    source: str = ""  # provenance: the file this composition was parsed from
    # item 424 C2: rows whose provider is synthesized rather than read from a
    # file. Kept in their own list because they carry no `from` path and
    # resolution reads no header for them.
    remotes: list["RemoteRowDecl"] = field(default_factory=list)
    # item 426 S2 (§3.1): the ordered layer stack. `stack` entries are LEVEL 1
    # peers — conflicts between them refuse — and `site` is the single LEVEL 2
    # layer, the one level at which "I decide" is expressible. Both are ordered
    # lists in a file, which is what makes the fold reproducible (§3.3).
    stack: list[tuple[str, int]] = field(default_factory=list)
    site: tuple[str, int] | None = None


# --- item 426 S2: layers and the fold ---------------------------------------

@dataclass
class Address:
    """A patch address (426 §2.3). Two spellings, both exact, both refusing
    rather than no-opping (§2.4).

    `key("db")` follows the CONTRACT wherever it moved and refuses if the key
    moved rows; `acme_pg::@db` names one exact row and refuses if that row is
    gone. The choice is a choice about failure mode, and both are useful.
    """
    kind: str                 # "key" | "label"
    line: int
    key: str | None = None    # kind == "key"
    realm: str | None = None  # kind == "key"; None == the shared realm
    label: str | None = None  # kind == "label"
    origin: str | None = None # kind == "label"; None == the layer's own origin

    def spelling(self) -> str:
        """The address as the layer author wrote it, for every diagnostic."""
        if self.kind == "key":
            if self.realm is None:
                return f'key("{self.key}")'
            return f'key("{self.key}", realm: "{self.realm}")'
        return f"@{self.label}" if self.origin is None \
            else f"{self.origin}::@{self.label}"


@dataclass
class LayerOp:
    """One of the four operations (426 §3.2), plus the site layer's `resolve`.

    There is deliberately NO positional operation: load order is derived by Kahn
    over the wiring graph, not declared, so a position operation would invent a
    concept the gate does not have.
    """
    op: str                   # "add" | "remove" | "replace" | "configure" | "resolve"
    line: int
    address: Address | None = None
    row: RowDecl | None = None                    # add / replace
    config: list[tuple[str, object, int]] = field(default_factory=list)
    winner: Address | None = None                 # resolve
    loser: Address | None = None                  # resolve


@dataclass
class LayerDecl:
    """A patch document. `site` marks LEVEL 2 (the operator's, exactly one);
    otherwise it is a LEVEL 1 stack layer and its conflicts with a peer refuse.

    A layer document may contain ONLY layer operations (426 §6.1) — no
    `component`, no `service`, no `extern`, no top-level `fn`. Without that rule
    a layer is a component-authoring surface, which is the surface §4 exists to
    profile.
    """
    name: str
    target: str               # the composition this layer patches
    ops: list[LayerOp]
    line: int
    site: bool = False
    touches: list[Address] | None = None   # None == the clause was not written
    source: str = ""


# --- v2.0: types & pure functions (docs/syntax-2.0.md §2–§3) ----------------

@dataclass
class RecordField:
    name: str
    type: str
    line: int


@dataclass
class VariantCase:
    name: str
    payload: str | None
    line: int


@dataclass
class TypeDecl:
    name: str
    params: list[str]
    fields: list[RecordField]
    cases: list[VariantCase]
    line: int
    public: bool = False


@dataclass
class UseDecl:
    path: str
    names: list[str] | None  # None = module namespace import
    alias: str | None
    line: int


@dataclass
class HostBody:
    backend: str
    text: str
    line: int
    # item 396 option A: provenance when this body was SPLICED from an external
    # host-code file (`= @backend file "path"`). Both stay `None` for an inline
    # `@backend { ... }` body, so a program that uses no file form lowers to a
    # byte-identical IR. Set by the compiler's body-file resolver, which reads
    # the file under the jail and replaces the HostBodyFile node below with a
    # resolved HostBody carrying the spliced (normalized) text plus these:
    #   source_path — the root-relative path as written, for `revl audit`
    #   sha256      — sha256 of the RAW file bytes read, so two compiles of the
    #                 same tree are byte-comparable and `revl verify` can re-hash
    source_path: str | None = None
    sha256: str | None = None


@dataclass
class HostBodyFile:
    """item 396 option A: an extern body that references an external host-code
    file, `= @backend file "path"`. The parser is IO-free and records only this
    node; the compiler layer (`_ModuleLoader`) resolves and reads the file under
    the jail right after parse, then REPLACES this node with a resolved
    `HostBody`, so nothing downstream (lower, emit, audit) ever sees this shape.
    """
    backend: str
    path: str   # the path string exactly as written, resolved by the compiler
    line: int


@dataclass
class HostRef:
    """item 396 option B: an extern body that IMPORTS a host symbol from an
    external host MODULE, `= @backend ref sym from "path"`. Unlike a
    `HostBodyFile` (option A, a compile-time text splice), this is NOT replaced:
    the referenced file is a normal host module and the emitter generates a LAZY
    import THUNK that imports the symbol at the extern's FIRST CALL (never at
    module top — a module-top import would run host code at artifact LOAD,
    outside every classification/approval/witness gate).

    The parser is IO-free and records the symbol and the written path. The
    compiler's ref resolver (`hostref.resolve_refs`) checks the file EXISTS under
    the ROOT-tree jail, pins a content hash of its bytes, and records the
    root-relative path (the emitted import specifier is derived from it). The
    node then flows THROUGH lower into the additive `refs` IR key, so an extern
    that uses no ref lowers to a byte-identical IR.
    """
    backend: str
    symbol: str        # the host identifier imported from the referenced module
    path: str          # the path string exactly as written
    line: int
    # set by the compiler's ref resolver (hostref.resolve_refs):
    rel_path: str | None = None   # resolved path RELATIVE TO THE ROOT tree
    sha256: str | None = None     # sha256 of the resolved file's raw bytes
    # item 410: the ROOT KIND this ref resolved against. `"stdlib"` when the
    # DECLARING module is install-origin (resolved through the item-319 search
    # path or realpath-contained in `stdlib_root()`), so the ref jails to the
    # install tree and the runner picks the install root at deploy. `None`
    # (absent in the IR) for a user-origin ref — every existing ref IR stays
    # byte-identical.
    root_kind: str | None = None


@dataclass
class ExternDecl:
    name: str
    classification: str  # 'pure' | 'acquire' | 'emission' | 'witnessed'
    params: list[FnParam]
    returns: str | None
    undo: object | None
    compensate: object | None
    # item 396: a body element is a resolved inline `HostBody`; before the
    # compiler's body-file resolver runs, an unresolved `HostBodyFile` (option A,
    # replaced by a `HostBody`); or a `HostRef` (option B), which flows through
    # unchanged into the `refs` IR key.
    bodies: list["HostBody | HostBodyFile | HostRef"]
    public: bool
    line: int
    # capability scope of a boundary-crossing extern (docs/design/243-witnessed-externs.md):
    # `witnessed[fs]` bounds *where* the reversible mutation crosses, exactly as
    # `emission[db]` bounds an emission. Empty for the unscoped/inapplicable
    # classifications. Read by the emission analysis (same authority namespace)
    # and carried onto the IR node so the audit surface names the boundary.
    capabilities: tuple[str, ...] = ()
    # explicit type-parameter names from an `extern pure fn id[T](...)` list.
    # externs share the fn signature table, so the same machinery covers them.
    type_params: list[str] = field(default_factory=list)
    # `async` modifier between the classification and `fn` (roadmap item 80,
    # docs/design/async-extern.md §1). Name matches `ServiceMethod.async_`
    # (parser.py:42) and `ProvideMethod.async_` (parser.py:186). Validity
    # (emission-only, no compensate) is checked in lower, not the parser.
    async_: bool = False
    # `deferred` modifier between the classification and `fn` (roadmap item 245,
    # docs/design/245-session-commit.md, Decision 2). Sits in the same modifier
    # slot as `async`: `extern emission[mail] deferred fn send(...)`. A deferred
    # emission does not fire at the call site — it enqueues onto the session's
    # deferral queue and returns Unit; the session commit flushes it (or an abort
    # drops it). Validity (emission-only, Unit-returning, no compensate, not
    # async) is checked in lower, not the parser.
    deferred: bool = False
    # item 388: the caller-decided colour marker, spelled `fn|async` in the
    # `async`/`deferred` slot (`extern emission fn|async engine_run(...)`). A poly
    # extern fixes NO colour at its declaration: one authored host body serves a
    # sync `def`/`function` clone at a sync call site and an `async def`/`async
    # function` clone at an async call site, monomorphized per call-site colour
    # (the EXTERN analog of item 342's arrow monomorphization,
    # docs/design/388-caller-decided-extern-colour.md, option a). Validity
    # (emission-only, not `deferred`, not combined with a fixed `async`, no
    # `compensate`, and the per-backend `await`-keyword lint) is checked in lower,
    # not the parser. `False` for every extern, so a non-poly extern is
    # byte-identical.
    colour_poly: bool = False
    # item 246: the declaration-owned `requires approval` clause, for first-party
    # code that knows its boundary is sensitive: `extern emission[production.payment]
    # fn charge(...) requires approval`. A crossing that reaches this extern must
    # carry a covering `with e` edge or admission refuses at lowering, holding even
    # with no policy file (Decision 3, floor-and-acknowledgment).
    requires_approval: bool = False
    # item 373: the reach clause `emission(confined: <param>)`, sibling to the
    # `[caps]` capability scope. Where `[caps]` names the boundary TOKEN the
    # crossing joins, `reach` names what the crossing is BOUNDED to — the
    # confinement a reviewer needs to see. `None` is a bare emission (no reach,
    # "unconfined"), which keeps the IR byte-identical. Otherwise a
    # `(kind, target)` pair: `kind` is `"confined"` (the only reach kind today)
    # and `target` names the PARAMETER carrying the confinement region. Only an
    # `emission` extern may carry it, and the target must name a real parameter
    # (both checked in lower) — so a weakened reach (confined -> unconfined) is a
    # reviewable diff, not a buried host-body comment.
    reach: tuple[str, str] | None = None
    # item 379 / option (b) of docs/design/378-sync-extern-service-reach.md: a
    # typed `config { field: T = default, ... }` block, the same shape a
    # `ComponentDecl` carries (parser.py:284), letting a document-global extern
    # read STATIC configuration resolved once at plug time instead of ambient
    # env vars. Empty for every extern that declares no `config` clause, so
    # their parse/IR/goldens stay byte-identical.
    config: list[ConfigField] = field(default_factory=list)
    # item 309: `undo idempotent <inverse>(result)` — the inverse-side claim
    # that re-running the declared inverse a second time with the same bound
    # `result` leaves the world where the first run left it (`undo(undo(s)) =
    # undo(s)`). `False` unless the author wrote `idempotent` in the undo slot,
    # so every existing extern's IR is byte-identical. Reuses item-44's shipped
    # `idempotent` kw token (no lexer change) in a new position; carried onto the
    # IR + WAL discharge-descriptor so recovery reads the register in a fresh
    # process (docs/design/309-idempotent-inverse.md, §1a).
    undo_idempotent: bool = False
    # item 440: `undo pure <inverse>(result)` — the READ tier, the third value of
    # 309's re-dispatch register. It claims the declared inverse CHANGES NOTHING
    # (it observes, it does not mutate), so re-issuing it is observationally free
    # and needs neither an idempotency key nor a fence nor an operator. `pure` is
    # already a reserved keyword and an inverse fn named `pure` is impossible, so
    # accepting the kw token in the undo slot is unambiguous — the same argument
    # item 309 made for `idempotent` there. It is a DECLARATION, not a derivation:
    # revl's `pure` extern CLASSIFICATION means "not acquire/emission/witnessed",
    # not "read-only" (`extern pure fn close_ledger(h) = @py { ... }` is shipped
    # in docs/guide-ai-agents.md), so the classification alone cannot be trusted
    # to mean read. Lower checks the named inverse IS a `pure`-classified extern,
    # which anchors the claim to the existing classification without deriving the
    # read tier from it. `False` for every existing extern (byte-identical IR).
    undo_read: bool = False
    # item 309: bare `idempotent` in the extern modifier slot — item-44's
    # emission delivery claim extended from service methods to externs (the
    # author asserts the remote treats re-delivery as delivery). Emission-only,
    # combinable with `async`/`deferred`; checked in lower. `False` for every
    # existing extern.
    idempotent: bool = False
    # item 309: `idempotent(key: <param>)` — the by-construction claim, naming
    # WHICH declared parameter carries the idempotency key the remote dedups on
    # (a 373-style parameter role, NOT a 294 capability valuation — §1c). `None`
    # unless the keyed form was written; lower checks the parameter exists and is
    # scalar-serializable, and threads the value into the WAL descriptor.
    idempotency_key: str | None = None
    # item 310: the `cache` trailing clause on an extern. Grammar-legal from slice
    # 1, but admission-refused (the interior-crossing slice is unshipped): an
    # extern crossing is INTERIOR to a called body, where only the runtime sees the
    # args, so the seam gate cannot act pre-execution. `None` unless written, so
    # every existing extern's IR is byte-identical.
    cache: "CacheClause | None" = None
    # item 257: the `validated` modifier on an `emission` extern: the boundary
    # validates the completion against a schema derived from the return type
    # (docs/design/257-typed-model-boundary.md). Sits in the same modifier slot
    # as `async`/`deferred`/`idempotent`. `False` for every existing extern, so
    # their IR is byte-identical; emission-only and non-`Unit`-returning, checked
    # in lower next to the sibling modifier rules.
    validated: bool = False
    # item 257 (Slice 2): the `retry N` validation-retry budget (§5.2) on a
    # `validated` emission extern. `0` when the clause is absent (byte-identical
    # IR); `retry N` sets it to a positive literal. Legal only alongside
    # `validated`, checked in lower.
    retry: int = 0


@dataclass
class FnParam:
    name: str
    type: str
    line: int
    # optional default value (roadmap item 187): `fn f(a: Int, b: Int = 0)`.
    # A pure expression, evaluated at the call site when the argument is
    # omitted (call-site resolution — the emitters never see a defaulted
    # parameter, only a fully-supplied argument list). `None` for a parameter
    # without a default. Only `fn_decl` parses defaults; extern (`=` opens a
    # host body) and prop-test (generated inputs) parameter lists do not.
    default: object | None = None


@dataclass
class FnDecl:
    name: str
    params: list[FnParam]
    returns: str | None
    body: list
    public: bool
    line: int
    verified: bool = False
    source: str = ""  # provenance: the file this fn was parsed from
    # explicit type-parameter names from a `fn id[T](...)` list (roadmap item
    # 6). Empty for the implicit form. Fed into the same tparam machinery the
    # implicit single-uppercase heuristic uses; never reaches the IR.
    type_params: list[str] = field(default_factory=list)
    # taint declassification slot (roadmap item 249, Slice C): the origins this
    # fn is DECLARED to be allowed to `endorse[<origin>]` in its body. An
    # `endorse[o]` whose origin is not in this set is refused at admission, so a
    # downgrade must appear in the enclosing declaration — never ambient. Empty
    # for a fn that declares no endorse slot (byte-identical to before).
    endorse_origins: frozenset = field(default_factory=frozenset)
    # item 310: the `cache` trailing clause. Only `cache pure` is legal on a plain
    # `fn` (a plain fn whose reach crosses a boundary gets the mismatch refusal
    # pointing at the emission that should carry the declaration). `None` unless
    # written, so every existing fn's IR is byte-identical.
    cache: "CacheClause | None" = None


# pure-expression AST (§3.2 — the TS-subset stratum)

@dataclass
class ExprLit:
    value: object
    line: int


@dataclass
class ExprVar:
    name: str
    line: int


@dataclass
class ExprEndorse:
    """`endorse[<origin>](<value>, reason = "...")` [`with <appr>`] — the scoped,
    reasoned taint declassifier (roadmap item 249, Slice C).

    Supersedes Slice A's ambient `endorse(v)`. Three properties, each on the node:
    `origin` names the coarse taint class being downgraded (and must appear in the
    enclosing declaration's endorse slot); `reason` is the mandatory audit string
    that lands in the boundary table's declassify record; `approval` is the name
    of an `Approval[declassify.<origin>]` value threaded through `with`, so an
    endorse under a `capability declassify.<origin> requires approval` policy rule
    is covered (item 246 surface). It is identity on its argument's base type and
    is spliced out of the IR after the taint verdict, so no emitter sees it."""
    origin: str
    expr: object
    reason: str
    line: int
    approval: str | None = None


@dataclass
class ExprBin:
    op: str
    left: object
    right: object
    line: int


@dataclass
class ExprUn:
    op: str
    operand: object
    line: int


@dataclass
class ExprCall:
    callee: object
    args: list
    line: int


@dataclass
class ExprField:
    target: object
    name: str
    line: int


@dataclass
class ExprIndex:
    target: object
    index: object
    line: int


@dataclass
class ExprOptField:
    target: object
    name: str
    line: int


@dataclass
class ExprOptCall:
    target: object
    method: str
    args: list
    line: int


@dataclass
class ExprIf:
    cond: object
    then: object
    otherwise: object
    line: int


@dataclass
class ExprRecord:
    fields: list
    line: int


@dataclass
class ExprRecordUpdate:
    """`{base | f1 = e1, f2 = e2}` — functional record update.

    Semantics (docs/records.md §2): evaluates `base`, then produces a *fresh*
    value of `base`'s record type with the named fields replaced; `base` is
    untouched, exactly like `Map.set`. The result's type is `base`'s type.
    """
    base: object
    updates: list  # [(field_name, expr)]
    line: int


@dataclass
class ExprBlockArm:
    """A match arm whose body is a statement block: `=> { stmt* ; expr }`.

    The block accepts the same statement set a normal fn/block body accepts
    (`let`, `var`, `while`, `if`, `for`, assignments, ...) and ends in an
    expression whose value is the arm's value (docs/records.md §4). Lowering
    lambda-lifts the block into a synthetic helper fn, so the imperative
    statements run where the value is destructured and the IR arm body stays an
    expression (a call). `return` is not a block-arm statement — the arm yields
    its final expression, not an early return from the enclosing function.
    """
    stmts: list  # block statements preceding the tail (any fn-body statement)
    tail: object
    line: int


@dataclass
class ExprList:
    items: list
    line: int


# ------------------------------------------------------ item 383: list transforms
# The receiver-first functional transforms `xs.map(f)` / `xs.filter(p)` /
# `xs.reduce(init, f)` are PURE SUGAR for the generic free functions
# `list_map` / `list_filter` / `list_reduce` in stdlib/list.rvl — the same
# desugar-to-a-plain-CALL shape as item 189's Value dot-accessors, except the
# free function is generic and takes a function-value argument (items 92/342).
#
# The redirect happens BEFORE typing and lowering (`desugar_list_transform` is
# called from typecheck.py and lower.py at the method-call site), so the
# existing generic-call + arrow-argument inference does all the work. This is
# deliberately NOT a `_BUILTIN_SIG` row: no builtin-method signature can express
# `map`'s result `List[<f's return>]` (the return type must be solved from the
# arrow), so the sugar is a syntactic redirect to a real generic `fn`, not a
# builtin. Receiver-first: the receiver becomes the leading argument, preserving
# the written argument order (`xs.reduce(init, f)` -> `list_reduce(xs, init, f)`).
LIST_TRANSFORMS = {
    "map": "list_map",
    "filter": "list_filter",
    "reduce": "list_reduce",
}


def desugar_list_transform(expr):
    """If `expr` is a `recv.map(...)` / `.filter(...)` / `.reduce(...)` call,
    return the equivalent `list_map(recv, ...)` free-function ExprCall; else
    return None. The receiver is threaded in as the leading argument."""
    callee = expr.callee
    if not isinstance(callee, ExprField):
        return None
    free = LIST_TRANSFORMS.get(callee.name)
    if free is None:
        return None
    return ExprCall(ExprVar(free, callee.line),
                    [callee.target, *expr.args], expr.line)


@dataclass
class ExprArrow:
    params: list[str]
    body: object
    line: int
    # item 75(a) §2.4 — the WRITTEN annotations and the RESOLVED types are
    # separate fields. They used to be one pair: the parser wrote the author's
    # annotations into `param_types` and the checker *overwrote* them with what
    # it resolved. That conflation is what left the IR emit condition unable to
    # tell a complete signature from a partial one, and it makes the async
    # colour rules (C1/C2) inexpressible, because nothing downstream could tell
    # an author-written return from a checker-derived one.
    #
    # written by the parser, never by the checker:
    written_param_types: list = field(default_factory=list)  # `(v: Int) => …`
    written_returns: str | None = None                       # `(v): Int => …`
    # written by the checker (`typecheck.py::_resolve_arrow`), never by the
    # parser. `None` (not `[]`) means the checker never resolved this arrow;
    # a `None` *entry* means that parameter is still unknown. Lowering reads
    # only these two, and only emits a signature when every entry is known.
    param_types: list | None = None
    returns: str | None = None
    # the same resolution as a function type, but in the CHECKER's spelling:
    # `param_types`/`returns` go to the IR and so have the implicit-type-
    # parameter marker stripped by `render_type`, which turns an unsolved `?B`
    # into the opaque nominal `B`. Re-inferring an already-resolved arrow off
    # the stripped fields would feed that `B` back into unification as a
    # concrete type, so the marked spelling is kept here for the checker.
    resolved_type: str | None = None


@dataclass
class ExprMatch:
    scrutinee: object
    arms: list  # [(pattern_name | "_", bind_name | None, body_expr)]
    line: int


@dataclass
class ExprHole:
    """`hole`, `hole "why"`, `hole[T]`, `hole[T] "why"` — docs/holes.md.

    A placeholder that *has a type* and no implementation. `type` is the
    author's `hole[T]` annotation, if written; `resolved` is the expected
    type the bidirectional checker supplied from context (declared return,
    service signature, parameter). Exactly one of the two must be known by
    the time the hole is lowered — a hole never guesses its own type.
    """
    message: str | None
    type: str | None
    line: int
    resolved: str | None = None

    @property
    def known_type(self) -> str | None:
        return self.type or self.resolved


# fn-body statements

@dataclass
class RecordPattern:
    fields: list[str]
    line: int


@dataclass
class ListPattern:
    binds: list[str]
    rest: str | None
    line: int


@dataclass
class LetPatternStmt:
    pattern: RecordPattern | ListPattern
    value: object
    mutable: bool
    line: int


@dataclass
class LetStmt:
    name: str
    value: object
    mutable: bool
    line: int
    # `let g: (Int) -> Int = …` — an optional declared type. It is the
    # checking position for the right-hand side (and the only way to give an
    # un-annotated arrow a type without passing it somewhere).
    type: str | None = None


@dataclass
class AssignStmt:
    name: str
    value: object
    line: int
    op: str = "="


@dataclass
class WhileStmt:
    cond: object
    body: list
    line: int


@dataclass
class ForStmt:
    bind: str
    iterable: object
    body: list
    line: int


@dataclass
class IfStmt:
    cond: object
    then: list
    otherwise: list | None
    line: int


@dataclass
class ExprStmt:
    expr: object
    line: int


@dataclass
class AssertStmt:
    expr: object
    line: int


@dataclass
class BreakStmt:
    """`break` — leave the innermost enclosing `while`/`for` (item 379,
    docs/design/379-break-continue.md). Bare, no label, no value; valid only
    inside a loop body in the fn statement grammar."""
    line: int


@dataclass
class ContinueStmt:
    """`continue` — skip to the innermost enclosing loop's next iteration
    (item 379). Bare, no label, no value; valid only inside a loop body in
    the fn statement grammar."""
    line: int


# --- v2.0 §7.1: lifecycle test statements ---------------------------------
# Stratum-3 statements, legal only inside a `lifecycle test` body. They are a
# script over a live composition, not pure code, so they are their own node
# set rather than an extension of the pure statement grammar.

@dataclass
class LoadStmt:
    component: str
    config: list[tuple[str, object, int]]   # (field, expr, line)
    line: int


@dataclass
class UnloadStmt:
    component: str
    line: int


@dataclass
class CallStmt:
    key: str
    method: str
    args: list
    bind: str | None
    line: int


@dataclass
class ResidueStmt:
    line: int


@dataclass
class AbortStmt:
    """`abort` — drive the enclosing session frame's 245 abort (roadmap item
    377). Marks every live activation frame aborting, replays the witnessed
    inverses (LIFO), and drops the deferral queue, exactly as
    `revl.mcp.session.Session.abort` does (docs/design/245-session-commit.md).

    This is what makes H1's flagship proof expressible in-language: perform
    witnessed mutations, `abort`, then `assert no_residue` — the witnessed
    effects revert and the workspace is left byte-identical to before, with no
    host Python in the loop (F-H1.7). Like a session abort it tears the live
    composition down, so it names the end of the driven composition."""

    line: int


@dataclass
class AdvanceStmt:
    """`advance <n><unit>` — drive the clock coeffect (item 57) forward inside a
    `lifecycle test`. The clock never moves on its own, so this is the only way
    a test can exercise a timer's *firing* — a firing is a deterministic
    timeline step (`fires on the 3rd tick`), not a wall-clock race
    (item 102, docs/time-coeffect.md)."""

    ms: int
    line: int


@dataclass
class TestDecl:
    name: str
    body: list
    line: int
    lifecycle: bool = False


@dataclass
class FaultTestDecl:
    """`fault test "name" for C { fail at step N  assert no residue }`.

    A declarable L-Raise (A8) experiment: activate `component` with a failure
    injected at one point of its activation body, then assert on what the
    paradigm promises about the wreckage.  See docs/fault-tests.md.
    """

    name: str
    component: str
    config: dict            # component config for the activation under test
    at_step: int | None     # 1-based index into the component's body steps
    at_effect: str | None   # `let effect NAME` binding (resolved to an index)
    asserts: list           # [(kind, line)] — kind from _FAULT_ASSERTS
    line: int


@dataclass
class PropTestDecl:
    """`prop test "name" (a: Int, b: Money) { assert … }` (roadmap item 37).

    A property test: the parameters are *generated inputs*, and the body is a
    pure assertion over them that must hold for every generated value.  The
    generators are DERIVED from the parameter types the checker already knows
    (records, ADTs — every constructor, `Opt`/`List` nesting, the i64 edge
    values); on failure the runner *shrinks* the input to a minimal
    counterexample.  See docs/prop-test.md.

    Precedent: `verified effect` (item 26) is the specific inverse-round-trip
    instance of this general form; `lifecycle`/`fault` set the pattern of a
    modifier/head changing a test's stratum without a new top-level keyword.
    """

    name: str
    params: list[FnParam]   # generated-input surface (name + declared type)
    body: list              # pure statements, at least one `assert`
    line: int


@dataclass
class SecretDecl:
    """A capability-bound secret declaration (roadmap item 256):
    `secret NAME for CAP`. The NAME is the manifest-visible handle the runtime
    resolves a value against; CAP is the emission capability token whose extern
    bodies the value is injected into, and nowhere else. The value is NEVER in
    the source or the IR - only the name and the capability are (the split from
    config is a hard rule, docs/design/256-capability-bound-secrets.md §1b)."""

    name: str
    capability: str
    line: int


@dataclass
class Program:
    filename: str
    services: list[ServiceDecl] = field(default_factory=list)
    components: list[ComponentDecl] = field(default_factory=list)
    type_decls: list[TypeDecl] = field(default_factory=list)
    # item 130 Slice 5: the typed-event declarations. Each also contributes a
    # record `TypeDecl` above (an event IS a record with a contract), so the
    # type table needs no event case; this list carries only the contract the
    # `on` handler reads. Empty for every program that declares no event.
    event_decls: list[EventDecl] = field(default_factory=list)
    fn_decls: list[FnDecl] = field(default_factory=list)
    uses: list[UseDecl] = field(default_factory=list)
    externs: list[ExternDecl] = field(default_factory=list)
    secrets: list[SecretDecl] = field(default_factory=list)
    tests: list[TestDecl] = field(default_factory=list)
    fault_tests: list[FaultTestDecl] = field(default_factory=list)
    prop_tests: list[PropTestDecl] = field(default_factory=list)
    # item 426 S1: composition documents. A PRE-LINKER artifact — the resolver
    # in `revl.composition` folds these into a row table and a file list; the
    # lowerer never reads them, so a program that declares none is byte-identical.
    compositions: list[CompositionDecl] = field(default_factory=list)
    # item 426 S2: layer documents. Also pre-linker — `revl.composition` folds
    # them into the row table before `compile_files` sees a single path.
    layers: list[LayerDecl] = field(default_factory=list)
    # Set by compile_files so the checker can resolve module-private vs
    # imported names without merging all files into one global namespace.
    fn_scopes: dict[int, set[str]] = field(default_factory=dict)
    fn_alias_scopes: dict[int, dict[str, set[str]]] = field(default_factory=dict)
    # Provenance for non-component declarations: id(decl) -> source file.
    # Components carry their own `source`; fns, externs and services do not,
    # and a why-trace needs a file for every hop it names (why.py). Keyed by
    # identity like `fn_scopes`, so merging modules preserves it for free.
    decl_files: dict[int, str] = field(default_factory=dict)


# `===` -> `==`, `!==` -> `!=`: both spellings, one meaning (structural,
# no coercion); the formatter story is canonicalization, the IR never
# carries the triple form
_CANONICAL_OPS = {"===": "==", "!==": "!="}

# item 384: foreign statement/declaration keywords that LEX as identifiers
# (none is a revl keyword) and so land in a statement- or declaration-dispatch
# position where they are already an error — but a cryptic one (`expected a
# top-level declaration, found 'def'`). Redirected to the revl spelling. The
# check runs only at those error sites, which no valid program reaches with
# these spellings, so it is false-positive-free (a fn/binding legitimately
# NAMED `def`/`throw` is parsed in name position, never reaching the dispatch).
# (message, hint) pairs; kept in sync with lower._FOREIGN_NAME_REDIRECTS.
_FOREIGN_STMT_KEYWORDS = {
    "def": ("revl has no `def`",
            "a function is declared with `fn` (syntax-2.0 §3.1)"),
    "throw": ("revl has no `throw`",
              "a pure function returns a `Result`; a component activation body "
              "signals failure with `fail` (syntax-2.0 §3.3, §4b.5)"),
    "elif": ("revl has no `elif`",
             "chain conditionals with `else if` (syntax-2.0 §3.2)"),
    "lambda": ("revl has no `lambda`",
               "an anonymous function is an arrow `x => …` (syntax-2.0 §3.2)"),
    "const": ("revl has no `const`",
              "use `let` (single-assignment) or `var` (mutable) (syntax-2.0 §3.5)"),
    "print": ("revl has no `print`",
              "pure code has no I/O — emit output through a service effect "
              "(syntax-2.0 §4)"),
}


# ---------------------------------------------------------------- parser

def _found(tok) -> str:
    """How a token reads in an `expected ..., found ...` message.

    The eof token carries `None` as its value, and `repr(None)` renders as
    `found None` — which reads as a literal in the source rather than as the
    input running out. `expect()` has always spelled this "end of file"; the
    expression path did not (issue #313), and an interpolation that ran out
    mid-expression is exactly where a reader meets it.
    """
    return repr(tok.value) if tok.value is not None else "end of file"


class Parser:
    def __init__(self, source: str, filename: str, line_offset: int = 0):
        self.filename = filename
        # `line_offset` is non-zero only for a sub-parse of a fragment — the
        # body of a `${...}` interpolation — so its tokens, its AST nodes and
        # every checker diagnostic on them carry the line the fragment occupies
        # in the real file instead of line 1 (issue #313).
        self.toks = lex(source, filename, line_offset=line_offset)
        self.pos = 0
        # When set, the next `_bor` call does not consume a top-level `|` — it
        # is the functional-record-update separator `{base | f = e}`, not the
        # bitwise-OR operator (item 366). The flag is cleared the moment it is
        # read so a *parenthesised* `(a | b)` inside the base still lexes as
        # bitwise OR.
        self._suppress_bor = False
        # item 379: bare `break`/`continue` are valid only inside a `while`/`for`
        # body. `_loop_depth` counts the enclosing loops of the statement being
        # parsed (parse-state, like `_suppress_bor`), incremented around each
        # loop's body parse. A match block arm is lambda-lifted into a separate
        # helper fn at lowering (src/revl/lower.py `_lift_block_arm`), so a
        # `break` written there would land in a fn with no loop; entering an arm
        # resets the depth to 0 so such a `break` is refused, and `_in_block_arm`
        # switches the refusal to the block-arm voice (C1,
        # docs/design/379-break-continue.md).
        self._loop_depth = 0
        self._in_block_arm = False
        # issue #310: how many expressions deep the cursor currently is, held
        # against `NESTING_LIMIT`. A `${...}` interpolation is parsed by a
        # SEPARATE `Parser` over the template body, so the depth is handed to
        # that sub-parser (`_parse_template_parts`) — otherwise nested
        # templates reset the count and walk straight past the bound.
        self._nesting = 0

    # -- token helpers

    def peek(self) -> Token:
        return self.toks[self.pos]

    def peek_ahead(self, offset: int = 1) -> Token:
        """The token `offset` past the cursor, CLAMPED to the eof token.

        Most lookaheads in this file are taken under a guard
        (`at("ident", "lifecycle")`) that already proves the current token is
        not eof, so a next token exists. Not all of them are:
        `_reject_lifecycle_stmt_here` takes its lookahead before any such
        guard, so a `test` body whose input simply ran out indexed past the end
        and threw a bare `IndexError` out of the parser.

        A frontend fault is not a refusal. `RevlError` is the language saying
        no and every caller handles it; an `IndexError` is an unhandled crash
        in a library, and in `revl.gate` an unhandled crash in a security
        surface. The token list always ends with an eof token, so clamping to
        the last one is exactly "there is nothing after this" — the answer
        every already-guarded call site computes anyway, which is why routing
        them through here changes no behaviour.

        Found by tools/fuzz_frontend.py; the reproducer is `test"e"{`.
        """
        return self.toks[min(self.pos + offset, len(self.toks) - 1)]

    def next(self) -> Token:
        tok = self.toks[self.pos]
        self.pos += 1
        return tok

    def at(self, kind: str, value=None) -> bool:
        tok = self.peek()
        return tok.kind == kind and (value is None or tok.value == value)

    def expect(self, kind: str, value=None, what: str | None = None) -> Token:
        tok = self.peek()
        if not self.at(kind, value):
            wanted = what or (value if value is not None else kind)
            got = repr(tok.value) if tok.value is not None else "end of file"
            hint = None
            if kind == "ident" and tok.kind == "kw":
                # repeated agent pain: a reserved word used where a NAME is
                # wanted reads as a parser confusion, not a naming mistake
                hint = (f"`{tok.value}` is a reserved keyword — it cannot "
                        "name a field, variable, parameter, or method; "
                        "pick another name")
            raise RevlError(self.filename, tok.line,
                            f"expected {wanted}, found {got}", hint)
        return self.next()

    def err(self, line: int, message: str, hint: str | None = None) -> RevlError:
        return RevlError(self.filename, line, message, hint)

    # -- item 157: `;` as an optional statement separator/terminator

    def _skip_semis(self) -> None:
        """`;` is an *optional* statement separator/terminator (item 157). It
        carries no meaning of its own: statements may be separated by a newline
        (as always) OR by `;`, and a leading, trailing, or repeated `;` — a lone
        `;` or `;;` being an empty statement — is a harmless no-op. Runs of them
        are skipped wherever statements are listed, so a program written with no
        `;` tokenises and parses to the exact same AST as before."""
        while self.at(";"):
            self.next()

    # -- item 158: cordis-domain nouns as CONTEXTUAL keywords in name position

    # `realm`, `intercept`, `isolate`, `in`, `with` are reserved where the
    # grammar wants the keyword (a statement/clause head: `isolate k in r`,
    # `intercept k with {…}`, `spawn C with {…}`, a `realm { … }` label). In a
    # position where only a NAME is grammatically possible — a record/param
    # field name, or a `.field` access — none of the five can head a clause, so
    # all five relax to ordinary identifiers there without ambiguity. (`in` and
    # `with` never *lead* anything: they are always the tail of an `isolate`/
    # `intercept`/`spawn` form, so their keyword role is untouched here.)
    _CONTEXTUAL_NOUNS = frozenset({"realm", "intercept", "isolate", "in", "with"})

    def _is_name_tok(self, tok: Token) -> bool:
        return tok.kind == "ident" or (
            tok.kind == "kw" and tok.value in self._CONTEXTUAL_NOUNS)

    def _name(self, what: str | None = None) -> str:
        """A NAME in a position where no keyword is grammatically possible
        (field name, parameter name, `.field` access). Accepts an ordinary
        `ident`, or one of the contextual cordis-domain nouns (item 158). A
        genuinely reserved keyword (`type`, `fn`, …) falls through to
        `expect("ident", …)` unchanged, so its "expected ident/…"-plus-"reserved
        keyword" diagnostic is byte-for-byte what it was before this broadening.
        `what` is forwarded verbatim so each call site keeps its exact prior
        wording (`None` → the default "expected ident")."""
        tok = self.peek()
        if self._is_name_tok(tok):
            return self.next().value
        return self.expect("ident", what=what).value

    # -- item 237: cordis-domain nouns as record FIELD names

    # A record FIELD position — a record-literal key (`{k: e}`), a functional
    # record-update field (`{base | k = e}`), or a record-type field
    # (`type T = {k: τ}`) — always has its name immediately followed by `:` or
    # `=`. None of the cordis-domain nouns can head a clause in that spot, so on
    # top of the item-158 five (`realm`/`intercept`/`isolate`/`in`/`with`, which
    # already relax via `_name`) the three component-grammar heads
    # `component`/`config`/`requires` (the nouns self-host dogfood item 234 hit)
    # also relax to ordinary field names here. They stay genuine keywords
    # everywhere they can LEAD a form — `component`/`config` as decl/body heads,
    # `requires` as a component clause head — because none of those are field
    # positions and none reach this helper. (Parameter position keeps refusing
    # them: see item 158 and `_name`.)
    _RECORD_KEY_NOUNS = _CONTEXTUAL_NOUNS | frozenset(
        {"component", "config", "requires"})

    def _record_key_name(self, what: str | None = None) -> str:
        """A NAME in record-FIELD position, broadening `_name` (item 158) with
        the three component-grammar nouns (item 237). A field name is always
        followed by `:` or `=`, so no keyword reading is grammatically possible.
        Any other reserved keyword (`type`, `fn`, …) still falls through to
        `expect("ident", …)` with its diagnostic byte-for-byte unchanged."""
        tok = self.peek()
        if tok.kind == "ident" or (
                tok.kind == "kw" and tok.value in self._RECORD_KEY_NOUNS):
            return self.next().value
        return self.expect("ident", what=what).value

    # -- productions

    def parse(self) -> Program:
        with recursion_headroom():
            try:
                return self._parse_program()
            except RevlError as e:
                better = self._maybe_stray_backtick_error(e)
                if better is not None:
                    raise better from None
                raise
            except RecursionError:
                # The backstop under `NESTING_LIMIT` (issue #310). The bound
                # above covers the expression ladder, which is what explodes
                # first and fastest; the other recursive descents here —
                # nested blocks, nested type arguments — are shallower per
                # level and reach python's limit only far past anything a
                # program means. Whichever one gives out, the caller gets a
                # diagnostic, because a `RecursionError` escaping a library is
                # an unhandled fault and `revl.gate` is a library with a
                # security contract.
                raise self._nesting_too_deep() from None

    def _nesting_too_deep(self) -> RevlError:
        return self.err(
            self.peek().line,
            "this program nests deeper than the compiler can parse",
            hint="the parser is recursive descent, so nesting costs stack: "
                 f"expressions are bounded at {NESTING_LIMIT} levels and the "
                 "other nestings by the interpreter's own limit. This is an "
                 "implementation bound, not a language one — name the inner "
                 "constructs with `let` bindings or helper functions.",
        )

    def _maybe_stray_backtick_error(self, e: RevlError) -> "RevlError | None":
        """Item 365: a stray backtick inside a host `//`/`/*` comment closes a
        backtick template early; the template's tail then reparses as revl and
        the raw parse error names whatever identifier the tail happens to hold,
        far from the real mistake. When the lexer flagged such a close (see
        `lexer._closing_backtick_is_stray`) at or before the failing line, point
        the diagnostic back at the template boundary instead — the item-70 move
        of naming the construct that swallowed the tokens.

        Only ever called AFTER a parse has already failed, so it can reword a
        genuine error but never reject accepted source (additivity)."""
        best = None
        for tok in self.toks:
            if tok.kind != "template":
                continue
            span = getattr(tok, "stray_backtick", None)
            if span is None:
                continue
            start_line, close_line = span
            # nearest suspect template whose stray close is at or before the
            # point the parse gave out.
            if e.line is not None and close_line > e.line:
                continue
            if best is None or close_line > best[1]:
                best = span
        if best is None:
            return None
        start_line, close_line = best
        opened = (f"opened on line {start_line}"
                  if start_line != close_line else "on this line")
        return RevlError(
            self.filename, close_line,
            f"a stray backtick closed the template {opened} early: this "
            "backtick sits inside the host comment or string but revl read it "
            "as the template's end",
            hint="revl templates have no backtick escape; embed a literal "
                 "backtick with an interpolation, `` ${\"`\"} ``, or move the "
                 "template's closing backtick to where the template really ends",
        )

    def _parse_program(self) -> Program:
        program = Program(self.filename)
        while True:
            self._skip_semis()
            if self.at("eof"):
                break
            if self.at("kw", "use"):
                program.uses.append(self.use_decl())
            elif self.at("kw", "service"):
                program.services.append(self.service(commutative=False))
            elif self.at("kw", "commutative"):
                self.next()
                if not self.at("kw", "service"):
                    tok = self.peek()
                    raise self.err(tok.line, f"expected `service` after `commutative`, found {tok.value!r}")
                program.services.append(self.service(commutative=True))
            elif self.at("kw", "component"):
                program.components.append(self.component())
            elif self.at("ident", "boot") and self.toks[self.pos + 1].kind == "kw" \
                    and self.toks[self.pos + 1].value == "component":
                # item 350: `boot` is a *contextual* keyword, the same discipline
                # `secret`/`fault`/`prop`/`lifecycle` use — it heads a declaration
                # ONLY immediately before `component`, so no program that already
                # used `boot` as an ordinary identifier breaks and the self-hosted
                # lexer's KEYWORDS table (and with it the generated gate crate's
                # frontier table) needs no sync.
                self.next()
                program.components.append(self.component(boot=True))
            elif self.at("kw", "type"):
                program.type_decls.append(self.type_decl(False))
            elif self.at("kw", "pub"):
                self.next()
                verified = False
                if self.at("kw", "verified"):
                    self.next()
                    verified = True
                commutative = False
                if self.at("kw", "commutative"):
                    self.next()
                    commutative = True
                # item 249 Slice C: an `endorse[<origin>]` declaration slot may
                # sit before `fn`, exactly where `emission[cap]` sits on an
                # extern — it names the taint classes the body may declassify.
                endorse_origins = self._endorse_slot()
                if self.at("kw", "fn"):
                    if commutative:
                        tok = self.peek()
                        raise self.err(tok.line, f"expected `service` after `commutative`, found {tok.value!r}")
                    program.fn_decls.append(self.fn_decl(True, verified, endorse_origins))
                elif self.at("kw", "type"):
                    if commutative:
                        tok = self.peek()
                        raise self.err(tok.line, f"expected `service` after `commutative`, found {tok.value!r}")
                    program.type_decls.append(self.type_decl(True))
                elif self.at("kw", "service"):
                    # services are interfaces and are pub by default; a `pub`
                    # prefix is accepted as documentation but adds nothing
                    program.services.append(self.service(commutative=commutative))
                elif self.at("kw", "extern"):
                    if commutative:
                        tok = self.peek()
                        raise self.err(tok.line, f"expected `service` after `commutative`, found {tok.value!r}")
                    program.externs.append(self.extern_decl(True))
                elif self.at("kw", "component"):
                    tok = self.peek()
                    raise self.err(
                        tok.line,
                        "components are never `pub` — they are composed through the manifest, not imported",
                    )
                else:
                    tok = self.peek()
                    if commutative:
                        raise self.err(tok.line, f"expected `service` after `commutative`, found {tok.value!r}")
                    raise self.err(tok.line, f"expected `fn`, `type`, `service`, or `extern` after `pub`, found {tok.value!r}")
            elif self.at("kw", "verified"):
                self.next()
                endorse_origins = self._endorse_slot()  # item 249 Slice C
                if self.at("kw", "fn"):
                    program.fn_decls.append(self.fn_decl(False, True, endorse_origins))
                else:
                    tok = self.peek()
                    raise self.err(tok.line, f"expected `fn` after `verified`, found {tok.value!r}")
            elif self.at("kw", "extern"):
                program.externs.append(self.extern_decl(False))
            elif self.at("ident", "endorse"):
                # item 249 Slice C: a top-level `endorse[<origin>] [verified] fn`
                # — the declassification slot before `fn`, mirroring `emission`.
                endorse_origins = self._endorse_slot()
                verified = False
                if self.at("kw", "verified"):
                    self.next()
                    verified = True
                if not self.at("kw", "fn"):
                    tok = self.peek()
                    raise self.err(tok.line, f"expected `fn` after `endorse[...]`, found {tok.value!r}",
                                   hint="the `endorse[<origin>]` slot names what a `fn` body "
                                        "may declassify — it can only precede a `fn` (item 249)")
                program.fn_decls.append(self.fn_decl(False, verified, endorse_origins))
            elif self.at("kw", "fn"):
                program.fn_decls.append(self.fn_decl(False))
            elif self.at("kw", "test"):
                program.tests.append(self.test_decl())
            elif self.at("ident", "fault") and self.peek_ahead(1).kind == "kw" \
                    and self.peek_ahead(1).value == "test":
                # `fault` is a *contextual* keyword: it only heads a
                # declaration when immediately followed by `test`, so adding
                # this form cannot break a program that already uses `fault`
                # as an ordinary identifier (and the self-hosted lexer's
                # KEYWORDS table needs no sync).
                program.fault_tests.append(self.fault_test_decl())

            elif self.at("ident", "event") \
                    and self.pos + 2 < len(self.toks) \
                    and self.toks[self.pos + 1].kind == "ident" \
                    and self.toks[self.pos + 2].kind in ("(", "{"):
                # item 130 Slice 5: `event <Name>(key: <field>) { <fields> }`.
                # `event` is a *contextual* keyword, the `boot`/`fault`/`secret`
                # discipline: it heads a declaration ONLY in the shape
                # `event IDENT (` / `event IDENT {`, so the corpus's
                # `emission fn log(event: Str)` parameters keep parsing and the
                # self-hosted lexer's KEYWORDS table (and the gate crate's
                # frontier derived from it) needs no sync. The `{` spelling is
                # admitted HERE and refused in `_event_contract` so the most
                # likely mistake — a key-less event — gets the diagnostic that
                # names the missing key, not "expected a top-level declaration". The declaration ALSO contributes an ordinary record
                # `TypeDecl`, because an event is a record with a contract (§6):
                # every record rule then applies to it with no event-specific
                # case anywhere in the type machinery.
                decl = self.event_decl()
                program.event_decls.append(decl)
                program.type_decls.append(
                    TypeDecl(decl.name, [], decl.fields, [], decl.line))

            elif self.at("ident", "secret") \
                    and self.peek_ahead(1).kind == "ident" \
                    and self.peek_ahead(2).kind == "kw" \
                    and self.peek_ahead(2).value == "for":
                # `secret` is a *contextual* keyword (roadmap item 256), the same
                # discipline `witnessed`/`deferred`/`fault`/`prop` use: it heads a
                # declaration ONLY in the shape `secret NAME for CAP`, so no program
                # that used `secret` as an ordinary identifier breaks and the
                # self-hosted lexer's KEYWORDS table needs no sync.
                program.secrets.append(self.secret_decl())

            elif self.at("ident", "prop") and self.peek_ahead(1).kind == "kw" \
                    and self.peek_ahead(1).value == "test":
                # `prop` is a *contextual* keyword: like `fault`, it only heads a
                # declaration when immediately followed by `test`, so adding
                # `prop test` cannot break a program that already uses `prop` as
                # an ordinary identifier, and the self-hosted lexer's KEYWORDS
                # table needs no sync (roadmap item 37).
                program.prop_tests.append(self.prop_test_decl())

            elif self.at("ident", "composition") \
                    and self.peek_ahead(1).kind == "ident":
                # item 426 S1. `composition` is a CONTEXTUAL keyword — it heads
                # a declaration only in the shape `composition NAME {`, so no
                # program that already uses `composition` as an ordinary
                # identifier breaks and the self-hosted lexer's KEYWORDS table
                # needs no sync (the same discipline `fault`/`prop`/`lifecycle`
                # use).
                program.compositions.append(self.composition_decl())

            elif self.at("ident", "layer") \
                    and self.toks[self.pos + 1].kind == "ident":
                # item 426 S2. `layer` is a CONTEXTUAL keyword on the same
                # discipline `composition` uses: it heads a declaration only in
                # the shape `layer NAME for COMPOSITION {`, so the self-hosted
                # lexer's KEYWORDS table still needs no sync and a program using
                # `layer` as an ordinary identifier is unaffected.
                program.layers.append(self.layer_decl(site=False))

            elif self.at("ident", "site") and self.toks[self.pos + 1].kind == "ident" \
                    and self.toks[self.pos + 1].value == "layer":
                # `site layer ...` — LEVEL 2, the operator's own. Two contextual
                # words, still no lexer change.
                self.next()
                program.layers.append(self.layer_decl(site=True))

            elif self.at("ident", "lifecycle"):
                # contextual keyword: `lifecycle` is a modifier on `test`
                # (syntax-2.0 §7.1). It is deliberately NOT a lexer keyword —
                # the grammar delta is one token in one position, and the
                # self-hosted lexer's token stream stays unchanged.
                nxt = self.peek_ahead(1)
                if not (nxt.kind == "kw" and nxt.value == "test"):
                    raise self.err(
                        self.peek().line,
                        "`lifecycle` is a modifier on `test` — expected `test` after it",
                        hint='write `lifecycle test "name" { ... }` (syntax-2.0 §7.1)',
                    )
                self.next()
                program.tests.append(self.test_decl(lifecycle=True))
            else:
                tok = self.peek()
                self._reject_foreign_keyword(tok)  # item 384
                raise self.err(tok.line, f"expected a top-level declaration, found {tok.value!r}")
        return program

    def use_decl(self) -> UseDecl:
        line = self.expect("kw", "use").line
        path_tok = self.expect("string", what="a module path string")
        path = path_tok.value
        if not path:
            raise self.err(line, "`use` path cannot be empty")
        names = None
        alias = None
        if self.at("{"):
            self.next()
            names = []
            while not self.at("}"):
                names.append(self.expect("ident").value)
                if self.at(","):
                    self.next()
            self.expect("}")
        elif self.at("kw", "as"):
            self.next()
            alias = self.expect("ident").value
        else:
            tok = self.peek()
            raise self.err(tok.line, f"expected `{{` or `as` after `use` path, found {tok.value!r}")
        return UseDecl(path, names, alias, line)

    def secret_decl(self) -> SecretDecl:
        """`secret NAME for CAP` (roadmap item 256). NAME is an ordinary
        identifier (the manifest-visible handle); CAP is a dotted capability
        token, the same grammar an `emission[...]` scope names. The value never
        appears here - only the name and the capability
        (docs/design/256-capability-bound-secrets.md §1)."""
        line = self.expect("ident", value="secret").line
        name = self.expect("ident", what="a secret name").value
        self.expect("kw", "for", what="`for` after a secret name")
        parts = [self.expect("ident", what="a capability name").value]
        while self.at("."):
            self.next()
            parts.append(self.expect("ident").value)
        return SecretDecl(name, ".".join(parts), line)

    def extern_decl(self, public: bool) -> ExternDecl:
        line = self.expect("kw", "extern").line
        # `pure`/`acquire`/`emission` are reserved keywords; `witnessed` (item
        # 243) is a CONTEXTUAL keyword recognised only in this classification
        # slot, so the self-hosted lexer's KEYWORDS set needs no sync and no
        # program that used `witnessed` as an ordinary name is broken.
        if self.peek().value not in ("pure", "acquire", "emission", "witnessed") \
                or (not self.at("kw") and not self.at("ident", "witnessed")):
            raise self.err(
                line,
                "unclassified extern — expected `pure`, `acquire`, `emission`, or "
                "`witnessed` after `extern`",
                hint="classification is mandatory: `pure` has no observable effect, "
                     "`acquire` must declare `undo`, `emission` may declare `compensate`, "
                     "and `witnessed` is a reversible mutation whose declared `undo` the "
                     "accumulator auto-registers (docs/design/243-witnessed-externs.md)",
            )
        classification = self.next().value
        # Capability scope, `witnessed[fs]` / `emission[gateway.send]`
        # (docs/design/243-witnessed-externs.md, item 343). A witnessed mutation
        # and an emission are capability-scoped alike — the bracket is revl's
        # parameterisation bracket — and both join the same authority namespace.
        # The declared token, not the extern NAME, is the emission's capability,
        # so a `capability C requires approval` rule and a standing grant target
        # the crossing by token (item 344). `pure`/`acquire` cross no boundary,
        # so the parse is still refused on them and the surface stays honest.
        capabilities: tuple[str, ...] = ()
        if self.at("["):
            if classification not in ("witnessed", "emission"):
                raise self.err(
                    self.peek().line,
                    f"`{classification}` extern takes no capability scope",
                    hint="only a `witnessed[caps]` or `emission[caps]` extern is "
                         "capability-scoped (docs/design/243-witnessed-externs.md, "
                         f"item 343); write `{classification} fn ...` without the "
                         "bracket",
                )
            capabilities = self._capability_list(kind=classification)
        # Optional reach clause `(confined: <param>)` (item 373), a sibling of
        # the `[caps]` scope above. It sits right after the classification (and
        # its optional bracket) and before the `async`/`deferred` modifiers.
        # `(` is not otherwise legal here — the next token is `async`/`deferred`
        # /`fn` — so the peek is unambiguous. Structural parse only; the
        # "emission-only" and "target names a parameter" rules are enforced in
        # lower, next to the sibling classification checks, with honest messages.
        reach: tuple[str, str] | None = None
        if self.at("("):
            reach = self._reach_clause()
        # Optional `async` modifier between the classification and `fn`,
        # mirroring where service-op modifiers sit (parser.py:895-906). The
        # classification stays first and mandatory, so the "unclassified
        # extern" diagnostic above is untouched. Validity rules (emission-only,
        # no compensate) are enforced in lower (docs/design/async-extern.md §1).
        # `async` and `deferred` modifiers, in either order, between the
        # classification (and its optional capability scope) and `fn`. `async`
        # is a reserved keyword; `deferred` (item 245) is a CONTEXTUAL keyword
        # recognised only in this modifier slot, so the lexer's KEYWORDS set
        # needs no sync and no program that used `deferred` as an ordinary name
        # is broken (the same discipline `witnessed` uses above). Their pairwise
        # validity (`deferred` is emission-only and async-exclusive) is enforced
        # in lower with honest messages, not the parser.
        # item 309: bare `idempotent` (and its `idempotent(key: p)` keyed form)
        # join the same modifier slot as `async`/`deferred`. `idempotent` is a
        # reserved keyword (item 44), so the lexer needs no change; the confined
        # reach clause is consumed above, so a `(` after `idempotent` here can
        # only be the key role bracket (no ambiguity, design §1). Validity
        # (emission-only, param exists + scalar) is enforced in lower.
        async_ = False
        deferred = False
        idempotent = False
        idempotency_key: str | None = None
        # item 257: `validated`, a CONTEXTUAL keyword (matched on the ident, like
        # `deferred`) recognised only in this modifier slot, so no program that
        # used `validated` as an ordinary name is broken and the lexer needs no
        # sync. Validity (emission-only, non-`Unit`) is enforced in lower.
        validated = False
        # item 257 (Slice 2): `retry N`, a CONTEXTUAL keyword (matched on the
        # ident, like `validated`/`deferred`) recognised only in this modifier
        # slot, so no program using `retry` as an ordinary name is broken and the
        # lexer needs no sync. `N` is a positive integer literal; the "legal only
        # with `validated`" rule is enforced in lower.
        retry_budget = 0
        retry_seen = False
        while True:
            if self.at("kw", "async") and not async_:
                self.next()
                async_ = True
            elif self.at("ident", "deferred") and not deferred:
                self.next()
                deferred = True
            elif self.at("ident", "validated") and not validated:
                self.next()
                validated = True
            elif self.at("ident", "retry") and not retry_seen:
                self.next()
                retry_budget = self._retry_budget()
                retry_seen = True
            elif self.at("kw", "idempotent") and not idempotent:
                self.next()
                idempotent = True
                if self.at("("):
                    idempotency_key = self._idempotency_key_clause()
            else:
                break
        self.expect("kw", "fn")
        # item 388: the caller-decided colour marker `fn|async`. It sits right
        # after `fn` (not in the pre-`fn` modifier slot) and reads as "either
        # colour": one authored body, colour decided at each call site. `async`
        # is a reserved keyword, so the lexer needs no change; a bare `fn` is
        # byte-identical. Validity (emission-only, not `deferred`, not also a
        # fixed `async`) is enforced in lower with honest messages.
        colour_poly = False
        if self.at("|"):
            self.next()
            self.expect("kw", "async",
                        what="`async` after `fn|` — the caller-decided colour "
                             "marker `fn|async` (item 388)")
            colour_poly = True
        name = self.expect("ident").value
        type_params = self._type_param_list()
        self.expect("(")
        params: list[FnParam] = []
        while not self.at(")"):
            pline = self.peek().line
            pname = self._name()
            self.expect(":")
            ptype = self.type_()
            params.append(FnParam(pname, ptype, pline))
            if self.at(","):
                self.next()
        self.expect(")")
        returns = None
        if self.at("arrow"):
            self.next()
            returns = self.type_()
        # item 310: the `cache` trailing clause, after the return type and before
        # the teardown clauses (design §Surface: "before `=` or `undo`"). Grammar-
        # legal but admission-refused for externs until the interior-crossing slice
        # lands (the extern crossing is interior to a called body). `cache` is a
        # contextual keyword, so an extern with no clause is byte-identical.
        cache = None
        if self.at("ident", "cache"):
            cache = self._cache_clause()
        undo = None
        undo_idempotent = False
        undo_read = False
        compensate = None
        if self.at("kw", "undo"):
            self.next()
            # item 309: an optional `idempotent` between `undo` and the inverse
            # expression. The word is reserved (item 44) and an inverse fn named
            # `idempotent` is impossible, so accepting the kw token here is
            # unambiguous (design §1a). It scopes the `undo(undo(s)) = undo(s)`
            # claim to this inverse, not the forward mutation.
            # item 440: `undo pure <inverse>(result)` — the READ tier, the
            # third register value, in the same slot and on the same argument:
            # `pure` is reserved, so an inverse fn named `pure` is impossible and
            # the kw token here is unambiguous. Both words are ACCEPTED here (in
            # either order) so that writing both gets an honest "two different
            # claims about one inverse" diagnostic from lower rather than a bare
            # parse error pointing at the inverse expression.
            while True:
                if self.at("kw", "idempotent") and not undo_idempotent:
                    self.next()
                    undo_idempotent = True
                elif self.at("kw", "pure") and not undo_read:
                    self.next()
                    undo_read = True
                else:
                    break
            undo = self.pure_expr()
        if self.at("kw", "compensate"):
            self.next()
            compensate = self.pure_expr()
        # item 246: the declaration-owned `requires approval` clause (a contextual
        # `approval` after the `requires` keyword, so the keyword set is untouched).
        requires_approval = False
        if self.at("kw", "requires"):
            self.next()
            self.expect("ident", "approval",
                        what="`approval` after `requires` (item 246)")
            requires_approval = True
        # item 379: an optional typed `config { ... }` block, reusing the same
        # `config_block()` a component uses (parser.py:1352-1365). It sits after
        # the teardown/approval clauses and before the `= @backend` bodies, the
        # last declaration-level clause. `config` is already a reserved keyword
        # (recognised in `component`), so the lexer needs no change and an
        # extern with no block is byte-identical.
        config: list[ConfigField] = []
        if self.at("kw", "config"):
            config = self.config_block()
        bodies: list[HostBody | HostBodyFile | HostRef] = []
        while self.at("="):
            self.next()
            if self.at("hostbody"):
                host_tok = self.next()
                backend, text = host_tok.value
                bodies.append(HostBody(backend, text, host_tok.line))
            elif self.at("@"):
                # item 396: the two file/module body forms. When `@py` is NOT
                # followed by `{`, the lexer emits a plain `@` token and re-lexes
                # the backend word as an ordinary identifier (lexer.py:322-324),
                # so both spellings need ZERO lexer change. `file`/`ref`/`from`
                # are CONTEXTUAL keywords recognised only in this slot (the
                # discipline `witnessed`/`deferred`/`confined` use), so the
                # KEYWORDS set is untouched and no program using them as names is
                # broken. The parser stays IO-free: it records the path (and, for
                # a ref, the symbol) and the compiler reads it, jailed.
                at_line = self.next().line
                backend = self.expect(
                    "ident",
                    what="a backend name after `@` (e.g. `@py file ...` or "
                         "`@py ref sym from ...`)").value
                if self.at("ident", "ref"):
                    # option B: `= @backend ref sym from "path"`
                    self.next()
                    sym_tok = self.expect(
                        "ident",
                        what="a host symbol name after `ref` (the identifier to "
                             "import from the referenced module, item 396)")
                    self.expect(
                        "ident", "from",
                        what='`from` — the host-import form `@backend ref sym '
                             'from "path"` (item 396)')
                    path_tok = self.expect(
                        "string", what="a host-module file path string")
                    bodies.append(HostRef(backend, sym_tok.value,
                                          path_tok.value, at_line))
                else:
                    # option A: `= @backend file "path"`
                    self.expect(
                        "ident", "file",
                        what='`file` — the external host-body form `@backend '
                             'file "path"`, or `ref sym from "path"` — the '
                             'host-import form (item 396)')
                    path_tok = self.expect("string",
                                           what="a host-body file path string")
                    bodies.append(HostBodyFile(backend, path_tok.value, at_line))
            else:
                tok = self.peek()
                raise self.err(
                    tok.line,
                    f"expected a `@backend {{ ... }}` host body, a `@backend "
                    f'file "path"` reference, or a `@backend ref sym from '
                    f'"path"` import after `=`, found {tok.value!r}')
        if not bodies:
            raise self.err(line, f"extern `{name}` must declare at least one `@backend {{ ... }}` body")
        return ExternDecl(name, classification, params, returns, undo, compensate, bodies, public, line,
                          capabilities=capabilities, type_params=type_params, async_=async_,
                          deferred=deferred, requires_approval=requires_approval,
                          reach=reach, config=config, colour_poly=colour_poly,
                          undo_idempotent=undo_idempotent, undo_read=undo_read,
                          idempotent=idempotent,
                          idempotency_key=idempotency_key, cache=cache,
                          validated=validated, retry=retry_budget)

    def _retry_budget(self) -> int:
        """The positive integer literal after a `retry` modifier (item 257 §5.2).

        `retry N` sets the validation-retry budget (attempts beyond the first) on
        a `validated` emission. `N` must be a positive literal — a `retry 0` (or a
        negative / non-integer) is refused here, because absent-clause already
        means zero and a written budget that does nothing is a mistake, not a
        no-op. The "legal only alongside `validated`" rule is enforced in lower,
        next to the sibling modifier-validity checks."""
        ntok = self.expect(
            "int", what="a positive integer retry budget after `retry` "
                        "(the attempts beyond the first, item 257 §5.2)")
        if ntok.value < 1:
            raise self.err(
                ntok.line,
                f"`retry` budget must be a positive integer, found {ntok.value}",
                hint="`retry N` sets the attempts BEYOND the first; omit the "
                     "clause for no retry (the budget defaults to 0, one attempt)")
        return ntok.value

    def _reach_clause(self) -> tuple[str, str]:
        """`(confined: <param>)` after an emission classification — item 373.

        The reach clause names what an emission crossing is BOUNDED to. `confined`
        is a CONTEXTUAL keyword recognised only in this slot (the discipline
        `witnessed`/`deferred` use), so the lexer's KEYWORDS set needs no sync and
        no program that used `confined` as an ordinary name is broken. The target
        is a bare ident naming the parameter that carries the confinement region;
        it is not resolved here (params are parsed just below) — lower checks it
        against the actual parameter list. `confined` is the only reach kind for
        now; the shape leaves room for more (the returned kind is carried through).
        """
        self.expect("(")
        kind = self.expect("ident", "confined",
                           what="`confined` — the reach kind (item 373)").value
        self.expect(":", what="`:` after the reach kind")
        target = self.expect("ident", what="the parameter the crossing is "
                                            "confined to").value
        self.expect(")")
        return (kind, target)

    def _idempotency_key_clause(self) -> str:
        """`(key: <param>)` after `idempotent` in the extern modifier slot — the
        keyed idempotency role, item 309 §1b.

        Names WHICH declared parameter carries the value the remote dedups on.
        This is the item-373 `confined:` precedent (a role annotation on the
        signature, checked against the parameter list in lower — NOT resolved
        here, since the parameters are parsed just below). `key` is a contextual
        word recognised only in this slot, so the lexer's KEYWORDS set needs no
        sync. The value is per-call DYNAMIC data that flows to the host, not a
        294 capability valuation (design §1c)."""
        self.expect("(")
        self.expect("ident", "key",
                    what="`key` — the idempotency key role (`idempotent(key: "
                         "<param>)`, item 309)")
        self.expect(":", what="`:` after `key`")
        target = self.expect("ident",
                             what="the parameter carrying the idempotency key").value
        self.expect(")")
        return target

    def _capability_list(self, kind: str = "emission") -> tuple[str, ...]:
        """`[a, b]` after `emission`/`witnessed` — the boundaries this operation
        may cross.

        Names are wiring names, not types: a requirement/provision key or an
        `emission` extern (docs/capabilities.md). They are not resolved here —
        a service is written before its providers exist — the G4 check in
        lower.py compares them against what a provider's body actually reaches.

        An entry may be a realm-style dotted token (`gateway.send`,
        `production.payment`) so an emission scope names the same tokens the
        item-246 `Approval[C]` / item-33 policy grammar do (item 343). A bare
        ident is the single-segment case, so every pre-343 `witnessed[fs]` list
        parses to the same tokens byte-for-byte.
        """
        line = self.expect("[").line
        names: list[str] = []
        while not self.at("]"):
            parts = [self.expect("ident", what="a capability name").value]
            while self.at("."):
                self.next()
                parts.append(self.expect("ident").value)
            names.append(self._capability_params(".".join(parts)))
            if self.at(","):
                self.next()
        self.expect("]")
        if not names:
            raise self.err(
                line,
                f"`{kind}[]` names no capability, so it forbids every crossing",
                hint="an operation that may not cross a boundary is a plain `fn` — "
                     f"drop the `{kind}` modifier instead (G4)",
            )
        seen: set[str] = set()
        for cap in names:
            if cap in seen:
                raise self.err(line, f"duplicate capability `{cap}` in `{kind}[...]`")
            seen.add(cap)
        return tuple(names)

    def _capability_params(self, token: str) -> str:
        """An optional parenthesized literal parameter list on a dotted
        capability token (item 294): `fs.write(path="/data/incoming")`,
        `db.read(table="orders")`, `model.complete(calls=3)`. A bare token with
        no `(` returns unchanged (byte-identical to every pre-294 token), so the
        extension is purely additive.

        Values are STATIC literals (a string or a non-negative integer). The
        parse funnels through `cap_order.make_cap`, the ONE canonical point: it
        validates against the CLOSED parameter registry (an unknown name like
        `pth=` refuses HERE, at parse, never silently inert), canonicalizes a
        path value (trailing slash dropped, `.`/`..`/`//`/`"/"` refused), refuses
        a parameter list on `*` and duplicate keys, and returns the canonical
        `(T, P)`, stored as its canonical spelling so the fold re-reads it at a
        single point."""
        if not self.at("("):
            return token
        from . import cap_order  # noqa: PLC0415 - lazy, avoids an import cycle
        line = self.next().line          # consume `(`
        raw: list[tuple[str, object]] = []
        while not self.at(")"):
            name = self.expect("ident", what="a capability parameter name").value
            self.expect("=", what="`=` after a capability parameter name")
            vtok = self.peek()
            if vtok.kind in ("string", "int"):
                self.next()
                value: object = vtok.value
            else:
                raise self.err(
                    vtok.line,
                    "a capability parameter value must be a string or integer "
                    f"literal, found {vtok.value!r}",
                    hint='write `path="/data/incoming"` or `calls=10`; a '
                         "per-instance value (`config.job_root`) is item 294 "
                         "Slice 2")
            raw.append((name, value))
            if self.at(","):
                self.next()
        self.expect(")")
        try:
            return cap_order.make_cap(token, raw).to_str()
        except cap_order.CapError as exc:
            raise self.err(line, str(exc), hint=exc.hint) from exc

    def _capability_token(self, what: str = "a capability token") -> str:
        """One capability token in an `Approval[C]` type or an `await
        approval[C]` form (item 246). A token names a boundary, not a type, so it
        is a string literal (`"production.payment"`), a dotted-ident path
        (`production.payment`), or a bare ident (`payment`) — never `*`, since an
        unnameable reach can never be approved into (Decision 1, the `*` row)."""
        tok = self.peek()
        if tok.kind == "string":
            self.next()
            token = tok.value
        else:
            parts = [self.expect("ident", what=what).value]
            while self.at("."):
                self.next()
                parts.append(self.expect("ident").value)
            token = ".".join(parts)
        if token == "*":
            # item 246, the `*` row (Decision 1): an unnameable reach can never be
            # proven reversible, so no approval shape can name it — no
            # `await approval["*"]`, no `Approval[*]`. A `*` crossing receives only
            # the per-call ticket, every time.
            raise self.err(
                tok.line,
                "`*` is not an approvable capability — an unnameable reach cannot "
                "be approved into (item 246, the `*` row)",
                hint="a bare `emission` reach is class (c) and receives the "
                     "per-call ticket, not a typed `Approval`")
        return token

    def _cache_clause(self) -> "CacheClause":
        """`cache (pure|capability|external) (invalidated_by <tok> (, <tok>)*)?
        (ttl <dur>)?` — the item-310 trailing clause after a return type.

        `cache` is a CONTEXTUAL keyword: the caller checks `at("ident", "cache")`
        in the post-return-type slot only, so a `cache` used as an ordinary name
        elsewhere is untouched (examples/handoff_cache.rvl). The class word is
        `pure` (a reserved keyword) or `capability`/`external` (contextual idents).
        `invalidated_by` takes shared dotted capability tokens; because it always
        consumes at least one token immediately, `... invalidated_by ttl ttl 5m`
        reads the FIRST `ttl` as the token then the SECOND as the clause head (the
        namespaces overlap, design §Surface). The per-class validity (freshness
        rules, class-vs-reach) is checked in lower, not here."""
        line = self.next().line   # consume the contextual `cache`
        if self.at("kw", "pure"):
            self.next()
            cls = "pure"
        elif self.at("ident", "capability"):
            self.next()
            cls = "capability"
        elif self.at("ident", "external"):
            self.next()
            cls = "external"
        else:
            tok = self.peek()
            raise self.err(
                tok.line,
                f"`cache` must name a class — `pure`, `capability`, or "
                f"`external` — found {tok.value!r}",
                hint="`cache pure` memoizes a pure function; `cache capability` "
                     "a capability-backed deterministic read; `cache external` "
                     "an external read (which requires a freshness bound) "
                     "(docs/design/310-capability-aware-caching.md)")
        invalidated_by: list[str] = []
        if self.at("ident", "invalidated_by"):
            self.next()
            invalidated_by.append(self._capability_token(
                what="an `invalidated_by` capability token"))
            while self.at(","):
                self.next()
                invalidated_by.append(self._capability_token(
                    what="an `invalidated_by` capability token"))
        ttl_ms: int | None = None
        if self.at("ident", "ttl"):
            self.next()
            ttl_ms = self._cache_duration()
        # duplicate-token guard, so a mis-typed `invalidated_by a, a` is caught
        # at parse (the same posture `_capability_list` takes on the scope list)
        seen: set[str] = set()
        for tok in invalidated_by:
            if tok in seen:
                raise self.err(
                    line, f"duplicate `invalidated_by` token `{tok}`")
            seen.add(tok)
        return CacheClause(cls, tuple(invalidated_by), ttl_ms, line)

    def _cache_duration(self) -> int:
        """A `ttl` duration in the clause slot — `<n>[ms|s|m|h]`, bare number
        seconds. The rvl lexer has no duration token, so `5m` arrives as an `int`
        `5` then the `ident` `m`, and `500ms` as `int 500` then `ident ms`. The
        value is funnelled through `policy._parse_ttl` so the source surface and
        the policy-string surface cannot drift (design §`ttl`)."""
        from . import policy  # noqa: PLC0415 - lazy, avoids an import cycle
        ntok = self.expect("int", what="a `ttl` duration count (an integer)")
        unit = ""
        if self.at("ident") and self.peek().value in ("ms", "s", "m", "h"):
            unit = self.next().value
        try:
            return policy._parse_ttl(f"{ntok.value}{unit}")
        except ValueError as exc:
            raise self.err(ntok.line, str(exc)) from None

    def _endorse_slot(self) -> frozenset:
        """Consume zero or more `endorse[<origin>[, <origin>...]]` declaration
        modifiers (roadmap item 249, Slice C) and return the declared origin set.

        The slot is spelled in the same bracket style as `emission[cap]`, so a
        declaration reads its declassification rights the way it reads its
        emission scope. `endorse` is not a reserved keyword (it is an ident whose
        expression form is intercepted in `_primary`), so the modifier is matched
        on the ident, not a kw."""
        origins: set[str] = set()
        while self.at("ident", "endorse"):
            self.next()
            self.expect("[", what="`[<origin>]` after `endorse` (the taint class "
                             "this declaration may declassify, item 249)")
            origins.add(self.expect("ident").value)
            while self.at(","):
                self.next()
                origins.add(self.expect("ident").value)
            self.expect("]")
        return frozenset(origins)

    def service(self, commutative: bool = False) -> ServiceDecl:
        line = self.expect("kw", "service").line
        name = self.expect("ident").value
        self.expect("{")
        methods: dict[str, MethodDecl] = {}
        while not self.at("}"):
            emission = False
            capabilities: tuple[str, ...] | None = None
            endorse_origins: frozenset = frozenset()
            async_ = False
            method_commutative = False
            method_idempotent = False
            # item 257: `validated`, a contextual keyword in the method modifier
            # slot (matched on the ident, like `endorse`), so `validated` stays a
            # legal ordinary name elsewhere. Emission-only, non-`Unit`, in lower.
            method_validated = False
            # item 257 (Slice 2): `retry N` in the method modifier slot, a
            # contextual keyword (matched on the ident, like `validated`). `0` is
            # the absent clause (byte-identical); `retry N` is a positive literal.
            # Legal only alongside `validated`, checked in lower.
            method_retry = 0
            mline = self.peek().line
            while (self.at("kw") and self.peek().value in ("emission", "async", "commutative", "idempotent")) \
                    or self.at("ident", "endorse") or self.at("ident", "validated") \
                    or self.at("ident", "retry"):
                if self.at("ident", "endorse"):
                    endorse_origins = endorse_origins | self._endorse_slot()
                    continue
                if self.at("ident", "validated"):
                    self.next()
                    method_validated = True
                    continue
                if self.at("ident", "retry"):
                    self.next()
                    method_retry = self._retry_budget()
                    continue
                modifier = self.next().value
                if modifier == "emission":
                    emission = True
                    # `emission[db, log]`: the bracket is revl's existing
                    # parameterisation bracket (`List[Row]`, `Map[Str, Int]`),
                    # so this reads as "emission, parameterised by the
                    # boundaries it may cross". Bare `emission` stays "any".
                    if self.at("["):
                        capabilities = self._capability_list()
                elif modifier == "async":
                    async_ = True
                elif modifier == "commutative":
                    method_commutative = True
                else:
                    # TODO(309-slice1): accept the `idempotent(key: p)` keyed form
                    # on a service-method emission too (design §1b, "extends to
                    # service-method emissions for symmetry with item 44"). The
                    # extern modifier slot already parses it; the service-method
                    # register is `declared` until this lands.
                    method_idempotent = True
            # `idempotent` is a delivery property, and only an emission is
            # delivered: a plain `fn` never crosses the boundary, so it has
            # nothing to re-deliver. Reject the claim rather than silently
            # dropping it (docs/delivery-semantics.md).
            if method_idempotent and not emission:
                raise self.err(
                    mline,
                    "`idempotent` describes how an emission is delivered, so it "
                    "is only meaningful on an `emission` operation",
                    hint="write `emission idempotent fn ...`; a plain `fn` is not "
                         "delivered, so there is nothing to re-deliver",
                )
            self.expect("kw", "fn")
            mname = self.expect("ident").value
            self.expect("(")
            params: list[tuple[str, str]] = []
            while not self.at(")"):
                pname = self._name()
                self.expect(":")
                params.append((pname, self.type_()))
                if self.at(","):
                    self.next()
            self.expect(")")
            returns = None
            if self.at("arrow"):
                self.next()
                returns = self.type_()
            # item 310: the `cache` trailing clause, after the return type. `cache`
            # is a contextual keyword recognised only here, so a method with no
            # cache clause is byte-identical and a service using `cache` as a key
            # name elsewhere is untouched.
            cache = None
            if self.at("ident", "cache"):
                cache = self._cache_clause()
            if mname in methods:
                raise self.err(mline, f"duplicate method `{mname}` in service {name}")
            methods[mname] = MethodDecl(
                mname, params, returns, emission, mline, async_=async_,
                commutative=method_commutative, idempotent=method_idempotent,
                capabilities=capabilities, endorse_origins=endorse_origins,
                cache=cache, validated=method_validated, retry=method_retry,
            )
        self.expect("}")
        return ServiceDecl(name, methods, line, commutative=commutative)

    def type_(self) -> str:
        """A type. `(` heads either a function type or a grouped type.

        The function type is spelled `(Int, Str) -> Bool` — syntax-2.0 §2 keeps
        type syntax revl's own, and `->` is already revl's return arrow in
        `fn`, `extern` and service signatures, so a function type reads as the
        signature it is with the parameter names elided. (TS's `(a: number) =>
        boolean` is not adopted: it *requires* parameter names, so the "same
        meaning → same syntax" premise of §0 fails.) See docs/function-types.md.
        """
        if self.at("("):
            line = self.next().line
            inner: list[str] = []
            while not self.at(")"):
                inner.append(self.type_())
                if self.at(","):
                    self.next()
            self.expect(")")
            if self.at("arrow"):
                self.next()
                # the return type is parsed as a full type, so `(Int) -> Str?`
                # is `(Int) -> Opt[Str]` and a right-nested `(Int) -> (Str) ->
                # Bool` associates to the right, as in every ML-family language
                return f"({', '.join(inner)}) -> {self.type_()}"
            if len(inner) != 1:
                raise self.err(
                    line,
                    f"`({', '.join(inner)})` is not a type — revl has no tuples",
                    hint="a parenthesised type group holds exactly one type; "
                         "a function type needs a `-> ReturnType` "
                         "(docs/function-types.md)",
                )
            # a grouped type: `((Int) -> Bool)?` is how an *optional function*
            # is spelled, since a trailing `?` otherwise binds to the return
            return self._type_suffix_tail(inner[0])
        return self._type_suffix(self.expect("ident", what="a type").value)

    def _type_suffix(self, base: str) -> str:
        """The `[...]` / `?` tail of a type, given its head.

        Split out of `type_` so `type X = List[Row]` can decide *after* reading
        the head that what follows is a type application rather than a variant
        case (a case is a bare name with an optional parenthesised payload, so
        `[` or `?` here is unambiguous)."""
        # item 246: `Approval[C]` carries a capability TOKEN, not a type — the
        # bracket argument may be a string literal or a dotted path, which the
        # ordinary type-application tail (which expects a type) cannot read.
        if base == "Approval" and self.at("["):
            self.next()
            token = self._capability_token()
            self.expect("]")
            return self._type_suffix_tail(f"Approval[{token}]")
        if self.at("["):
            self.next()
            inner = [self.type_()]
            while self.at(","):
                self.next()
                inner.append(self.type_())
            self.expect("]")
            # item 130: `Stream[T]` / `Stream[T, State]`. The optional second
            # argument is the state index, `State ∈ {Created, Active, Paused,
            # Closed}` (docs/design/130-stream-reactive-types.md §1). The checker
            # uses the index for linearity and use-after-close; a stray arity or a
            # non-state second argument is a type-formation error caught here.
            if base == "Stream":
                if len(inner) not in (1, 2):
                    raise self.err(
                        self.peek().line,
                        f"`Stream` takes 1 or 2 type arguments, got {len(inner)}",
                        hint="a stream is `Stream[T]` or the state-indexed "
                             "`Stream[T, State]` with `State ∈ {Created, Active, "
                             "Paused, Closed}` (item 130)")
                if len(inner) == 2 and inner[1] not in _STREAM_STATES:
                    raise self.err(
                        self.peek().line,
                        f"`Stream`'s second argument must be a state, got "
                        f"`{inner[1]}`",
                        hint="the state index is one of `Created`, `Active`, "
                             "`Paused`, `Closed` (item 130 §1)")
            rendered = f"{base}[{', '.join(inner)}]"
        else:
            rendered = base
        return self._type_suffix_tail(rendered)

    def _type_suffix_tail(self, rendered: str) -> str:
        """The `?` tail alone, given an already-rendered type."""
        if self.at("?"):
            self.next()
            rendered = f"Opt[{rendered}]"  # T? sugar (syntax-2.0 §2)
        return rendered

    def _provision_key(self, what: str = "a provision key") -> str:
        """A provision key, optionally namespace-qualified as `ns::key`
        (docs/namespacing.md).

        The `::` separator is two adjacent `:` tokens, so this is a pure
        parser addition — the lexer is untouched. An unqualified key returns
        its bare identifier verbatim, so v1 programs lower byte-for-byte as
        before; a qualified key returns the joined `ns::local` string, which
        is the key's wiring identity (G2 / injection resolution)."""
        first = self.expect("ident", what=what).value
        # `ns::local`: a `:` immediately followed by another `:`. A single
        # `:` here is the ordinary `key: Service` separator and is left alone.
        if self.at(":") and self.peek_ahead(1).kind == ":":
            self.next()  # first `:`
            self.next()  # second `:`
            local = self.expect("ident", what="a key after `::`").value
            return f"{first}::{local}"
        return first

    def component(self, boot: bool = False) -> ComponentDecl:
        line = self.expect("kw", "component").line
        name = self.expect("ident").value
        requires: list[tuple[str, str, int]] = []
        provides: list[tuple[str, str, int]] = []
        require_carry: dict = {}
        while self.at("kw", "requires") or self.at("kw", "provides"):
            kw = self.next().value
            target = requires if kw == "requires" else provides
            while True:
                bline = self.peek().line
                local = self._provision_key(what="a requirement or provision key")
                self.expect(":")
                svc = self.expect("ident").value
                target.append((local, svc, bline))
                # item 296: an optional `carrying(tok, ...)` clause on a
                # *require* binding declares the capability tokens this alias's
                # emission crossings contribute (alias token carry-over). A
                # contextual ident so no keyword is added.
                if kw == "requires" and self.at("ident", "carrying"):
                    self.next()
                    require_carry[local] = self._carry_tokens()
                # a comma continues the same clause; `requires`/`provides`/`{` end it
                if self.at(","):
                    self.next()
                else:
                    break
        self.expect("{")
        config: list[ConfigField] = []
        body: list = []
        while True:
            self._skip_semis()
            if self.at("}"):
                break
            if self.at("kw", "config"):
                if config:
                    raise self.err(self.peek().line, f"duplicate `config` block in component {name}")
                config = self.config_block(boot=boot, owner=name)
            else:
                body.append(self.stmt(in_method=False))
        self.expect("}")
        return ComponentDecl(name, config, requires, provides, body, line,
                             require_carry=require_carry, boot=boot)

    # -- item 426 S1: the composition document -----------------------------

    def _row_label(self) -> str:
        """`@label` — the `@` token followed by a name.

        No lexer change: `@` heads a host body only when the identifier after it
        is followed by `{` (lexer.py:422-446), and a row label never is. NOTE
        for 426 S2: `configure @db { ... }` DOES put a `{` after the label, so
        that spelling lexes as a `@db` HOST BODY and the fold's parser must
        either take a different shape or the lexer must learn the composition
        context. Recorded here rather than discovered there."""
        self.expect("@", what="`@` before a row label")
        return self._name(what="a row label after `@`")

    def composition_decl(self) -> CompositionDecl:
        line = self.next().line                       # `composition`
        name = self.expect("ident", what="a composition name").value
        self.expect("{")
        rows: list[RowDecl] = []
        remotes: list[RemoteRowDecl] = []
        uses: list[tuple[str, int]] = []
        stack: list[tuple[str, int]] = []
        site: tuple[str, int] | None = None
        seen: dict[str, int] = {}
        while True:
            self._skip_semis()
            if self.at("}"):
                break
            if self.at("kw", "use"):
                uline = self.next().line
                uses.append((self.expect("string", what="a module path string").value, uline))
                continue
            if self.at("ident", "stack"):
                # item 426 S2 §3.1: a LEVEL 1 peer. The list is ORDERED in the
                # file, but the fold's result does not depend on that order —
                # peer conflicts refuse rather than resolving by position
                # (§3.4), so the order only ever decides message ordering.
                sline = self.next().line
                stack.append((self.expect("string", what="a layer path string").value, sline))
                continue
            if self.at("ident", "site"):
                sline = self.next().line
                if site is not None:
                    raise self.err(
                        sline,
                        f"composition {name} declares a second `site` layer",
                        hint="there is exactly ONE site layer (426 §3.1): it is "
                             "the single level at which the operator resolves a "
                             "peer conflict, and a precedence order between two "
                             "site layers would be precedence choosing a "
                             "provider, which decision 4 forbids")
                site = (self.expect("string", what="a layer path string").value, sline)
                continue
            if self.at("ident", "remote"):
                # item 424 C2: a row whose provider is SYNTHESIZED from a
                # service declaration plus a peer address (D-424c.1).
                remote = self.remote_row_decl(name)
                self._composition_label(name, remote.label, remote.line, seen)
                remotes.append(remote)
                continue
            if not self.at("ident", "row"):
                tok = self.peek()
                raise self.err(
                    tok.line,
                    "expected `row`, `remote`, `use`, `stack`, `site`, or "
                    f"`}}` in composition {name}, found {tok.value!r}",
                    hint="a composition document declares rows: "
                         '`row @label from "path.rvl" provides key`, or '
                         '`remote @label provides key: Service at host("h:port")`')
            rows.append(self.row_decl(name))
            self._composition_label(name, rows[-1].label, rows[-1].line, seen)
        self.expect("}")
        return CompositionDecl(name, rows, line, uses, stack=stack,
                               site=site, remotes=remotes)

    def _composition_label(self, composition: str, label: str, line: int,
                           seen: dict[str, int]) -> None:
        """426 §1.2: two labels with the same spelling WITHIN ONE ORIGIN is a
        refusal at parse time, the same shape as a duplicate component name.
        Across origins they are distinct qualified labels and do not collide,
        which is why this check is per document.

        One namespace, not two: a `remote` row's label is a row label like any
        other, so `@billing` cannot be both a file row and a remote row. The
        whole point of D-424c.1 is that a consumer cannot tell the difference,
        and two rows that a consumer cannot tell apart must not share a name.
        """
        if label in seen:
            raise self.err(
                line,
                f"duplicate row label `@{label}` in composition "
                f"{composition} (first declared on line {seen[label]})",
                hint="a label is the row's identity and is scoped to this "
                     "document's origin, so it must be unique here (426 §1.2); "
                     "a `remote` row shares that one namespace, because a "
                     "consumer cannot tell the two apart (424 D-424c.1)")
        seen[label] = line

    def row_decl(self, composition: str) -> RowDecl:
        line = self.next().line                       # `row`
        label = self._row_label()
        if not self.at("ident", "from"):
            tok = self.peek()
            raise self.err(tok.line,
                           f"expected `from` after row label `@{label}`, "
                           f"found {tok.value!r}",
                           hint='a row names its source file: `row @%s from '
                                '"path.rvl" provides key`' % label)
        self.next()
        path = self.expect("string", what="a row source path string").value
        if not path:
            raise self.err(line, f"row `@{label}` has an empty `from` path")
        # 426 §1.3: the claim assertion is REQUIRED. It is what makes the
        # document unable to lie about the wiring, and `provides nothing` is the
        # ordinary spelling for a sink row, not a special case.
        if not self.at("kw", "provides"):
            tok = self.peek()
            raise self.err(tok.line,
                           f"expected `provides` after the `from` path of row "
                           f"`@{label}`, found {tok.value!r}",
                           hint="every row asserts what it claims; a row that "
                                "claims nothing writes `provides nothing` "
                                "(426 §1.3)")
        self.next()
        claims: list[tuple[str, int]] = []
        if self.at("ident", "nothing"):
            self.next()
        else:
            while True:
                kline = self.peek().line
                claims.append((self._provision_key(what="a provision key"), kline))
                if self.at(","):
                    self.next()
                    continue
                break
        component: str | None = None
        config: list[tuple[str, object, int]] = []
        granted: list[tuple[str, int]] | None = None
        while True:
            if self.at("kw", "component"):
                cline = self.next().line
                if component is not None:
                    raise self.err(cline, f"duplicate `component` clause on row `@{label}`")
                component = self.expect("ident", what="a component name").value
            elif self.at("kw", "config"):
                cline = self.peek().line
                if config:
                    raise self.err(cline, f"duplicate `config` clause on row `@{label}`")
                config = self.row_config_block(label)
            elif self.at("ident", "granted"):
                gline = self.next().line
                if granted is not None:
                    raise self.err(gline, f"duplicate `granted` clause on row `@{label}`")
                granted = []
                self.expect("{")
                while not self.at("}"):
                    kline = self.peek().line
                    granted.append((self._provision_key(what="a granted key"), kline))
                    if self.at(","):
                        self.next()
                self.expect("}")
            else:
                break
        return RowDecl(label, path, claims, line, component, config, granted)

    # -- item 426 S2: layers, addresses and the four operations -------------

    def _address(self) -> Address:
        """`key("db")`, `key("kv", realm: "t")`, `@db`, or `acme_pg::@db`.

        NOTE (the S1 finding, resolved): `configure @db { ... }` would put a `{`
        immediately after the label, and the lexer turns `@ident {` into a
        verbatim HOST BODY (lexer.py:422-446). The fold therefore spells it
        `configure @db with { ... }`, which is the shape `spawn C with { ... }`
        and `intercept k with { ... }` already use, and no lexer change is
        needed. `::` likewise reaches here as two `:` pieces rather than a new
        operator token, so the self-hosted lexer needs no sync either.
        """
        if self.at("hostbody"):
            # The S1 finding, caught rather than leaked: `@db {` never reaches
            # the parser as `@` + `db` + `{` — the lexer consumed it as a
            # verbatim `@db` HOST BODY (lexer.py:422-446), so the token here
            # carries the config block as opaque text. Say so instead of
            # printing the tuple.
            tok = self.peek()
            backend, _body = tok.value
            raise self.err(
                tok.line,
                f"`@{backend} {{ ... }}` is a HOST BODY, not a row address",
                hint=f"a brace cannot follow a row label: write `configure "
                     f"@{backend} with {{ ... }}`, the same shape `spawn C with "
                     "{ ... }` uses (426 S2)")
        if self.at("ident", "key"):
            line = self.next().line
            self.expect("(")
            key = self.expect("string", what="a provision key string").value
            realm = None
            if self.at(","):
                self.next()
                self.expect("kw", "realm", what="`realm:` inside `key(...)`")
                self.expect(":")
                realm = self.expect("string", what="a realm name string").value
            self.expect(")")
            if not key:
                raise self.err(line, "`key(\"\")` names no provision key")
            return Address("key", line, key=key, realm=realm)
        return self._label_address()

    def _label_address(self) -> Address:
        """`@db` (this layer's own origin) or `acme_pg::@db` (fully qualified).

        The origin is never MINTED by a document — it is read off where the
        document lives (426 §1.2) — but it is written here as the qualifier of a
        cross-origin reference, which is the only place it appears in source.
        """
        origin = None
        if self.at("."):
            # The PROJECT's own origin is spelled `.` (426 §1.2) — reserved and
            # unmintable by anyone else, so `.::@db` is how a layer names a row
            # the composition itself declared.
            self.next()
            origin = "."
        elif self.at("ident") and not self.at("ident", "key"):
            origin = self._name(what="an origin qualifier")
        if origin is not None:
            self.expect(":", what="`::` after an origin qualifier")
            self.expect(":", what="`::` after an origin qualifier")
        line = self.peek().line
        self.expect("@", what="`@` before a row label")
        return Address("label", line, label=self._name(what="a row label after `@`"),
                       origin=origin)

    def layer_decl(self, site: bool) -> LayerDecl:
        line = self.next().line                       # `layer`
        name = self.expect("ident", what="a layer name").value
        if not self.at("kw", "for"):
            tok = self.peek()
            raise self.err(
                tok.line,
                f"expected `for` after layer name `{name}`, found {tok.value!r}",
                hint="a layer names the composition it patches: "
                     f"`layer {name} for MyComposition {{ ... }}`")
        self.next()
        target = self.expect("ident", what="the composition this layer patches").value
        self.expect("{")
        ops: list[LayerOp] = []
        touches: list[Address] | None = None
        while True:
            self._skip_semis()
            if self.at("}"):
                break
            if self.at("ident", "touches"):
                tline = self.next().line
                if touches is not None:
                    raise self.err(tline, f"duplicate `touches` clause on layer `{name}`")
                touches = [self._address()]
                while self.at(","):
                    self.next()
                    touches.append(self._address())
                continue
            ops.append(self._layer_op(name, site))
        self.expect("}")
        return LayerDecl(name, target, ops, line, site=site, touches=touches)

    def _layer_op(self, layer: str, site: bool) -> LayerOp:
        tok = self.peek()
        if self.at("ident", "add"):
            oline = self.next().line
            if not self.at("ident", "row"):
                raise self.err(self.peek().line,
                               f"expected `row` after `add` in layer `{layer}`",
                               hint='`add row @label from "path.rvl" provides key`')
            return LayerOp("add", oline, row=self.row_decl(layer))
        if self.at("ident", "remove"):
            oline = self.next().line
            return LayerOp("remove", oline, address=self._address())
        if self.at("ident", "replace"):
            oline = self.next().line
            address = self._address()
            if not self.at("kw", "with"):
                raise self.err(self.peek().line,
                               f"expected `with` after `replace {address.spelling()}`",
                               hint=f"`replace {address.spelling()} with row @label "
                                    'from "path.rvl" provides key`')
            self.next()
            if not self.at("ident", "row"):
                raise self.err(self.peek().line,
                               f"expected `row` after `replace ... with` in layer `{layer}`")
            return LayerOp("replace", oline, address=address, row=self.row_decl(layer))
        if self.at("ident", "configure"):
            oline = self.next().line
            address = self._address()
            if not self.at("kw", "with"):
                raise self.err(
                    self.peek().line,
                    f"expected `with` after `configure {address.spelling()}`, "
                    f"found {self.peek().value!r}",
                    hint=f"the fields go in a `with` block: `configure "
                         f"{address.spelling()} with {{ field: value }}`. The "
                         "brace cannot follow the label directly — `@db {` is a "
                         "HOST BODY to the lexer (426 S2)")
            self.next()
            return LayerOp("configure", oline, address=address,
                           config=self._layer_config_block(layer, address))
        if self.at("ident", "resolve"):
            oline = self.next().line
            if not site:
                raise self.err(
                    oline,
                    f"`resolve` is a SITE layer operation, and `{layer}` is a "
                    "stack layer",
                    hint="a peer never resolves a peer conflict: refusal is only "
                         "meaningful between peers, and the operator is not a "
                         "peer (426 §3.4). Write it in the site layer")
            address = self._address()
            if not self.at("ident", "to"):
                raise self.err(self.peek().line,
                               f"expected `to` after `resolve {address.spelling()}`",
                               hint="`resolve key(\"db\") to acme::@db over corp::@db` "
                                    "— the operator names BOTH sides")
            self.next()
            winner = self._label_address()
            if not self.at("ident", "over"):
                raise self.err(self.peek().line,
                               "expected `over` after the winning row of a `resolve`",
                               hint="naming both sides is the point: the losing row "
                                    "is written down, never inferred (426 §3.4)")
            self.next()
            return LayerOp("resolve", oline, address=address,
                           winner=winner, loser=self._label_address())
        raise self.err(
            tok.line,
            f"expected `add`, `remove`, `replace`, `configure`"
            f"{', `resolve`' if site else ''}, `touches`, or `}}` in layer "
            f"`{layer}`, found {tok.value!r}",
            hint="there are four operations and no more (426 §3.2). There is no "
                 "positional operation: load order is derived from the wiring, "
                 "not declared, so no layer gets to reorder anything")

    def _layer_config_block(self, layer: str,
                            address: Address) -> list[tuple[str, object, int]]:
        """`with { field: value, ... }` on a `configure`.

        Merged into the target row's config and re-checked against the
        component's declared types, so a wrong-typed value is a REFUSAL and not
        a runtime surprise (426 §3.2, exit test 9)."""
        line = self.expect("{").line
        out: list[tuple[str, object, int]] = []
        seen: set[str] = set()
        while not self.at("}"):
            fline = self.peek().line
            field_name = self._name(what="a config field name")
            if field_name in seen:
                raise self.err(fline, f"duplicate config field `{field_name}` in "
                                      f"`configure {address.spelling()}` "
                                      f"(layer `{layer}`)")
            seen.add(field_name)
            self.expect(":")
            out.append((field_name, self.literal(), fline))
            if self.at(","):
                self.next()
        self.expect("}")
        if not out:
            raise self.err(line, f"`configure {address.spelling()}` sets no field "
                                 f"(layer `{layer}`)",
                           hint="an operation that changes nothing is dead weight in "
                                "the diff — drop it")
        return out
    def remote_row_decl(self, composition: str) -> RemoteRowDecl:
        """`remote @label provides <key>: <Service> [in realm("r")]
        at host("h:port") [through <ident>] [on_failure(withdraw|result)]
        [redirect(refuse|same_origin)]`

        Item 424 D-424c.1, slice C2. Every word this clause introduces is a
        CONTEXTUAL keyword read only here (`remote`, `at`, `host`, `through`,
        `on_failure`, `redirect`, and their arguments); `provides`, `in` and
        `realm` are
        the keywords the language already has. So the lexer stays context-free
        and the self-host lexer needs no sync — the same discipline 426 S2 chose
        for `configure @db with { ... }`, and the reason `remote` is not being
        promoted to a real keyword: `remote` is a perfectly ordinary provision
        key, require alias and config field name today, and reserving it would
        break those programs, force a matching edit in the self-host lexer, and
        put a second copy of the reserved-word set on every backend that
        re-derives it.

        Unlike a `row`, a `remote` names no `from` path: its provider does not
        exist as source until resolution synthesizes it from the service
        declaration and the peer address (§4 of the design note — the same
        `synthesize_provider` a config row, a seam forwarder and item 60's mock
        provider are the other three kinds of).
        """
        line = self.next().line                       # `remote`
        label = self._row_label()
        if not self.at("kw", "provides"):
            tok = self.peek()
            raise self.err(
                tok.line,
                f"expected `provides` after remote row label `@{label}`, "
                f"found {tok.value!r}",
                hint='a remote row names the key it claims AND the service it '
                     'remotes: `remote @%s provides key: Service at '
                     'host("h:port")`' % label)
        self.next()
        key = self._provision_key(what="a provision key")
        # The service name is REQUIRED and is not inferred from the key. A
        # remote row has no component header to check the claim against, so the
        # service declaration is the only contract there is; making the document
        # name it keeps the "a composition cannot lie about its wiring" property
        # 426 §1.3 buys for an ordinary row.
        if not self.at(":"):
            tok = self.peek()
            raise self.err(
                tok.line,
                f"expected `: <Service>` after `provides {key}` on remote row "
                f"`@{label}`, found {tok.value!r}",
                hint="a remote row has no component header, so the service "
                     "declaration IS its contract and the document names it "
                     "(424 D-424c.1)")
        self.next()
        service = self.expect("ident", what="a service name").value

        realm: str | None = None
        host: str | None = None
        host_line = line
        transport: str | None = None
        on_failure = "withdraw"
        on_failure_line = line
        redirect = "refuse"
        redirect_line = line
        while True:
            if self.at("kw", "in"):
                iline = self.next().line
                if realm is not None:
                    raise self.err(iline, f"duplicate `in realm(...)` clause on "
                                          f"remote row `@{label}`")
                # D-424c.4: `@RemoteScope` is a REALM and there is nothing to
                # build. Two peers of one service are two rows in two realms,
                # they are two different `(key, realm)` addresses, and G2 keeps
                # them from colliding with no new rule (426 §2.3).
                realm = self.realm_label()
            elif self.at("ident", "at"):
                aline = self.next().line
                if host is not None:
                    raise self.err(aline, f"duplicate `at host(...)` clause on "
                                          f"remote row `@{label}`")
                if not self.at("ident", "host"):
                    tok = self.peek()
                    raise self.err(tok.line,
                                   f"expected `host(\"...\")` after `at` on "
                                   f"remote row `@{label}`, found {tok.value!r}")
                self.next()
                self.expect("(")
                tok = self.peek()
                if tok.kind != "string":
                    raise self.err(
                        tok.line,
                        "a peer address is a static string literal",
                        hint="the address is read before the composition exists "
                             "and is exactly the class of value roadmap item 350 "
                             "binds through a `boot` component; until 350 lands "
                             "it is written here as a literal, never computed")
                host = self.next().value
                host_line = tok.line
                self.expect(")")
            elif self.at("ident", "through"):
                tline = self.next().line
                if transport is not None:
                    raise self.err(tline, f"duplicate `through` clause on remote "
                                          f"row `@{label}`")
                transport = self.expect("ident", what="a transport name").value
            elif self.at("ident", "on_failure"):
                on_failure_line = self.next().line
                self.expect("(")
                tok = self.peek()
                choice = tok.value if tok.kind == "ident" else None
                if choice not in ("withdraw", "result"):
                    raise self.err(
                        tok.line,
                        f"`on_failure` takes `withdraw` or `result`, found "
                        f"{tok.value!r}",
                        hint="`withdraw` (the default) reuses peer-death "
                             "withdrawal, R2/R3; `result` returns the failure "
                             "in-band and is admitted only if every method "
                             "returns `Result[T, E]`. Silently swallowing a "
                             "transport failure has no spelling (424 D-424c.3)")
                self.next()
                on_failure = choice
                self.expect(")")
            elif self.at("ident", "redirect"):
                redirect_line = self.next().line
                self.expect("(")
                tok = self.peek()
                choice = tok.value if tok.kind == "ident" else None
                if choice not in ("refuse", "same_origin"):
                    raise self.err(
                        tok.line,
                        f"`redirect` takes `refuse` or `same_origin`, found "
                        f"{tok.value!r}",
                        hint="`refuse` (the default) is the whole point of "
                             "writing the peer address on the row: a redirect "
                             "to another host would make the row stop "
                             "describing where the crossing goes. "
                             "`same_origin` follows a 307 or 308 that stays on "
                             "the declared origin, with the method and the body "
                             "intact; a 301/302/303 re-issues the POST as a GET "
                             "and is refused either way")
                self.next()
                redirect = choice
                self.expect(")")
            else:
                break

        if host is None:
            raise self.err(
                line,
                f"remote row `@{label}` names no peer address",
                hint='every remote row writes `at host("host:port")`; the reach '
                     "bound is derived from that host, and there is no default "
                     "peer to fall back to")
        return RemoteRowDecl(label, key, service, host, line, realm=realm,
                             transport=transport, on_failure=on_failure,
                             on_failure_line=on_failure_line,
                             redirect=redirect, redirect_line=redirect_line,
                             host_line=host_line)

    def row_config_block(self, label: str) -> list[tuple[str, object, int]]:
        """`config { field: <literal>, ... }` on a row.

        Values, not types: the component declares the typed `config` block and
        the row supplies constants for it, checked against those declared types
        at resolution (426 §3.2's "a value that does not fit the declared return
        type does not admit", applied to the base composition)."""
        self.expect("kw", "config")
        self.expect("{")
        out: list[tuple[str, object, int]] = []
        seen: set[str] = set()
        while not self.at("}"):
            fline = self.peek().line
            field_name = self._name(what="a config field name")
            if field_name in seen:
                raise self.err(fline, f"duplicate config field `{field_name}` on row `@{label}`")
            seen.add(field_name)
            self.expect(":")
            out.append((field_name, self.literal(), fline))
            if self.at(","):
                self.next()
        self.expect("}")
        return out

    def _carry_tokens(self) -> tuple[str, ...]:
        """`(cache, log)` after `carrying` on a require binding (item 296) — the
        consumer-facing capability tokens an aliased crossing contributes.

        The same wiring-name grammar as `emission[...]` (dotted tokens allowed),
        but parenthesised, since it annotates a require binding rather than an
        operation classification."""
        line = self.expect("(").line
        names: list[str] = []
        while not self.at(")"):
            parts = [self.expect("ident", what="a capability name").value]
            while self.at("."):
                self.next()
                parts.append(self.expect("ident").value)
            names.append(".".join(parts))
            if self.at(","):
                self.next()
        self.expect(")")
        if not names:
            raise self.err(
                line,
                "`carrying()` names no capability token",
                hint="a require that carries no token is an ordinary require — "
                     "drop the `carrying(...)` clause (item 296)")
        return tuple(names)

    def config_block(self, boot: bool = False, owner: str = "") -> list[ConfigField]:
        self.expect("kw", "config")
        self.expect("{")
        fields: list[ConfigField] = []
        while not self.at("}"):
            fline = self.peek().line
            fname = self._name()
            self.expect(":")
            ftype = self.type_()
            bound = self._config_bound(boot, owner, fname)
            default = None
            if self.at("="):
                self.next()
                default = self.literal()
            fields.append(ConfigField(fname, ftype, default, fline, bound=bound))
            if self.at(","):
                self.next()
        self.expect("}")
        return fields

    def _config_bound(self, boot: bool, owner: str, fname: str) -> dict | None:
        """The optional ADMISSION BOUND on a `boot component` config field
        (item 350): `under "<prefix>"` or `in [lit, ...]`, between the declared
        type and the `=` default.

        A bound is a check applied to the value the HOST injects, so it is legal
        only where host injection is contract-declared — inside a `boot`
        component. Allowing it on an ordinary component's config would ship
        grammar nothing enforces, which is the fail-open shape this item exists
        to remove, so it is refused there with the reason.

        `in` is already a keyword (realm placement); `under` is contextual and is
        recognised only in this slot, so the lexer (and the generated gate
        crate's frontier table) is untouched."""
        if not (self.at("ident", "under") or self.at("kw", "in")):
            return None
        tok = self.peek()
        if not boot:
            raise self.err(
                tok.line,
                f"config field `{fname}` declares a bound outside a `boot` component",
                hint="a bound is checked against the value the HOST injects, and host "
                     "injection is contract-declared only for the boot component — "
                     f"move `{fname}` into `boot component {owner or '<Boot>'}`'s config "
                     "block, or drop the bound (item 350)",
            )
        if self.at("ident", "under"):
            self.next()
            prefix = self.expect("string", what="a path prefix string after `under`").value
            if not prefix:
                raise self.err(tok.line, "`under` prefix cannot be empty",
                               hint="an empty prefix confines nothing — name the directory "
                                    "the injected path must stay inside (item 350)")
            return {"kind": "under", "prefix": prefix}
        self.next()  # `in`
        self.expect("[", what="`[` after `in` in a config bound")
        values: list = []
        while not self.at("]"):
            values.append(self.literal())
            if self.at(","):
                self.next()
        self.expect("]")
        if not values:
            raise self.err(
                tok.line,
                f"config field `{fname}` declares an empty `in [...]` bound",
                hint="an empty admissible set admits nothing, so the composition could "
                     "never boot — list the values the host may inject (item 350)",
            )
        return {"kind": "in", "values": values}

    def literal(self):
        tok = self.peek()
        if tok.kind == "-" and self.peek_ahead(1).kind == "int":
            self.next()
            return -self.next().value
        if tok.kind in ("int", "float"):
            return self.next().value
        if tok.kind == "string":
            return self.next().value
        if tok.kind == "template":
            raise self.err(tok.line, "config defaults cannot interpolate")
        if tok.kind == "kw" and tok.value in ("true", "false", "null"):
            self.next()
            return {"true": True, "false": False, "null": None}[tok.value]
        raise self.err(tok.line, f"expected a literal, found {tok.value!r}")

    def stmt(self, in_method: bool, in_async_method: bool = False):
        tok = self.peek()
        # `y = expr` — assignment to a `var` bound earlier in this method
        if in_method and tok.kind == "ident" and self.peek_ahead(1).kind == "=":
            self.next()
            self.next()
            return AssignStmt(tok.value, self.pure_expr(), tok.line)
        if tok.kind == "kw" and tok.value in ("let", "var"):
            mutable = tok.value == "var"
            self.next()
            bind = self.expect("ident").value
            declared = None
            if self.at(":"):
                self.next()
                declared = self.type_()
            self.expect("=")
            # `let x = effect … undo …` binds an acquisition; anything else
            # binds a plain value, so a method can name an intermediate
            # result instead of nesting every call into one expression. A
            # `verified` modifier (syntax-2.0 §7) marks the acquisition for
            # inverse round-trip testing (roadmap item 26).
            verified_effect = False
            if not mutable and self.at("kw", "verified"):
                self.next()
                if not self.at("kw", "effect"):
                    tok2 = self.peek()
                    raise self.err(tok2.line,
                                   f"expected `effect` after `verified`, found {tok2.value!r}",
                                   hint="`verified` marks an effect acquisition for inverse "
                                        "round-trip testing: `let x = verified effect … undo …`")
                verified_effect = True
            if not mutable and self.at("kw", "effect"):
                if declared is not None:
                    # an acquisition binds a *host-valued* object, which the
                    # checker's frontier documents as untyped; accepting an
                    # annotation here and then ignoring it would be a silent lie
                    raise self.err(
                        tok.line,
                        f"`let {bind}: {declared} = effect …` — an acquisition "
                        "binding cannot be annotated",
                        hint="`effect` binds a host-valued object, whose type "
                             "revl does not model (see the frontier in "
                             "src/revl/typecheck.py); drop the annotation",
                    )
                acquire, undo, line, setup, is_async = self.effect_form(tok.line)
                return LetEffect(bind, acquire, undo, line, setup, verified_effect,
                                 is_async)
            # item 130: `let sub = subscribe <stream> undo sub.close()` — a
            # subscription bracket. It is deliberately the `effect … undo …`
            # shape (a subscription IS an acquisition), so the bracket
            # registration and the teardown-reachability argument fall out of the
            # existing lowering (design §1). An acquisition binding is never
            # annotated (it holds a host-valued subscription on the frontier).
            if not mutable and self.at("kw", "subscribe"):
                if declared is not None:
                    raise self.err(
                        tok.line,
                        f"`let {bind}: {declared} = subscribe …` — a subscription "
                        "binding cannot be annotated",
                        hint="`subscribe` binds a `Stream[T, Active]` subscription "
                             "whose state index the checker tracks; drop the "
                             "annotation (item 130)",
                    )
                (stream, stages, policy, buffer, drain_ms, undo,
                 line) = self.subscribe_form(tok.line, bind)
                return LetEffect(
                    bind,
                    SubscribeExpr(stream, policy, line, stages, buffer, drain_ms),
                    undo, line, subscribe=True)
            # item 246: `let a = await approval[C] { fields }` — an acquisition-
            # shaped suspension that yields an `Approval[C]`. Allowed in the
            # activation body exactly where `let x = effect …` is (both bind a
            # value the plain-value stratum otherwise refuses here).
            if not mutable and self.at("kw", "await") \
                    and self.peek_ahead(1).kind == "ident" \
                    and self.peek_ahead(1).value == "approval":
                if in_method:
                    raise self.err(
                        tok.line,
                        "`await approval[C]` is only allowed in a component "
                        "activation body, not a provide method",
                        hint="mint the approval in the activation body and thread "
                             "it to the crossing there; a provide method runs "
                             "while the component is ACTIVE (item 246)")
                if declared is not None:
                    raise self.err(
                        tok.line,
                        f"`let {bind}: {declared} = await approval[…]` — the "
                        f"binding's type is `Approval[C]`, fixed by the "
                        f"capability, so it cannot be annotated",
                        hint="drop the annotation; `await approval[C]` already "
                             "names the capability the value carries")
                request = self._await_approval_expr()
                return LetApprovalStmt(bind, request, tok.line)
            if verified_effect:
                tok2 = self.peek()
                raise self.err(tok2.line,
                               f"expected `effect` after `verified`, found {tok2.value!r}",
                               hint="`verified` marks an effect acquisition for inverse "
                                    "round-trip testing: `let x = verified effect … undo …`")
            if not in_method:
                raise self.err(
                    tok.line,
                    f"`{'var' if mutable else 'let'} {bind} = …` binds a plain value, "
                    "which a component activation body has no use for",
                    hint="an activation body records effects: write "
                         f"`let {bind} = effect … undo …`, or move the computation "
                         "into a `fn` (G6)",
                )
            return LetStmt(bind, self.pure_expr(), mutable, tok.line, declared)
        if tok.kind == "kw" and tok.value == "verified":
            # `verified effect … undo …` — the effect is marked for inverse
            # round-trip testing (syntax-2.0 §7, roadmap item 26). `verified`
            # heads a body statement only before `effect`; `verified fn` is a
            # top-level declaration, never a body statement.
            self.next()
            if not self.at("kw", "effect"):
                tok2 = self.peek()
                raise self.err(tok2.line,
                               f"expected `effect` after `verified`, found {tok2.value!r}",
                               hint="inside a body, `verified` marks an effect for inverse "
                                    "round-trip testing: `verified effect … undo …`")
            acquire, undo, line, setup, is_async = self.effect_form(tok.line)
            return EffectStmt(acquire, undo, line, setup, verified=True,
                              is_async=is_async)
        if tok.kind == "kw" and tok.value == "effect":
            acquire, undo, line, setup, is_async = self.effect_form(tok.line)
            return EffectStmt(acquire, undo, line, setup, is_async=is_async)
        if tok.kind == "kw" and tok.value == "subscribe":
            # item 130: a subscription must be bound — its inverse `close` names
            # the subscription handle, so a bare `subscribe orders undo …` has no
            # name for the teardown to close (the same reason `spawn` must bind).
            raise self.err(
                tok.line,
                "a `subscribe` must be bound to a subscription handle: "
                "`let sub = subscribe <stream> undo sub.close()`",
                hint="the subscription is a single-consumer acquisition whose "
                     "inverse `close` needs a name; bind it with `let` (item 130)",
            )
        if tok.kind == "ident" and tok.value == "on" and self._at_event_handler():
            # item 130 Slice 5: `on <Event> as <x> in <sub> { … }`, the typed-
            # event handler. It parses to the SAME `StreamIterStmt` the Slice 4
            # `every … in` does (§6: `on … as` desugars to `every … in`), so it
            # inherits that form's whole admission and lowering — including the
            # position rules below, which is why the same in-method refusal
            # applies verbatim.
            if in_method:
                raise self.err(
                    tok.line,
                    "`on … as` event handling is only allowed in a "
                    "component activation body",
                    hint="a provide method runs while the component is ACTIVE; "
                         "`next` is a suspension and the iteration is owned by "
                         "the activation frame that holds the subscription "
                         "bracket (item 130 §3.3, §4.7)",
                )
            return self.event_handler()
        if tok.kind == "kw" and tok.value in ("every", "after"):
            # item 130 Slice 4: `every <x> in <sub> { … }` is stream iteration,
            # `every <n><unit> { … }` is a timer. ONE token of lookahead past the
            # bind separates them with no ambiguity — an IDENT-then-`in` is the
            # stream form, a NUMBER-then-unit the timer — which is why the design
            # reuses `every` rather than minting a keyword (§1, judgment call 1).
            if tok.value == "every" and self._at_stream_iter():
                if in_method:
                    raise self.err(
                        tok.line,
                        "`every … in` stream iteration is only allowed in a "
                        "component activation body",
                        hint="a provide method runs while the component is ACTIVE; "
                             "`next` is a suspension and the iteration is owned by "
                             "the activation frame that holds the subscription "
                             "bracket (item 130 §3.3, §4.7)",
                    )
                return self.stream_iter()
            if in_method:
                raise self.err(
                    tok.line,
                    f"`{tok.value}` timers are only allowed in a component activation body",
                    hint="a timer is a revertible schedule the activation frame owns; "
                         "arm it in the component body, not a provide method "
                         "(docs/time-coeffect.md)",
                )
            return self.timer()
        if tok.kind == "kw" and tok.value == "fail":
            if in_method:
                raise self.err(
                    tok.line,
                    "`fail` is only allowed in a component activation body (A8)",
                    hint="provide-method bodies run while the component is ACTIVE; "
                         "deliberate L-Raise is an activation-time transition",
                )
            self.next()
            return FailStmt(self.pure_expr(), tok.line)
        if tok.kind == "kw" and tok.value == "if":
            if in_method:
                raise self.err(
                    tok.line,
                    "`if` guards are only allowed in a component activation body",
                    hint="provide-method bodies run while the component is ACTIVE; "
                         "use a pure `if` expression in the method value instead (G6)",
                )
            return self.component_if()
        if tok.kind == "kw" and tok.value == "emit":
            self.next()
            return self._emit_stmt(tok.line, is_async=False)
        if tok.kind == "kw" and tok.value == "await":
            if in_method and not in_async_method:
                raise self.err(
                    tok.line,
                    "`await` is only allowed in a component body",
                    hint="a provide method runs while the component is ACTIVE; iteration "
                         "boundaries (paper §4.3.2) exist only during activation (A1). "
                         "Declare the operation `async fn` to `await` a host async value in "
                         "a provide method (services 2.0, §5)",
                )
            self.next()
            # item 131: `await emit <call> [compensate <e>]` — an AWAITED
            # emission step. The boundary marker sits outermost (design §2):
            # the step is an iteration boundary whose payload is an emission.
            # `await` on a provide-method emission is not this form — that path
            # is refused above unless the method is `async fn`.
            if not in_method and self.at("kw", "emit"):
                self.next()
                return self._emit_stmt(tok.line, is_async=True)
            return AwaitStmt(self.pure_expr(), tok.line)
        if tok.kind == "kw" and tok.value == "return":
            if not in_method:
                raise self.err(tok.line, "`return` is only allowed inside a provide method body")
            self.next()
            # a void operation returns nothing: `fn f(x) { return }`
            if self.at("}"):
                return ReturnStmt(None, tok.line)
            return ReturnStmt(self.pure_expr(), tok.line)
        if tok.kind == "kw" and tok.value == "isolate":
            if in_method:
                raise self.err(tok.line, "`isolate` is not allowed inside a method body")
            self.next()
            key = self._provision_key()
            self.expect("kw", "in")
            # `realms(...)` (plural, item 162) binds the key across N realms with
            # an optional routing strategy; `realm(...)` (singular) is unchanged.
            # `realms`/`strategy` are ordinary identifiers (NOT reserved words) —
            # they head a clause only in this exact `isolate <key> in …` position,
            # so a program using either as a name stays valid and the reference
            # KEYWORDS set (and the selfhosted lexer that mirrors it) is untouched.
            if self.at("ident", "realms"):
                realms, strategy = self.realms_route()
                return RouteStmt(key, realms, strategy, tok.line)
            return IsolateStmt(key, self.realm_label(), tok.line)
        if tok.kind == "kw" and tok.value == "intercept":
            if in_method:
                raise self.err(tok.line, "`intercept` is not allowed inside a method body")
            self.next()
            key = self._provision_key()
            self.expect("kw", "with")
            return InterceptStmt(key, self.record_literal(), tok.line)
        if tok.kind == "kw" and tok.value == "handoff":
            if in_method:
                raise self.err(tok.line, "`handoff` is not allowed inside a method body")
            self.next()
            key = self._provision_key(what="a provided key")
            self.expect(":")
            state_type = self.type_()
            return HandoffStmt(key, state_type, tok.line)
        if tok.kind == "kw" and tok.value == "provide":
            if in_method:
                raise self.err(tok.line, "`provide` is not allowed inside a method body")
            return self.provide()
        if tok.kind == "kw" and tok.value in ("break", "continue"):
            # item 379: `break`/`continue` are loop control, and the
            # activation/provide-method grammar has no loop form (loops live
            # only in the fn statement grammar). Redirect in the block-arm
            # voice `_refuse_block_arm_stmt` uses for loops themselves.
            raise self.err(
                tok.line,
                f"`{tok.value}` is not valid here: activation and provide-method "
                "bodies have no loops",
                hint="iterate in a module `fn` (the only grammar with `while`/"
                     "`for`, and thus `break`/`continue`) and call it from here",
            )
        self._reject_foreign_keyword(tok)  # item 384
        raise self.err(
            tok.line,
            f"expected a statement (`let`, `effect`, `emit`, `fail`, `if`{', `return`' if in_method else ', `provide`'}), found {tok.value!r}",
            hint="revl bodies contain only effect forms — plain expressions have no effect to record (G6)",
        )

    def _emit_stmt(self, line: int, *, is_async: bool) -> "EmitStmt":
        """Parse an `emit` statement body (the `emit` keyword already consumed).

        Shared by the plain `emit <call> [compensate …] [with …]` step and the
        item-131 awaited `await emit <call> [compensate …]` step; `is_async`
        records which spelling headed it so the admission pass (lower.py) can
        enforce the exact `await`/async pairing and the emitters can prefix the
        tier's await marker."""
        expr = self.pure_expr()
        compensate = None
        if self.at("kw", "compensate"):
            self.next()
            compensate = self.pure_expr()
        # item 246: `emit <call> with <e>` threads an `Approval[C]` to the
        # crossing. The clause is the explicit dataflow that turns
        # "unreachable without approval" into a type check (Decision 3).
        approval = None
        if self.at("kw", "with"):
            self.next()
            approval = self.pure_expr()
        return EmitStmt(expr, line, compensate, approval, is_async)

    def effect_form(self, line: int):
        self.expect("kw", "effect")
        # item 131: `effect await <expr> undo <expr>` — an ASYNC acquisition.
        # The `await` is a divert boundary (paper §4.3.2): the fiber suspends
        # during the call and the LANDED result is bound, not the in-flight
        # value. The block form `effect { …setup…; acq }` keeps its stratum-1
        # interior and does NOT take `await` (design §2 fence) — hoist the
        # preparation into a module fn, which async-colors under item 90, and
        # write `effect await prepped_open(cfg) undo …`.
        is_async = False
        if self.at("kw", "await"):
            self.next()
            is_async = True
            if self.at("{"):
                raise self.err(
                    line,
                    "`effect await { … }` — the block effect form does not take "
                    "`await` (item 131)",
                    hint="hoist the preparation into a module fn (it async-colors "
                         "under item 90) and write `effect await prepped_open(cfg) "
                         "undo …`; awaits interleaved with pure setup steps reopen "
                         "the acquisition-atomicity argument (design §4 clause 1)")
        # instance-parametric components: `effect spawn C with {..} undo …`.
        # `spawn` is the one new acquisition form (docs/design-v2-instances.md);
        # its inverse is the instance's own teardown, so an `undo` is required
        # exactly as for any acquisition.
        if self.at("kw", "spawn"):
            acquire = self.spawn_expr()
            if not self.at("kw", "undo"):
                raise self.err(
                    line,
                    "a `spawn` acquisition needs `undo <handle>.dispose()`",
                    hint="an instance is an acquisition whose inverse is its own "
                         "teardown; write `let s = effect spawn "
                         f"{acquire.component} … undo s.dispose()` (G4)",
                )
            self.next()
            undo = self.pure_expr()
            return acquire, undo, line, [], is_async
        # capability leases: `effect lease fs.write(path="/tmp") ttl 10m undo
        # l.revoke()` (item 294 Slice 2). A lease is a ticket-gated acquisition of
        # a standing grant over the capability's cone; its inverse is its own
        # revoke, so an `undo` is required exactly as for `spawn`. The acquired
        # value is a lease handle, and `undo l.revoke()` retires the grant on the
        # LIFO teardown. `lease` is a CONTEXTUAL keyword, not reserved: the lease
        # form is `effect lease <ident…>` (the capability's first segment is an
        # ident), so `effect lease()`, `effect lease.m()`, and any other use of a
        # binding named `lease` stay ordinary acquisition expressions. `await`
        # does not combine with a lease (it is gated at load, not a suspension).
        if self.at("ident", "lease") and self.peek_ahead(1).kind == "ident":
            if is_async:
                raise self.err(
                    line,
                    "`effect await lease …` — a lease acquisition is gated at "
                    "load, not an await suspension source (item 294)",
                    hint="write `let l = effect lease <cap> ttl <dur> undo "
                         "l.revoke()` without `await`")
            self.next()                       # consume `lease`
            acquire = self._lease_acquire(line)
            if not self.at("kw", "undo"):
                raise self.err(
                    line,
                    "a `lease` acquisition needs `undo l.revoke()`",
                    hint="a lease is an acquisition whose inverse is its own "
                         "revoke; write `let l = effect lease "
                         f"{acquire.capability} … undo l.revoke()` (G4, item 294)")
            self.next()
            undo = self.pure_expr()
            return acquire, undo, line, [], is_async
        setup: list = []
        if self.at("{"):
            self.next()
            stmts = []
            while True:
                self._skip_semis()
                if self.at("}"):
                    break
                if self.at("kw", "fail"):
                    raise self.err(
                        self.peek().line,
                        "`fail` is not allowed in an effect block setup (G6)",
                        hint="effect block bodies are stratum-1 pure code plus a final acquisition; "
                             "deliberate L-Raise is a component activation statement",
                    )
                stmts.append(self.fn_stmt())
            self.expect("}")
            if not stmts or not isinstance(stmts[-1], ExprStmt):
                raise self.err(
                    line,
                    "an effect block must end with the acquisition expression",
                    hint="the final expression is the acquired value; earlier statements are pure setup (G6)",
                )
            acquire = stmts[-1].expr
            setup = stmts[:-1]
        else:
            acquire = self.pure_expr()
        if not self.at("kw", "undo"):
            # witnessed-inverse externs (item 243, docs/design/243-witnessed-externs.md):
            # a witnessed call's inverse is the extern's own DECLARED `undo`,
            # auto-registered by the teardown accumulator on the `Ok` branch —
            # there is no site-spelled undo, so the grammar admits its omission
            # for a bare-name call. Whether the callee is ACTUALLY a witnessed
            # extern is not decidable here: `use` imports are resolved in a
            # later pass (compiler.py's `_ModuleLoader`), one file at a time,
            # so an imported witnessed extern's classification is unknown at
            # this point even though a same-file one's is (item 315 — the
            # per-file `_witnessed_names` set this replaced could see only
            # same-file `extern` decls, so an imported `write`/`rm` etc. was
            # hard-refused here before module resolution ever ran). Rather
            # than duplicate resolution, the parser admits every bare-name
            # call missing its `undo` and defers the real gate to lower.py's
            # `_lower_effect_step`, which runs on the MERGED program — after
            # imports are resolved — and refuses there if the callee turns
            # out not to be witnessed after all (same message, same G4 code).
            # Anything that cannot possibly BE an extern call by bare name (a
            # dotted path, a literal, a binary op, …) is refused immediately,
            # exactly as before — no import can turn `Pool.open(...)` into a
            # witnessed call, so there is nothing to defer.
            #
            # Item 420(d): a BARE NAME defers too, called or not. `effect
            # open_h` names the same extern `effect open_h()` does, so the
            # parser's copy of the refusal could otherwise deny a declared
            # `undo` that the lowering (which HAS the extern table) can see
            # and name. Deferring both spellings leaves the parser's domain
            # exactly the shapes where no declared inverse can exist, which
            # is what makes the generic wording below the right one for every
            # refusal it still raises.
            if isinstance(acquire, ExprVar) or (
                    isinstance(acquire, ExprCall)
                    and isinstance(acquire.callee, ExprVar)):
                return acquire, None, line, setup, is_async
            message, hint = missing_undo_refusal(_describe_expr(acquire))
            raise self.err(line, message, hint=hint)
        self.next()
        undo = self.pure_expr()
        return acquire, undo, line, setup, is_async

    def _stream_chain(self):
        """`.map(<arrow>)` / `.filter(<arrow>)` / `.take(<int>)` after the stream
        operand of a `subscribe` (item 130 Slice 2, §1).

        Parsed HERE rather than as ordinary method calls on purpose: see
        `StreamStage`. Each link is a derived stream; the chain is left-to-right,
        so `src.filter(p).map(f)` filters first."""
        stages: list = []
        while self.at("."):
            dot = self.peek()
            name = self.toks[self.pos + 1] if self.pos + 1 < len(self.toks) else None
            if name is None or name.kind != "ident" \
                    or name.value not in _STREAM_COMBINATORS:
                found = name.value if name is not None else "end of input"
                raise self.err(
                    dot.line,
                    f"`.{found}` is not a stream combinator",
                    hint="the v1 combinators are `map(f)`, `filter(p)` and "
                         "`take(n)`, each a pure derived stream; the multi-source "
                         "`merge(a, b)` is spelled in the `subscribe` head, not "
                         "as a link in this chain (item 130 §1)")
            self.next()                      # '.'
            kind = self.next().value         # the combinator name
            self.expect("(")
            if kind == "take":
                ntok = self.peek()
                if ntok.kind != "int" or ntok.value < 1:
                    raise self.err(
                        ntok.line,
                        f"`take` needs a positive whole count, found "
                        f"{ntok.value!r}",
                        hint="`take(3)` ends the derived stream with a `Closed` "
                             "terminal after 3 items (item 130 §1)")
                self.next()
                arg = Lit(ntok.value, ntok.line)
            else:
                # `map`/`filter` take a G6-PURE transform; an arrow `x => …` is
                # the only anonymous-function surface revl has, and its body is a
                # single pure expression by construction (rule 3.5).
                arg = self.pure_expr()
            self.expect(")")
            stages.append(StreamStage(kind, arg, dot.line))
        return stages

    def _subscribe_quals(self, line: int):
        """`[policy <name>] [buffer <n>] [drain <n><unit>]` after the stream
        operand of a `subscribe` (item 130 §4.4, §8).

        Bare-ident qualifiers, not reserved words, order-free, each at most once
        — exactly the `effect lease … ttl … uses …` shape (`_lease_acquire`).
        Returns `(policy, buffer, drain_ms)`."""
        policy = None
        buffer = None
        drain_ms = None
        while (self.at("ident", "policy") or self.at("ident", "buffer")
               or self.at("ident", "drain")):
            qual = self.next().value
            if qual == "policy":
                if policy is not None:
                    raise self.err(line, "duplicate `policy` on a `subscribe`")
                tok = self.peek()
                if tok.kind != "ident" or tok.value not in _STREAM_POLICIES:
                    raise self.err(
                        tok.line,
                        f"unknown backpressure policy {tok.value!r}",
                        hint="the declared policies are `error` (the default — a "
                             "full buffer faults and closes, no silent loss), "
                             "`drop_newest`, `drop_oldest` and `block` "
                             "(item 130 §4.4)")
                self.next()
                policy = tok.value
            elif qual == "buffer":
                if buffer is not None:
                    raise self.err(line, "duplicate `buffer` on a `subscribe`")
                tok = self.peek()
                if tok.kind != "int" or tok.value < 1:
                    raise self.err(
                        tok.line,
                        f"`buffer` needs a positive whole capacity, found "
                        f"{tok.value!r}",
                        hint="every subscription's buffer is BOUNDED — there are "
                             "no unbounded buffers (item 130 §4.4)")
                self.next()
                buffer = tok.value
            else:
                if drain_ms is not None:
                    raise self.err(line, "duplicate `drain` on a `subscribe`")
                drain_ms = self._duration_ms()
        if drain_ms is not None and policy != "block":
            raise self.err(
                line,
                "`drain` is the `block`-policy drain window and needs "
                "`policy block`",
                hint="only a `block` subscription pauses its provider, so only it "
                     "has a drain window to re-check on the clock's `advance`; "
                     "the `drop_*`/`error` policies resolve an overflow "
                     "immediately (item 130 §4.4, §8)")
        return policy or "error", buffer, drain_ms

    def _at_stream_merge(self) -> bool:
        """True at the head of a `merge(` fan-in (item 130 Slice 3)."""
        nxt = self.toks[self.pos + 1] if self.pos + 1 < len(self.toks) else None
        return self.at("ident", "merge") and nxt is not None and nxt.kind == "("

    def _stream_merge(self):
        """`merge(a, b)` — the multi-source fan-in a `subscribe` may acquire
        (item 130 Slice 3, §1).

        Parsed HERE, in the `subscribe` head, for exactly the reason Slice 2
        parses its combinator chain as stages (`StreamStage`): a
        `<src>.merge(..)` method spelling would grow the shared host-verb
        namespace docs/stdlib-2.0.md promises is disjoint from the value-method
        table, so this adds zero host verbs and the exact-set pin in
        tests/test_map_value_type.py needs no change.

        Recursive: a merged stream is itself a stream, so `merge(merge(a, b), c)`
        is the three-source fan-in with no extra machinery. An operand is a bare
        stream name or a nested `merge`; a per-operand combinator chain is not
        admitted, since the chain applies to the subscription as a whole."""
        mline = self.peek().line
        self.next()                       # `merge`
        self.expect("(")
        sources = [self._stream_operand()]
        while self.at(","):
            self.next()
            sources.append(self._stream_operand())
        self.expect(")")
        if len(sources) != 2:
            raise self.err(
                mline,
                f"`merge` takes exactly 2 streams, got {len(sources)}",
                hint="v1 `merge` is the two-source fan-in (item 130 §1); a merged "
                     "stream is itself a stream, so nest for more: "
                     "`subscribe merge(merge(a, b), c) undo sub.close()`",
            )
        return StreamMergeExpr(sources, mline)

    def _stream_operand(self):
        """One source of a fan-in: a bare stream name, or a nested `merge`."""
        if self._at_stream_merge():
            return self._stream_merge()
        if self.at("ident"):
            tok = self.next()
            return Postfix(tok.value, [], tok.line)
        return self.pure_expr()

    def subscribe_form(self, line: int, bind: str):
        """`subscribe <stream>[.<combinator>…] [policy P] [buffer N]
        [drain <dur>] undo <close>` (item 130).

        The stream is a pure expression naming the `Stream[T]` capability (or
        the Slice 3 `merge(a, b)` fan-in), optionally wrapped in a derived-stream
        combinator chain (Slice 2); the
        `undo` is required (rule 3.2 — a held subscription with no inverse has no
        place on the accumulator, the same G4 reason plain `let` is refused in an
        activation body). Returns `(stream, stages, policy, buffer, drain_ms,
        undo, line)`."""
        self.expect("kw", "subscribe")
        # A bare identifier head lets the combinator chain be parsed as stages
        # rather than as method calls (see `StreamStage`); any other operand
        # shape falls through to the ordinary pure expression, which the
        # admission pass then refuses for not naming a stream source.
        stages: list = []
        if self._at_stream_merge():
            # Slice 3: the multi-source fan-in. A merged stream IS a stream, so
            # the Slice 2 combinator chain applies to it unchanged.
            stream = self._stream_merge()
            stages = self._stream_chain()
        elif self.at("ident"):
            tok = self.next()
            stream = Postfix(tok.value, [], tok.line)
            stages = self._stream_chain()
        else:
            stream = self.pure_expr()
        policy, buffer, drain_ms = self._subscribe_quals(line)
        if not self.at("kw", "undo"):
            raise self.err(
                line,
                f"`subscribe` needs `undo {bind}.close()` (rule 3.2)",
                hint="a subscription is an acquisition whose inverse closes the "
                     f"stream; write `let {bind} = subscribe <stream> undo "
                     f"{bind}.close()`. Unloading the owner then CLOSES the stream "
                     "by the same LIFO teardown any bracket rides (item 130 §0)",
            )
        self.next()
        undo = self.pure_expr()
        return stream, stages, policy, buffer, drain_ms, undo, line

    def _lease_acquire(self, line: int) -> "LeaseAcquire":
        """`<cap> [ttl <n><unit>] [uses <n>]` after `effect lease` (item 294).

        The capability is the standard parameterized token grammar (a bare or
        parameterized dotted token, funneled through `cap_order` at
        `_capability_params`, so `*` and unregistered parameters refuse exactly as
        in an `emission[...]` scope). `ttl`/`uses` are bare-ident qualifiers (not
        reserved words); order-free, each at most once. At least one must bound the
        grant — an unbounded lease is refused here, the item-344 mandatory-bound
        rule enforced at the source instead of only at mint."""
        captok = self.peek()
        if captok.value == "*":
            raise self.err(captok.line,
                           "`*` is not a leasable capability — an unnameable "
                           "reach cannot be granted (item 294, the `*` row)",
                           hint="name the boundary the lease grants")
        parts = [self.expect("ident", what="a capability token after "
                             "`effect lease`").value]
        while self.at("."):
            self.next()
            parts.append(self.expect("ident").value)
        capability = self._capability_params(".".join(parts))
        ttl_ms = None
        uses = None
        while self.at("ident", "ttl") or self.at("ident", "uses"):
            qual = self.next().value
            if qual == "ttl":
                if ttl_ms is not None:
                    raise self.err(line, "duplicate `ttl` on a lease")
                ttl_ms = self._duration_ms()
            else:
                if uses is not None:
                    raise self.err(line, "duplicate `uses` on a lease")
                ntok = self.peek()
                if ntok.kind != "int" or ntok.value < 1:
                    raise self.err(
                        ntok.line,
                        f"`uses` on a lease needs a positive whole count, found "
                        f"{ntok.value!r}",
                        hint="write `uses 3` — the number of class-(c) crossings "
                             "the lease may auto-approve")
                self.next()
                uses = ntok.value
        if ttl_ms is None and uses is None:
            raise self.err(
                line,
                "a lease must be bounded — give `ttl <dur>` and/or `uses <n>`",
                hint="an unbounded lease would convert prompt-per-call into "
                     "prompt-never forever; consent stays bounded (item 344/294)")
        return LeaseAcquire(capability, ttl_ms, uses, line)

    def _duration_ms(self) -> int:
        """`<n><unit>` (e.g. `10m`, `30s`, `250ms`) -> milliseconds, reusing the
        timer duration units. The unit is a bare ident token following the count."""
        num = self.peek()
        if num.kind != "int" or num.value < 1:
            raise self.err(num.line,
                           f"expected a positive whole-number duration, found "
                           f"{num.value!r}",
                           hint="a duration is `<n><unit>`, e.g. `10m` "
                                "(units: ms, s, m, h, d)")
        self.next()
        unit = self.peek()
        if unit.kind != "ident" or unit.value not in self._DURATION_UNITS:
            raise self.err(unit.line,
                           f"expected a duration unit (ms, s, m, h, d), found "
                           f"{unit.value!r}")
        self.next()
        return num.value * self._DURATION_UNITS[unit.value]

    # duration units -> milliseconds. `ms` before `m` and `s` in the lexer's
    # eyes is moot — the unit is a whole ident token here, matched verbatim.
    _DURATION_UNITS = {"ms": 1, "s": 1000, "m": 60_000, "h": 3_600_000, "d": 86_400_000}

    def _at_stream_iter(self) -> bool:
        """True at the head of `every <IDENT> in …` — the item-130 Slice 4
        stream-iteration form, as opposed to an `every <n><unit>` timer.

        The whole disambiguation is one token of lookahead past the bind: the
        timer's delay is a NUMBER, the iteration's bind is an IDENT followed by
        `in`. Nothing else in the grammar can start that way, so `every` carries
        two forms with no ambiguity and no new keyword (design §1)."""
        bind = self.toks[self.pos + 1] if self.pos + 1 < len(self.toks) else None
        sep = self.toks[self.pos + 2] if self.pos + 2 < len(self.toks) else None
        return (bind is not None and bind.kind == "ident"
                and sep is not None and sep.kind == "kw" and sep.value == "in")

    def stream_iter(self) -> "StreamIterStmt":
        """`every <x> in <sub> { <emit>* }` (item 130 Slice 4, §1, §4.7).

        The subject (`_iteration_subject`) is a bare subscription name and the
        body (`_iteration_body`) is emissions plus `fail`; both are shared with
        Slice 5's `on … as … in`, which is the same iteration with a contract on
        each item."""
        kw = self.expect("kw", "every")
        bind = self.expect("ident", what="the item name after `every`").value
        self.expect("kw", "in")
        subject = self._iteration_subject(bind, f"`every {bind} in …`")
        body = self._iteration_body(bind, subject.head, kw.line,
                                    form="`every … in`",
                                    head=f"`every {bind} in {subject.head}`")
        return StreamIterStmt(bind, subject, body, kw.line)

    def _at_event_handler(self) -> bool:
        """True at the head of `on <Event> as …` — the item-130 Slice 5 typed-
        event handler.

        `on` is a CONTEXTUAL keyword (the `boot`/`fault`/`secret` discipline):
        it heads a statement only in the shape `on IDENT as`, so a program that
        used `on` as an ordinary identifier keeps parsing and the self-hosted
        lexer's KEYWORDS table needs no sync — the same reason Slice 4 reused
        `every` rather than minting a keyword (§1, judgment call 1)."""
        if not self.at("ident", "on") or self.pos + 2 >= len(self.toks):
            return False
        name = self.toks[self.pos + 1]
        sep = self.toks[self.pos + 2]
        return (name.kind == "ident" and sep.kind == "kw" and sep.value == "as")

    def event_handler(self) -> "StreamIterStmt":
        """`on <Event> as <x> in <sub> { … }` — the typed-event handler (item
        130 Slice 5, §6).

        Parses to a `StreamIterStmt` carrying the event's name, because §6's
        call is that `on … as` DESUGARS to `every … in`: an event is a stream
        item with a contract, and its handler is the Slice 4 iteration with that
        contract applied per item. One node, one lowering, one emitted loop — so
        the two properties the guarantee rests on (the iteration boundary
        immediately after the await, and a `Faulted` that is not caught) are
        literally the same code, not a second implementation that could drift.

        The `in <sub>` clause names the subscription the handler pulls, and it
        is the one place this surface departs from §6's `on <Event> as <x> { … }`
        sketch. That sketch resolves the event's stream through the provide/
        inject graph — "the event source is the provided `Stream[T]`" — which
        needs a REQUIRED `Stream[T]` capability the language does not have yet
        (`subscribe`'s own diagnostic says so: a required stream capability is a
        later slice). Naming the subscription explicitly keeps the source
        honest, and keeps every Slice 2/3 qualifier — `policy`, `buffer`,
        `drain`, the combinator chain, `merge` — available to an event consumer,
        which an implicit `subscribe` would have stranded."""
        kw = self.expect("ident", "on")
        event = self.expect("ident", what="the event's name after `on`").value
        self.expect("kw", "as")
        bind = self.expect("ident",
                           what=f"the item name after `on {event} as`").value
        if not self.at("kw", "in"):
            tok = self.peek()
            raise self.err(
                tok.line,
                f"`on {event} as {bind}` needs the subscription it handles: "
                f"`on {event} as {bind} in <sub> {{ … }}`",
                hint="an event handler is the Slice 4 iteration with a contract "
                     "on each item (item 130 §6), so it pulls a subscription a "
                     "`subscribe … undo …` bracket already owns — which is what "
                     "keeps the event's teardown the SAME single LIFO bracket a "
                     "plain stream's is")
        self.next()
        subject = self._iteration_subject(
            bind, f"`on {event} as {bind} in …`")
        body = self._iteration_body(bind, subject.head, kw.line,
                                    form="`on … as`",
                                    head=f"`on {event} as {bind}`")
        return StreamIterStmt(bind, subject, body, kw.line, event=event)

    def _iteration_subject(self, bind: str, form: str) -> "Postfix":
        """The subscription an `every … in` / `on … as … in` pulls.

        A BARE identifier, and that is not a shortcut: a `Subscription` is a
        host-local with no nominal type, so it cannot be returned from a fn,
        stored in a record or passed anywhere — a bare name is the only way to
        spell one, and admitting a general expression here would only produce
        worse diagnostics for shapes the lowering must refuse anyway."""
        subj = self.peek()
        if subj.kind != "ident":
            found = subj.value if subj.kind in ("ident", "kw") else repr(subj.value)
            raise self.err(
                subj.line,
                f"{form} needs the name of a subscription, found {found}",
                hint=f"subscribe first, then iterate: `let sub = subscribe "
                     f"<stream> undo sub.close()` then bind the items with "
                     f"`{bind}` from `sub` (item 130 §1)")
        self.next()
        return Postfix(subj.value, [], subj.line)

    def _iteration_body(self, bind: str, subject: str, head_line: int, *,
                        form: str, head: str) -> list:
        """The per-item body shared by `every … in` (Slice 4) and `on … as`
        (Slice 5) — one parser, so the two forms cannot admit different work.

        The body is emissions (the effectful callback, G1/G8-checked) plus
        `fail` (the A8 handler-failure path). Two shapes are refused by name:

        * an ACQUISITION (`effect … undo …`, `subscribe`, a timer, `spawn`)
          — one accumulator entry per delivered item is unbounded in the length
          of the stream, and the per-iteration discharge that would bound it does
          not exist (§4.7). Acquire once, before the loop. Slice 5 does not
          change this calculus: an event's dedup memory is a fixed-size window
          per handler (§6), constant in the length of the stream, so it bounds
          nothing an acquisition would need bounded.
        * an `emit … compensate …` — a compensation registered per item has the
          same unbounded shape, and the same refusal the timer body already makes
          for the same reason.

        A bare `await` inside the body is refused too: the loop IS the pull, and
        a second `next` on the same subscription inside its own iteration would
        be a second consumer of a single-consumer subscription (rule 3.1)."""
        self.expect("{")
        body: list = []
        while True:
            self._skip_semis()
            if self.at("}"):
                break
            inner = self.stmt(in_method=False)
            if isinstance(inner, EmitStmt):
                if inner.compensate is not None:
                    raise self.err(
                        inner.line,
                        f"an {form} body `emit` cannot declare `compensate`",
                        hint="a per-item compensation would put one accumulator "
                             "entry on the owner's LIFO stack per delivered item, "
                             "unbounded in the length of the stream; the "
                             "subscription's own `close` is the iteration's "
                             "inverse (item 130 §4.7)")
                body.append(inner)
                continue
            if isinstance(inner, FailStmt):
                body.append(inner)
                continue
            if isinstance(inner, AwaitStmt):
                raise self.err(
                    inner.line,
                    f"an {form} body cannot `await` — the loop IS the pull",
                    hint="each turn of the iteration already awaits "
                         f"`{subject}.next()` and binds the item to `{bind}`; "
                         "a second `next` inside the body would be a second "
                         "consumer racing a single-consumer subscription for "
                         "items (rule 3.1, item 130 §4.1)")
            raise self.err(
                getattr(inner, "line", head_line),
                f"an {form} body records emissions (and `fail`) only",
                hint="the body is a setup-mode effect context: its `emit`s are "
                     "capability-checked against the component's row (G1) and "
                     "enumerated on its boundary (G8), and a `fail` aborts the "
                     "iteration so the prefix — subscription bracket included — "
                     "reverts LIFO (A8). An ACQUISITION belongs before the loop: "
                     "one bracket per delivered item is unbounded in the length "
                     "of the stream (item 130 §4.7)")
        self.expect("}")
        if not body:
            raise self.err(
                head_line,
                f"an {head} body is empty",
                hint="an iteration that does nothing per item still pulls the "
                     "subscription to its terminal; drop it, or give it work")
        return body

    def timer(self) -> "TimerStmt":
        """`every 30s { emit … }` / `after 5m { emit … }` (item 57).

        The delay is `<int><unit>` (e.g. `30s`, `5m`, `250ms`); the body is one
        or more `emit` statements that run at each firing. Kept to emissions in
        this first slice — a firing that acquires long-lived effects, guards, or
        nests further timers is a documented follow-on (docs/time-coeffect.md);
        the audited reach a timer needs is exactly its emissions."""
        kw = self.next()  # `every` | `after`
        mode = kw.value
        num = self.peek()
        if num.kind != "int":
            raise self.err(num.line,
                           f"expected a whole-number delay after `{mode}`, found {num.value!r}",
                           hint=f"a timer delay is `<n><unit>`, e.g. `{mode} 30s {{ … }}` "
                                "(units: ms, s, m, h, d)")
        if num.value <= 0:
            raise self.err(num.line,
                           f"a `{mode}` delay must be positive (found {num.value})",
                           hint="a zero or negative interval has no meaning for a schedule")
        self.next()
        unit_tok = self.peek()
        if unit_tok.kind != "ident" or unit_tok.value not in self._DURATION_UNITS:
            found = unit_tok.value if unit_tok.kind in ("ident", "kw") else repr(unit_tok.value)
            raise self.err(unit_tok.line,
                           f"expected a duration unit after `{mode} {num.value}`, found {found}",
                           hint="units are `ms`, `s`, `m`, `h`, `d` — write the delay with no "
                                f"space, e.g. `{mode} {num.value}s {{ … }}`")
        self.next()
        interval_ms = num.value * self._DURATION_UNITS[unit_tok.value]
        self.expect("{")
        body: list = []
        while True:
            self._skip_semis()
            if self.at("}"):
                break
            inner = self.stmt(in_method=False)
            if not isinstance(inner, EmitStmt):
                raise self.err(
                    getattr(inner, "line", kw.line),
                    f"a `{mode}` timer body records emissions only",
                    hint="a timer firing runs at activation-time stratum with the "
                         "component's declared capabilities; its body is `emit` "
                         "statement(s). Richer bodies are a documented follow-on "
                         "(docs/time-coeffect.md)")
            if inner.compensate is not None:
                raise self.err(
                    inner.line,
                    "a timer-body `emit` cannot declare `compensate`",
                    hint="a periodic firing is not a one-shot acquisition, so there is "
                         "no single teardown to compensate; the timer's own "
                         "cancellation is its inverse (docs/time-coeffect.md)")
            body.append(inner)
        self.expect("}")
        if not body:
            raise self.err(kw.line,
                           f"an `{mode}` timer body is empty",
                           hint="a timer with no `emit` does nothing; drop it or give it work")
        return TimerStmt(mode, interval_ms, body, kw.line)

    def spawn_expr(self) -> "SpawnExpr":
        """`spawn <Component> [with { field: <expr>, ... }]`."""
        line = self.expect("kw", "spawn").line
        component = self.expect("ident").value
        config: dict = {}
        if self.at("kw", "with"):
            self.next()
            self.expect("{")
            while not self.at("}"):
                fline = self.peek().line
                field = self._name()
                if field in config:
                    raise self.err(fline, f"duplicate config field `{field}` in spawn")
                self.expect(":")
                config[field] = self.pure_expr()
                if self.at(","):
                    self.next()
            self.expect("}")
        return SpawnExpr(component, config, line)

    def component_if(self) -> IfStmt:
        line = self.expect("kw", "if").line
        self.expect("(")
        cond = self.pure_expr()
        self.expect(")")
        if self.at("{"):
            then = self.component_guard_block()
        else:
            then = [self.stmt(in_method=False)]
        if not then:
            raise self.err(line, "component `if` guard cannot be empty",
                           hint="a guard exists to decide a deliberate L-Raise (A8)")
        otherwise = None
        if self.at("kw", "else"):
            self.next()
            if self.at("kw", "if"):
                otherwise = [self.component_if()]
            elif self.at("{"):
                otherwise = self.component_guard_block()
            else:
                otherwise = [self.stmt(in_method=False)]
            if not otherwise:
                raise self.err(line, "component `else` guard cannot be empty",
                               hint="a guard exists to decide a deliberate L-Raise (A8)")
        return IfStmt(cond, then, otherwise, line)

    def component_guard_block(self) -> list:
        self.expect("{")
        stmts = []
        while True:
            self._skip_semis()
            if self.at("}"):
                break
            stmts.append(self.stmt(in_method=False))
        self.expect("}")
        return stmts

    def realm_label(self) -> str:
        """`realm("<label>")` — static string literals only (v2)."""
        line = self.expect("kw", "realm").line
        self.expect("(")
        tok = self.peek()
        if tok.kind != "string":
            raise self.err(
                line,
                "dynamic realm labels are not supported — a realm is a static string literal",
                hint="config is unknown at link and admission time, so the linker could "
                     "neither prove nor refute a collision between config-derived realms "
                     "(G2 would be unsound); dynamic realms await instance-parametric "
                     "components (docs/design-v2-realms.md)",
            )
        self.next()
        label = tok.value
        if not label:
            raise self.err(line, "a realm label cannot be empty")
        if not _REALM_LABEL_RE.fullmatch(label):
            raise self.err(
                line,
                f"invalid realm label {label!r}",
                hint="realm labels must start with an ASCII letter or digit and contain "
                     "only ASCII letters, digits, `.`, `_`, or `-`",
            )
        self.expect(")")
        return label

    def realms_route(self) -> tuple[list[str], str | None]:
        """`realms("w1", "w2", ...) [strategy(<ident>)]` — the multi-realm bind
        (item 162), the plural of `realm("<label>")`. Same static-string-literal
        rule as `realm_label` (a realm is not config-derived, else G2 would be
        unsound). Returns the ordered realm list and the strategy name (or
        `None`). The order is preserved as written — a router's rotation is
        defined over the list in declaration order."""
        line = self.expect("ident", "realms").line
        self.expect("(")
        if self.at(")"):
            raise self.err(
                line,
                "`realms(...)` needs at least one realm label",
                hint="the multi-realm bind names the realms to route across; for a single "
                     "realm use `realm(\"<label>\")` (singular)",
            )
        realms: list[str] = []
        while True:
            tok = self.peek()
            if tok.kind != "string":
                raise self.err(
                    line,
                    "dynamic realm labels are not supported — a realm is a static string literal",
                    hint="config is unknown at link and admission time, so the linker could "
                         "neither prove nor refute a collision between config-derived realms "
                         "(G2 would be unsound); dynamic realms await instance-parametric "
                         "components (docs/design-v2-realms.md)",
                )
            self.next()
            label = tok.value
            if not label:
                raise self.err(line, "a realm label cannot be empty")
            if not _REALM_LABEL_RE.fullmatch(label):
                raise self.err(
                    line,
                    f"invalid realm label {label!r}",
                    hint="realm labels must start with an ASCII letter or digit and contain "
                         "only ASCII letters, digits, `.`, `_`, or `-`",
                )
            if label in realms:
                raise self.err(
                    line,
                    f"realm `{label}` is listed twice in `realms(...)` — routing a key to "
                    f"the same realm twice is meaningless",
                    hint="each realm in the list is a distinct routing target; remove the "
                         "duplicate (G2 already keeps one provider per (key, realm))",
                )
            realms.append(label)
            if self.at(","):
                self.next()
                # allow a trailing comma before `)`
                if self.at(")"):
                    break
            else:
                break
        self.expect(")")
        strategy: str | None = None
        if self.at("ident", "strategy"):
            self.next()
            self.expect("(")
            strategy = self.expect("ident", what="a strategy name").value
            self.expect(")")
        return realms, strategy

    def record_literal(self) -> dict:
        """`{ field: literal | [literal, ...], ... }` — static metadata (v2)."""
        self.expect("{")
        record: dict = {}
        while not self.at("}"):
            fline = self.peek().line
            field_name = self._record_key_name()
            if field_name in record:
                raise self.err(fline, f"duplicate metadata field `{field_name}`")
            self.expect(":")
            if self.at("["):
                self.next()
                values = []
                while not self.at("]"):
                    values.append(self.literal())
                    if self.at(","):
                        self.next()
                self.expect("]")
                record[field_name] = values
            else:
                record[field_name] = self.literal()
            if self.at(","):
                self.next()
        self.expect("}")
        return record

    # -- v2.0: type & function declarations (syntax-2.0 §2–§3) ----------------

    def type_decl(self, public: bool = False) -> TypeDecl:
        line = self.expect("kw", "type").line
        name = self.expect("ident").value
        params: list[str] = []
        if self.at("["):
            self.next()
            while not self.at("]"):
                params.append(self.expect("ident").value)
                if self.at(","):
                    self.next()
            self.expect("]")
        self.expect("=")
        if self.at("{"):
            self.next()
            fields: list[RecordField] = []
            while not self.at("}"):
                fline = self.peek().line
                fname = self._record_key_name()
                self.expect(":")
                ftype = self.type_()
                fields.append(RecordField(fname, ftype, fline))
                if self.at(","):
                    self.next()
            self.expect("}")
            return TypeDecl(name, params, fields, [], line, public)
        if self.at("("):
            # `type Handler = (Int) -> Str`: a variant case is a bare name, so
            # a `(` here can only head a function type. Carried as the sole
            # case name exactly like `type Rows = List[Row]` below, and
            # recognised as a transparent alias in lowering.
            return TypeDecl(name, params, [],
                            [VariantCase(self.type_(), None, line)], line, public)
        cases: list[VariantCase] = []
        while True:
            cline = self.peek().line
            cname = self.expect("ident").value
            if not cases and (self.at("[") or self.at("?")):
                # `type Rows = List[Row]` / `type MaybeRow = Row?`: a variant
                # case is a bare name with an optional parenthesised payload,
                # so a `[` or `?` here can only be a type application — this is
                # an alias right-hand side. It is carried as the sole case name
                # (a name no case could otherwise have) and recognised as an
                # alias in lowering, where the type table is known.
                rendered = self._type_suffix(cname)
                if self.at("|"):
                    raise self.err(
                        self.peek().line,
                        "revl has no union types — `|` separates the cases of a "
                        f"variant, and `{rendered}` is a type, not a case",
                        hint="declare the alternatives as named cases "
                             "(`type T = Hit(Row) | Missing`), or alias a single "
                             "type (`type Rows = List[Row]`) — syntax-2.0 §2",
                    )
                return TypeDecl(name, params, [],
                                [VariantCase(rendered, None, cline)], line, public)
            payload = None
            if self.at("("):
                self.next()
                payload = self.type_()
                self.expect(")")
            cases.append(VariantCase(cname, payload, cline))
            if self.at("|"):
                self.next()
            else:
                break
        return TypeDecl(name, params, [], cases, line, public)

    def event_decl(self) -> "EventDecl":
        """`event <Name>(key: <field>[, window: <n>]) { <field>: <type>, … }`
        — a typed external event (item 130 Slice 5, §6).

        The body is a record body, parsed exactly as `type N = { … }` parses
        one, because that is what it is: §6's call is that an event is a
        `Stream[T]` element with a contract, so the schema half of the events
        proposal is "an ordinary record type-check on `T`" and needs no new
        machinery. What the head adds is the contract — the identity `key` a
        duplicate repeats, and the bounded `window` of keys the handler
        remembers. The key is checked against the fields in lowering, where the
        whole type table is known, exactly as item 309 checks
        `idempotent(key: p)` against a signature's parameters."""
        line = self.expect("ident", "event").line
        name = self.expect("ident", what="the event's name").value
        key, window = self._event_contract(name)
        self.expect("{", what=f"the fields of `event {name}`")
        fields: list[RecordField] = []
        while not self.at("}"):
            fline = self.peek().line
            fname = self._record_key_name()
            self.expect(":")
            ftype = self.type_()
            fields.append(RecordField(fname, ftype, fline))
            if self.at(","):
                self.next()
        self.expect("}")
        if not fields:
            raise self.err(
                line,
                f"`event {name}` declares no fields",
                hint="an event is a record with a contract (item 130 §6); give it "
                     "the fields the provider delivers, including its key field")
        return EventDecl(name, key, window, fields, line)

    def _event_contract(self, name: str):
        """`(key: <field>[, window: <n>])` — the contract clause of an `event`
        declaration (item 130 Slice 5, §6).

        `key`/`window` are contextual words recognised only in this slot, the
        same discipline item 309's `idempotent(key: p)` and item 373's
        `confined: p` use, so the lexer's KEYWORDS set stays untouched. The key
        is REQUIRED: it is what makes the two obligations §6 assigns to events
        beyond a plain stream — handler idempotency and duplicate handling —
        checkable at all, and an event without one would carry those rows as a
        claim nothing backs."""
        if not self.at("("):
            tok = self.peek()
            raise self.err(
                tok.line,
                f"`event {name}` needs a key: `event {name}(key: <field>) "
                f"{{ … }}`",
                hint="the key names the field carrying the event's identity — the "
                     "value a duplicate delivery repeats — so the handler can "
                     "dedup on it and its idempotency obligation is checkable "
                     "(item 130 §6; the role spelling is item 309's)")
        self.expect("(")
        self.expect("ident", "key",
                    what=f"`key` — the event's identity field (`event {name}"
                         "(key: <field>)`, item 130 §6)")
        self.expect(":", what="`:` after `key`")
        key = self.expect("ident",
                          what="the field carrying the event's identity").value
        window = None
        if self.at(","):
            self.next()
            self.expect("ident", "window",
                        what="`window` — the bounded dedup memory (`event "
                             f"{name}(key: <field>, window: <n>)`, item 130 §6)")
            self.expect(":", what="`:` after `window`")
            tok = self.peek()
            if tok.kind != "int" or tok.value < 1:
                raise self.err(
                    tok.line,
                    f"`window` needs a positive whole count, found {tok.value!r}",
                    hint="the dedup memory is BOUNDED by construction — a handler "
                         "remembers the last N keys it admitted, never one entry "
                         "per delivered item (item 130 §6, §4.7)")
            self.next()
            window = tok.value
        self.expect(")", what="`)` closing the event's contract clause")
        return key, window

    def _type_param_list(self) -> list[str]:
        """An optional `[T, U]` type-parameter list after a `fn`/`extern` name
        (roadmap item 6). Returns [] when there is no `[`, so the implicit form
        `fn id(x: T)` is unaffected. Names are recorded on the declaration and
        become that function's type parameters in the checker (see
        docs/generics.md). Collision with a declared/builtin type is diagnosed
        later, in the checker, where the whole-program type table is known.

        provide-methods do not take this list: they are not entries in the
        shared fn/extern signature table, so `fn f[...]()` inside a `service`
        still fails at `[` as before."""
        if not self.at("["):
            return []
        bline = self.next().line
        names: list[str] = []
        while not self.at("]"):
            tok = self.expect("ident", what="a type-parameter name")
            if tok.value in names:
                raise self.err(tok.line, f"duplicate type parameter `{tok.value}`")
            names.append(tok.value)
            if self.at(","):
                self.next()
        self.expect("]")
        if not names:
            raise self.err(bline, "an empty type-parameter list `[]` is not allowed",
                           hint="drop the brackets for a non-generic fn, or name "
                                "at least one parameter: `fn id[T](x: T) -> T`")
        return names

    def fn_decl(self, public: bool, verified: bool = False,
                endorse_origins: frozenset = frozenset()) -> FnDecl:
        line = self.expect("kw", "fn").line
        name = self.expect("ident").value
        type_params = self._type_param_list()
        self.expect("(")
        params: list[FnParam] = []
        seen_default = False
        while not self.at(")"):
            pline = self.peek().line
            pname = self._name()
            self.expect(":")
            ptype = self.type_()
            # optional default value (roadmap item 187): `= <pure expr>`. A
            # `fn` body opens with `{`, never `=`, so the `=` here is
            # unambiguous. Defaults must be trailing — a required parameter
            # after a defaulted one has no positional slot a caller could
            # reach (revl has no keyword arguments).
            default = None
            if self.at("="):
                self.next()
                default = self.pure_expr()
                seen_default = True
            elif seen_default:
                raise self.err(pline,
                               f"parameter `{pname}` has no default but follows a "
                               "defaulted parameter",
                               hint="once a parameter declares a default, every "
                                    "parameter after it must too — a required "
                                    "parameter after a defaulted one has no call "
                                    "position, since revl calls are positional")
            params.append(FnParam(pname, ptype, pline, default))
            if self.at(","):
                self.next()
        self.expect(")")
        returns = None
        if self.at("arrow"):
            self.next()
            returns = self.type_()
        # item 310: the `cache` trailing clause, between the return type and the
        # body. Only `cache pure` is legal on a plain `fn` (checked in lower); the
        # clause slot is unambiguous (a fn body opens with `{`, never `cache`).
        cache = None
        if self.at("ident", "cache"):
            cache = self._cache_clause()
        self.expect("{")
        body = []
        while True:
            self._skip_semis()
            if self.at("}"):
                break
            body.append(self.fn_stmt())
        self.expect("}")
        return FnDecl(name, params, returns, body, public, line, verified,
                      source=self.filename, type_params=type_params,
                      endorse_origins=endorse_origins, cache=cache)

    def test_decl(self, lifecycle: bool = False) -> TestDecl:
        line = self.expect("kw", "test").line
        tok = self.expect("string")
        name = tok.value
        if not name:
            raise self.err(tok.line, "a test name cannot be empty")
        self.expect("{")
        body = []
        while True:
            self._skip_semis()
            if self.at("}"):
                break
            if lifecycle:
                body.append(self.lifecycle_stmt())
            else:
                self._reject_lifecycle_stmt_here()
                body.append(self.fn_stmt())
        self.expect("}")
        return TestDecl(name, body, line, lifecycle)

    # -- v2.0 §7.1: lifecycle test bodies -----------------------------------

    # `load` / `unload` / `call` are *contextual* statement keywords: they are
    # ordinary identifiers everywhere else in the language, and only a
    # `lifecycle test` body reads them as statements.
    _LIFECYCLE_STMT_WORDS = ("load", "unload", "call", "advance")

    def _reject_lifecycle_stmt_here(self) -> None:
        """A lifecycle statement inside a plain `test` (or any pure body) is
        refused by name rather than by a confusing expression-parse error."""
        tok = self.peek()
        nxt = self.peek_ahead(1)
        word = None
        # `advance` is followed by a duration (`advance 30s`), so its lookahead
        # is an int; the others name a component/key and are followed by an ident.
        nxt_ok = nxt.kind == "ident" or (tok.value == "advance" and nxt.kind == "int")
        if tok.kind == "ident" and tok.value in self._LIFECYCLE_STMT_WORDS and nxt_ok:
            word = tok.value
        elif tok.kind == "ident" and tok.value == "abort" and nxt.kind in (
                "}", ";", "kw", "ident"):
            # `abort` (item 377) takes no operand, so it is a bare statement: it
            # is the lifecycle word only when it stands alone (next token ends
            # the body or begins another statement), never when it heads an
            # expression (`abort.foo()`, `abort(x)`, `abort + 1`) that merely
            # uses the name — those keep working.
            word = "abort"
        elif tok.kind == "kw" and tok.value == "assert" and nxt.kind == "ident" and nxt.value == "no_residue":
            word = "assert no_residue"
        if word is None:
            return
        raise self.err(
            tok.line,
            f"`{word}` is only allowed in a `lifecycle test` body",
            hint='a plain `test` block is pure (syntax-2.0 §7); write `lifecycle test "name" '
                 "{ ... }` to drive a composition (§7.1)",
        )

    def lifecycle_stmt(self):
        tok = self.peek()
        if tok.kind == "ident" and tok.value == "load":
            self.next()
            component = self.expect("ident", what="a component name").value
            config: list[tuple[str, object, int]] = []
            if self.at("kw", "with"):
                self.next()
                self.expect("{")
                while not self.at("}"):
                    fline = self.peek().line
                    field = self._name("a config field name")
                    self.expect(":")
                    config.append((field, self.pure_expr(), fline))
                    if self.at(","):
                        self.next()
                self.expect("}")
            return LoadStmt(component, config, tok.line)
        if tok.kind == "ident" and tok.value == "unload":
            self.next()
            return UnloadStmt(self.expect("ident", what="a component name").value, tok.line)
        if tok.kind == "kw" and tok.value in ("let", "var"):
            if tok.value == "var":
                raise self.err(tok.line, "`var` has no meaning in a lifecycle test — bindings name "
                                         "the result of a `call` and are single-assignment",
                               hint="use `let`")
            self.next()
            bind = self.expect("ident").value
            self.expect("=")
            return self._call_stmt(bind)
        if tok.kind == "ident" and tok.value == "call":
            return self._call_stmt(None)
        if tok.kind == "ident" and tok.value == "advance":
            self.next()
            ms = self._advance_duration_ms()
            return AdvanceStmt(ms, tok.line)
        if tok.kind == "ident" and tok.value == "abort":
            self.next()
            return AbortStmt(tok.line)
        if tok.kind == "kw" and tok.value == "assert":
            self.next()
            nxt = self.peek()
            if nxt.kind == "ident" and nxt.value == "no_residue":
                self.next()
                return ResidueStmt(tok.line)
            if nxt.kind == "ident" and nxt.value == "call":
                # `assert call key.op(...) ...` (roadmap item 407). A witnessed
                # `call` is the effectful driver of the composition (it is
                # recorded for teardown and residue checking), while an `assert`
                # is a pure observation over the test's `let` bindings. Letting
                # the call be evaluated inside the assertion would hide a
                # witnessed effect from the timeline the checker walks, so it
                # stays a statement. Redirect to the one-line hoist rather than
                # letting `pure_expr` read `call` as a bare variable and fail
                # further along with an opaque "expected a lifecycle statement".
                raise self.err(
                    tok.line,
                    "a witnessed `call` cannot be evaluated inside an `assert`: "
                    "the call is an effect, the assert is a pure observation",
                    hint="hoist the call to its own step, then assert over the "
                         f"binding: `let result = {self._peek_call_suggestion()}` "
                         "then `assert result == ...` (syntax-2.0 §7.1)",
                )
            # anything else is a pure Bool expression over the test's `let`
            # bindings; an unbound bare word is caught in lowering, where the
            # binding scope is known, and reported as an unknown assertion
            return AssertStmt(self.pure_expr(), tok.line)
        if tok.kind == "ident" and tok.value == "swap":
            # `swap C -> C2` cannot exist: G2 forbids two components in one
            # document from providing the same key, so a replacement provider
            # for a key is not expressible (syntax-2.0 §7.1).
            raise self.err(
                tok.line,
                "there is no `swap` statement",
                hint="two components may not provide the same key in one document (G2), so a "
                     "replacement *provider* is not expressible; a replacement *instance* is "
                     "`unload C` then `load C with { ... }` (syntax-2.0 §7.1)",
            )
        raise self.err(
            tok.line,
            f"expected a lifecycle statement, found {tok.value!r}",
            hint="a lifecycle test body is `load` / `unload` / `call` / `let … = call …` / "
                 "`advance` / `abort` / `assert` (syntax-2.0 §7.1)",
        )

    def _advance_duration_ms(self) -> int:
        """Parse the `<n><unit>` after `advance` (item 102) into milliseconds,
        reusing item 57's duration units. `advance` is the only lifecycle
        statement that moves the clock coeffect, so a timer's firing becomes an
        assertable timeline step (docs/time-coeffect.md §advance)."""
        num = self.peek()
        if num.kind != "int":
            raise self.err(num.line,
                           f"expected a whole-number duration after `advance`, found {num.value!r}",
                           hint="an advance is `<n><unit>`, e.g. `advance 30s` (units: ms, s, m, h, d)")
        if num.value <= 0:
            raise self.err(num.line,
                           f"an `advance` duration must be positive (found {num.value})",
                           hint="advancing the clock by zero fires nothing; give it a real span")
        self.next()
        unit_tok = self.peek()
        if unit_tok.kind != "ident" or unit_tok.value not in self._DURATION_UNITS:
            found = unit_tok.value if unit_tok.kind in ("ident", "kw") else repr(unit_tok.value)
            raise self.err(unit_tok.line,
                           f"expected a duration unit after `advance {num.value}`, found {found}",
                           hint="units are `ms`, `s`, `m`, `h`, `d` — write the advance with no "
                                f"space, e.g. `advance {num.value}s`")
        self.next()
        return num.value * self._DURATION_UNITS[unit_tok.value]

    def _peek_call_suggestion(self) -> str:
        """Best-effort `call key.op(...)` reconstruction for the item-407
        redirect, read WITHOUT consuming tokens. Falls back to a generic shape
        when the tokens after `call` do not look like `key.op(`."""
        toks = self.toks
        i = self.pos  # points at the `call` token
        if not (i < len(toks) and toks[i].kind == "ident" and toks[i].value == "call"):
            return "call key.op(...)"
        key_tok = toks[i + 1] if i + 1 < len(toks) else None
        dot_tok = toks[i + 2] if i + 2 < len(toks) else None
        op_tok = toks[i + 3] if i + 3 < len(toks) else None
        if (key_tok is not None and key_tok.kind == "ident"
                and dot_tok is not None and dot_tok.kind == "."
                and op_tok is not None and op_tok.kind == "ident"):
            return f"call {key_tok.value}.{op_tok.value}(...)"
        return "call key.op(...)"

    def _call_stmt(self, bind: str | None) -> CallStmt:
        tok = self.peek()
        if not (tok.kind == "ident" and tok.value == "call"):
            raise self.err(tok.line, f"expected `call` after `let {bind} =`, found {tok.value!r}",
                           hint="a lifecycle binding names the result of a service call: "
                                "`let x = call key.op(args)`")
        self.next()
        key = self._provision_key()
        self.expect(".")
        method = self.expect("ident", what="an operation name").value
        self.expect("(")
        args = []
        while not self.at(")"):
            args.append(self.pure_expr())
            if self.at(","):
                self.next()
        self.expect(")")
        return CallStmt(key, method, args, bind, tok.line)

    # -- fault tests (docs/fault-tests.md) ---------------------------------

    def fault_test_decl(self) -> FaultTestDecl:
        """fault test STR for IDENT [with { k: lit, … }] { fail at …  assert … }

        Everything after `fault test` is contextual: `for` and `with` are
        existing keywords; `at`, `step`, `no`, `residue`, `emissions`,
        `inverses`, `lifo`, `failed`, `siblings` and `unaffected` are plain
        identifiers matched by spelling, so no new reserved word lands in the
        language.
        """
        line = self.next().line              # `fault`
        self.expect("kw", "test")
        name_tok = self.expect("string", what="a fault-test name")
        name = name_tok.value
        if not name:
            raise self.err(name_tok.line, "a fault test name cannot be empty")
        self.expect("kw", "for", what="`for <component>` after the fault test name")
        component = self.expect("ident", what="a component name").value

        config: dict = {}
        if self.at("kw", "with"):
            self.next()
            self.expect("{")
            while not self.at("}"):
                fline = self.peek().line
                key = self._name("a config field name")
                if key in config:
                    raise self.err(fline, f"duplicate config field `{key}` in fault test `{name}`")
                self.expect(":")
                config[key] = self.literal()
                if self.at(","):
                    self.next()
            self.expect("}")

        self.expect("{")
        at_step: int | None = None
        at_effect: str | None = None
        asserts: list = []
        while True:
            self._skip_semis()
            if self.at("}"):
                break
            tok = self.peek()
            if tok.kind == "kw" and tok.value == "fail":
                if at_step is not None or at_effect is not None:
                    raise self.err(tok.line,
                                   f"fault test `{name}` already has an injection point")
                self.next()
                self._expect_word("at", "`at` after `fail`")
                at_step, at_effect = self._fault_injection_point()
            elif tok.kind == "kw" and tok.value == "assert":
                self.next()
                asserts.append((self._fault_assertion(), tok.line))
            else:
                raise self.err(
                    tok.line,
                    f"expected `fail at …` or `assert …` in a fault test, found {tok.value!r}",
                )
        self.expect("}")
        if at_step is None and at_effect is None:
            raise self.err(line, f"fault test `{name}` has no `fail at …` injection point",
                           hint="a fault test must say where the activation dies, e.g. "
                                "`fail at step 2` or `fail at effect pool`")
        if not asserts:
            raise self.err(line, f"fault test `{name}` asserts nothing",
                           hint="add at least one of `assert failed`, `assert no residue`, "
                                "`assert inverses lifo`, `assert no emissions`, "
                                "`assert siblings unaffected`")
        return FaultTestDecl(name, component, config, at_step, at_effect, asserts, line)

    def _expect_word(self, word: str, what: str) -> None:
        """Consume a contextual keyword spelled as a bare identifier."""
        tok = self.peek()
        if tok.kind != "ident" or tok.value != word:
            got = repr(tok.value) if tok.value is not None else "end of file"
            raise self.err(tok.line, f"expected {what}, found {got}")
        self.next()

    def _fault_injection_point(self) -> tuple:
        tok = self.peek()
        if tok.kind == "ident" and tok.value == "step":
            self.next()
            index = self.expect("int", what="a 1-based body step index")
            if index.value < 1:
                raise self.err(index.line, "`fail at step` is 1-based; step 0 does not exist")
            return index.value, None
        if tok.kind == "kw" and tok.value == "effect":
            self.next()
            named = self.peek()
            if named.kind not in ("ident", "string"):
                raise self.err(named.line,
                               f"expected an effect binding name, found {named.value!r}")
            self.next()
            return None, named.value
        raise self.err(tok.line,
                       f"expected `step <n>` or `effect <name>` after `fail at`, found {tok.value!r}")

    def _fault_assertion(self) -> str:
        tok = self.peek()
        if tok.kind == "ident" and tok.value == "failed":
            self.next()
            return "failed"
        if tok.kind == "ident" and tok.value == "no":
            self.next()
            what = self.peek()
            if what.kind == "ident" and what.value in ("residue", "emissions"):
                self.next()
                return "no-residue" if what.value == "residue" else "no-emissions"
            raise self.err(what.line,
                           f"expected `residue` or `emissions` after `no`, found {what.value!r}")
        if tok.kind == "ident" and tok.value == "inverses":
            self.next()
            self._expect_word("lifo", "`lifo` after `inverses`")
            return "inverses-lifo"
        if tok.kind == "ident" and tok.value == "siblings":
            self.next()
            self._expect_word("unaffected", "`unaffected` after `siblings`")
            return "siblings-unaffected"
        raise self.err(
            tok.line,
            f"unknown fault-test assertion {tok.value!r}",
            hint="fault tests assert on the activation's wreckage, not on values: "
                 "`failed`, `no residue`, `inverses lifo`, `no emissions`, "
                 "`siblings unaffected`",
        )

    # -- property tests (docs/prop-test.md, roadmap item 37) ---------------

    def prop_test_decl(self) -> PropTestDecl:
        """prop test STR (name: Type, …) { assert … }

        `prop` and `test` are matched by spelling/keyword before this is
        entered; the parameter list is exactly a `fn` parameter list (each an
        input to be *generated* from its type), and the body is the same pure
        statement grammar a plain `test` body is — so `assert` reads as it does
        everywhere else, only checked over many generated inputs.
        """
        line = self.next().line              # `prop`
        self.expect("kw", "test")
        name_tok = self.expect("string", what="a prop-test name")
        name = name_tok.value
        if not name:
            raise self.err(name_tok.line, "a prop test name cannot be empty")
        self.expect("(", what="`(` — a prop test's parameters are its generated inputs")
        params: list[FnParam] = []
        seen: set[str] = set()
        while not self.at(")"):
            pline = self.peek().line
            pname = self._name("a parameter name")
            if pname in seen:
                raise self.err(pline, f"duplicate parameter `{pname}` in prop test `{name}`")
            seen.add(pname)
            self.expect(":", what="`:` and a type — a prop-test parameter is a generated input")
            ptype = self.type_()
            params.append(FnParam(pname, ptype, pline))
            if self.at(","):
                self.next()
        self.expect(")")
        if not params:
            raise self.err(line, f"prop test `{name}` has no parameters",
                           hint="a prop test's parameters are its generated inputs: "
                                'write e.g. `prop test "commutes" (a: Int, b: Int) { … }`')
        self.expect("{")
        body = []
        while True:
            self._skip_semis()
            if self.at("}"):
                break
            self._reject_lifecycle_stmt_here()
            body.append(self.fn_stmt())
        self.expect("}")
        if not any(isinstance(stmt, AssertStmt) for stmt in body):
            raise self.err(line, f"prop test `{name}` asserts nothing",
                           hint="a prop test states a property to hold for every generated "
                                "input: add at least one `assert <bool expr>`")
        return PropTestDecl(name, params, body, line)

    def fn_stmt(self):
        tok = self.peek()
        if tok.kind == "kw" and tok.value == "fail":
            raise self.err(
                tok.line,
                "`fail` is only allowed in a component activation body (A8)",
                hint="pure functions and tests return `Result` values; deliberate L-Raise "
                     "is a component activation transition",
            )
        if tok.kind == "kw" and tok.value in ("let", "var"):
            mutable = tok.value == "var"
            self.next()
            if self.at("{"):
                pattern = self._record_pattern()
                self.expect("=")
                return LetPatternStmt(pattern, self.pure_expr(), mutable, tok.line)
            if self.at("["):
                pattern = self._list_pattern()
                self.expect("=")
                return LetPatternStmt(pattern, self.pure_expr(), mutable, tok.line)
            name = self.expect("ident").value
            declared = None
            if self.at(":"):
                self.next()
                declared = self.type_()
            self.expect("=")
            return LetStmt(name, self.pure_expr(), mutable, tok.line, declared)
        if tok.kind == "kw" and tok.value == "return":
            self.next()
            value = None if self.at("}") else self.pure_expr()
            return ReturnStmt(value, tok.line)
        if tok.kind == "kw" and tok.value == "if":
            return self.if_stmt()
        if tok.kind == "kw" and tok.value == "while":
            return self.while_stmt()
        if tok.kind == "kw" and tok.value == "for":
            return self.for_stmt()
        if tok.kind == "kw" and tok.value == "assert":
            self.next()
            return AssertStmt(self.pure_expr(), tok.line)
        if tok.kind == "kw" and tok.value in ("break", "continue"):
            return self._loop_control_stmt(tok)
        if tok.kind == "ident" and self._assign_ahead():
            self.next()
            op = "="
            if self.at("="):
                self.next()
            else:
                op = self.next().value + "="
                self.next()
            return AssignStmt(tok.value, self.pure_expr(), tok.line, op)
        return ExprStmt(self.pure_expr(), tok.line)

    def _loop_control_stmt(self, tok):
        """`break` / `continue` — bare loop control (item 379). Valid only
        inside a `while`/`for` body (`_loop_depth > 0`). Outside a loop it
        replaces today's misleading G1 "`break` is not declared" with a
        redirect in the item-384 voice; inside a match block arm (where the
        depth has been reset to 0) it names the lambda-lift that makes the
        `break` unlandable (C1, docs/design/379-break-continue.md)."""
        self.next()
        if self._loop_depth == 0:
            if self._in_block_arm:
                raise self.err(
                    tok.line,
                    f"`{tok.value}` cannot leave a match block arm "
                    "(docs/records.md §4)",
                    hint=f"a block arm is lifted into its own function, so a "
                         f"`{tok.value}` here has no enclosing loop to target; "
                         f"put the loop and its `{tok.value}` in a module `fn` "
                         f"the arm calls",
                )
            raise self.err(
                tok.line,
                f"`{tok.value}` is only valid inside a `while` or `for` body",
                hint=("return early or restructure the loop"
                      if tok.value == "break"
                      else "move the skip into the loop's header condition, or "
                           "restructure the loop"),
            )
        return (BreakStmt(tok.line) if tok.value == "break"
                else ContinueStmt(tok.line))

    def _assign_ahead(self) -> bool:
        """True when the token after the current identifier starts `=` or a
        compound assignment (`+=`, `-=`, `*=`, `/=`, `%=`)."""
        nxt = self.peek_ahead(1)
        if nxt.kind == "=":
            return True
        if nxt.kind in ("+", "-", "*", "/", "%"):
            return self.peek_ahead(2).kind == "="
        return False

    def _record_pattern(self) -> RecordPattern:
        line = self.expect("{").line
        fields: list[str] = []
        while not self.at("}"):
            fields.append(self._name())
            if self.at(","):
                self.next()
        self.expect("}")
        return RecordPattern(fields, line)

    def _list_pattern(self) -> ListPattern:
        line = self.expect("[").line
        binds: list[str] = []
        rest: str | None = None
        while not self.at("]"):
            if self._rest_pattern_ahead():
                self.next()
                self.next()
                self.next()
                rest = self.expect("ident").value
                break
            binds.append(self.expect("ident").value)
            if self.at(","):
                self.next()
        self.expect("]")
        return ListPattern(binds, rest, line)

    def _rest_pattern_ahead(self) -> bool:
        return (
            self.at(".")
            and self.peek_ahead(1).kind == "."
            and self.peek_ahead(2).kind == "."
        )

    def while_stmt(self) -> WhileStmt:
        line = self.expect("kw", "while").line
        self.expect("(")
        cond = self.pure_expr()
        self.expect(")")
        self._loop_depth += 1
        try:
            body = self.block() if self.at("{") else [self.fn_stmt()]
        finally:
            self._loop_depth -= 1
        return WhileStmt(cond, body, line)

    def for_stmt(self) -> ForStmt:
        line = self.expect("kw", "for").line
        self.expect("(")
        # item 384 (pairs with 379): revl's only loop header is the TS for-of
        # `for (x of xs)`. A C-style `for (let i = 0; i < n; i += 1)` opens
        # with a `let`/`var` keyword (or a bare `i = …`/`;`) where the bind
        # name is expected, and used to report the cryptic `expected ident,
        # found 'let'`. Redirect to for-of / `while` instead.
        if self.at("kw", "let") or self.at("kw", "var"):
            raise self.err(
                self.peek().line,
                "revl has no C-style `for (init; cond; step)` loop",
                hint="iterate with `for (x of xs)`, or count with a `var` and a "
                     "`while (cond)` loop (syntax-2.0 §3.5)",
            )
        bind = self.expect("ident").value
        # A bare C-style header without `let` (`for (i = 0; …)`) reaches here
        # with `=`/`;` where `of` is expected — same redirect.
        if self.at("=") or self.at(";"):
            raise self.err(
                self.peek().line,
                "revl has no C-style `for (init; cond; step)` loop",
                hint="iterate with `for (x of xs)`, or count with a `var` and a "
                     "`while (cond)` loop (syntax-2.0 §3.5)",
            )
        # `for (x in xs)` (Python / JS enumerate-keys) walks the wrong thing;
        # revl's `of` walks elements. Redirect the `in` keyword to `of`.
        if self.at("kw", "in"):
            raise self.err(
                self.peek().line,
                "revl iterates elements with `for (x of xs)`, not `for (x in xs)`",
                hint="`of` binds each element; revl has no key-enumerating "
                     "`in` loop (syntax-2.0 §3.5)",
            )
        self.expect("kw", "of")
        iterable = self.pure_expr()
        self.expect(")")
        self._loop_depth += 1
        try:
            body = self.block() if self.at("{") else [self.fn_stmt()]
        finally:
            self._loop_depth -= 1
        return ForStmt(bind, iterable, body, line)

    def if_stmt(self) -> IfStmt:
        line = self.expect("kw", "if").line
        self.expect("(")
        cond = self.pure_expr()
        self.expect(")")
        then = self.block() if self.at("{") else [self.fn_stmt()]
        # item 384: `elif` (Python) lexes as an identifier, so after the `then`
        # block it lands as a bare call-expression statement and reports a
        # cryptic error deep in the following `{...}`. Catch it at the natural
        # `else`-position and redirect to `else if`.
        if self.at("ident", "elif"):
            raise self.err(
                self.peek().line,
                "revl has no `elif`",
                hint="chain conditionals with `else if` (syntax-2.0 §3.2)",
            )
        otherwise = None
        if self.at("kw", "else"):
            self.next()
            if self.at("kw", "if"):
                otherwise = [self.if_stmt()]
            else:
                otherwise = self.block() if self.at("{") else [self.fn_stmt()]
        return IfStmt(cond, then, otherwise, line)

    def block(self) -> list:
        self.expect("{")
        stmts = []
        while True:
            self._skip_semis()
            if self.at("}"):
                break
            stmts.append(self.fn_stmt())
        self.expect("}")
        return stmts

    # pure expressions — precedence climbing (§3.2)

    def _parse_template_parts(self, raw_parts, line: int, interp_lines=None):
        """Turn lexer template parts into ("text", str) / ("expr", ast): each
        `${...}` body is re-parsed as a full pure expression (§3.2).

        `interp_lines` is the lexer's side-band list of absolute start lines,
        one per `${...}`, and becomes the sub-parser's line offset. Without it
        every sub-parse started at line 1, so a fault inside an interpolation —
        a parse error here, or a checker refusal later on the AST this builds —
        was reported at line 1 of the file no matter where the template sat
        (issue #313). It is read defensively: a `template` token minted by
        something other than `lex` (the formatter, a test) has no such list, and
        the template's own line is the honest fallback.
        """
        parts = []
        expr_index = 0
        for kind, value in raw_parts:
            if kind == "text":
                parts.append(("text", value))
                continue
            if interp_lines and expr_index < len(interp_lines):
                interp_line = interp_lines[expr_index]
            else:
                interp_line = line
            expr_index += 1
            sub = Parser(value, self.filename, line_offset=interp_line - 1)
            # the interpolation is nested INSIDE this expression: carry the
            # depth across so `${`${`${...}`}`}` is bounded too (issue #310)
            sub._nesting = self._nesting
            expr = sub.pure_expr()
            if not sub.at("eof"):
                extra = sub.peek()
                raise self.err(interp_line,
                               f"unexpected {extra.value!r} in `${{...}}` interpolation",
                               hint="an interpolation holds one expression")
            parts.append(("expr", expr))
        return parts

    def pure_expr(self):
        return self._ternary()

    def _ternary(self):
        """The head of the precedence ladder, and so the one place every
        NESTED expression re-enters (a parenthesised group, a call argument, a
        list or record element, a lambda body, a `${...}` interpolation). The
        depth is counted here, once per level, and refused past
        `NESTING_LIMIT` with a diagnostic that names the bound (issue #310).

        A stated limit, not a crash: the bound is the compiler's, not the
        language's, so it has to be said out loud. `_bin` itself loops rather
        than recursing, so a long `a + b + c ...` chain costs no depth."""
        self._nesting += 1
        try:
            if self._nesting > NESTING_LIMIT:
                raise self.err(
                    self.peek().line,
                    f"expression nesting is deeper than the parser's limit of "
                    f"{NESTING_LIMIT} levels",
                    hint="this is an implementation bound, not a language one: "
                         "the parser is recursive descent and a nesting this "
                         "deep would exhaust the interpreter's stack. Name the "
                         "inner expressions with `let` bindings and the nesting "
                         "goes away.",
                )
            return self._ternary_body()
        finally:
            self._nesting -= 1

    def _ternary_body(self):
        cond = self._or()
        if self.at("?"):
            self.next()
            then = self._ternary()
            self.expect(":")
            otherwise = self._ternary()
            return ExprIf(cond, then, otherwise, cond.line)
        # item 384: `a if c else b` is the Python conditional expression. An
        # `if` immediately following a parsed expression is never valid revl
        # (its `if` *statement* always opens `if (`), so an `if` here that is
        # NOT followed by `(` is the Python postfix-if. Redirect to `c ? a : b`
        # instead of the cryptic `expected (, found '<cond>'`. The `(`
        # exclusion keeps a real `if` statement on the next line — reached as a
        # separate statement, not within this expression — untouched.
        if (self.at("kw", "if")
                and self.pos + 1 < len(self.toks)
                and self.peek_ahead(1).kind != "("):
            raise self.err(
                self.peek().line,
                "revl has no Python-style `a if c else b` conditional expression",
                hint="revl's conditional expression is `c ? a : b` — the "
                     "condition comes first (syntax-2.0 §3.2)",
            )
        return cond

    def _or(self):
        return self._bin(self._nullish, ("||",))

    def _nullish(self):
        # `??` is a right-associative binary operator typed against Opt[T]
        # (typecheck._binop_type). TS forbids mixing `??` with `&&`/`||`
        # without parentheses; we enforce the same (§0: no silently different
        # meaning) via _reject_nullish_mix.
        left = self._and()
        if self.at("??"):
            line = self.next().line
            right = self._nullish()
            self._reject_nullish_mix("??", left, line)
            self._reject_nullish_mix("??", right, line)
            return ExprBin("??", left, right, left.line)
        return left

    @staticmethod
    def _is_unparen_bin(node, ops: tuple) -> bool:
        return (isinstance(node, ExprBin) and node.op in ops
                and not getattr(node, "_paren", False))

    def _reject_nullish_mix(self, op: str, operand, line: int) -> None:
        """`??` cannot be adjacent to `&&`/`||` without parentheses, and vice
        versa (matches TS, which makes the unparenthesized form a syntax
        error)."""
        if op == "??" and self._is_unparen_bin(operand, ("&&", "||")):
            raise self.err(
                line,
                f"`??` cannot be mixed with `{operand.op}` without parentheses",
                hint=f"write `(a {operand.op} b) ?? c` or `a ?? (b {operand.op} c)` "
                     "to say which you mean",
            )
        if op in ("&&", "||") and self._is_unparen_bin(operand, ("??",)):
            raise self.err(
                line,
                f"`{op}` cannot be mixed with `??` without parentheses",
                hint=f"write `(a ?? b) {op} c` or `a {op} (b ?? c)` to say which you mean",
            )

    def _and(self):
        return self._bin(self._bor, ("&&",))

    # Bitwise `| ^ &` sit between `&&` and equality, in C/TypeScript order
    # (loosest `|`, then `^`, then `&`), so `a & b == c` parses as
    # `a & (b == c)` exactly as it does in TS — §0 keeps shared syntax meaning
    # what TS means by it (item 366, docs/arithmetic.md).
    def _bor(self):
        # `_suppress_bor` marks the one context where a top-level `|` is a
        # record-update separator, not the operator; clear it on read so it
        # suppresses only this leftmost `|` and nested `(a | b)` still parse.
        if self._suppress_bor:
            self._suppress_bor = False
            return self._bxor()
        return self._bin(self._bxor, ("|",))

    def _bxor(self):
        return self._bin(self._band, ("^",))

    def _band(self):
        return self._bin(self._eq, ("&",))

    def _eq(self):
        return self._bin(self._cmp, ("==", "===", "!=", "!=="))

    def _cmp(self):
        return self._bin(self._shift, ("<", ">", "<=", ">="))

    # The Int32 shifts bind tighter than the relational operators and looser
    # than additive — C/TypeScript order, so `a + b << c` is `(a + b) << c`
    # (item 366).
    def _shift(self):
        return self._bin(self._add, ("<<", ">>"))

    def _add(self):
        return self._bin(self._mul, ("+", "-"))

    def _mul(self):
        return self._bin(self._unary, ("*", "/", "%"))

    def _bin(self, operand, ops):
        left = operand()
        while True:
            op = None
            for candidate in ops:
                if self.at(candidate):
                    op = candidate
                    break
            if op is None:
                return left
            op_line = self.next().line
            right = operand()
            canonical = _CANONICAL_OPS.get(op, op)
            if canonical in ("&&", "||"):
                self._reject_nullish_mix(canonical, left, op_line)
                self._reject_nullish_mix(canonical, right, op_line)
            # `===`/`!==` are accepted spellings of the ONE structural
            # equality (syntax-2.0 §3.2): canonicalized here so the IR
            # carries a single operator and no backend can diverge
            left = ExprBin(canonical, left, right, left.line)

    def _unary(self):
        tok = self.peek()
        if tok.kind in ("!", "-", "~"):
            # `~` is the Int32 bitwise complement, grouped with the other
            # prefix unaries (item 366, docs/arithmetic.md).
            self.next()
            return ExprUn(tok.kind, self._unary(), tok.line)
        if tok.kind == "kw" and tok.value == "emit":
            self.next()
            return EmitExpr(self._unary(), tok.line)
        return self._postfix()

    def _await_approval_expr(self) -> ApprovalExpr:
        """`await approval[C] { field: expr, ... }` — parsed only as the RHS of a
        `let` binding (item 246). Not a general expression: an approval is an
        acquisition-shaped suspension, bound once and threaded by `with`."""
        line = self.expect("kw", "await").line
        self.expect("ident", "approval")
        self.expect("[")
        capability = self._capability_token("a capability token in `approval[...]`")
        self.expect("]")
        fields: list[tuple[str, object]] = []
        if self.at("{"):
            self.next()
            while not self.at("}"):
                fname = self._record_key_name()
                self.expect(":")
                fields.append((fname, self.pure_expr()))
                if self.at(","):
                    self.next()
            self.expect("}")
        return ApprovalExpr(capability, fields, line)

    def _postfix(self):
        node = self._primary()
        # Once an optional access (`?.`) is taken, only another `?.` may
        # follow: a plain `.field`/`(...)`/`[i]` applied to a possibly-None
        # result would not short-circuit (`a?.b.c` runs `.c` on None). We
        # reject that rather than emit wrong runtime behavior — chain with
        # `?.` (`a?.b?.c`) or unwrap the optional first.
        optional = False
        while True:
            if self.at("."):
                if optional:
                    raise self._optional_chain_error()
                self.next()
                node = ExprField(node, self._record_key_name(), node.line)
            elif self.at("?."):
                # `expr?.name` / `expr?.name(args)`: short-circuit on Opt-None.
                # Modelled as an ExprOptField / ExprOptCall so lowering can
                # emit a conditional and typing can flow Opt into inner types.
                self.next()
                name = self._record_key_name()
                if self.at("("):
                    self.next()
                    args = []
                    while not self.at(")"):
                        args.append(self.pure_expr())
                        if self.at(","):
                            self.next()
                    self.expect(")")
                    node = ExprOptCall(node, name, args, node.line)
                else:
                    node = ExprOptField(node, name, node.line)
                optional = True
            elif self.at("("):
                if optional:
                    raise self._optional_chain_error()
                self.next()
                args = []
                while not self.at(")"):
                    args.append(self.pure_expr())
                    # item 384: `f(k=v)` is a Python keyword argument — revl
                    # calls are positional. Redirect before the stray `=`
                    # reports `expected ), found '='`.
                    if self.at("="):
                        raise self.err(
                            self.peek().line,
                            "revl has no keyword arguments — `f(k=v)` is not a call",
                            hint="pass arguments positionally, e.g. `f(v)` "
                                 "(syntax-2.0 §3.1)",
                        )
                    if self.at(","):
                        self.next()
                self.expect(")")
                node = ExprCall(node, args, node.line)
            elif self.at("["):
                if optional:
                    raise self._optional_chain_error()
                self.next()
                index = self.pure_expr()
                # item 384: `xs[a:b]` is Python slice syntax — revl indexes a
                # single element and slices with a method. Redirect the `:`
                # before it reports `expected ], found ':'`.
                if self.at(":"):
                    raise self.err(
                        self.peek().line,
                        "revl has no slice syntax `xs[a:b]`",
                        hint="take a sublist with `xs.slice(a, b)`; `[i]` indexes "
                             "one element (docs/stdlib-2.0.md)",
                    )
                self.expect("]")
                node = ExprIndex(node, index, node.line)
            else:
                break
        return node

    def _optional_chain_error(self) -> RevlError:
        tok = self.peek()
        return self.err(
            tok.line,
            "an optional access `?.` can only be followed by another `?.` — "
            "a plain `.field`, call, or index after `?.` would not short-circuit",
            hint="chain with `?.` (`a?.b?.c`), or unwrap the optional first with "
                 "`match` or `??` before the next access",
        )

    def _endorse_expr(self) -> ExprEndorse:
        """`endorse[<origin>](<value>, reason = "...")` [`with <appr>`] — the
        scoped, reasoned declassifier (item 249, Slice C).

        The ambient single-argument `endorse(v)` of Slice A is superseded: it is
        refused here with a migration hint, so a downgrade is always scoped and
        reasoned. The `reason` string is mandatory (it lands in the audit's
        declassify record); an optional `with <appr>` threads an approval."""
        line = self.next().line  # consume `endorse`
        if not self.at("["):
            raise self.err(
                line,
                "the ambient `endorse(v)` is superseded — a declassification must "
                "name the taint class it downgrades and carry a reason",
                hint="write `endorse[<origin>](v, reason = \"...\")` (e.g. "
                     "`endorse[web](page, reason = \"operator-reviewed\")`), and "
                     "declare the slot on the enclosing `fn`/operation "
                     "(`endorse[web] fn ...`) (item 249, Slice C)")
        self.next()  # `[`
        origin = self.expect("ident", what="the taint class `endorse[<origin>]` "
                             "downgrades (e.g. `web`, `net`, `fs`)").value
        self.expect("]")
        self.expect("(", what="`(value, reason = \"...\")` after `endorse[<origin>]`")
        value = self.pure_expr()
        reason = None
        if self.at(","):
            self.next()
            self.expect("ident", "reason",
                        what="`reason = \"...\"` — the mandatory audit reason for "
                             "an `endorse` (item 249, Slice C)")
            self.expect("=")
            rtok = self.peek()
            if rtok.kind != "string":
                raise self.err(rtok.line,
                               f"`endorse` reason must be a string literal, found "
                               f"{rtok.value!r}",
                               hint="e.g. `reason = \"operator-reviewed template\"`")
            reason = self.next().value
        self.expect(")")
        approval = None
        if self.at("kw", "with"):
            self.next()
            approval = self.expect("ident", what="the `Approval[declassify.<origin>]` "
                                   "value to thread through `with` (item 249/246)").value
        if reason is None:
            raise self.err(
                line,
                "an `endorse` must carry a reason",
                hint="write `endorse[<origin>](v, reason = \"...\")` — the reason "
                     "is recorded on the audit's declassify surface (item 249)")
        return ExprEndorse(origin, value, reason, line, approval)

    def _hole_expr(self) -> ExprHole:
        """`hole` [`[` Type `]`] [StringLit] — docs/holes.md.

        The type rides in `[...]` rather than after a `:` for two reasons.
        `[]` is already revl's type-application bracket (`List[Row]`,
        §2), so `hole[Db]` reads as a type position on sight; and a `:`
        ascription would be genuinely ambiguous with the TS ternary the
        language admits verbatim (`c ? hole "x" : y` — §3.2). The message
        is a juxtaposed string literal, matching `test "name"`; nothing
        else in the grammar juxtaposes a string, so it cannot be misread.
        """
        line = self.expect("kw", "hole").line
        type_name = None
        if self.at("["):
            self.next()
            type_name = self.type_()
            self.expect("]")
        message = None
        if self.peek().kind == "string":
            message = self.next().value
        return ExprHole(message, type_name, line)

    def _match_expr(self) -> ExprMatch:
        """`match <expr> { arm ("," arm)* [","] "}"` — syntax-2.0 §3.3."""
        line = self.expect("kw", "match").line
        scrutinee = self.pure_expr()
        self.expect("{")
        arms: list = []
        while not self.at("}"):
            pattern, bind = self._match_pattern()
            self.expect("=>")
            if self.at("{") and self._block_arm_ahead():
                body: object = self._match_block_arm(self.peek().line)
            else:
                body = self.pure_expr()
            arms.append((pattern, bind, body))
            if self.at(","):
                self.next()
            else:
                break
        self.expect("}")
        return ExprMatch(scrutinee, arms, line)

    def _if_expr(self) -> ExprIf:
        """`if (cond) { then } else { otherwise }` in EXPRESSION position — a
        block-bodied conditional whose value is the taken branch's final
        expression (item 196). It is the block-bodied twin of the ternary
        `cond ? then : otherwise` and lowers to the very same ExprIf node, so
        both branches are required (an expression-if needs an `else`) and must
        agree in type, which the checker enforces on ExprIf exactly as it does
        for the ternary. Statement-position `if` (no `else`, side-effecting
        body) is dispatched in `fn_stmt`/`component_if` before `_primary` is
        ever reached, so it keeps its existing semantics untouched."""
        line = self.expect("kw", "if").line
        self.expect("(")
        cond = self.pure_expr()
        self.expect(")")
        then = self._if_branch_expr()
        if not self.at("kw", "else"):
            tok = self.peek()
            raise self.err(
                tok.line,
                f"an `if` used as an expression needs an `else`, found {tok.value!r}",
                hint="an expression must produce a value on every path; write "
                     "`if (c) { a } else { b }` (or use a statement `if` for a "
                     "side-effecting body)",
            )
        self.next()
        otherwise = self._if_branch_expr()
        return ExprIf(cond, then, otherwise, line)

    def _if_branch_expr(self):
        """A `{ expr }` branch of an expression-position `if`: one value
        expression wrapped in braces. Keeping the branch a single expression
        (not a statement block) is what makes the whole `if` carry the same
        node shape as a ternary operand, so no backend needs new emit support."""
        self.expect("{")
        self._skip_semis()
        value = self.pure_expr()
        self._skip_semis()
        self.expect("}")
        return value

    def _record_update_ahead(self) -> bool:
        """Current token is `{` — is this `{base | f = e, …}` (functional
        record update, docs/records.md §1) rather than a record literal?

        A record literal's top level can never contain a bare `|` (field
        values are bracket-balanced), so a depth-1 `|` before the matching
        `}` settles it."""
        i = self.pos + 1  # skip the `{`
        depth = 1
        while i < len(self.toks):
            kind = self.toks[i].kind
            if kind in ("{", "(", "["):
                depth += 1
            elif kind in ("}", ")", "]"):
                depth -= 1
                if depth == 0:
                    return False
            elif kind == "|" and depth == 1:
                return True
            elif kind == "eof":
                return False
            i += 1
        return False

    def _block_arm_ahead(self) -> bool:
        """Current token is `{` right after a match arm's `=>` — statement
        block (docs/records.md §4) or record value?

        The only `{...}` an arm body can otherwise be is a record: a record
        *literal* always opens `ident :` (or is the empty `{}`), and a record
        *update* opens `base | ...`. Anything else — a `let`/`var`/`if`/`while`/
        `for`/assignment, or a bare tail expression — is a statement block."""
        first = self.peek_ahead(1)  # token after the `{`
        if first.kind == "}":
            return False  # empty record literal
        if self._record_update_ahead():
            return False  # `{ base | f = e }`
        if first.kind == "ident" and self.peek_ahead(2).kind == ":":
            return False  # `{ field: value, ... }`
        return True

    def _match_block_arm(self, line: int):
        """`{ stmt* tail }` — a statement-block arm (docs/records.md §4).

        The block is parsed like a normal fn/block body: any fn-body statement
        may precede the trailing expression, whose value is the arm's value.
        `return` is rejected here — the arm yields its final expression, and
        lowering lambda-lifts the block into a helper fn where a `return` would
        silently mean something else (early return from the helper, not the
        enclosing function)."""
        self.expect("{")
        # C1 (item 379): the block is lambda-lifted into a helper fn at
        # lowering, so a `break`/`continue` targeting a loop *outside* the arm
        # would land in a loopless fn. Reset the loop-depth context to 0 for the
        # arm body so such a jump is refused at parse time (in the block-arm
        # voice); a loop written *inside* the arm restores a positive depth for
        # its own `break` (docs/design/379-break-continue.md).
        saved_depth, saved_in_arm = self._loop_depth, self._in_block_arm
        self._loop_depth, self._in_block_arm = 0, True
        stmts = []
        try:
            while True:
                self._skip_semis()
                if self.at("}"):
                    break
                stmts.append(self.fn_stmt())
        finally:
            self._loop_depth, self._in_block_arm = saved_depth, saved_in_arm
        self.expect("}")
        if not stmts:
            raise self.err(line,
                           "a match block arm must end in an expression (its "
                           "value) (docs/records.md §4)")
        for stmt in stmts:
            if isinstance(stmt, ReturnStmt):
                raise self.err(stmt.line,
                               "a match block arm yields its final expression, not "
                               "`return` (docs/records.md §4)")
        tail = stmts[-1]
        if not isinstance(tail, ExprStmt):
            raise self.err(getattr(tail, "line", line),
                           "a match block arm must end in an expression (its "
                           f"value), found `{tail.__class__.__name__}` "
                           "(docs/records.md §4)")
        return ExprBlockArm(stmts[:-1], tail.expr, line)

    def _match_pattern(self):
        tok = self.peek()
        if tok.kind != "ident":
            raise self.err(tok.line, f"expected a match pattern (case name or `_`), found {tok.value!r}")
        self.next()
        if tok.value == "_":
            return "_", None
        if not self.at("("):
            return tok.value, None
        self.next()
        bind = self.expect("ident").value
        self.expect(")")
        return tok.value, bind

    def _primary(self):
        tok = self.peek()
        if tok.kind in ("int", "float"):
            self.next()
            return ExprLit(tok.value, tok.line)
        if tok.kind == "string":
            self.next()
            return ExprLit(tok.value, tok.line)
        if tok.kind == "template":
            self.next()
            return Interp(self._parse_template_parts(
                tok.value, tok.line, getattr(tok, "interp_lines", None)), tok.line)
        if tok.kind == "kw" and tok.value in ("true", "false", "null"):
            self.next()
            return ExprLit({"true": True, "false": False, "null": None}[tok.value], tok.line)
        # item 384: a Python `lambda x: …` lexes as the identifier `lambda`
        # juxtaposed with a param name (or a bare `:`), a shape revl never has
        # (no two identifiers abut, and `:` cannot follow an expression here).
        # Redirect to the arrow `x => …` before the `:` reports the cryptic
        # `expected an expression, found ':'`. Guarded on the juxtaposition so
        # a value legitimately referenced as `lambda` (never followed by an
        # ident or `:` in expression position) is untouched.
        if (tok.kind == "ident" and tok.value == "lambda"
                and self.pos + 1 < len(self.toks)
                and self.peek_ahead(1).kind in ("ident", ":")):
            raise self.err(
                tok.line,
                "revl has no `lambda`",
                hint="an anonymous function is an arrow `x => …` "
                     "(e.g. `xs.map(x => x + 1)`) (syntax-2.0 §3.2)",
            )
        # item 249 Slice C: the scoped declassifier `endorse[<origin>](v, reason
        # = "...")`. `endorse` is an ident, intercepted before the plain
        # variable-reference path when it heads a `[` or `(` (its call/scope
        # forms); a bare `endorse` used as a value name is untouched.
        if (tok.kind == "ident" and tok.value == "endorse"
                and self.pos + 1 < len(self.toks)
                and self.peek_ahead(1).kind in ("[", "(")):
            return self._endorse_expr()
        if self._is_name_tok(tok):
            # item 158: a variable *reference* is a name position too — a param
            # (or record field) named with a contextual noun must be usable, and
            # none of the five nouns can lead an expression (their keyword roles
            # are all dispatched or `expect`ed before `_primary` is ever reached
            # for a leading token), so reading one here is unambiguous.
            self.next()
            if self.at("=>"):
                self.next()
                return ExprArrow([tok.value], self._arrow_body(), tok.line, [None])
            return ExprVar(tok.value, tok.line)
        if tok.kind == "kw" and tok.value == "hole":
            return self._hole_expr()
        if tok.kind == "kw" and tok.value == "config":
            # `config` is a keyword for the declaration block, but in pure
            # expression position it heads `config.<field>` access (component
            # effect blocks and guard conditions).
            self.next()
            return ExprVar(tok.value, tok.line)
        if tok.kind == "(":
            if self._arrow_params_ahead():
                self.next()
                params = []
                param_types: list = []
                while not self.at(")"):
                    params.append(self._name())
                    # `(v: Int) => ...` — an optional per-parameter annotation.
                    # It is what types an arrow that is *not* in checking
                    # position (docs/function-types.md).
                    if self.at(":"):
                        self.next()
                        param_types.append(self.type_())
                    else:
                        param_types.append(None)
                    if self.at(","):
                        self.next()
                self.expect(")")
                # item 75(a): `(v: Int): Int => …` — an optional return
                # annotation. `:` and not `->`, because `) -> T` is already the
                # tail of a function *type* and would put two readings of the
                # same tokens next to each other, while `:` already means "the
                # type of this named thing" at every other revl annotation site
                # (docs/function-types.md §2(c)). It is a full type, so `?`
                # binds to it: `(v: Int): Str? => …` returns `Opt[Str]`.
                returns = None
                if self.at(":"):
                    self.next()
                    returns = self.type_()
                self.expect("=>")
                return ExprArrow(params, self._arrow_body(), tok.line,
                                 param_types, returns)
            self.next()
            node = self.pure_expr()
            # item 384: `(a, b)` is a Python/JS tuple — revl has no tuple type.
            # (An arrow's `(x, y) => …` param list was already dispatched by
            # `_arrow_params_ahead`, so a comma here is a value tuple.) Redirect
            # to a named record instead of the cryptic `expected ), found ','`.
            if self.at(","):
                raise self.err(
                    self.peek().line,
                    "revl has no tuples — `(a, b)` is not a value",
                    hint="group values in a record with named fields, e.g. "
                         "`{ first: a, second: b }` (syntax-2.0 §2)",
                )
            self.expect(")")
            # mark the group so `??`/`&&`/`||` mixing checks treat it as
            # explicitly parenthesized (e.g. `(a ?? b) || c` is allowed)
            try:
                node._paren = True
            except AttributeError:
                pass
            return node
        if tok.kind == "{":
            if self._record_update_ahead():
                self.next()
                # The top-level `|` here separates base from updates; suppress
                # its reading as bitwise OR (item 366). A parenthesised `|`
                # inside the base is unaffected — `_bor` clears the flag on read.
                self._suppress_bor = True
                base = self.pure_expr()
                self._suppress_bor = False
                self.expect("|")
                updates = []
                while not self.at("}"):
                    fname = self._record_key_name()
                    self.expect("=")
                    updates.append((fname, self.pure_expr()))
                    if self.at(","):
                        self.next()
                self.expect("}")
                return ExprRecordUpdate(base, updates, tok.line)
            self.next()
            fields = []
            while not self.at("}"):
                # item 384: a string-keyed literal `{"k": v}` is a Python/JS
                # dict; revl records take bare identifier keys. Redirect to
                # ident keys or `Map` instead of `expected ident, found 'k'`.
                if self.at("string"):
                    raise self.err(
                        self.peek().line,
                        "revl records use identifier keys, not string keys "
                        "like `{\"k\": v}`",
                        hint="write `{ k: v }` with a bare-identifier key, or use "
                             "`Map.new()` for dynamic string keys (docs/records.md, "
                             "docs/stdlib-2.0.md)",
                    )
                fname = self._record_key_name()
                self.expect(":")
                fexpr = self.pure_expr()
                fields.append((fname, fexpr))
                if self.at(","):
                    self.next()
            self.expect("}")
            return ExprRecord(fields, tok.line)
        if tok.kind == "[":
            self.next()
            items = []
            while not self.at("]"):
                items.append(self.pure_expr())
                # item 383: `[x for x in xs]` is a comprehension — a shape revl
                # does not have. Without this the loop re-enters `pure_expr` on
                # the `for` keyword and reports the cryptic `expected an
                # expression, found 'for'`; redirect to the spelling that works.
                if self.at("kw", "for"):
                    raise self.err(
                        self.peek().line,
                        "revl has no list comprehensions",
                        hint="use `xs.map(x => …)` / `xs.filter(x => …)` "
                             "(with `use \"stdlib/list.rvl\"`), or a "
                             "`for (x of xs) { … }` loop that pushes onto a "
                             "`var` list")
                if self.at(","):
                    self.next()
            self.expect("]")
            return ExprList(items, tok.line)
        if tok.kind == "kw" and tok.value == "match":
            return self._match_expr()
        if tok.kind == "kw" and tok.value == "if":
            return self._if_expr()
        self._reject_incr_decr(tok)  # item 384 / syntax-2.0 §3.3
        raise self.err(tok.line, f"expected an expression, found {_found(tok)}")

    def _reject_foreign_keyword(self, tok) -> None:
        """item 384: a known-foreign statement/declaration keyword (`def`,
        `throw`, `elif`, `lambda`, `const`, `print`) lexes as an identifier and
        reaches a statement/declaration dispatch as an error. Redirect it to
        the revl spelling instead of the cryptic `expected a … found '<kw>'`."""
        if tok.kind == "ident":
            hit = _FOREIGN_STMT_KEYWORDS.get(tok.value)
            if hit is not None:
                raise self.err(tok.line, hit[0], hint=hit[1])

    def _reject_incr_decr(self, tok) -> None:
        """item 384 / syntax-2.0 §3.3: `i++` / `i--` lex as two adjacent
        `+`/`-` tokens — revl has no in/decrement, expressions are pure. This
        fires ONLY on the `_primary` error path, which no valid program
        reaches, so it is false-positive-free. `++` strands a `+` in operand
        position (`_unary` has no unary `+`), so the erroring token IS a `+`
        with a `+` on one side; postfix `--` is consumed as `x - (- <next>)`,
        so the erroring token sits just past a `- -` pair. Either way the
        author wanted mutation: redirect to the §3.3-promised `+= 1` / `-= 1`
        instead of the cryptic `expected an expression, found '+'`."""
        toks, i = self.toks, self.pos
        sign = None
        if tok.kind == "+" and (
                (i > 0 and toks[i - 1].kind == "+")
                or (i + 1 < len(toks) and toks[i + 1].kind == "+")):
            sign = "+"
        elif i >= 2 and toks[i - 1].kind == "-" and toks[i - 2].kind == "-":
            sign = "-"
        if sign is None:
            return
        word = "increment" if sign == "+" else "decrement"
        # postfix `--` errors on the token PAST the operator pair; point the
        # diagnostic back at the operator itself.
        line = toks[i - 1].line if sign == "-" else tok.line
        raise self.err(
            line,
            f"revl has no `{sign}{sign}` {word} operator — expressions are pure "
            "(syntax-2.0 §3.3)",
            hint=f"mutate a `var` with `{sign}= 1` (write `i {sign}= 1`), inside "
                 "a `while`/`for` loop body",
        )

    def _arrow_body(self):
        """The body of an arrow `=> …`. A closure body is a single pure
        *expression*; revl has no statement-block arrow, so a value returned
        by a closure is computed, never assigned into an enclosing cell.

        The one shape that reads as an *attempt* at reference capture —
        `(…) => { name = … }`, a closure writing a name bound in an enclosing
        scope — is refused here with an explicit diagnostic (roadmap item 129,
        docs/closures.md) instead of the incidental record-literal parse error
        (`{ name =` is not a record: records key with `:`, updates with `|`).

        revl closures capture strictly BY VALUE (syntax-2.0 §3.5): they
        snapshot the values they read. That is not an ergonomic choice — it is
        what keeps the value-semantic equality the derived LIFO teardown (G7)
        and no-residue containment (A8) rest on. An inverse the teardown
        accumulator holds closes over the *values* the forward effect used; a
        closure that could write a live mutable cell would let those values
        shift out from under the inverse, and the recovery-exactness proof
        would lose its subject. So there is no shared mutable environment to
        write through, and the write form is rejected rather than snapshotted."""
        if self.at("{"):
            nxt = self.peek_ahead(1)
            after = self.peek_ahead(2)
            compound = (after.kind in ("+", "-", "*", "/", "%")
                        and self.peek_ahead(3).kind == "=")
            if self._is_name_tok(nxt) and (after.kind == "=" or compound):
                raise self.err(
                    nxt.line,
                    f"a closure cannot assign to `{nxt.value}`: captures are "
                    "by value, not by reference (G6)",
                    hint="a revl closure snapshots the values it reads "
                         "(syntax-2.0 §3.5, docs/closures.md) — there is no "
                         "shared mutable cell to write through. Return the "
                         f"computed value, or mutate the `var` `{nxt.value}` in "
                         "the enclosing `fn` body, not inside the closure.",
                )
        return self.pure_expr()

    def _arrow_params_ahead(self) -> bool:
        """Current token is `(` — is this `(a, b) => …` / `(a: Int) => …`
        rather than a parenthesised expression?

        A parameter annotation can be an arbitrarily nested type (`(f: (Int)
        -> List[Str]) => …`), so the list is skipped by balancing brackets
        rather than by token shape; what settles it is the `=>` after the
        closing paren, which can follow nothing else. The first two tokens are
        still shape-checked so that a malformed `(a + b) => c` reports as a bad
        expression rather than as a bad parameter list.

        item 75(a): a return annotation may sit between the two, so `)` `:`
        `<type>` `=>` settles it as well. The type is read with the real
        `type_()` on a saved-and-restored position rather than scanned by token
        shape — a hand-rolled scan cannot bound itself (a ternary's
        `c ? (x) : (y)` is `)` `:` too, and any later `=>` in the statement
        would fool it), and `type_()` is greedy and cannot consume `=>`, so the
        lookahead terminates exactly where the annotation does."""
        i = self.pos
        if self.toks[i].kind != "(":
            return False
        head = self.toks[i + 1]
        if head.kind != ")" and not (
            self._is_name_tok(head) and self.toks[i + 2].kind in (",", ")", ":")
        ):
            return False
        depth = 0
        while i < len(self.toks):
            kind = self.toks[i].kind
            if kind in ("(", "["):
                depth += 1
            elif kind in (")", "]"):
                depth -= 1
                if depth == 0:
                    if self.toks[i + 1].kind == "=>":
                        return True
                    if self.toks[i + 1].kind != ":":
                        return False
                    return self._return_annotation_ahead(i + 2)
            elif kind == "eof":
                return False
            i += 1
        return False

    def _return_annotation_ahead(self, start: int) -> bool:
        """Does a complete type followed by `=>` start at token `start`?

        Speculative: the position is saved and restored, and a parse error in
        the candidate type means "not an arrow" rather than a diagnostic — the
        caller falls back to the parenthesised-expression reading, which
        reports its own."""
        saved = self.pos
        try:
            self.pos = start
            self.type_()
            return self.at("=>")
        except RevlError:
            return False
        finally:
            self.pos = saved

    def provide(self) -> ProvideStmt:
        line = self.expect("kw", "provide").line
        key = self._provision_key()
        self.expect("{")
        methods: list[ProvideMethod] = []
        while not self.at("}"):
            mline = self.peek().line
            async_ = False
            if self.at("kw", "async"):
                self.next()
                async_ = True
            if self.at("kw", "emission"):
                # repeated agent pain (findings-uxprobe R1): purity modifiers
                # died as a bare parser error with no hint
                tok = self.peek()
                raise self.err(
                    tok.line,
                    f"expected fn, found {tok.value!r}",
                    hint="provider methods are plain `fn` — emission-ness is "
                         "inherited from the service declaration (G4 upper "
                         "bound); write `fn <name>(...)`")
            self.expect("kw", "fn")
            mname = self.expect("ident").value
            self.expect("(")
            params: list[str] = []
            param_types: list = []
            while not self.at(")"):
                params.append(self._name())
                # optional `: Type` annotation — models write these on
                # autopilot from the `fn` stratum; accept and (later) check
                # them against the service signature (A6)
                if self.at(":"):
                    self.next()
                    param_types.append(self.type_())
                else:
                    param_types.append(None)
                if self.at(","):
                    self.next()
            self.expect(")")
            # optional `-> T` return annotation — models write the full `fn`
            # signature; accept and check it against the service (A6)
            returns = None
            if self.at("arrow"):
                self.next()
                returns = self.type_()
            if self.at("="):
                self.next()
                body = [ReturnStmt(self.pure_expr(), mline)]
            else:
                self.expect("{")
                body = []
                while True:
                    self._skip_semis()
                    if self.at("}"):
                        break
                    body.append(self.stmt(in_method=True, in_async_method=async_))
                self.expect("}")
            methods.append(ProvideMethod(mname, params, body, mline, async_=async_,
                                         param_types=param_types, returns=returns))
        self.expect("}")
        return ProvideStmt(key, methods, line)

    def expr(self):
        tok = self.peek()
        if tok.kind in ("int", "float"):
            self.next()
            base = Lit(tok.value, tok.line)
        elif tok.kind == "string":
            self.next()
            base = Lit(tok.value, tok.line)
        elif tok.kind == "template":
            self.next()
            base = Interp(self._parse_template_parts(
                tok.value, tok.line, getattr(tok, "interp_lines", None)), tok.line)
        elif tok.kind == "kw" and tok.value in ("true", "false", "null"):
            self.next()
            base = Lit({"true": True, "false": False, "null": None}[tok.value], tok.line)
        elif tok.kind == "ident" or (tok.kind == "kw" and tok.value == "config"):
            # `config` is a keyword for the declaration block, but in
            # expression position it heads `config.<field>` access
            self.next()
            base = Postfix(tok.value, [], tok.line)
        else:
            raise self.err(tok.line, f"expected an expression, found {_found(tok)}")

        while self.at("."):
            self.next()
            op_tok = self.expect("ident")
            args = None
            if self.at("("):
                self.next()
                args = []
                while not self.at(")"):
                    args.append(self.expr())
                    if self.at(","):
                        self.next()
                self.expect(")")
            if not isinstance(base, Postfix):
                raise self.err(op_tok.line, "method calls on literals are not supported in v0")
            base.ops.append(PostfixOp(op_tok.value, args, op_tok.line))
        return base


def _describe_expr(expr) -> str:
    if isinstance(expr, Postfix):
        return "`" + ".".join([expr.head] + [op.name for op in expr.ops]) + "`"
    if isinstance(expr, Lit):
        return repr(expr.value)
    path = _dotted_path(expr)
    if path:
        return f"`{path}`"
    if isinstance(expr, ExprLit):
        return repr(expr.value)
    return "the expression"


def missing_undo_refusal(head: str, declared: tuple[str, str] | None = None) -> tuple[str, str]:
    """The ONE rendering of G4's bare-acquisition refusal: `(message, hint)`.

    Two positions raise it and neither may drift from the other. The parser
    refuses at the point it can prove the acquisition is not a bare name
    (`effect Pool.open(url)`); `lower.py._lower_effect_step` refuses on the
    MERGED, post-import program, which is where a bare name's classification
    is finally known (item 315). So the text lives here, once, and both call
    it.

    `declared` is the half only the lowering can supply: the acquisition's
    callee IS a declared extern, and it DOES declare an inverse
    (`(classification, inverse_callee)`), which was rejected rather than
    absent. That distinction is item 420(d). Saying "effect has no `undo`"
    about `extern acquire fn open_h() -> H undo close_h(result)` denies the
    existence of something the author wrote two lines up and sends them
    looking for a missing declaration instead of at the rule that discarded
    it: only a `witnessed` extern's declared inverse is auto-registered by
    the teardown accumulator, so an `acquire` extern's is never replayed on
    either tier (`ext["undo"]` is read only by the item-243 witnessed
    emitters). The refusal names the rule and both fixes the author can
    enact (item 274), instead of a fact that is not true. It does NOT offer
    the generic wording's third escape: `emit` marks an `emission` crossing,
    and `emit open_h()` on an `acquire`-classified extern is itself refused
    ("`emit` on a fn expression, which is not declared `emission`"), so
    naming it here would be advice the author cannot take, which is exactly
    the failure 274 is about.

    The parser cannot supply `declared` and must not try: `use` imports
    resolve one file at a time, after parsing, so an imported extern's
    classification is unknown there. Its domain is exactly the shapes that
    can never BE a bare-name extern call, which is why the generic wording
    is the right one for every refusal it still raises."""
    spelling = head.strip("`")
    if declared is not None:
        classification, inverse = declared
        article = "an" if classification[:1].lower() in "aeiou" else "a"
        message = (
            f"effect has no site `undo`: {head} declares "
            f"`undo {inverse}(...)`, but {article} `{classification}` extern's "
            f"declared inverse is never replayed")
        hint = (
            f"spell the inverse at the site, where it is the teardown that "
            f"actually runs on abort: `effect {spelling}(...) undo "
            f"{inverse}(<the acquired handle>)`. To have the DECLARED inverse "
            f"be the one that replays, classify {head} `witnessed`, which "
            f"registers it on the `Ok` branch and requires the return be "
            f"`Result[Witness, Error]` "
            f"(docs/design/243-witnessed-externs.md, G4)")
        return message, hint
    return (
        f"effect has no `undo` and {head} is not pure",
        f"write `effect {spelling}(...) undo <expr>`, or mark the call `emit` "
        f"if it deliberately crosses the system boundary (G4)")


def _dotted_path(expr) -> str | None:
    """Render ExprCall/ExprField/ExprVar chains as `a.b.c` for diagnostics."""
    if isinstance(expr, ExprCall):
        return _dotted_path(expr.callee)
    if isinstance(expr, ExprField):
        target = _dotted_path(expr.target)
        return f"{target}.{expr.name}" if target else None
    if isinstance(expr, ExprVar):
        return expr.name
    return None


def parse_file(path: str) -> Program:
    import os

    with open(path, encoding="utf-8") as handle:
        program = Parser(handle.read(), path).parse()
    # provenance is recorded relative to the invocation cwd so IR documents
    # stay machine-independent when compiled from the project root
    source = os.path.relpath(path)
    for component in program.components:
        component.source = source
    for composition in program.compositions:
        composition.source = source
    for layer in program.layers:
        layer.source = source
    for decl in (*program.fn_decls, *program.externs, *program.services):
        program.decl_files[id(decl)] = source
    for fn in program.fn_decls:
        fn.source = source
    return program
